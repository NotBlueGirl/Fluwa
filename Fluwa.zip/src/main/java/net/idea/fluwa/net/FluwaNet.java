package net.idea.fluwa.net;

import net.idea.fluwa.Fluwa;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class FluwaNet {
    private static final String VER = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(new ResourceLocation(Fluwa.MODID, "main"), () -> VER, VER::equals, VER::equals);

    public static void register() {
        net.idea.fluwa.lighting.LightingObj.BROADCAST = b -> {
            var srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
            if (srv != null) toAllLarge(new Pkt(Pkt.S_LIGHTING, null, null, b));
        };
        CH.registerMessage(0, Pkt.class, Pkt::encode, Pkt::decode, Pkt::handle);
    }

    public static void toPlayer(ServerPlayer p, Pkt pkt) { CH.send(PacketDistributor.PLAYER.with(() -> p), pkt); }
    public static void toAll(Pkt pkt) { CH.send(PacketDistributor.ALL.noArg(), pkt); }
    public static void toServer(Pkt pkt) { CH.sendToServer(pkt); }

    // ---- large payloads (models): split into S_CHUNK packets, reassembled by ClientNet
    static final int CHUNK = 900_000;
    static final java.util.concurrent.atomic.AtomicInteger IDS = new java.util.concurrent.atomic.AtomicInteger(1);

    static java.util.List<Pkt> split(Pkt p) {
        if (p.data.length <= CHUNK) return java.util.List.of(p);
        int id = IDS.getAndIncrement(), total = (p.data.length + CHUNK - 1) / CHUNK;
        java.util.List<Pkt> l = new java.util.ArrayList<>();
        for (int i = 0; i < total; i++) {
            byte[] part = java.util.Arrays.copyOfRange(p.data, i * CHUNK, Math.min(p.data.length, (i + 1) * CHUNK));
            l.add(new Pkt(Pkt.S_CHUNK, i == 0 ? p.s : java.util.List.of(), new int[]{id, i, total, p.type}, part));
        }
        return l;
    }
    public static void toAllLarge(Pkt p) { for (Pkt x : split(p)) toAll(x); }
    public static void toPlayerLarge(ServerPlayer pl, Pkt p) { for (Pkt x : split(p)) toPlayer(pl, x); }
}
