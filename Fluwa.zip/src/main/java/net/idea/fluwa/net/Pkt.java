package net.idea.fluwa.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Supplier;

/** Generic Fluwa packet: type + strings + ints + optional binary payload. */
public class Pkt {
    // server -> client
    public static final int S_REMOTE = 1, S_SCRIPTS = 2, S_ZSPACE = 3, S_SCREEN = 4, S_STATE = 5, S_SKYBOX = 6, S_SOUND = 7, S_CONSOLE = 8, S_ZSTATUS = 9, S_NOCOLLIDE = 10, S_MODEL = 11,
            S_MODELPART = 12, S_CHUNK = 13, S_PROJ = 14, S_ZTREE = 15, S_ZPROPS = 16, S_ENTFLAG = 17, S_HALLU = 18,
            S_TDK = 19, S_WEDIT = 20, S_ZITEM = 21, S_LIGHTING = 22, S_TWEEN = 23, S_HITBOX = 24;
    // client -> server
    public static final int C_REMOTE = 101, C_ZREQUEST = 102, C_ZSAVE = 103, C_ZDELETE = 104, C_ZRELOAD = 105, C_ZRUN = 106,
            C_ZTREE = 107, C_ZPROPS = 108, C_ZSET = 109, C_ZINSERT = 110, C_ZACTION = 111, C_PROJ = 112,
            C_TDK = 113, C_WEDIT = 114, C_ZITEM = 115, C_MODELPARTS = 116;

    public final int type;
    public final List<String> s;
    public final int[] n;
    public final byte[] data;

    public Pkt(int type, List<String> s, int[] n, byte[] data) {
        this.type = type; this.s = s == null ? List.of() : s; this.n = n == null ? new int[0] : n; this.data = data == null ? new byte[0] : data;
    }
    public Pkt(int type, String... s) { this(type, Arrays.asList(s), null, null); }

    public String s(int i) { return i < s.size() ? s.get(i) : ""; }
    public int n(int i) { return i < n.length ? n[i] : 0; }

    public static void encode(Pkt p, FriendlyByteBuf b) {
        b.writeVarInt(p.type);
        b.writeVarInt(p.s.size());
        for (String x : p.s) b.writeByteArray(x.getBytes(StandardCharsets.UTF_8));
        b.writeVarIntArray(p.n);
        b.writeByteArray(p.data);
    }

    public static Pkt decode(FriendlyByteBuf b) {
        int t = b.readVarInt();
        int c = b.readVarInt();
        if (c < 0 || c > 100000) throw new IllegalArgumentException("bad packet");
        List<String> s = new ArrayList<>(c);
        for (int i = 0; i < c; i++) s.add(new String(b.readByteArray(), StandardCharsets.UTF_8));
        int[] n = b.readVarIntArray(1024);
        byte[] d = b.readByteArray();
        return new Pkt(t, s, n, d);
    }

    public static void handle(Pkt p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        if (p.type >= 100) {
            var sender = c.getSender();
            if (sender != null) c.enqueueWork(() -> net.idea.fluwa.server.ServerNet.handle(p, sender));
        } else {
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> net.idea.fluwa.client.ClientNet.handle(p)));
        }
        c.setPacketHandled(true);
    }
}
