package net.idea.fluwa.mixin;

import net.idea.fluwa.api.Colliders;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.ArrayList;
import java.util.List;

/** adds Fluwa colliders (moving tween blocks, solid BlockEntities) to the shapes an entity collides with */
@Mixin(Entity.class)
public abstract class EntityCollideMixin {
    @ModifyVariable(method = "collide", at = @At("STORE"), ordinal = 0)
    private List<VoxelShape> fluwa$extraColliders(List<VoxelShape> list, Vec3 move) {
        if (Colliders.SOURCES.isEmpty()) return list;
        Entity self = (Entity) (Object) this;
        AABB box = self.getBoundingBox().expandTowards(move).inflate(0.5);
        List<VoxelShape> extra = new ArrayList<>();
        Colliders.collect(self.level(), self, box, extra);
        if (extra.isEmpty()) return list;
        List<VoxelShape> out = new ArrayList<>(list.size() + extra.size());
        out.addAll(list);
        out.addAll(extra);
        return out;
    }
}
