package net.idea.fluwa.mixin;

import net.idea.fluwa.client.ModelParts;
import net.minecraft.client.model.geom.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** v0.5.2: remembers the name of every model part ("head", "right_hind_leg", ...) so any entity model can be edited part by part */
@Mixin(ModelPart.class)
public abstract class ModelPartMixin {
    @Inject(method = "getChild", at = @At("RETURN"))
    private void fluwa$name(String name, CallbackInfoReturnable<ModelPart> cir) {
        ModelPart p = cir.getReturnValue();
        if (p != null) ModelParts.NAMES.put(p, name);
    }
}
