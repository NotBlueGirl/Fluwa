package net.idea.fluwa.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.idea.fluwa.client.ClientModels;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * v0.5.2 model part transforms (ModelPart.Offset / Rotation / Scale, World Editor → Entities):
 * the whole-model transform wraps the renderer, part transforms are applied after setupAnim (right before the model is drawn).
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("HEAD"))
    private void fluwa$wholeIn(LivingEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light, CallbackInfo ci) {
        ps.pushPose();
        try { ClientModels.applyWhole(e, ps); } catch (RuntimeException ignored) {}
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("RETURN"))
    private void fluwa$wholeOut(LivingEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light, CallbackInfo ci) {
        ps.popPose();
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/EntityModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V"))
    private void fluwa$partsIn(LivingEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light, CallbackInfo ci) {
        try { ClientModels.applyParts(e, ((LivingEntityRenderer<?, ?>) (Object) this).getModel()); } catch (RuntimeException ignored) {}
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/EntityModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V", shift = At.Shift.AFTER))
    private void fluwa$partsOut(LivingEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light, CallbackInfo ci) {
        ClientModels.restoreParts();
    }
}
