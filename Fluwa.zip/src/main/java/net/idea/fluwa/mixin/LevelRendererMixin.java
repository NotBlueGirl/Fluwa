package net.idea.fluwa.mixin;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import net.idea.fluwa.client.LightingClient;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * v0.5 Lighting / Sky / Clouds hooks into the vanilla sky renderer. When a custom sun, moon or star setup is active the
 * vanilla ones are skipped and LightingClient draws its own (AFTER_SKY).
 */
@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
    // ---------------------------------------------------------------- sun / moon / stars
    @Redirect(method = "renderSky", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/BufferUploader;drawWithShader(Lcom/mojang/blaze3d/vertex/BufferBuilder$RenderedBuffer;)V", ordinal = 1))
    private void fluwa$sun(BufferBuilder.RenderedBuffer b) {
        if (LightingClient.customCelestial()) b.release(); else BufferUploader.drawWithShader(b);
    }

    @Redirect(method = "renderSky", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/BufferUploader;drawWithShader(Lcom/mojang/blaze3d/vertex/BufferBuilder$RenderedBuffer;)V", ordinal = 2))
    private void fluwa$moon(BufferBuilder.RenderedBuffer b) {
        if (LightingClient.customCelestial()) b.release(); else BufferUploader.drawWithShader(b);
    }

    @Redirect(method = "renderSky", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;getStarBrightness(F)F"))
    private float fluwa$stars(ClientLevel level, float pt) {
        return LightingClient.customCelestial() ? 0f : level.getStarBrightness(pt);
    }

    // ---------------------------------------------------------------- clouds
    @Inject(method = "renderClouds", at = @At("HEAD"), cancellable = true)
    private void fluwa$cloudsOff(CallbackInfo ci) {
        if (LightingClient.cloudsDisabled()) ci.cancel();
    }

    @Redirect(method = "renderClouds", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/DimensionSpecialEffects;getCloudHeight()F"))
    private float fluwa$cloudHeight(DimensionSpecialEffects fx) {
        return LightingClient.cloudHeight(fx.getCloudHeight());
    }

    @ModifyConstant(method = "renderClouds", constant = @Constant(floatValue = 0.03f))
    private float fluwa$cloudSpeed(float v) { return LightingClient.cloudSpeed(v); }

    @Redirect(method = "renderClouds", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;getCloudColor(F)Lnet/minecraft/world/phys/Vec3;"))
    private Vec3 fluwa$cloudColor(ClientLevel level, float pt) {
        return LightingClient.cloudColor(level.getCloudColor(pt));
    }

    @ModifyArg(method = "renderClouds", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;setShaderTexture(ILnet/minecraft/resources/ResourceLocation;)V"), index = 1)
    private ResourceLocation fluwa$cloudTexture(ResourceLocation rl) { return LightingClient.cloudTexture(rl); }

    @Inject(method = "renderClouds", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/VertexBuffer;drawWithShader(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lnet/minecraft/client/renderer/ShaderInstance;)V"))
    private void fluwa$cloudAlpha(CallbackInfo ci) {
        float a = LightingClient.cloudAlpha();
        if (a != 1) com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1, 1, 1, a);
    }

    @Inject(method = "renderClouds", at = @At("RETURN"))
    private void fluwa$cloudReset(CallbackInfo ci) {
        if (LightingClient.cloudAlpha() != 1) com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1, 1, 1, 1);
    }
}
