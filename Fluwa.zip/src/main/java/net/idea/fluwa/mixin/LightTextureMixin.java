package net.idea.fluwa.mixin;

import com.mojang.blaze3d.platform.NativeImage;
import net.idea.fluwa.client.LightingClient;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** v0.5 Lighting: Brightness, Ambient, OutdoorAmbient, ColorShift_*, GlobalShadows, ShadowSoftness applied to the lightmap */
@Mixin(LightTexture.class)
public abstract class LightTextureMixin {
    @Shadow @Final private NativeImage lightPixels;

    @Inject(method = "updateLightTexture", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/texture/DynamicTexture;upload()V"))
    private void fluwa$lighting(float partialTicks, CallbackInfo ci) {
        try { LightingClient.lightmap(lightPixels); } catch (RuntimeException ignored) {}
    }
}
