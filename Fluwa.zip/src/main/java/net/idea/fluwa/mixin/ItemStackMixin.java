package net.idea.fluwa.mixin;

import net.idea.fluwa.api.ItemObj;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Item.MaxStack / MaxDurability / Rarity / CanDamage overrides stored in the stack NBT ("fluwa" compound) */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @Inject(method = "getMaxStackSize", at = @At("HEAD"), cancellable = true)
    private void fluwa$maxStack(CallbackInfoReturnable<Integer> cir) {
        int m = ItemObj.maxStack((ItemStack) (Object) this);
        if (m > 0) cir.setReturnValue(m);
    }

    @Inject(method = "getMaxDamage", at = @At("HEAD"), cancellable = true)
    private void fluwa$maxDamage(CallbackInfoReturnable<Integer> cir) {
        int m = ItemObj.maxDur((ItemStack) (Object) this);
        if (m >= 0) cir.setReturnValue(m);
    }

    @Inject(method = "isDamageableItem", at = @At("HEAD"), cancellable = true)
    private void fluwa$damageable(CallbackInfoReturnable<Boolean> cir) {
        ItemStack s = (ItemStack) (Object) this;
        int m = ItemObj.maxDur(s);
        if (m >= 0) cir.setReturnValue(m > 0 && !s.isEmpty() && (s.getTag() == null || !s.getTag().getBoolean("Unbreakable")));
    }

    @Inject(method = "getRarity", at = @At("HEAD"), cancellable = true)
    private void fluwa$rarity(CallbackInfoReturnable<Rarity> cir) {
        Rarity r = ItemObj.rarity((ItemStack) (Object) this);
        if (r != null) cir.setReturnValue(r);
    }

    @Inject(method = "hurt(ILnet/minecraft/util/RandomSource;Lnet/minecraft/server/level/ServerPlayer;)Z", at = @At("HEAD"), cancellable = true)
    private void fluwa$hurt(int amount, net.minecraft.util.RandomSource rnd, net.minecraft.server.level.ServerPlayer sp, CallbackInfoReturnable<Boolean> cir) {
        ItemStack s = (ItemStack) (Object) this;
        if (!ItemObj.flag(s, "CanDamage")) { cir.setReturnValue(false); return; }
        net.idea.fluwa.server.ItemEvents.damaged(s, amount);
    }
}
