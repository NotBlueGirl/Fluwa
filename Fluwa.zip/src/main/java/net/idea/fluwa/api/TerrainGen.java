package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.synth.ImprovedNoise;
import org.luaj.vm2.*;
import com.google.gson.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.file.*;
import java.util.*;

/**
 * getAccess("TerrainGenerator"): noise + heightmap terrain (runtime), biomes (runtime),
 * and new / edited dimensions & world generation types (datapack "fluwa_generated", applied after a world restart).
 */
public class TerrainGen extends LObj {
    public TerrainGen() { super("Service"); name = "TerrainGenerator"; }

    static double noise(double x, double z, double scale, long seed, int octaves) {
        ImprovedNoise n = new ImprovedNoise(RandomSource.create(seed));
        double v = 0, amp = 1, freq = 1 / Math.max(1e-6, scale), norm = 0;
        for (int i = 0; i < octaves; i++) { v += n.noise(x * freq, 0, z * freq) * amp; norm += amp; amp *= 0.5; freq *= 2; }
        return v / norm;
    }

    /** settings: {seed, scale=48, amplitude=12, base=64, octaves=4, surface="grass_block", under="dirt", deep="stone", depth=3, water=nil, waterBlock="water"} */
    static LuaValue generate(DimensionObj d, Vec3L a, Vec3L b, LuaValue st) {
        Level l = d.level(); d.checkWrite();
        LuaValue s = st.istable() ? st : new LuaTable();
        long seed = (long) s.get("seed").optdouble(l instanceof net.minecraft.server.level.ServerLevel sl ? sl.getSeed() : 0);
        double scale = s.get("scale").optdouble(48), ampl = s.get("amplitude").optdouble(12);
        int base = s.get("base").optint(64), oct = s.get("octaves").optint(4), depth = s.get("depth").optint(3);
        BlockState top = Conv.block(s.get("surface").optjstring("grass_block")), under = Conv.block(s.get("under").optjstring("dirt")),
                deep = Conv.block(s.get("deep").optjstring("stone")), air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        LuaValue wv = s.get("water");
        BlockState water = Conv.block(s.get("waterBlock").optjstring("water"));
        BlockPos mn = Conv.min(a, b), mx = Conv.max(a, b);
        Conv.checkVolume((long) (mx.getX() - mn.getX() + 1) * (mx.getY() - mn.getY() + 1) * (mx.getZ() - mn.getZ() + 1));
        ImprovedNoise n = new ImprovedNoise(RandomSource.create(seed));
        int count = 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int x = mn.getX(); x <= mx.getX(); x++) for (int z = mn.getZ(); z <= mx.getZ(); z++) {
            double v = 0, am = 1, fr = 1 / scale, norm = 0;
            for (int i = 0; i < oct; i++) { v += n.noise(x * fr, 0, z * fr) * am; norm += am; am *= 0.5; fr *= 2; }
            int h = base + (int) Math.round(v / norm * ampl);
            for (int y = mn.getY(); y <= mx.getY(); y++) {
                BlockState bs = y > h ? (!wv.isnil() && y <= wv.toint() ? water : air) : y == h ? top : y > h - depth ? under : deep;
                l.setBlock(p.set(x, y, z), bs, 2);
                count++;
            }
        }
        return valueOf(count);
    }


    // ================================================================ 0.2: dimensions / generation types
    static final String PACK = "fluwa_generated";
    static final List<String> PRESETS = List.of("overworld", "nether", "end", "amplified", "large_biomes", "caves", "floating_islands");

    static MinecraftServer srv() {
        MinecraftServer s = GameRuntime.cur().server();
        if (s == null) throw new LuaError("TerrainGenerator dimension functions are Server-Side only");
        return s;
    }

    static Path packDir() { return srv().getWorldPath(LevelResource.DATAPACK_DIR).resolve(PACK); }

    static String[] id(String n) {
        String id = n.toLowerCase(Locale.ROOT).trim();
        if (!id.contains(":")) id = "fluwa:" + id;
        if (!id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")) throw new LuaError("Bad dimension name '" + n + "' (use a-z 0-9 _ . - /)");
        return id.split(":", 2);
    }

    /** read a setting by any of the given names (Preset / preset) */
    static LuaValue opt(LuaValue s, String... names) {
        if (!s.istable()) return LuaValue.NIL;
        for (String n : names) { LuaValue v = s.get(n); if (!v.isnil()) return v; }
        return LuaValue.NIL;
    }

    static JsonObject generator(LuaValue s) {
        String type = opt(s, "Type", "type").optjstring("noise").toLowerCase(Locale.ROOT);
        String biome = opt(s, "Biome", "biome").optjstring(null);
        JsonObject g = new JsonObject();
        switch (type) {
            case "flat", "void" -> {
                g.addProperty("type", "minecraft:flat");
                JsonObject st = new JsonObject();
                st.addProperty("biome", biome != null ? biome : type.equals("void") ? "minecraft:the_void" : "minecraft:plains");
                st.addProperty("lakes", false);
                st.addProperty("features", opt(s, "Features", "features").optboolean(false));
                JsonArray layers = new JsonArray();
                LuaValue ls = opt(s, "Layers", "layers");
                if (type.equals("flat") && ls.istable()) for (int i = 1; i <= ls.length(); i++) {
                    LuaValue l = ls.get(i);
                    JsonObject o = new JsonObject();
                    String blk = (l.istable() ? l.get(1).optjstring(l.get("block").optjstring("minecraft:stone")) : l.tojstring());
                    o.addProperty("block", blk.contains(":") ? blk : "minecraft:" + blk);
                    o.addProperty("height", l.istable() ? l.get(2).optint(l.get("height").optint(1)) : 1);
                    layers.add(o);
                } else if (type.equals("flat")) {
                    for (String[] d : new String[][]{{"minecraft:bedrock", "1"}, {"minecraft:dirt", "2"}, {"minecraft:grass_block", "1"}}) {
                        JsonObject o = new JsonObject(); o.addProperty("block", d[0]); o.addProperty("height", Integer.parseInt(d[1])); layers.add(o);
                    }
                }
                st.add("layers", layers);
                st.add("structure_overrides", new JsonArray());
                g.add("settings", st);
            }
            case "noise" -> {
                String preset = opt(s, "Preset", "preset").optjstring("overworld").toLowerCase(Locale.ROOT).replace("minecraft:", "");
                if (!PRESETS.contains(preset)) throw new LuaError("Unknown preset '" + preset + "'. Presets: " + String.join(", ", PRESETS));
                g.addProperty("type", "minecraft:noise");
                g.addProperty("settings", "minecraft:" + preset);
                JsonObject bs = new JsonObject();
                if (biome != null) { bs.addProperty("type", "minecraft:fixed"); bs.addProperty("biome", biome.contains(":") ? biome : "minecraft:" + biome); }
                else if (preset.equals("end")) bs.addProperty("type", "minecraft:the_end");
                else { bs.addProperty("type", "minecraft:multi_noise"); bs.addProperty("preset", preset.equals("nether") ? "minecraft:nether" : "minecraft:overworld"); }
                g.add("biome_source", bs);
            }
            default -> throw new LuaError("Unknown generation Type '" + type + "' (noise, flat, void)");
        }
        return g;
    }

    static JsonObject dimType(LuaValue s) {
        JsonObject t = new JsonObject();
        boolean nether = "nether".equals(opt(s, "Preset", "preset").optjstring("").replace("minecraft:", ""));
        t.addProperty("ultrawarm", opt(s, "Ultrawarm", "ultrawarm").optboolean(nether));
        t.addProperty("natural", opt(s, "Natural", "natural").optboolean(!nether));
        t.addProperty("piglin_safe", opt(s, "PiglinSafe", "piglin_safe").optboolean(nether));
        t.addProperty("respawn_anchor_works", nether);
        t.addProperty("bed_works", opt(s, "BedWorks", "bed_works").optboolean(!nether));
        t.addProperty("has_raids", opt(s, "HasRaids", "has_raids").optboolean(!nether));
        t.addProperty("has_skylight", opt(s, "HasSkylight", "has_skylight").optboolean(!nether));
        t.addProperty("has_ceiling", opt(s, "HasCeiling", "has_ceiling").optboolean(nether));
        t.addProperty("coordinate_scale", opt(s, "CoordinateScale", "coordinate_scale").optdouble(nether ? 8 : 1));
        t.addProperty("ambient_light", opt(s, "AmbientLight", "ambient_light").optdouble(nether ? 0.1 : 0));
        LuaValue ft = opt(s, "FixedTime", "fixed_time");
        if (!ft.isnil()) t.addProperty("fixed_time", ft.checklong());
        int minY = opt(s, "MinY", "min_y").optint(nether ? 0 : -64), height = opt(s, "Height", "height").optint(nether ? 256 : 384);
        if (minY % 16 != 0 || height % 16 != 0 || height < 16 || height > 4064) throw new LuaError("MinY and Height must be multiples of 16 (Height 16..4064)");
        t.addProperty("min_y", minY);
        t.addProperty("height", height);
        t.addProperty("logical_height", Math.min(height, opt(s, "LogicalHeight", "logical_height").optint(nether ? 128 : height)));
        String eff = opt(s, "Effects", "effects").optjstring(nether ? "minecraft:the_nether" : "minecraft:overworld");
        t.addProperty("effects", eff.contains(":") ? eff : "minecraft:" + eff);
        t.addProperty("infiniburn", nether ? "#minecraft:infiniburn_nether" : "#minecraft:infiniburn_overworld");
        t.addProperty("monster_spawn_light_level", 0);
        t.addProperty("monster_spawn_block_light_limit", 0);
        return t;
    }

    static void writeJson(Path p, JsonElement e) {
        try { Files.createDirectories(p.getParent()); Files.writeString(p, new GsonBuilder().setPrettyPrinting().create().toJson(e)); }
        catch (java.io.IOException ex) { throw new LuaError("Can't write " + p + ": " + ex.getMessage()); }
    }

    static void ensurePack() {
        Path mc = packDir().resolve("pack.mcmeta");
        if (Files.exists(mc)) return;
        JsonObject o = new JsonObject(), pk = new JsonObject();
        pk.addProperty("pack_format", 15);
        pk.addProperty("description", "Dimensions created by Fluwa TerrainGenerator");
        o.add("pack", pk);
        writeJson(mc, o);
    }

    /** create (or overwrite) a dimension in the generated datapack. Returns info table. */
    public static LuaValue createDimension(String name, LuaValue s) {
        String[] id = id(name);
        ensurePack();
        JsonObject dim = new JsonObject();
        String typeRef = opt(s, "DimensionType", "dimension_type").optjstring(null);
        if (typeRef != null) dim.addProperty("type", typeRef.contains(":") ? typeRef : "minecraft:" + typeRef);
        else {
            dim.addProperty("type", id[0] + ":" + id[1]);
            writeJson(packDir().resolve("data/" + id[0] + "/dimension_type/" + id[1] + ".json"), dimType(s));
        }
        dim.add("generator", generator(s));
        Path f = packDir().resolve("data/" + id[0] + "/dimension/" + id[1] + ".json");
        writeJson(f, dim);
        boolean loaded = GameRuntime.cur().dimByName(id[0] + ":" + id[1]) != null;
        LuaTable r = new LuaTable();
        r.set("Id", id[0] + ":" + id[1]);
        r.set("File", f.toString());
        r.set("Loaded", LuaValue.valueOf(loaded));
        r.set("RequiresRestart", LuaValue.TRUE);
        GameRuntime.cur().output(0, "[TerrainGenerator] " + (loaded ? "Updated " : "Created ") + id[0] + ":" + id[1] + " - restart the world/server to apply"
                + (loaded ? " (only new chunks use the new generator)" : ""));
        return r;
    }

    static {
        reg(TerrainGen.class, "CreateDimension", (s, a) -> createDimension(a.checkjstring(1), a.arg(2)));
        reg(TerrainGen.class, "EditDimension", (s, a) -> createDimension(a.checkjstring(1), a.arg(2)));
        reg(TerrainGen.class, "DeleteDimension", (s, a) -> {
            String[] id = id(a.checkjstring(1));
            boolean any = false;
            for (String k : new String[]{"dimension", "dimension_type"}) {
                try { any |= Files.deleteIfExists(packDir().resolve("data/" + id[0] + "/" + k + "/" + id[1] + ".json")); }
                catch (java.io.IOException e) { throw new LuaError(e.getMessage()); }
            }
            return LuaValue.valueOf(any); });
        reg(TerrainGen.class, "ListDimensions", (s, a) -> {
            LuaTable loaded = new LuaTable(), pending = new LuaTable();
            for (var l : srv().getAllLevels()) loaded.insert(0, LuaValue.valueOf(l.dimension().location().toString()));
            Path data = packDir().resolve("data");
            if (Files.isDirectory(data)) try (var st = Files.walk(data)) {
                st.filter(p -> p.getParent().getFileName().toString().equals("dimension") && p.toString().endsWith(".json")).forEach(p -> {
                    String ns = data.relativize(p).getName(0).toString();
                    String path = p.getParent().relativize(p).toString().replace('\\', '/').replaceAll("\\.json$", "");
                    pending.insert(0, LuaValue.valueOf(ns + ":" + path));
                });
            } catch (java.io.IOException ignored) {}
            LuaTable r = new LuaTable(); r.set("Loaded", loaded); r.set("Generated", pending); return r; });
        reg(TerrainGen.class, "Presets", (s, a) -> { LuaTable t = new LuaTable(); for (String p : PRESETS) t.insert(0, LuaValue.valueOf(p)); return t; });
        // runtime biome editing (like /fillbiome)
        reg(TerrainGen.class, "SetBiome", (s, a) -> {
            DimensionObj d = checkObj(a.arg1(), DimensionObj.class);
            Vec3L p1 = Vec3L.check(a.arg(2)), p2 = Vec3L.check(a.arg(3));
            String biome = a.checkjstring(4);
            if (!biome.contains(":")) biome = "minecraft:" + biome;
            BlockPos mn = Conv.min(p1, p2), mx = Conv.max(p1, p2);
            var src = srv().createCommandSourceStack().withLevel((net.minecraft.server.level.ServerLevel) d.level()).withSuppressedOutput().withPermission(4);
            int r = srv().getCommands().performPrefixedCommand(src, String.format("fillbiome %d %d %d %d %d %d %s",
                    mn.getX(), mn.getY(), mn.getZ(), mx.getX(), mx.getY(), mx.getZ(), biome));
            return LuaValue.valueOf(r > 0); });
        reg(TerrainGen.class, "GetBiome", (s, a) -> {
            DimensionObj d = checkObj(a.arg1(), DimensionObj.class);
            var h = d.level().getBiome(Vec3L.check(a.arg(2)).pos());
            return LuaValue.valueOf(h.unwrapKey().map(k -> k.location().toString()).orElse("unknown")); });
    }

    /** Instance:new("Dimension") - set properties, then :Create() or Parent = World.Dimensions */
    public static final class Builder extends LObj {
        final LuaTable props = new LuaTable();
        public Builder() { super("DimensionBuilder"); name = "NewDimension"; }
        @Override protected LuaValue getProp(String k) {
            LuaValue v = props.get(k);
            return v.isnil() ? super.getProp(k) : v;
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            if (k.equals("Name") || k.equals("Parent")) return super.setProp(k, v);
            props.set(k, v); return true;
        }
        @Override public void setParent(LObj p) {
            if (p != null && "Dimensions".equals(p.getName())) { createDimension(name, props); return; }
            super.setParent(p);
        }
        static { reg(Builder.class, "Create", (s, a) -> createDimension(((Builder) s).name, ((Builder) s).props)); }
    }
    static {
        reg(TerrainGen.class, "Noise", (s, a) -> valueOf(noise(a.checkdouble(1), a.checkdouble(2), a.optdouble(3, 48), (long) a.optdouble(4, 0), a.optint(5, 1))));
        reg(TerrainGen.class, "Generate", (s, a) -> generate(checkObj(a.arg1(), DimensionObj.class), Vec3L.check(a.arg(2)), Vec3L.check(a.arg(3)), a.arg(4)));
    }
}
