package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.idea.fluwa.mesh.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.luaj.vm2.*;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.function.Consumer;

/** getAccess("Projector") - import / create / edit / place 3D models (.obj .gltf .glb .fbx). */
public final class Projector extends LObj {
    /** client hooks: local rendering sink for client-runtime objects and GUI opening */
    public static Consumer<Pkt> CLIENT_SINK;
    public static Consumer<String> CLIENT_OPEN_GUI;

    /** per-runtime registry of live objects + replication ticker */
    public static final class Reg {
        final FluwaRuntime rt;
        public final Map<Integer, ProjectorObj> objs = new LinkedHashMap<>();
        Reg(FluwaRuntime rt) { this.rt = rt; }

        void send(Pkt p) {
            if (rt.server) { if (ScriptManager().isPresent()) FluwaNet.toAll(p); }
            else if (CLIENT_SINK != null) CLIENT_SINK.accept(p);
        }
        void sendLarge(Pkt p) {
            if (rt.server) { if (ScriptManager().isPresent()) FluwaNet.toAllLarge(p); }
            else if (CLIENT_SINK != null) CLIENT_SINK.accept(p);
        }
        static Optional<Object> ScriptManager() { return Optional.ofNullable(net.idea.fluwa.server.ScriptManager.rt); }

        void tick() {
            for (ProjectorObj o : new ArrayList<>(objs.values())) {
                if (o.destroyed) continue;
                o.tickAnim();
                if (!o.inWorld() && !o.sentAdd && !o.inViewport()) continue;
                o.flush(this);
                if (rt.server && o.inWorld() && (o.collision || o.listens("E_Touched") || o.listens("E_TouchEnded"))) touch(o);
            }
        }

        void touch(ProjectorObj o) {
            String d = o.worldDim();
            if (!(rt instanceof GameRuntime g) || d == null) return;
            ServerLevel lvl = null;
            for (var l : g.levels()) if (l.dimension().location().toString().equals(d) && l instanceof ServerLevel s) lvl = s;
            if (lvl == null) return;
            double[] b = o.worldBounds();
            AABB box = new AABB(b[0], b[1], b[2], b[3], b[4], b[5]);
            if (box.getSize() > 512) return;
            Set<Integer> now = new HashSet<>();
            for (Entity e : lvl.getEntities((Entity) null, box.inflate(0.05), e -> e != null && e.isAlive())) {
                if (o.attachEnt != null && o.attachEnt.raw() == e) continue;
                now.add(e.getId());
                if (!o.touching.contains(e.getId())) o.fire("E_Touched", g.wrapEntity(e));
                if (o.collision) collide(e, box);
            }
            for (Integer id : o.touching) if (!now.contains(id)) { Entity e = lvl.getEntity(id); if (e != null) o.fire("E_TouchEnded", g.wrapEntity(e)); }
            o.touching.clear(); o.touching.addAll(now);
        }

        /** very simple AABB collision: stand on top, otherwise pushed out sideways */
        static void collide(Entity e, AABB box) {
            AABB eb = e.getBoundingBox();
            if (!eb.intersects(box)) return;
            double up = box.maxY - eb.minY;
            if (up >= 0 && up < 0.75 && e.getDeltaMovement().y <= 0.05) {
                e.setPos(e.getX(), box.maxY, e.getZ());
                e.setDeltaMovement(e.getDeltaMovement().multiply(1, 0, 1)); e.setOnGround(true); e.fallDistance = 0; e.hurtMarked = true;
                if (e instanceof ServerPlayer sp) sp.connection.teleport(e.getX(), box.maxY, e.getZ(), e.getYRot(), e.getXRot());
                return;
            }
            double px1 = box.maxX - eb.minX, px2 = eb.maxX - box.minX, pz1 = box.maxZ - eb.minZ, pz2 = eb.maxZ - box.minZ;
            double m = Math.min(Math.min(px1, px2), Math.min(pz1, pz2));
            Vec3 push = m == px1 ? new Vec3(px1, 0, 0) : m == px2 ? new Vec3(-px2, 0, 0) : m == pz1 ? new Vec3(0, 0, pz1) : new Vec3(0, 0, -pz2);
            e.setPos(e.getX() + push.x, e.getY(), e.getZ() + push.z);
            e.hurtMarked = true;
            if (e instanceof ServerPlayer sp) sp.connection.teleport(e.getX(), e.getY(), e.getZ(), e.getYRot(), e.getXRot());
        }
    }

    public static Reg reg(FluwaRuntime rt) {
        if (rt == null) rt = FluwaRuntime.current();
        FluwaRuntime r = rt;
        return (Reg) r.state.computeIfAbsent("projector", k -> {
            Reg g = new Reg(r);
            r.tickers.add(g::tick);
            r.onClose(() -> { if (!r.server && CLIENT_SINK != null) CLIENT_SINK.accept(new Pkt(Pkt.S_PROJ, List.of("clear"), new int[]{-1}, null));
                else if (r.server) for (ProjectorObj o : g.objs.values()) g.send(new Pkt(Pkt.S_PROJ, List.of("del"), new int[]{o.id}, null)); });
            return g;
        });
    }

    /** send every server object to a joining player */
    public static void sendAll(ServerPlayer to) {
        var r = net.idea.fluwa.server.ScriptManager.rt;
        if (r == null) return;
        Reg g = (Reg) r.state.get("projector");
        if (g == null) return;
        for (ProjectorObj o : g.objs.values()) if (o.sentAdd) {
            FluwaNet.toPlayerLarge(to, new Pkt(Pkt.S_PROJ, List.of("add", o.name), new int[]{o.id}, o.mesh.toBytes()));
            o.dirtyState = true;
        }
    }

    /** server -> client click / interact (C_PROJ n = {id, button}) */
    public static void clicked(ServerPlayer sp, int id, int button) {
        var r = net.idea.fluwa.server.ScriptManager.rt;
        if (r == null) return;
        r.within(() -> {
            Reg g = (Reg) r.state.get("projector");
            ProjectorObj o = g == null ? null : g.objs.get(id);
            if (o == null || !o.inWorld() || o.worldBounds()[0] > sp.getX() + 64 || o.worldBounds()[3] < sp.getX() - 64) return null;
            PlayerObj p = r.wrap(sp);
            if (button == 0) o.fire("E_Clicked", p); else o.interact(p);
            return null;
        });
    }

    /** client-runtime objects clicked locally */
    public static void clickedLocal(FluwaRuntime r, int id, int button) {
        if (r == null || r.closed) return;
        r.within(() -> {
            Reg g = (Reg) r.state.get("projector");
            ProjectorObj o = g == null ? null : g.objs.get(id);
            if (o == null) return null;
            LuaValue p = r instanceof GameRuntime gr ? gr.localPlayer() : NIL;
            if (button == 0) o.fire("E_Clicked", p); else o.interact(p instanceof PlayerObj pp ? pp : null);
            return null;
        });
    }

    // ------------------------------------------------------------------ files
    static Path dir(FluwaRuntime rt) {
        if (rt.server) return ModelSync.modelsDir();
        return net.minecraftforge.fml.loading.FMLPaths.GAMEDIR.get().resolve("fluwa").resolve("models");
    }
    static Path resolve(FluwaRuntime rt, String p, boolean mustExist) {
        Path d = dir(rt).toAbsolutePath().normalize();
        String rel = p.startsWith("models/") ? p.substring(7) : p;
        Path f = d.resolve(rel).normalize();
        if (!f.startsWith(d)) throw new LuaError("Projector paths must stay inside the fluwa/models folder: " + p);
        if (mustExist && !Files.isRegularFile(f)) throw new LuaError("Model not found: " + f);
        return f;
    }
    static Mesh loadMesh(FluwaRuntime rt, String path) {
        if (!MeshLoader.supported(path)) throw new LuaError("Unsupported model format: " + path + " (use .obj .gltf .glb .fbx; .ftx is read as .fbx)");
        try { return MeshCache.get(resolve(rt, path.replaceAll("(?i)\\.ftx$", ".fbx"), true)).copy(); }
        catch (IOException e) { throw new LuaError("Can't load model " + path + ": " + e.getMessage()); }
    }

    public static ProjectorObj imp(FluwaRuntime rt, String path, LuaValue settings, boolean place) {
        Mesh m = loadMesh(rt, path);
        ProjectorObj o = new ProjectorObj(m);
        o.source = path; o.format = ext(path); o.name = Paths.get(path).getFileName().toString().replaceAll("\\.[^.]+$", "");
        apply(o, settings);
        boolean world = !(settings.istable() && settings.get("World").isboolean() && !settings.get("World").toboolean());
        if (place && world && o.parent == null && o.attachEnt == null && o.dim == null) o.dim = "minecraft:overworld";
        rt.post(() -> { o.fire("E_Imported", o, valueOf(path)); o.fire("E_Loaded", o); });
        return o;
    }
    static String ext(String p) { int i = p.lastIndexOf('.'); return i < 0 ? "" : p.substring(i + 1).toLowerCase(Locale.ROOT); }

    static void apply(ProjectorObj o, LuaValue s) {
        if (!s.istable()) return;
        for (String k : new String[]{"Name", "CFrame", "Position", "Scale", "Visible", "Transparency", "Material", "Texture", "Collision", "CanCollide", "Anchored", "Class"}) {
            LuaValue v = s.get(k);
            if (v.isnil()) v = s.get(k.toLowerCase(Locale.ROOT));
            if (!v.isnil()) { if (k.equals("Name")) o.setName(v.tojstring()); else o.setProp(k, v); }
        }
        LuaValue p = s.get("Parent");
        if (!p.isnil()) o.setParent(checkObj(p, LObj.class));
        if (s.get("Optimize").optboolean(false)) o.mesh.optimize();
        if (!s.get("Animation").isnil()) o.play(s.get("Animation").tojstring(), 1, true);
    }

    public static String export(ProjectorObj o, String path, String fmt) {
        String f = fmt != null ? fmt.toLowerCase(Locale.ROOT).replace(".", "") : ext(path).isEmpty() ? "glb" : ext(path);
        if (ext(path).isEmpty()) path = path + "." + f;
        Path out = resolve(o.rt, path, false);
        try {
            Files.createDirectories(out.getParent());
            Files.write(out, MeshExport.export(o.mesh, f));
        } catch (IOException e) { o.fire("E_Error", valueOf("EXPORT"), valueOf(e.toString())); throw new LuaError("Export failed: " + e.getMessage()); }
        o.fire("E_Exported", valueOf(path), valueOf(f));
        return path;
    }

    static void setTexture(ProjectorObj o, String path) {
        try {
            byte[] b = path.isEmpty() ? new byte[0] : Files.readAllBytes(resolve(o.rt, path, true));
            o.mesh.texture = b; o.texture = path; o.dirtyTex = true;
            o.fire("E_TextureChanged", valueOf(path));
        } catch (IOException e) { throw new LuaError("Can't read texture " + path + ": " + e.getMessage()); }
    }

    static void setMaterial(ProjectorObj o, LuaValue v) {
        int color = -1; double tr = -1;
        if (v instanceof MaterialObj m) { o.material = m.name; color = m.color; tr = m.transparency; if (m.texture != null) setTexture(o, m.texture); }
        else if (v.istable()) {
            o.material = v.get("Name").optjstring(o.material);
            if (!v.get("Color").isnil()) color = ColorL.check(v.get("Color"));
            if (!v.get("Transparency").isnil()) tr = v.get("Transparency").todouble();
            if (!v.get("Texture").isnil()) setTexture(o, v.get("Texture").tojstring());
        } else {
            String s = v.checkjstring();
            o.material = s;
            if (s.startsWith("#")) color = ColorL.check(v);
        }
        if (color >= 0) for (Mesh.Part p : o.mesh.parts) p.color = (p.color & 0xFF000000) | color;
        if (tr >= 0) o.transparency = tr;
        o.dirtyMesh = true;
        o.fire("E_MaterialChanged", valueOf(o.material));
    }

    static LuaValue bone(ProjectorObj o, String name) {
        int i = o.mesh.findNode(name);
        return i < 0 ? NIL : new BoneObj(o, i);
    }

    static void setBone(ProjectorObj o, String name, CFrameL c) {
        int i = o.mesh.findNode(name);
        if (i < 0) throw new LuaError("Bone not found: " + name);
        Mesh.Node n = o.mesh.nodes.get(i);
        n.t = new float[]{(float) c.x, (float) c.y, (float) c.z};
        n.r = Mesh.quatFromRows(c.r);
        n.saveRest();
        o.dirtyMesh = true;
        o.fire("E_BoneMoved", valueOf(name), c);
    }

    static LuaTable inspect(ProjectorObj o) {
        LuaTable t = new LuaTable();
        t.set("Name", o.getName()); t.set("Class", o.objClass); t.set("Format", o.format); t.set("Source", o.source);
        t.set("Vertices", valueOf(o.mesh.vertexCount())); t.set("Polygons", valueOf(o.mesh.triangleCount()));
        t.set("Size", o.getProp("Size")); t.set("HasTexture", valueOf(o.mesh.texture.length > 0));
        LuaTable parts = new LuaTable(); int i = 1;
        for (Mesh.Part p : o.mesh.parts) { LuaTable x = new LuaTable(); x.set("Name", p.name); x.set("Vertices", valueOf(p.vertexCount()));
            x.set("Color", String.format("#%06x", p.color & 0xFFFFFF)); x.set("Visible", valueOf(p.visible)); parts.set(i++, x); }
        t.set("Meshes", parts);
        t.set("Bones", o.getProp("Bones"));
        LuaTable an = new LuaTable(); i = 1;
        for (Mesh.Anim a : o.mesh.anims) { LuaTable x = new LuaTable(); x.set("Name", a.name); x.set("Duration", valueOf(a.duration)); an.set(i++, x); }
        t.set("Animations", an);
        t.set("InWorld", valueOf(o.inWorld()));
        return t;
    }

    static ProjectorObj obj(LuaValue v) { return checkObj(v, ProjectorObj.class); }

    // ------------------------------------------------------------------ helper types
    public static final class BoneObj extends LObj {
        final ProjectorObj o; final int i;
        BoneObj(ProjectorObj o, int i) { super("ProjectorBone"); this.o = o; this.i = i; name = o.mesh.nodes.get(i).name; }
        @Override protected LuaValue getProp(String k) {
            Mesh.Node n = o.mesh.nodes.get(i);
            switch (k) {
                case "CFrame": return new CFrameL(n.t[0], n.t[1], n.t[2], Mesh.rowsFromQuat(n.r));
                case "Position": return new Vec3L(n.t[0], n.t[1], n.t[2]);
                case "Scale": return new Vec3L(n.s[0], n.s[1], n.s[2]);
                case "ParentBone": return n.parent < 0 ? NIL : valueOf(o.mesh.nodes.get(n.parent).name);
                case "Object": return o;
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            if (k.equals("CFrame")) { setBone(o, name, CFrameL.check(v)); return true; }
            return super.setProp(k, v);
        }
    }

    public static final class AnimInfo extends LObj {
        final Mesh.Anim a;
        AnimInfo(Mesh.Anim a) { super("ProjectorAnimation"); this.a = a; name = a.name; }
        @Override protected LuaValue getProp(String k) {
            if (k.equals("Duration") || k.equals("Length")) return valueOf(a.duration);
            if (k.equals("Channels")) return valueOf(a.ch.size());
            return super.getProp(k);
        }
    }

    public static final class MeshPart extends LObj {
        final ProjectorObj o; final Mesh.Part p;
        MeshPart(ProjectorObj o, Mesh.Part p) { super("ProjectorMesh"); this.o = o; this.p = p; name = p.name; }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Visible": return valueOf(p.visible);
                case "Color": return new ColorL(p.color >> 16 & 255, p.color >> 8 & 255, p.color & 255);
                case "Vertices": return valueOf(p.vertexCount());
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            switch (k) {
                case "Visible": p.visible = v.toboolean(); o.dirtyState = true; return true;
                case "Color": p.color = (p.color & 0xFF000000) | ColorL.check(v); o.dirtyMesh = true; return true;
            }
            return super.setProp(k, v);
        }
    }

    public static final class MaterialObj extends LObj {
        int color = 0xFFFFFF; double transparency; String texture;
        MaterialObj() { super("ProjectorMaterial"); name = "Material"; }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Color": return new ColorL(color >> 16 & 255, color >> 8 & 255, color & 255);
                case "Transparency": return valueOf(transparency);
                case "Texture": return texture == null ? NIL : valueOf(texture);
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            switch (k) {
                case "Color": color = ColorL.check(v); return true;
                case "Transparency": transparency = v.checkdouble(); return true;
                case "Texture": texture = v.isnil() ? null : v.tojstring(); return true;
            }
            return super.setProp(k, v);
        }
    }

    // ------------------------------------------------------------------ service
    final FluwaRuntime r;
    public Projector(FluwaRuntime r) { super("Service"); this.r = r; name = "Projector"; reg(r); }

    static float[] flatVerts(Mesh m) { int n = 0; for (Mesh.Part p : m.parts) n += p.v.length; float[] o = new float[n]; int i = 0; for (Mesh.Part p : m.parts) { System.arraycopy(p.v, 0, o, i, p.v.length); i += p.v.length; } return o; }

    static {
        Class<Projector> C = Projector.class;
        reg(C, "Import|Imp", (s, a) -> imp(s.rt, a.checkjstring(1), a.arg(2), true));
        reg(C, "Load", (s, a) -> imp(s.rt, a.checkjstring(1), a.arg(2), false));
        reg(C, "Export|Exp", (s, a) -> valueOf(export(obj(a.arg1()), a.checkjstring(2), a.optjstring(3, null))));
        reg(C, "Create", (s, a) -> {
            String cls = a.optjstring(1, "Part");
            ProjectorObj o = new ProjectorObj(MeshLoader.primitive(cls, a.arg(2).istable() ? a.arg(2).get("Segments").optint(16) : 16));
            o.objClass = cls; o.name = cls; o.format = "primitive"; o.source = cls;
            apply(o, a.arg(2));
            return o; });
        reg(C, "Preload", (s, a) -> { loadMesh(s.rt, a.checkjstring(1)); return TRUE; });
        reg(C, "GetCache", (s, a) -> { LuaTable t = new LuaTable(); int i = 1; for (String k : MeshCache.keys()) t.set(i++, valueOf(k)); return t; });
        reg(C, "ClearCache", (s, a) -> { MeshCache.clear(); return NONE; });
        reg(C, "Raycast", (s, a) -> obj(a.arg1()).raycast(Vec3L.check(a.arg(2)), Vec3L.check(a.arg(3)), a.optdouble(4, 512)));
        reg(C, "Attach", (s, a) -> { ProjectorObj o = obj(a.arg1()); if (!a.isnil(3)) o.cf = CFrameL.check(a.arg(3)); o.setParent(checkObj(a.arg(2), LObj.class)); return NONE; });
        reg(C, "Detach", (s, a) -> { ProjectorObj o = obj(a.arg1()); CFrameL w = o.worldCF(); String d = o.worldDim();
            o.setParent(null); o.cf = w; o.dim = d; o.dirtyState = true; return NONE; });
        reg(C, "Clone", (s, a) -> obj(a.arg1()).copyObj());
        reg(C, "Merge", (s, a) -> {
            ProjectorObj o1 = obj(a.arg1()), o2 = obj(a.arg(2));
            Mesh m = o1.mesh.copy();
            CFrameL rel = o1.worldCF().inverse().times(o2.worldCF());
            float[][] g = o2.mesh.globals();
            for (Mesh.Part p : o2.mesh.parts) {
                Mesh.Part c = p.copy();
                float[] v = p.node >= 0 && p.node < g.length ? Mesh.apply(p.v, g[p.node]) : p.v.clone();
                for (int i = 0; i + 7 < v.length; i += 8) {
                    Vec3L w = rel.point(new Vec3L(v[i] * o2.sx / o1.sx, v[i + 1] * o2.sy / o1.sy, v[i + 2] * o2.sz / o1.sz));
                    v[i] = (float) w.x; v[i + 1] = (float) w.y; v[i + 2] = (float) w.z;
                }
                c.v = v; c.node = -1; m.parts.add(c);
            }
            ProjectorObj o = new ProjectorObj(m);
            o.name = o1.name + "+" + o2.name; o.cf = o1.cf; o.sx = o1.sx; o.sy = o1.sy; o.sz = o1.sz; o.format = "merged"; o.dim = o1.worldDim();
            return o; });
        reg(C, "Optimize", (s, a) -> { ProjectorObj o = obj(a.arg1()); int n = o.mesh.optimize(); o.dirtyMesh = true; return valueOf(n); });
        reg(C, "SetLOD", (s, a) -> {
            ProjectorObj o = obj(a.arg1()); int lv = Math.max(0, a.checkint(2));
            if (o.base == null) o.base = o.mesh.copy();
            Mesh m = o.base.copy();
            if (lv > 0) for (Mesh.Part p : m.parts) {
                int tris = p.v.length / 24, keep = 0; float[] out = new float[p.v.length];
                for (int t = 0; t < tris; t++) if (t % (lv + 1) == 0) { System.arraycopy(p.v, t * 24, out, keep * 24, 24); keep++; }
                p.v = Arrays.copyOf(out, keep * 24);
            }
            o.mesh = m; o.lod = lv; o.dirtyMesh = true; return NONE; });
        reg(C, "GetPolygons", (s, a) -> {
            ProjectorObj o = obj(a.arg1()); LuaTable t = new LuaTable(); int n = 1;
            for (float[] v : o.mesh.posed()) for (int i = 0; i + 23 < v.length && n <= 50000; i += 24) {
                LuaTable tri = new LuaTable();
                for (int k = 0; k < 3; k++) tri.set(k + 1, new Vec3L(v[i + k * 8], v[i + k * 8 + 1], v[i + k * 8 + 2]));
                t.set(n++, tri);
            }
            return t; });
        reg(C, "GetVertices", (s, a) -> {
            float[] v = flatVerts(obj(a.arg1()).mesh); LuaTable t = new LuaTable();
            for (int i = 0, n = 1; i + 7 < v.length && n <= 150000; i += 8) t.set(n++, new Vec3L(v[i], v[i + 1], v[i + 2]));
            return t; });
        reg(C, "GetVertex", (s, a) -> {
            ProjectorObj o = obj(a.arg1()); int idx = a.checkint(2) - 1;
            for (Mesh.Part p : o.mesh.parts) { int n = p.vertexCount(); if (idx < n) return new Vec3L(p.v[idx * 8], p.v[idx * 8 + 1], p.v[idx * 8 + 2]); idx -= n; }
            return NIL; });
        reg(C, "SetVertex", (s, a) -> {
            ProjectorObj o = obj(a.arg1()); int idx0 = a.checkint(2), idx = idx0 - 1; Vec3L nv = Vec3L.check(a.arg(3));
            for (Mesh.Part p : o.mesh.parts) {
                int n = p.vertexCount();
                if (idx < n) {
                    Vec3L old = new Vec3L(p.v[idx * 8], p.v[idx * 8 + 1], p.v[idx * 8 + 2]);
                    p.v[idx * 8] = (float) nv.x; p.v[idx * 8 + 1] = (float) nv.y; p.v[idx * 8 + 2] = (float) nv.z;
                    o.dirtyMesh = true; o.fire("E_VertexChanged", valueOf(idx0), old, nv); return TRUE;
                }
                idx -= n;
            }
            throw new LuaError("Vertex index out of range: " + idx0); });
        reg(C, "SetMaterial", (s, a) -> { setMaterial(obj(a.arg1()), a.arg(2)); return NONE; });
        reg(C, "NewMaterial|CreateMaterial", (s, a) -> { MaterialObj m = new MaterialObj(); if (a.arg1().istable()) {
                LuaValue t = a.arg1(); if (!t.get("Name").isnil()) m.name = t.get("Name").tojstring();
                if (!t.get("Color").isnil()) m.color = ColorL.check(t.get("Color"));
                if (!t.get("Transparency").isnil()) m.transparency = t.get("Transparency").todouble();
                if (!t.get("Texture").isnil()) m.texture = t.get("Texture").tojstring(); }
            else if (a.isstring(1)) m.name = a.tojstring(1);
            return m; });
        reg(C, "SetTexture", (s, a) -> { setTexture(obj(a.arg1()), a.checkjstring(2)); return NONE; });
        reg(C, "SetBone", (s, a) -> { setBone(obj(a.arg1()), a.checkjstring(2), CFrameL.check(a.arg(3))); return NONE; });
        reg(C, "GetBone", (s, a) -> bone(obj(a.arg1()), a.checkjstring(2)));
        reg(C, "PlayAnimation", (s, a) -> { obj(a.arg1()).play(a.optjstring(2, null), a.optdouble(3, 1), a.optboolean(4, true)); return NONE; });
        reg(C, "StopAnimation", (s, a) -> { ProjectorObj o = obj(a.arg1()); if (o.playing) o.fire("E_AnimationEnd", valueOf(String.valueOf(o.anim)));
            o.playing = false; o.time = 0; for (Mesh.Node n : o.mesh.nodes) n.restore(); o.dirtyState = true; return NONE; });
        reg(C, "PauseAnimation", (s, a) -> { ProjectorObj o = obj(a.arg1()); o.paused = !o.paused; o.dirtyState = true; return NONE; });
        reg(C, "SetAnimationTime", (s, a) -> { ProjectorObj o = obj(a.arg1()); o.time = Math.max(0, a.checkdouble(2)); o.dirtyState = true; return NONE; });
        reg(C, "GetAnimationTime", (s, a) -> valueOf(obj(a.arg1()).time));
        reg(C, "SetCFrame|PivotTo", (s, a) -> { obj(a.arg1()).setProp("CFrame", a.arg(2)); return NONE; });
        reg(C, "SetScale", (s, a) -> { obj(a.arg1()).setScale(a.arg(2)); return NONE; });
        reg(C, "SetVisible", (s, a) -> { obj(a.arg1()).setProp("Visible", a.arg(2)); return NONE; });
        reg(C, "SetTransparency", (s, a) -> { obj(a.arg1()).setProp("Transparency", a.arg(2)); return NONE; });
        reg(C, "SetCollision", (s, a) -> { obj(a.arg1()).collision = a.toboolean(2); return NONE; });
        reg(C, "Convert", (s, a) -> { ProjectorObj o = obj(a.arg1()); String f = a.checkjstring(2).replace(".", "").toLowerCase(Locale.ROOT);
            return valueOf(export(o, "converted/" + o.getName().replaceAll("[^A-Za-z0-9_\\-]", "_") + "." + f, f)); });
        reg(C, "Inspect", (s, a) -> inspect(obj(a.arg1())));
        reg(C, "GetObjects|GetAll", (s, a) -> list(reg(s.rt).objs.values()));
    }
}
