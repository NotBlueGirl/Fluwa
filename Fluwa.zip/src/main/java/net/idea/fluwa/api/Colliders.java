package net.idea.fluwa.api;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Extra collision shapes that are not real blocks: moving tween blocks (CanCollide) and solid BlockEntities.
 * Fed into Entity#collide by mixin.EntityCollideMixin on both server and client.
 */
public final class Colliders {
    private Colliders() {}

    public interface Source { void collect(Level level, Entity who, AABB box, List<VoxelShape> out); }

    public static final List<Source> SOURCES = new CopyOnWriteArrayList<>();
    /** solid BlockEntities (uuid -> block state), replicated by Hitbox packets */
    public static final Map<java.util.UUID, BlockState> SOLID = new java.util.concurrent.ConcurrentHashMap<>();

    static {
        SOURCES.add((level, who, box, out) -> {
            if (SOLID.isEmpty()) return;
            for (net.minecraft.world.entity.Display.BlockDisplay d : level.getEntitiesOfClass(net.minecraft.world.entity.Display.BlockDisplay.class, box.inflate(1.5))) {
                if (d == who) continue;
                BlockState s = SOLID.get(d.getUUID());
                if (s == null) continue;
                VoxelShape sh = s.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
                if (!sh.isEmpty()) out.add(sh.move(d.getX(), d.getY(), d.getZ()));
            }
        });
    }

    /** set while Fluwa itself pushes an entity out of a moving group */
    public static boolean SUSPEND;

    public static void collect(Level level, Entity who, AABB box, List<VoxelShape> out) {
        if (SUSPEND) return;
        // the client is authoritative for its own player: server-side player.move() must not use (slightly different)
        // server tween positions, otherwise the server rejects the movement ("moved wrongly") and snaps the player back
        if (!level.isClientSide && who instanceof net.minecraft.world.entity.player.Player) return;
        for (Source s : SOURCES) {
            try { s.collect(level, who, box, out); } catch (RuntimeException ignored) {}
        }
    }

    /** collision shapes of a block group (rel pos -> state) placed at offset, inside box */
    public static void group(Map<BlockPos, BlockState> blocks, Vec3 off, AABB box, List<VoxelShape> out) {
        if (blocks == null || blocks.isEmpty()) return;
        AABB q = box.move(-off.x, -off.y, -off.z);
        int x0 = (int) Math.floor(q.minX) - 1, x1 = (int) Math.floor(q.maxX) + 1;
        int y0 = (int) Math.floor(q.minY) - 1, y1 = (int) Math.floor(q.maxY) + 1;
        int z0 = (int) Math.floor(q.minZ) - 1, z1 = (int) Math.floor(q.maxZ) + 1;
        long cells = (long) (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1);
        if (cells > 32768) return;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) {
            BlockState s = blocks.get(m.set(x, y, z));
            if (s == null) continue;
            VoxelShape sh = s.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
            if (sh.isEmpty()) continue;
            out.add(sh.move(off.x + x, off.y + y, off.z + z));
        }
    }

    /** sweep box by v against shapes (vanilla axis order) */
    static Vec3 slide(AABB box, Vec3 v, List<VoxelShape> sh) {
        double x = v.x, y = v.y, z = v.z;
        if (y != 0) { y = net.minecraft.world.phys.shapes.Shapes.collide(net.minecraft.core.Direction.Axis.Y, box, sh, y); if (y != 0) box = box.move(0, y, 0); }
        boolean zFirst = Math.abs(x) < Math.abs(z);
        if (zFirst && z != 0) { z = net.minecraft.world.phys.shapes.Shapes.collide(net.minecraft.core.Direction.Axis.Z, box, sh, z); if (z != 0) box = box.move(0, 0, z); }
        if (x != 0) { x = net.minecraft.world.phys.shapes.Shapes.collide(net.minecraft.core.Direction.Axis.X, box, sh, x); if (!zFirst && x != 0) box = box.move(x, 0, 0); }
        if (!zFirst && z != 0) z = net.minecraft.world.phys.shapes.Shapes.collide(net.minecraft.core.Direction.Axis.Z, box, sh, z);
        return new Vec3(x, y, z);
    }

    /**
     * The group moved from prev to now this tick. Entities standing on it ride along; entities in its way are pushed
     * (relative sweep, so no tunnelling at any speed). Must run BEFORE the entity's own movement in the same tick.
     */
    public static void pushCarry(Entity e, Map<BlockPos, BlockState> blocks, Vec3 prev, Vec3 now) {
        Vec3 d = now.subtract(prev);
        if (d.lengthSqr() < 1e-12 || e.noPhysics) return;
        Vec3 move;
        if (standsOn(blocks, prev, e)) move = d;
        else {
            AABB box = e.getBoundingBox();
            List<VoxelShape> sh = new java.util.ArrayList<>();
            group(blocks, prev, box.expandTowards(-d.x, -d.y, -d.z).inflate(0.1), sh);
            if (sh.isEmpty()) return;
            // in the group's frame the entity moves by -d; whatever is blocked is the push
            move = slide(box, d.reverse(), sh).add(d);
            if (move.lengthSqr() < 1e-12) return;
        }
        SUSPEND = true;
        try {
            e.move(net.minecraft.world.entity.MoverType.SHULKER_BOX, move);
            if (move.y > 0) { e.fallDistance = 0; e.setOnGround(true); }
        } finally { SUSPEND = false; }
        if (e.getDeltaMovement().y < 0 && move.y >= 0 && standsOn(blocks, now, e)) e.setDeltaMovement(e.getDeltaMovement().multiply(1, 0, 1));
    }

    /** true if the entity stands on the group (feet touching its top) */
    public static boolean standsOn(Map<BlockPos, BlockState> blocks, Vec3 off, Entity e) {
        AABB feet = e.getBoundingBox();
        feet = new AABB(feet.minX + 0.01, feet.minY - 0.12, feet.minZ + 0.01, feet.maxX - 0.01, feet.minY + 0.05, feet.maxZ - 0.01);
        List<VoxelShape> l = new java.util.ArrayList<>();
        group(blocks, off, feet, l);
        for (VoxelShape s : l) for (AABB b : s.toAabbs()) if (b.intersects(feet)) return true;
        return false;
    }
}
