package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import org.luaj.vm2.*;

import java.util.*;

/**
 * Structure template (structure-block format, saved in world/generated/<ns>/structures).
 * v0.5.2: editable block / entity data (GetBlocks, GetBlock, SetBlock, RemoveBlock, GetEntities), Pivot, Clone.
 * Positions are local (0,0,0 = min corner). Editing works on a decoded copy that is written back lazily.
 */
public class StructureObj extends LObj {
    private StructureTemplate tpl;
    ResourceLocation id;
    /** local pivot: Place puts this point at the target position, its Y rotation (snapped to 90°) rotates the structure */
    CFrameL pivot = new CFrameL(0, 0, 0);
    /** last Place() - used by Structure:TweenPosition to move the placed copy */
    DimensionObj placedDim; Vec3L placedAt; LuaValue placedOpts; List<BlockPos> placedBlocks;

    // decoded model (null until the first edit / read)
    record B(BlockState state, CompoundTag nbt) {}
    private LinkedHashMap<BlockPos, B> blocks;
    private List<CompoundTag> entities;
    private int[] size;
    private boolean dirty;

    public StructureObj(StructureTemplate t, ResourceLocation id) { super("Structure"); tpl = t; this.id = id; if (id != null) name = id.toString(); }
    public StructureObj() { this(new StructureTemplate(), null); }

    // ------------------------------------------------------------ model <-> template
    private void decode() {
        if (blocks != null) return;
        CompoundTag t = tpl.save(new CompoundTag());
        blocks = new LinkedHashMap<>(); entities = new ArrayList<>();
        ListTag sz = t.getList("size", Tag.TAG_INT);
        size = new int[]{sz.size() > 0 ? sz.getInt(0) : 0, sz.size() > 1 ? sz.getInt(1) : 0, sz.size() > 2 ? sz.getInt(2) : 0};
        ListTag pal = t.contains("palette", Tag.TAG_LIST) ? t.getList("palette", Tag.TAG_COMPOUND)
                : t.contains("palettes", Tag.TAG_LIST) && !t.getList("palettes", Tag.TAG_LIST).isEmpty() ? t.getList("palettes", Tag.TAG_LIST).getList(0) : new ListTag();
        List<BlockState> states = new ArrayList<>();
        var lookup = BuiltInRegistries.BLOCK.asLookup();
        for (int i = 0; i < pal.size(); i++) states.add(NbtUtils.readBlockState(lookup, pal.getCompound(i)));
        ListTag bl = t.getList("blocks", Tag.TAG_COMPOUND);
        for (int i = 0; i < bl.size(); i++) {
            CompoundTag b = bl.getCompound(i);
            ListTag p = b.getList("pos", Tag.TAG_INT);
            int si = b.getInt("state");
            if (si < 0 || si >= states.size()) continue;
            blocks.put(new BlockPos(p.getInt(0), p.getInt(1), p.getInt(2)), new B(states.get(si), b.contains("nbt", Tag.TAG_COMPOUND) ? b.getCompound("nbt") : null));
        }
        ListTag el = t.getList("entities", Tag.TAG_COMPOUND);
        for (int i = 0; i < el.size(); i++) entities.add(el.getCompound(i));
    }

    /** current template (re-encoded after edits) */
    public StructureTemplate tpl() {
        if (!dirty) return tpl;
        CompoundTag t = new CompoundTag();
        ListTag sz = new ListTag();
        for (int v : size) sz.add(IntTag.valueOf(v));
        t.put("size", sz);
        Map<BlockState, Integer> idx = new LinkedHashMap<>();
        ListTag bl = new ListTag();
        for (var e : blocks.entrySet()) {
            int si = idx.computeIfAbsent(e.getValue().state(), k -> idx.size());
            CompoundTag b = new CompoundTag();
            ListTag p = new ListTag();
            p.add(IntTag.valueOf(e.getKey().getX())); p.add(IntTag.valueOf(e.getKey().getY())); p.add(IntTag.valueOf(e.getKey().getZ()));
            b.put("pos", p); b.putInt("state", si);
            if (e.getValue().nbt() != null) b.put("nbt", e.getValue().nbt().copy());
            bl.add(b);
        }
        ListTag pal = new ListTag();
        for (BlockState s : idx.keySet()) pal.add(NbtUtils.writeBlockState(s));
        t.put("palette", pal);
        t.put("blocks", bl);
        ListTag el = new ListTag();
        for (CompoundTag e : entities) el.add(e.copy());
        t.put("entities", el);
        StructureTemplate n = new StructureTemplate();
        n.load(BuiltInRegistries.BLOCK.asLookup(), t);
        tpl = n; dirty = false;
        return tpl;
    }
    private void changed() { dirty = true; }

    static BlockPos local(LuaValue v) {
        Vec3L p = Vec3L.check(v);
        BlockPos b = BlockPos.containing(Math.floor(p.x + 1e-6), Math.floor(p.y + 1e-6), Math.floor(p.z + 1e-6));
        if (b.getX() < 0 || b.getY() < 0 || b.getZ() < 0) throw new LuaError("Structure positions are local and start at 0,0,0 (got " + b.toShortString() + ")");
        if (b.getX() > 4096 || b.getY() > 4096 || b.getZ() > 4096) throw new LuaError("Structure position is too far: " + b.toShortString());
        return b;
    }

    static CompoundTag nbtArg(LuaValue v) {
        if (v.isnil()) return null;
        if (v.isstring()) {
            try { return TagParser.parseTag(v.tojstring()); }
            catch (Exception e) { throw new LuaError("Bad NBT: " + e.getMessage()); }
        }
        if (v.istable()) { Tag t = Conv.toTag(v); if (t instanceof CompoundTag c) return c; throw new LuaError("NBT table must have named keys"); }
        throw new LuaError("NBT must be a table or an SNBT string");
    }

    static LuaTable blockTable(BlockPos p, B b) {
        LuaTable t = new LuaTable();
        t.set("Position", Vec3L.of(p));
        t.set("Id", valueOf(Conv.id(b.state())));
        t.set("State", valueOf(net.minecraft.commands.arguments.blocks.BlockStateParser.serialize(b.state())));
        if (b.nbt() != null) t.set("NBT", Conv.toLua(b.nbt()));
        return t;
    }

    // ------------------------------------------------------------ placing
    static Rotation rotation(String r) {
        return switch (r) {
            case "90", "cw", "clockwise_90" -> Rotation.CLOCKWISE_90;
            case "180", "clockwise_180" -> Rotation.CLOCKWISE_180;
            case "270", "-90", "ccw", "counterclockwise_90" -> Rotation.COUNTERCLOCKWISE_90;
            default -> Rotation.NONE;
        };
    }
    Rotation pivotRotation() {
        // yaw of the pivot's look vector, snapped to 90°
        Vec3L l = pivot.look();
        double yaw = Math.toDegrees(Math.atan2(l.x, -l.z));
        int q = (int) Math.round(yaw / 90.0) & 3;
        return switch (q) { case 1 -> Rotation.CLOCKWISE_90; case 2 -> Rotation.CLOCKWISE_180; case 3 -> Rotation.COUNTERCLOCKWISE_90; default -> Rotation.NONE; };
    }

    void place(DimensionObj d, Vec3L at, LuaValue opts, boolean noEntities) {
        var sl = EntityObj.sl(d.level());
        StructurePlaceSettings st = new StructurePlaceSettings();
        Rotation rot = pivotRotation();
        if (opts != null && opts.istable()) {
            if (!opts.get("rotation").isnil()) rot = rotation(opts.get("rotation").tojstring().toLowerCase(Locale.ROOT));
            st.setIgnoreEntities(!opts.get("entities").optboolean(true));
            String m = opts.get("mirror").optjstring("none").toLowerCase(Locale.ROOT);
            st.setMirror(switch (m) { case "x", "front_back" -> net.minecraft.world.level.block.Mirror.FRONT_BACK; case "z", "left_right" -> net.minecraft.world.level.block.Mirror.LEFT_RIGHT; default -> net.minecraft.world.level.block.Mirror.NONE; });
        }
        BlockPos pv = BlockPos.containing(Math.floor(pivot.x), Math.floor(pivot.y), Math.floor(pivot.z));
        st.setRotation(rot);
        st.setRotationPivot(pv);
        BlockPos target = at.pos();
        BlockPos origin = target.subtract(pv);
        if (noEntities) st.setIgnoreEntities(true);
        tpl().placeInWorld(sl, origin, origin, st, sl.random, 2);
        // remember where the blocks went (for tweening / moving the placed copy)
        decode();
        List<BlockPos> out = new ArrayList<>(blocks.size());
        for (BlockPos lp : blocks.keySet()) out.add(StructureTemplate.calculateRelativePosition(st, lp).offset(origin));
        placedDim = d; placedAt = new Vec3L(target.getX(), target.getY(), target.getZ()); placedOpts = opts; placedBlocks = out;
    }
    public void place(DimensionObj d, Vec3L at, LuaValue opts) { place(d, at, opts, false); }

    /** moves the last placed copy: clears its blocks and places it again at p (entities are not duplicated) */
    void moveTo(Vec3L p) {
        if (placedDim == null) throw new LuaError("Structure is not placed (Structure:Place(dimension, pos) first)");
        BlockPos np = p.pos();
        if (placedAt != null && np.equals(placedAt.pos())) return;
        var lv = placedDim.level();
        BlockState air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        if (placedBlocks != null) for (BlockPos b : placedBlocks) lv.setBlock(b, air, 2 | 16);
        place(placedDim, new Vec3L(np.getX(), np.getY(), np.getZ()), placedOpts, true);
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Size": return size();
            case "Id": return id == null ? NIL : valueOf(id.toString());
            case "Pivot": return pivot;
            case "Position": return placedAt == null ? NIL : placedAt;
            case "Placed": return valueOf(placedDim != null);
            case "BlockCount": decode(); return valueOf(blocks.size());
            case "EntityCount": decode(); return valueOf(entities.size());
        }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) {
        if (k.equals("Pivot")) { pivot = CFrameL.check(v); return true; }
        if (k.equals("Position")) { moveTo(Vec3L.check(v)); return true; }
        if (k.equals("Size")) { decode(); BlockPos s = local(v); size = new int[]{s.getX(), s.getY(), s.getZ()}; blocks.keySet().removeIf(p -> p.getX() >= size[0] || p.getY() >= size[1] || p.getZ() >= size[2]); changed(); return true; }
        return super.setProp(k, v);
    }
    Vec3L size() { if (blocks != null) return new Vec3L(size[0], size[1], size[2]); Vec3i s = tpl.getSize(); return new Vec3L(s.getX(), s.getY(), s.getZ()); }

    @Override protected LuaValue cloneObj() {
        StructureObj c = new StructureObj();
        c.tpl.load(BuiltInRegistries.BLOCK.asLookup(), tpl().save(new CompoundTag()));
        c.id = null; c.name = name; c.pivot = pivot;
        return c;
    }

    static {
        Class<StructureObj> C = StructureObj.class;
        WorldTween.install(C, WorldTween.STRUCTURE);
        reg(C, "MoveTo", (s, a) -> { ((StructureObj) s).moveTo(Vec3L.check(a.arg1())); return NONE; });
        reg(C, "Place", (s, a) -> { ((StructureObj) s).place(checkObj(a.arg1(), DimensionObj.class), Vec3L.check(a.arg(2)), a.arg(3)); return NONE; });
        reg(C, "Capture", (s, a) -> {
            StructureObj o = (StructureObj) s; DimensionObj d = checkObj(a.arg1(), DimensionObj.class);
            Vec3L v1 = Vec3L.check(a.arg(2)), v2 = Vec3L.check(a.arg(3));
            BlockPos mn = Conv.min(v1, v2), mx = Conv.max(v1, v2);
            Vec3i size = new Vec3i(mx.getX() - mn.getX() + 1, mx.getY() - mn.getY() + 1, mx.getZ() - mn.getZ() + 1);
            Conv.checkVolume((long) size.getX() * size.getY() * size.getZ());
            o.tpl().fillFromWorld(d.level(), mn, size, a.optboolean(4, true), Blocks.STRUCTURE_VOID);
            o.blocks = null; o.entities = null; o.dirty = false;
            return NONE; });
        reg(C, "Save", (s, a) -> {
            StructureObj o = (StructureObj) s; var srv = GameRuntime.cur().server();
            if (srv == null) throw new LuaError("Structure:Save is only Server-Side");
            ResourceLocation id = Conv.rl(a.optjstring(1, o.id == null ? "fluwa:unnamed" : o.id.toString()));
            StructureTemplate t = srv.getStructureManager().getOrCreate(id);
            t.load(BuiltInRegistries.BLOCK.asLookup(), o.tpl().save(new CompoundTag()));
            boolean ok = srv.getStructureManager().save(id);
            o.tpl = t; o.id = id; o.name = id.toString(); o.blocks = null; o.entities = null; o.dirty = false;
            return valueOf(ok); });
        // ---- v0.5.2
        reg(C, "GetSize", (s, a) -> ((StructureObj) s).size());
        reg(C, "SetSize", (s, a) -> { s.set(valueOf("Size"), a.arg1()); return NONE; });
        reg(C, "GetBlocks", (s, a) -> {
            StructureObj o = (StructureObj) s; o.decode();
            boolean air = a.optboolean(1, false);   // GetBlocks(true) also lists air
            LuaTable t = new LuaTable(); int i = 1;
            for (var e : o.blocks.entrySet()) if (air || !e.getValue().state().isAir()) t.set(i++, blockTable(e.getKey(), e.getValue()));
            return t; });
        reg(C, "GetBlock", (s, a) -> {
            StructureObj o = (StructureObj) s; o.decode();
            BlockPos p = local(a.arg1());
            B b = o.blocks.get(p);
            if (b == null) return NIL;
            BlockObj bo = new BlockObj();
            bo.templateId = net.minecraft.commands.arguments.blocks.BlockStateParser.serialize(b.state());
            bo.templateNbt = b.nbt() == null ? null : b.nbt().copy();
            bo.pos = p;
            return bo; });
        reg(C, "SetBlock", (s, a) -> {
            StructureObj o = (StructureObj) s; o.decode();
            BlockPos p = local(a.arg1());
            String bid = a.arg(2) instanceof BlockObj bo ? (bo.rawLevel() != null ? net.minecraft.commands.arguments.blocks.BlockStateParser.serialize(bo.state()) : bo.templateId) : a.checkjstring(2);
            BlockState st = Conv.block(bid);
            CompoundTag nbt = nbtArg(a.arg(3));
            if (nbt == null && a.arg(2) instanceof BlockObj bo && bo.templateNbt != null) nbt = bo.templateNbt.copy();
            o.blocks.put(p, new B(st, nbt));
            for (int i = 0; i < 3; i++) o.size[i] = Math.max(o.size[i], (i == 0 ? p.getX() : i == 1 ? p.getY() : p.getZ()) + 1);
            o.changed();
            return NONE; });
        reg(C, "RemoveBlock", (s, a) -> {
            StructureObj o = (StructureObj) s; o.decode();
            boolean had = o.blocks.remove(local(a.arg1())) != null;
            if (had) o.changed();
            return valueOf(had); });
        reg(C, "GetEntities", (s, a) -> {
            StructureObj o = (StructureObj) s; o.decode();
            LuaTable t = new LuaTable(); int i = 1;
            for (CompoundTag e : o.entities) {
                LuaTable r = new LuaTable();
                ListTag p = e.getList("pos", Tag.TAG_DOUBLE), bp = e.getList("blockPos", Tag.TAG_INT);
                if (p.size() == 3) r.set("Position", new Vec3L(p.getDouble(0), p.getDouble(1), p.getDouble(2)));
                if (bp.size() == 3) r.set("BlockPosition", new Vec3L(bp.getInt(0), bp.getInt(1), bp.getInt(2)));
                CompoundTag n = e.getCompound("nbt");
                r.set("Id", valueOf(n.getString("id")));
                r.set("NBT", Conv.toLua(n));
                t.set(i++, r);
            }
            return t; });
        reg(C, "AddEntity", (s, a) -> {   // AddEntity(type, Vec3 local, [nbt])
            StructureObj o = (StructureObj) s; o.decode();
            String type = Conv.rl(a.checkjstring(1)).toString();
            if (!BuiltInRegistries.ENTITY_TYPE.containsKey(new ResourceLocation(type))) throw new LuaError("Unknown entity type " + type);
            Vec3L p = Vec3L.check(a.arg(2));
            CompoundTag n = nbtArg(a.arg(3)); if (n == null) n = new CompoundTag();
            n.putString("id", type);
            CompoundTag e = new CompoundTag();
            ListTag pl = new ListTag(); pl.add(DoubleTag.valueOf(p.x)); pl.add(DoubleTag.valueOf(p.y)); pl.add(DoubleTag.valueOf(p.z));
            ListTag bl = new ListTag(); bl.add(IntTag.valueOf((int) Math.floor(p.x))); bl.add(IntTag.valueOf((int) Math.floor(p.y))); bl.add(IntTag.valueOf((int) Math.floor(p.z)));
            e.put("pos", pl); e.put("blockPos", bl); e.put("nbt", n);
            o.entities.add(e); o.changed();
            return NONE; });
        reg(C, "ClearEntities", (s, a) -> { StructureObj o = (StructureObj) s; o.decode(); o.entities.clear(); o.changed(); return NONE; });
        reg(C, "Fill", (s, a) -> {   // Fill(from, to, block_id)
            StructureObj o = (StructureObj) s; o.decode();
            BlockPos p1 = local(a.arg(1)), p2 = local(a.arg(2));
            BlockState st = Conv.block(a.checkjstring(3));
            BlockPos mn = new BlockPos(Math.min(p1.getX(), p2.getX()), Math.min(p1.getY(), p2.getY()), Math.min(p1.getZ(), p2.getZ()));
            BlockPos mx = new BlockPos(Math.max(p1.getX(), p2.getX()), Math.max(p1.getY(), p2.getY()), Math.max(p1.getZ(), p2.getZ()));
            Conv.checkVolume((long) (mx.getX() - mn.getX() + 1) * (mx.getY() - mn.getY() + 1) * (mx.getZ() - mn.getZ() + 1));
            for (BlockPos q : BlockPos.betweenClosed(mn, mx)) o.blocks.put(q.immutable(), new B(st, null));
            o.size[0] = Math.max(o.size[0], mx.getX() + 1); o.size[1] = Math.max(o.size[1], mx.getY() + 1); o.size[2] = Math.max(o.size[2], mx.getZ() + 1);
            o.changed();
            return NONE; });
        reg(C, "GetPivot", (s, a) -> ((StructureObj) s).pivot);
        reg(C, "SetPivot", (s, a) -> { ((StructureObj) s).pivot = CFrameL.check(a.arg1()); return NONE; });
        reg(C, "Clone", (s, a) -> ((StructureObj) s).cloneObj());
    }
}
