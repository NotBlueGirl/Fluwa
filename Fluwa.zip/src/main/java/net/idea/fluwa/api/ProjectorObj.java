package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.idea.fluwa.mesh.*;
import net.idea.fluwa.net.Pkt;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import org.luaj.vm2.*;

import java.util.*;

/**
 * ProjectorObject - a 3D model (.obj/.gltf/.glb/.fbx or primitive) placed in the world, attached to an entity / another
 * ProjectorObject, or shown in a ViewportFrame. Server objects are replicated to every client (S_PROJ);
 * client objects are rendered only locally.
 */
public class ProjectorObj extends EvObj {
    static final java.util.concurrent.atomic.AtomicInteger IDS = new java.util.concurrent.atomic.AtomicInteger(1);
    static final List<String> EVENTS = List.of("E_Imported", "E_Exported", "E_Loaded", "E_Error", "E_AnimationStart", "E_AnimationEnd",
            "E_AnimationKey", "E_VertexChanged", "E_MaterialChanged", "E_TextureChanged", "E_BoneMoved", "E_Touched", "E_Clicked",
            "E_Interacted", "E_ParentChanged", "E_ChildAdded", "E_ChildRemoved", "E_Used", "E_Attacked", "E_TouchEnded");

    public final int id;
    public Mesh mesh, base;
    public String source = "", format = "mesh", objClass = "Model";
    public CFrameL cf = new CFrameL(0, 0, 0);
    public double sx = 1, sy = 1, sz = 1;
    public boolean visible = true, collision, anchored = true, loaded = true;
    public double transparency;
    public String material = "Plastic", texture = "", gui;
    public int lod;
    public final Set<String> tags = new LinkedHashSet<>();
    public final CompoundTag nbt = new CompoundTag();
    // animation
    public String anim; public boolean playing, paused, loop = true; public double speed = 1, time;
    // placement
    public String dim;              // dimension id when in world
    public EntityObj attachEnt;     // following an entity
    // replication flags
    boolean dirtyMesh = true, dirtyState = true, dirtyTex, sentAdd;
    final Set<Integer> touching = new HashSet<>();

    public ProjectorObj(Mesh m) {
        super("ProjectorObject");
        id = (rt != null && !rt.server ? -1 : 1) * IDS.getAndIncrement();
        mesh = m; name = "Model";
        Projector.reg(rt).objs.put(id, this);
    }

    @Override protected Collection<String> eventNames() { return EVENTS; }

    // ------------------------------------------------------------------ placement
    public boolean inViewport() { return parent != null && "ViewportFrame".equals(parent.className); }
    public boolean inWorld() { return !destroyed && (dim != null || attachEnt != null || parent instanceof ProjectorObj p && p.inWorld()); }

    @Override public void setParent(LObj p) {
        attachEnt = null; dim = null;
        if (p instanceof DimensionObj d) dim = d.level().dimension().location().toString();
        else if (p != null && "Workspace".equals(p.className)) dim = "minecraft:overworld";
        else if (p instanceof EntityObj e) attachEnt = e;
        super.setParent(p);
        dirtyState = true;
        fire("E_ParentChanged", p == null ? NIL : p);
    }

    /** world CFrame (follows attachments) */
    public CFrameL worldCF() {
        if (attachEnt != null && attachEnt.raw() != null) {
            Entity e = attachEnt.raw();
            float yaw = e instanceof net.minecraft.world.entity.LivingEntity l ? l.yBodyRot : e.getYRot();
            return CFrameL.fromYawPitch(Vec3L.of(e.position()), yaw, 0).times(cf);
        }
        if (parent instanceof ProjectorObj p) return p.worldCF().times(cf);
        return cf;
    }
    public String worldDim() {
        if (attachEnt != null && attachEnt.raw() != null) return attachEnt.raw().level().dimension().location().toString();
        if (parent instanceof ProjectorObj p) return p.worldDim();
        return dim;
    }

    @Override protected void onDestroy() {
        Projector.Reg r = Projector.reg(rt);
        r.objs.remove(id);
        r.send(new Pkt(Pkt.S_PROJ, List.of("del"), new int[]{id}, null));
    }

    // ------------------------------------------------------------------ replication
    String stateString() {
        CFrameL w = worldCF();
        double[] r = w.r;
        StringBuilder b = new StringBuilder();
        double[] vals = {w.x, w.y, w.z, r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], sx, sy, sz, transparency, speed, time};
        for (int i = 0; i < vals.length; i++) { if (i > 0) b.append(','); b.append((float) vals[i]); }
        return b.toString();
    }

    void flush(Projector.Reg r) {
        if (dirtyMesh) {
            dirtyMesh = false; dirtyTex = false; sentAdd = true;
            r.sendLarge(new Pkt(Pkt.S_PROJ, List.of("add", name), new int[]{id}, mesh.toBytes()));
            dirtyState = true;
        }
        if (dirtyTex) { dirtyTex = false; r.sendLarge(new Pkt(Pkt.S_PROJ, List.of("tex"), new int[]{id}, mesh.texture)); }
        boolean moving = attachEnt != null || parent instanceof ProjectorObj;
        if (dirtyState || moving) {
            dirtyState = false;
            String d = worldDim();
            boolean show = visible && inWorld() && d != null;
            r.send(new Pkt(Pkt.S_PROJ, List.of("state", d == null ? "" : d, anim == null ? "" : anim, stateString(), String.join(",", hiddenParts())),
                    new int[]{id, show ? 1 : 0, playing && !paused ? 1 : 0, loop ? 1 : 0, attachEnt != null && attachEnt.raw() != null ? attachEnt.raw().getId() : -1}, null));
        }
    }

    List<String> hiddenParts() { List<String> l = new ArrayList<>(); for (Mesh.Part p : mesh.parts) if (!p.visible) l.add(p.name.replace(",", "_")); return l; }

    void tickAnim() {
        if (!playing || paused) return;
        Mesh.Anim a = mesh.findAnim(anim);
        if (a == null) { playing = false; return; }
        double old = time;
        time += speed / 20.0;
        if (listens("E_AnimationKey")) {
            TreeSet<Float> keys = new TreeSet<>();
            for (Mesh.Channel c : a.ch) for (float t : c.times) keys.add(t);
            for (Float k : keys.subSet((float) old, false, (float) Math.min(time, a.duration), true)) fire("E_AnimationKey", valueOf(a.name), valueOf(k));
        }
        if (a.duration > 0 && time >= a.duration) {
            if (loop) time %= a.duration;
            else { time = a.duration; playing = false; dirtyState = true; fire("E_AnimationEnd", valueOf(a.name)); }
        }
    }

    // ------------------------------------------------------------------ geometry helpers
    /** local (mesh) -> world transform including scale */
    Vec3L toWorld(CFrameL w, double x, double y, double z) { return w.point(new Vec3L(x * sx, y * sy, z * sz)); }

    public double[] worldBounds() {
        float[] b = mesh.bounds();
        CFrameL w = worldCF();
        double[] o = {Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE};
        for (int i = 0; i < 8; i++) {
            Vec3L p = toWorld(w, (i & 1) == 0 ? b[0] : b[3], (i & 2) == 0 ? b[1] : b[4], (i & 4) == 0 ? b[2] : b[5]);
            o[0] = Math.min(o[0], p.x); o[1] = Math.min(o[1], p.y); o[2] = Math.min(o[2], p.z);
            o[3] = Math.max(o[3], p.x); o[4] = Math.max(o[4], p.y); o[5] = Math.max(o[5], p.z);
        }
        return o;
    }

    /** ray in world space against every triangle; returns {t, nx, ny, nz} or null */
    public double[] ray(Vec3L origin, Vec3L dir, double max) {
        CFrameL w = worldCF();
        Vec3L d = dir.unit();
        double best = max; double[] res = null;
        for (float[] v : mesh.posed()) {
            for (int i = 0; i + 23 < v.length; i += 24) {
                Vec3L a = toWorld(w, v[i], v[i + 1], v[i + 2]), b = toWorld(w, v[i + 8], v[i + 9], v[i + 10]), c = toWorld(w, v[i + 16], v[i + 17], v[i + 18]);
                Vec3L e1 = b.sub(a), e2 = c.sub(a), p = d.cross(e2);
                double det = e1.dot(p);
                if (Math.abs(det) < 1e-9) continue;
                double inv = 1 / det;
                Vec3L s = origin.sub(a);
                double u = s.dot(p) * inv; if (u < 0 || u > 1) continue;
                Vec3L q = s.cross(e1);
                double vv = d.dot(q) * inv; if (vv < 0 || u + vv > 1) continue;
                double t = e2.dot(q) * inv;
                if (t >= 0 && t < best) { best = t; Vec3L n = e1.cross(e2).unit(); res = new double[]{t, n.x, n.y, n.z}; }
            }
        }
        return res;
    }

    public RayResult raycast(Vec3L origin, Vec3L dir, double max) {
        double[] h = ray(origin, dir, max);
        if (h == null) return new RayResult(false, null, null, null, null, max);
        return new RayResult(true, origin.add(dir.unit().scale(h[0])), new Vec3L(h[1], h[2], h[3]), this, null, h[0]);
    }

    public ProjectorObj copyObj() {
        ProjectorObj c = new ProjectorObj(mesh.copy());
        c.name = name; c.source = source; c.format = format; c.objClass = objClass; c.cf = cf; c.sx = sx; c.sy = sy; c.sz = sz;
        c.visible = visible; c.collision = collision; c.anchored = anchored; c.transparency = transparency; c.material = material;
        c.texture = texture; c.gui = gui; c.tags.addAll(tags); c.nbt.merge(nbt.copy()); c.anim = anim; c.loop = loop; c.speed = speed;
        for (LObj ch : listChildren()) if (ch instanceof ProjectorObj p) p.copyObj().setParent(c);
        return c;
    }

    @Override protected LuaValue cloneObj() { return copyObj(); }

    // ------------------------------------------------------------------ properties
    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Class": return valueOf(objClass);
            case "CFrame": return cf;
            case "WorldCFrame": return worldCF();
            case "Position": return cf.pos();
            case "Scale": return new Vec3L(sx, sy, sz);
            case "Size": { float[] b = mesh.bounds(); return new Vec3L((b[3] - b[0]) * sx, (b[4] - b[1]) * sy, (b[5] - b[2]) * sz); }
            case "Visible": return valueOf(visible);
            case "Transparency": return valueOf(transparency);
            case "Material": return valueOf(material);
            case "Texture": return valueOf(texture);
            case "Vertices": return valueOf(mesh.vertexCount());
            case "Polygons": return valueOf(mesh.triangleCount());
            case "Bones": { LuaTable t = new LuaTable(); int i = 1; for (Mesh.Node n : mesh.nodes) t.set(i++, valueOf(n.name)); return t; }
            case "Animations": { LuaTable t = new LuaTable(); int i = 1; for (Mesh.Anim a : mesh.anims) t.set(i++, new Projector.AnimInfo(a)); return t; }
            case "Meshes": { LuaTable t = new LuaTable(); int i = 1; for (Mesh.Part p : mesh.parts) t.set(i++, new Projector.MeshPart(this, p)); return t; }
            case "Children": return list(listChildren());
            case "Tags": { LuaTable t = new LuaTable(); int i = 1; for (String s : tags) t.set(i++, valueOf(s)); return t; }
            case "NBTs": return Conv.toLua(nbt);
            case "GUI": return gui == null ? NIL : valueOf(gui);
            case "Collision": case "CanCollide": return valueOf(collision);
            case "Anchored": return valueOf(anchored);
            case "Loaded": return valueOf(loaded);
            case "Source": return valueOf(source);
            case "Format": return valueOf(format);
            case "Playing": return valueOf(playing && !paused);
            case "Animation": return anim == null ? NIL : valueOf(anim);
            case "AnimationTime": return valueOf(time);
            case "LOD": return valueOf(lod);
            case "Dimension": { String d = worldDim(); return d == null ? NIL : valueOf(d); }
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "CFrame": cf = CFrameL.check(v); dirtyState = true; return true;
            case "Position": { Vec3L p = Vec3L.check(v); cf = new CFrameL(p.x, p.y, p.z, cf.r); dirtyState = true; return true; }
            case "Scale": setScale(v); return true;
            case "Visible": visible = v.toboolean(); dirtyState = true; return true;
            case "Transparency": transparency = Math.max(0, Math.min(1, v.checkdouble())); dirtyState = true; return true;
            case "Material": Projector.setMaterial(this, v); return true;
            case "Texture": Projector.setTexture(this, v.checkjstring()); return true;
            case "Tags": tags.clear(); if (v.istable()) for (int i = 1; i <= v.length(); i++) tags.add(v.get(i).tojstring()); else if (!v.isnil()) tags.add(v.tojstring()); return true;
            case "Collision": case "CanCollide": collision = v.toboolean(); return true;
            case "Anchored": anchored = v.toboolean(); return true;
            case "Class": objClass = v.checkjstring(); return true;
        }
        return super.setProp(k, v);
    }

    void setScale(LuaValue v) {
        if (v.isnumber()) sx = sy = sz = v.todouble();
        else { Vec3L s = Vec3L.check(v); sx = s.x; sy = s.y; sz = s.z; }
        dirtyState = true;
    }

    public void play(String name, double sp, boolean lp) {
        Mesh.Anim a = mesh.findAnim(name);
        if (a == null) { fire("E_Error", valueOf("NO_ANIMATION"), valueOf("Animation not found: " + (name == null ? "(first)" : name))); return; }
        anim = a.name; speed = sp; loop = lp; time = 0; playing = true; paused = false; dirtyState = true;
        fire("E_AnimationStart", valueOf(a.name));
    }

    public void interact(PlayerObj p) {
        fire("E_Interacted", p == null ? NIL : p);
        if (gui != null && p != null) {
            if (rt.server) { if (p.raw() instanceof net.minecraft.server.level.ServerPlayer sp) net.idea.fluwa.net.FluwaNet.toPlayer(sp, new Pkt(Pkt.S_SCREEN, gui)); }
            else if (Projector.CLIENT_OPEN_GUI != null) Projector.CLIENT_OPEN_GUI.accept(gui);
        }
    }

    static ProjectorObj self(LObj s) { return (ProjectorObj) s; }

    static {
        Class<ProjectorObj> C = ProjectorObj.class;
        reg(C, "SetCFrame|PivotTo", (s, a) -> { self(s).setProp("CFrame", a.arg1()); return NONE; });
        reg(C, "GetCFrame", (s, a) -> self(s).cf);
        reg(C, "SetPosition", (s, a) -> { self(s).setProp("Position", a.arg1()); return NONE; });
        reg(C, "GetPosition", (s, a) -> self(s).cf.pos());
        reg(C, "SetScale", (s, a) -> { self(s).setScale(a.arg1()); return NONE; });
        reg(C, "GetScale", (s, a) -> self(s).getProp("Scale"));
        reg(C, "SetVisible", (s, a) -> { self(s).setProp("Visible", a.arg1()); return NONE; });
        reg(C, "SetTransparency", (s, a) -> { self(s).setProp("Transparency", a.arg1()); return NONE; });
        reg(C, "SetMaterial", (s, a) -> { Projector.setMaterial(self(s), a.arg1()); return NONE; });
        reg(C, "SetTexture", (s, a) -> { Projector.setTexture(self(s), a.checkjstring(1)); return NONE; });
        reg(C, "GetBone", (s, a) -> Projector.bone(self(s), a.checkjstring(1)));
        reg(C, "SetBone", (s, a) -> { Projector.setBone(self(s), a.checkjstring(1), CFrameL.check(a.arg(2))); return NONE; });
        reg(C, "PlayAnimation", (s, a) -> { self(s).play(a.optjstring(1, null), a.optdouble(2, 1), a.optboolean(3, true)); return NONE; });
        reg(C, "StopAnimation", (s, a) -> { ProjectorObj o = self(s); if (o.playing) o.fire("E_AnimationEnd", valueOf(String.valueOf(o.anim)));
            o.playing = false; o.time = 0; for (Mesh.Node n : o.mesh.nodes) n.restore(); o.dirtyState = true; return NONE; });
        reg(C, "PauseAnimation", (s, a) -> { ProjectorObj o = self(s); o.paused = !o.paused; o.dirtyState = true; return NONE; });
        reg(C, "Export", (s, a) -> valueOf(Projector.export(self(s), a.checkjstring(1), a.optjstring(2, null))));
        reg(C, "Raycast", (s, a) -> self(s).raycast(Vec3L.check(a.arg(1)), Vec3L.check(a.arg(2)), a.optdouble(3, 512)));
        reg(C, "SetNBT", (s, a) -> { ProjectorObj o = self(s); if (a.isnil(2)) o.nbt.remove(a.checkjstring(1)); else o.nbt.put(a.checkjstring(1), Conv.toTag(a.arg(2))); return NONE; });
        reg(C, "GetNBT|ReadNBT", (s, a) -> { ProjectorObj o = self(s); var t = o.nbt.get(a.checkjstring(1)); return t == null ? NIL : Conv.toLua(t); });
        reg(C, "GetNBTs", (s, a) -> Conv.toLua(self(s).nbt));
        reg(C, "Use", (s, a) -> { self(s).fire("E_Used", a.arg1()); return NONE; });
        reg(C, "Attack", (s, a) -> { self(s).fire("E_Attacked", a.arg1()); return NONE; });
        reg(C, "Interact", (s, a) -> { self(s).interact(a.arg1() instanceof PlayerObj p ? p : null); return NONE; });
        reg(C, "SetGUI", (s, a) -> { self(s).gui = a.isnil(1) ? null : a.arg1() instanceof LObj o ? o.getName() : a.checkjstring(1); return NONE; });
        reg(C, "GetGUI", (s, a) -> self(s).getProp("GUI"));
        reg(C, "HasTag", (s, a) -> valueOf(self(s).tags.contains(a.checkjstring(1))));
        reg(C, "AddTag", (s, a) -> { self(s).tags.add(a.checkjstring(1)); return NONE; });
        reg(C, "RemoveTag", (s, a) -> { self(s).tags.remove(a.checkjstring(1)); return NONE; });
        reg(C, "Inspect", (s, a) -> Projector.inspect(self(s)));
    }
}
