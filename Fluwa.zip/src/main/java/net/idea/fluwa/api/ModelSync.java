package net.idea.fluwa.api;

import net.idea.fluwa.mesh.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.idea.fluwa.server.ScriptManager;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import org.luaj.vm2.LuaError;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Player:SetModel / Entity:SetModel (Server-Side):
 *   "name.obj|.gltf|.glb|.fbx" - 3D model from <world>/fluwa/models/ (textures: embedded, referenced, or same name .png)
 *   "minecraft:zombie"         - look like an entity type
 *   nil / ""                   - normal model
 */
public final class ModelSync {
    private ModelSync() {}
    public record Model(String kind, String entity, Mesh mesh, byte[] bytes, float scale, String desc) {}
    static final Map<UUID, Model> MODELS = new ConcurrentHashMap<>();
    /** hidden model parts per entity (server authoritative): uuid -> part names */
    static final Map<UUID, Set<String>> HIDDEN = new ConcurrentHashMap<>();

    public static Path modelsDir() {
        if (ScriptManager.root == null) throw new LuaError("Fluwa scripts folder is not ready");
        return ScriptManager.root.resolve("models");
    }

    /** resolve a model path inside <world>/fluwa/models */
    public static Path resolve(String arg) {
        Path dir = modelsDir().toAbsolutePath().normalize();
        Path f = dir.resolve(arg).normalize();
        if (!f.startsWith(dir)) throw new LuaError("Model path must stay inside fluwa/models: " + arg);
        if (!Files.isRegularFile(f)) throw new LuaError("Model not found: " + f + " (put model files into <world>/fluwa/models)");
        return f;
    }

    public static Mesh loadMesh(String arg) {
        try { return MeshCache.get(resolve(arg)); }
        catch (IOException e) { throw new LuaError("Can't load model " + arg + ": " + e.getMessage()); }
        catch (RuntimeException e) { if (e instanceof LuaError le) throw le; throw new LuaError("Can't load model " + arg + ": " + e); }
    }

    public static void set(Entity p, String arg, float scale) {
        UUID id = p.getUUID();
        if (arg == null || arg.isBlank()) { MODELS.remove(id); FluwaNet.toAll(new Pkt(Pkt.S_MODEL, id.toString(), "", "", "1")); return; }
        Model m;
        if (MeshLoader.supported(arg)) {
            Mesh mesh = loadMesh(arg);
            m = new Model("mesh", "", mesh, mesh.toBytes(), scale, arg);
        } else {
            ResourceLocation rid = ResourceLocation.tryParse(arg.contains(":") ? arg : "minecraft:" + arg);
            if (rid == null || !BuiltInRegistries.ENTITY_TYPE.containsKey(rid))
                throw new LuaError("Unknown model / entity type: " + arg + " (use a .obj/.gltf/.glb/.fbx file or an entity id)");
            if (rid.equals(BuiltInRegistries.ENTITY_TYPE.getKey(p.getType()))) { set(p, null, 1); return; }
            m = new Model("entity", rid.toString(), null, new byte[0], scale, rid.toString());
        }
        MODELS.put(id, m);
        FluwaNet.toAllLarge(packet(id, m));
    }

    public static Model model(UUID id) { return MODELS.get(id); }
    public static String get(UUID id) { Model m = MODELS.get(id); return m == null ? null : m.desc; }

    public static void setHidden(UUID id, String part, boolean hidden) {
        Set<String> s = HIDDEN.computeIfAbsent(id, k -> ConcurrentHashMap.newKeySet());
        if (hidden) s.add(part); else s.remove(part);
        FluwaNet.toAll(new Pkt(Pkt.S_MODELPART, List.of(id.toString(), part), new int[]{hidden ? 1 : 0}, null));
    }
    /** per-part transforms (offset xyz in blocks, rotation xyz in degrees, scale xyz): uuid -> part -> 9 floats */
    static final Map<UUID, Map<String, float[]>> XF = new ConcurrentHashMap<>();
    public static final float[] IDENTITY_XF = {0, 0, 0, 0, 0, 0, 1, 1, 1};
    public static String xfString(float[] f) {
        if (f == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 9; i++) { if (i > 0) b.append(','); b.append(f[i]); }
        return b.toString();
    }
    public static float[] parseXf(String s) {
        if (s == null || s.isBlank()) return null;
        String[] p = s.split(",");
        float[] f = IDENTITY_XF.clone();
        for (int i = 0; i < Math.min(9, p.length); i++) try { f[i] = Float.parseFloat(p[i].trim()); } catch (NumberFormatException ignored) {}
        return f;
    }
    public static boolean isIdentity(float[] f) { return f == null || java.util.Arrays.equals(f, IDENTITY_XF); }
    public static void setTransform(UUID id, String part, float[] xf) {
        if (isIdentity(xf)) { Map<String, float[]> m = XF.get(id); if (m != null) m.remove(part); xf = null; }
        else XF.computeIfAbsent(id, k -> new ConcurrentHashMap<>()).put(part, xf.clone());
        FluwaNet.toAll(new Pkt(Pkt.S_MODELPART, List.of(id.toString(), part, xfString(xf)), new int[]{2}, null));
    }
    public static float[] transform(UUID id, String part) { Map<String, float[]> m = XF.get(id); float[] f = m == null ? null : m.get(part); return f == null ? IDENTITY_XF.clone() : f.clone(); }
    /** all parts with a transform or hidden flag (for editors) */
    /** v0.5.2: model part names per entity type, reported by clients (ModelParts.report) */
    static final Map<String, List<String>> PART_NAMES = new ConcurrentHashMap<>();
    public static void clientParts(List<String> rows) {
        if (rows.size() > 400) return;
        for (String r : rows) {
            int t = r.indexOf('\t');
            if (t <= 0 || r.length() > 6000) continue;
            String type = r.substring(0, t);
            List<String> n = new ArrayList<>();
            for (String x : r.substring(t + 1).split(",")) if (!x.isBlank() && x.length() <= 64 && n.size() < 300) n.add(x.trim());
            if (!n.isEmpty()) PART_NAMES.put(type, List.copyOf(n));
        }
    }
    static final List<String> HUMANOID = List.of("Head", "Hat", "Body", "RightArm", "LeftArm", "RightLeg", "LeftLeg");
    static boolean humanoidType(String type) {
        return type.matches("minecraft:(player|zombie|husk|drowned|zombie_villager|skeleton|stray|wither_skeleton|armor_stand|piglin|piglin_brute|zombified_piglin|giant|vindicator|evoker|pillager|illusioner)");
    }
    /** part names of an entity's model (custom mesh parts, or the vanilla/mod model parts reported by clients) */
    public static List<String> partNames(Entity e) {
        UUID id = e.getUUID();
        Model m = MODELS.get(id);
        LinkedHashSet<String> n = new LinkedHashSet<>();
        if (m != null && m.mesh() != null) for (var p : m.mesh().parts) n.add(p.name);
        else {
            String type = m != null && m.kind().equals("entity") ? m.entity()
                    : e instanceof net.minecraft.world.entity.player.Player ? "minecraft:player" : String.valueOf(BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()));
            List<String> k = PART_NAMES.get(type);
            if (k != null) n.addAll(k);
            else if (humanoidType(type)) n.addAll(HUMANOID);
        }
        n.addAll(touchedParts(id));
        n.remove("Model");
        return new ArrayList<>(n);
    }

    public static Set<String> touchedParts(UUID id) {
        Set<String> s = new LinkedHashSet<>();
        Set<String> h = HIDDEN.get(id); if (h != null) s.addAll(h);
        Map<String, float[]> m = XF.get(id); if (m != null) s.addAll(m.keySet());
        return s;
    }

    public static boolean hidden(UUID id, String part) { Set<String> s = HIDDEN.get(id); return s != null && s.contains(part); }

    static Pkt packet(UUID id, Model m) {
        return new Pkt(Pkt.S_MODEL, List.of(id.toString(), m.kind, m.entity, Float.toString(m.scale), m.desc), null, m.bytes);
    }

    public static void sendAll(ServerPlayer to) {
        MODELS.forEach((k, v) -> FluwaNet.toPlayerLarge(to, packet(k, v)));
        HIDDEN.forEach((k, s) -> { for (String p : s) FluwaNet.toPlayer(to, new Pkt(Pkt.S_MODELPART, List.of(k.toString(), p), new int[]{1}, null)); });
        XF.forEach((k, m) -> m.forEach((p, f) -> FluwaNet.toPlayer(to, new Pkt(Pkt.S_MODELPART, List.of(k.toString(), p, xfString(f)), new int[]{2}, null))));
    }
    public static void clear() { MODELS.clear(); HIDDEN.clear(); XF.clear(); MeshCache.clear(); }
}
