package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.luaj.vm2.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Roblox-style tweens for world objects (server + client runtimes).
 *
 *   obj:TweenPosition(endPos, [direction="Out"], [style="Quad"], [time=1], [override=false], [callback])  -> bool
 *   obj:TweenCFrame(endCFrame, [direction], [style], [time], [override], [callback])                     -> bool
 *   (an extra boolean canCollide may follow the callback, or replace it: ..., override, canCollide, callback; default true)
 *   obj:CancelTween()  -> bool       obj:IsTweening() -> bool
 *
 * Supported: Block, Entity (+ Player), Chunk, Structure (after Structure:Place).
 *
 * Smoothness: the server only decides start / end, every client animates the tween itself at its frame rate:
 *  - Entities: the client places the entity on the exact eased curve every tick (render interpolation does the rest),
 *    the server moves it quietly (no teleport packets) and teleports it to the goal at the end.
 *  - Blocks / Chunks / Structures ("ghost" tweens): the real blocks are lifted out of the world, clients draw a
 *    baked copy (vertex buffer) that glides along the curve, and at the end the blocks are put back at the goal
 *    (block entities / NBT / Fluwa BlockData are kept). Goals are snapped to the block (chunk) grid.
 */
public final class WorldTween {
    private WorldTween() {}

    /** client sink for tweens started by client runtimes (set by client.ClientTween) */
    public static volatile java.util.function.Consumer<Pkt> LOCAL;

    /** how one kind of world object is read / moved */
    public interface Mover {
        Vec3L position(LObj o);
        Level level(LObj o);
        /** null = object has no rotation */
        default CFrameL cframe(LObj o) { return null; }
        /** snaps the goal to the grid the object lives on */
        default Vec3L snap(LObj o, Vec3L p) { return p; }
        /** world blocks of a ghost tween, null for entities */
        default List<BlockPos> blocks(LObj o) { return null; }
        default Entity entity(LObj o) { return null; }
        /** puts the object at its final place */
        void finish(LObj o, Vec3L pos, CFrameL rot);
    }

    record Cap(BlockPos pos, BlockState state, CompoundTag nbt) {}

    static final class T {
        int id; FluwaRuntime rt; LObj obj; Mover mv; Level level;
        Vec3L p0, p1; float yaw0, yaw1, pitch0, pitch1; boolean rot;
        String dir, style; double time; long start; LuaValue cb;
        List<Cap> ghost; BlockPos origin; byte[] payload;
        Entity ent; boolean noGravity;
        boolean collide; Map<BlockPos, BlockState> shape; BlockPos min, max; Vec3 lastOff;
    }

    static Vec3 off(T t) { Vec3L p = lerp(t, eased(t, t.rt.tick)); return new Vec3(p.x, p.y, p.z); }

    static {
        // moving tween blocks with CanCollide = true
        Colliders.SOURCES.add((level, who, box, out) -> {
            for (T t : WorldTween.ALL.values()) {
                if (t.level != level || !t.collide || t.shape == null || t.ghost == null) continue;
                Colliders.group(t.shape, off(t), box, out);
            }
        });
    }

    private static final String KEY = "fluwa.worldTweens";
    static final AtomicInteger IDS = new AtomicInteger(1);
    /** every running tween (resent to players that join / change dimension) */
    static final Map<Integer, T> ALL = new ConcurrentHashMap<>();
    static final int MAX_GHOST_BLOCKS = 200_000;

    @SuppressWarnings("unchecked")
    static Map<LObj, T> active(FluwaRuntime rt) {
        Object m = rt.state.get(KEY);
        if (m != null) return (Map<LObj, T>) m;
        Map<LObj, T> nm = new LinkedHashMap<>();
        rt.state.put(KEY, nm);
        rt.tickers.add(() -> tick(rt, nm));
        rt.onClose(() -> {
            for (T t : new ArrayList<>(nm.values())) {
                nm.remove(t.obj);
                try { complete(t, t.p1, t.rot ? t.yaw1 : 0, t.rot ? t.pitch1 : 0, false); } catch (RuntimeException ignored) {}
            }
        });
        return nm;
    }

    static FluwaRuntime rtOf(LObj o) {
        FluwaRuntime rt = o.rt != null ? o.rt : FluwaRuntime.current();
        if (rt == null) throw new LuaError("Tween: no running script");
        return rt;
    }

    // ================================================================ start
    static LuaValue start(LObj o, Mover mv, Varargs a, boolean cframe) {
        FluwaRuntime rt = rtOf(o);
        T t = new T();
        t.rt = rt; t.obj = o; t.mv = mv;
        t.p0 = mv.position(o);
        Vec3L goal;
        if (cframe) {
            CFrameL g = CFrameL.check(a.arg(1));
            goal = g.pos();
            CFrameL c0 = mv.cframe(o);
            if (c0 != null) {
                t.rot = true;
                t.yaw0 = c0.mcYaw(); t.pitch0 = c0.mcPitch(); t.pitch1 = g.mcPitch();
                float d = ((g.mcYaw() - t.yaw0) % 360 + 540) % 360 - 180; // shortest way around
                t.yaw1 = t.yaw0 + d;
            }
        } else goal = Vec3L.check(a.arg(1));
        t.p1 = mv.snap(o, goal);
        t.dir = Easing.name(a.arg(2), "Out");
        t.style = Easing.name(a.arg(3), "Quad");
        t.time = Math.max(0, a.optdouble(4, 1));
        boolean override = a.optboolean(5, false);
        // ..., callback, canCollide   or   ..., canCollide, callback
        if (a.arg(6).isboolean()) { t.collide = a.arg(6).toboolean(); t.cb = a.arg(7); }
        else { t.cb = a.arg(6); t.collide = a.optboolean(7, true); }
        Map<LObj, T> m = active(rt);
        T cur = m.get(o);
        if (cur != null) {
            if (!override) return LuaValue.FALSE;
            stopAtCurrent(rt, m, cur);
            t.p0 = mv.position(o);
            if (t.rot) { CFrameL c0 = mv.cframe(o); if (c0 != null) { t.yaw0 = c0.mcYaw(); t.pitch0 = c0.mcPitch(); } }
        }
        t.level = mv.level(o);
        t.start = rt.tick;
        t.id = IDS.getAndIncrement();
        if (t.time > 0 && t.level != null) begin(t);
        m.put(o, t);
        if (t.level != null && t.time > 0) { ALL.put(t.id, t); send(t, startPkt(t)); }
        if (t.time <= 0) step(rt, m, t);
        return LuaValue.TRUE;
    }

    /** lifts ghost blocks out of the world / prepares the entity */
    static void begin(T t) {
        List<BlockPos> bs = t.mv.blocks(t.obj);
        if (bs != null) {
            Level l = t.level;
            t.origin = t.p0.pos();
            List<Cap> caps = new ArrayList<>();
            for (BlockPos p : bs) {
                BlockState st = l.getBlockState(p);
                if (st.isAir()) continue;
                BlockEntity be = l.getBlockEntity(p);
                caps.add(new Cap(p.immutable(), st, be == null ? null : be.saveWithoutMetadata()));
            }
            if (caps.size() > MAX_GHOST_BLOCKS) throw new LuaError("Tween: too many blocks (" + caps.size() + ")");
            t.payload = payload(l, caps, t.origin);
            // lift out: no drops, no neighbour reactions
            BlockState air = Blocks.AIR.defaultBlockState();
            for (Cap c : caps) {
                if (c.nbt() != null) l.removeBlockEntity(c.pos());
                l.setBlock(c.pos(), air, 2 | 16 | 32);
            }
            t.ghost = caps;
            t.shape = new HashMap<>();
            int[] mn = {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE}, mx = {Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE};
            for (Cap c : caps) {
                BlockPos r = c.pos().subtract(t.origin);
                t.shape.put(r, c.state());
                mn[0] = Math.min(mn[0], r.getX()); mn[1] = Math.min(mn[1], r.getY()); mn[2] = Math.min(mn[2], r.getZ());
                mx[0] = Math.max(mx[0], r.getX()); mx[1] = Math.max(mx[1], r.getY()); mx[2] = Math.max(mx[2], r.getZ());
            }
            if (!caps.isEmpty()) { t.min = new BlockPos(mn[0], mn[1], mn[2]); t.max = new BlockPos(mx[0], mx[1], mx[2]); }
            t.lastOff = new Vec3(t.p0.x, t.p0.y, t.p0.z);
        } else {
            t.ent = t.mv.entity(t.obj);
            if (t.ent != null) { t.noGravity = t.ent.isNoGravity(); t.ent.setNoGravity(true); }
        }
    }

    /** exposed blocks (palette + positions relative to origin + light) for the clients, gzip NBT */
    static byte[] payload(Level l, List<Cap> caps, BlockPos origin) {
        Map<BlockPos, BlockState> set = new HashMap<>();
        for (Cap c : caps) set.put(c.pos(), c.state());
        Map<BlockState, Integer> pal = new LinkedHashMap<>();
        int[] buf = new int[caps.size() * 5]; int n = 0;
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (Cap c : caps) {
            boolean hidden = true;
            for (Direction d : Direction.values()) {
                q.setWithOffset(c.pos(), d);
                BlockState ns = set.get(q);
                if (ns == null || !ns.isSolidRender(l, q)) { hidden = false; break; }
            }
            if (hidden) continue; // fully enclosed - never visible while moving
            int sky = l.getBrightness(LightLayer.SKY, c.pos()), blk = l.getBrightness(LightLayer.BLOCK, c.pos());
            for (Direction d : Direction.values()) {
                q.setWithOffset(c.pos(), d);
                if (set.containsKey(q)) continue;
                sky = Math.max(sky, l.getBrightness(LightLayer.SKY, q)); blk = Math.max(blk, l.getBrightness(LightLayer.BLOCK, q));
            }
            int idx = pal.computeIfAbsent(c.state(), k -> pal.size());
            buf[n++] = c.pos().getX() - origin.getX(); buf[n++] = c.pos().getY() - origin.getY(); buf[n++] = c.pos().getZ() - origin.getZ();
            buf[n++] = idx; buf[n++] = sky << 4 | blk;
        }
        CompoundTag t = new CompoundTag();
        ListTag pl = new ListTag();
        for (BlockState s : pal.keySet()) pl.add(NbtUtils.writeBlockState(s));
        t.put("pal", pl);
        t.putIntArray("b", Arrays.copyOf(buf, n));
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            NbtIo.writeCompressed(t, out);
            return out.toByteArray();
        } catch (IOException e) { throw new LuaError("Tween: " + e); }
    }

    // ================================================================ ticking
    static void tick(FluwaRuntime rt, Map<LObj, T> m) {
        if (m.isEmpty()) return;
        for (T t : new ArrayList<>(m.values())) step(rt, m, t);
    }

    static double eased(T t, long tick) {
        double f = t.time <= 0 ? 1 : Math.min(1, Math.max(0, (tick - t.start) / 20.0 / t.time));
        return f >= 1 ? 1 : Easing.ease(f, t.dir, t.style);
    }
    static Vec3L lerp(T t, double e) {
        return new Vec3L(t.p0.x + (t.p1.x - t.p0.x) * e, t.p0.y + (t.p1.y - t.p0.y) * e, t.p0.z + (t.p1.z - t.p0.z) * e);
    }

    static void step(FluwaRuntime rt, Map<LObj, T> m, T t) {
        if (m.get(t.obj) != t) return;
        if (t.obj.destroyed) { m.remove(t.obj); drop(t); done(rt, t, "Canceled"); return; }
        boolean finished = t.time <= 0 || (rt.tick - t.start) / 20.0 >= t.time;
        try {
            if (finished) { m.remove(t.obj); complete(t, t.p1, t.yaw1, t.pitch1, true); return; }
            if (t.ent != null) quiet(t, eased(t, rt.tick));
            if (t.ghost != null && t.collide) carry(t);
        } catch (RuntimeException ex) {
            m.remove(t.obj);
            drop(t);
            rt.reportError("[Tween " + t.obj.className + "] " + (ex instanceof LuaError le ? le.getMessage() : ex.toString()));
            done(rt, t, "Canceled");
        }
    }

    /** mobs / items standing on a moving collidable group ride along (players are carried by their client) */
    static void carry(T t) {
        Vec3 now = off(t), prev = t.lastOff;
        t.lastOff = now;
        if (prev == null || t.min == null || t.level.isClientSide) return;
        Vec3 d = now.subtract(prev);
        if (d.lengthSqr() < 1e-10) return;
        AABB area = new AABB(prev.x + t.min.getX(), prev.y + t.min.getY(), prev.z + t.min.getZ(),
                prev.x + t.max.getX() + 1, prev.y + t.max.getY() + 2.5, prev.z + t.max.getZ() + 1).inflate(1);
        area = area.expandTowards(d.x, d.y, d.z);
        for (Entity e : t.level.getEntities((Entity) null, area, x -> !(x instanceof net.minecraft.world.entity.player.Player) && !x.isPassenger()))
            Colliders.pushCarry(e, t.shape, prev, now);
    }

    /** server-side entity position while tweening (no teleport packets - clients animate it themselves) */
    static void quiet(T t, double e) {
        Entity en = t.ent;
        Vec3L p = lerp(t, e);
        en.setPos(p.x, p.y, p.z);
        if (t.rot) {
            float yaw = (float) (t.yaw0 + (t.yaw1 - t.yaw0) * e), pitch = (float) (t.pitch0 + (t.pitch1 - t.pitch0) * e);
            en.setYRot(yaw); en.setXRot(pitch); en.setYHeadRot(yaw);
        }
        en.setDeltaMovement(Vec3.ZERO);
        en.fallDistance = 0;
    }

    /** puts the object at pos and ends the tween */
    static void complete(T t, Vec3L pos, float yaw, float pitch, boolean callback) {
        ALL.remove(t.id);
        try {
            restore(t);
            CFrameL rot = t.rot ? CFrameL.fromYawPitch(pos, yaw, pitch) : null;
            if (t.ent != null) t.ent.setNoGravity(t.noGravity);
            t.mv.finish(t.obj, pos, rot);
            if (t.ent != null) { t.ent.setDeltaMovement(Vec3.ZERO); t.ent.fallDistance = 0; }
        } finally {
            if (t.level != null && t.time > 0) send(t, endPkt(t, pos, false));
        }
        if (callback) done(t.rt, t, "Completed");
    }

    /** cancel / override: stop where the object is now (snapped to its grid) */
    static void stopAtCurrent(FluwaRuntime rt, Map<LObj, T> m, T t) {
        m.remove(t.obj);
        double e = eased(t, rt.tick);
        Vec3L at = t.mv.snap(t.obj, lerp(t, e));
        complete(t, at, (float) (t.yaw0 + (t.yaw1 - t.yaw0) * e), (float) (t.pitch0 + (t.pitch1 - t.pitch0) * e), false);
        done(rt, t, "Canceled");
    }

    /** object destroyed / failed: put lifted blocks back where they were (unless destroyed) and stop drawing */
    static void drop(T t) {
        ALL.remove(t.id);
        try {
            if (!t.obj.destroyed) restore(t);
            if (t.ent != null) t.ent.setNoGravity(t.noGravity);
        } catch (RuntimeException ignored) {}
        if (t.level != null && t.time > 0) send(t, endPkt(t, null, true));
    }

    /** lifted blocks back to their original place (the Mover then moves them like MoveTo, all in one tick -> no flicker) */
    static void restore(T t) {
        if (t.ghost == null) return;
        List<Cap> g = t.ghost; t.ghost = null;
        for (Cap c : g) {
            t.level.setBlock(c.pos(), c.state(), 2 | 16);
            if (c.nbt() != null) { BlockEntity be = t.level.getBlockEntity(c.pos()); if (be != null) be.load(c.nbt()); }
        }
    }

    static void done(FluwaRuntime rt, T t, String status) {
        if (t.cb != null && t.cb.isfunction()) rt.callAsync(t.cb, LuaValue.valueOf(status), "Tween callback");
    }

    static LuaValue cancel(LObj o) {
        FluwaRuntime rt = rtOf(o);
        Map<LObj, T> m = active(rt);
        T t = m.get(o);
        if (t == null) return LuaValue.FALSE;
        stopAtCurrent(rt, m, t);
        return LuaValue.TRUE;
    }

    // ================================================================ network
    static String v(Vec3L p) { return p.x + "," + p.y + "," + p.z; }

    /** s: start, id, dim, kind(e/g), entityId, durationMs, elapsedMs, dir, style, from, to, rot, origin */
    static Pkt startPkt(T t) {
        long elapsedMs = Math.max(0, (t.rt.tick - t.start) * 50);
        String rot = t.rot ? t.yaw0 + "," + t.yaw1 + "," + t.pitch0 + "," + t.pitch1 : "";
        String origin = t.origin == null ? "" : t.origin.getX() + "," + t.origin.getY() + "," + t.origin.getZ();
        return new Pkt(Pkt.S_TWEEN, List.of("start", String.valueOf(t.id), t.level.dimension().location().toString(),
                t.ghost != null ? "g" : "e", String.valueOf(t.ent != null ? t.ent.getId() : -1),
                String.valueOf((long) (t.time * 1000)), String.valueOf(elapsedMs), t.dir, t.style, v(t.p0), v(t.p1), rot, origin, t.collide ? "1" : "0"),
                null, t.payload);
    }
    /** s: end, id, finalPos, remove(0/1) */
    static Pkt endPkt(T t, Vec3L at, boolean remove) {
        return new Pkt(Pkt.S_TWEEN, "end", String.valueOf(t.id), at == null ? "" : v(at), remove ? "1" : "0");
    }

    static void send(T t, Pkt p) {
        if (t.level.isClientSide) { var l = LOCAL; if (l != null) l.accept(p); return; }
        var srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return;
        for (ServerPlayer sp : srv.getPlayerList().getPlayers())
            if (sp.level() == t.level) FluwaNet.toPlayerLarge(sp, p);
    }

    /** running tweens for a player that just joined / changed dimension */
    public static void sendAll(ServerPlayer sp) {
        for (T t : ALL.values())
            if (t.level == sp.level() && !t.level.isClientSide) FluwaNet.toPlayerLarge(sp, startPkt(t));
    }

    // ================================================================ Lua API
    /** registers TweenPosition / TweenCFrame / CancelTween / IsTweening on a class */
    public static void install(Class<? extends LObj> c, Mover mv) {
        LObj.reg(c, "TweenPosition|TP", (s, a) -> start(s, mv, a, false));
        LObj.reg(c, "TweenCFrame", (s, a) -> start(s, mv, a, true));
        LObj.reg(c, "CancelTween", (s, a) -> cancel(s));
        LObj.reg(c, "IsTweening", (s, a) -> LuaValue.valueOf(active(rtOf(s)).containsKey(s)));
    }

    // ================================================================ movers
    public static final Mover ENTITY = new Mover() {
        public Vec3L position(LObj o) { return Vec3L.of(((EntityObj) o).e().position()); }
        public Level level(LObj o) { return ((EntityObj) o).e().level(); }
        public Entity entity(LObj o) { return ((EntityObj) o).e(); }
        public CFrameL cframe(LObj o) { var e = ((EntityObj) o).e(); return CFrameL.fromYawPitch(Vec3L.of(e.position()), e.getYRot(), e.getXRot()); }
        public void finish(LObj o, Vec3L p, CFrameL r) {
            EntityObj eo = (EntityObj) o; var e = eo.e();
            if (r != null) eo.teleport(p.x, p.y, p.z, r.mcYaw(), r.mcPitch());
            else eo.teleport(p.x, p.y, p.z, e.getYRot(), e.getXRot());
        }
    };

    static Vec3L round(Vec3L p) { return new Vec3L(Math.round(p.x), Math.round(p.y), Math.round(p.z)); }

    public static final Mover BLOCK = new Mover() {
        public Vec3L position(LObj o) { return Vec3L.of(((BlockObj) o).pos); }
        public Level level(LObj o) { return ((BlockObj) o).level; }
        public Vec3L snap(LObj o, Vec3L p) { return round(p); }
        public List<BlockPos> blocks(LObj o) { return List.of(((BlockObj) o).pos); }
        public void finish(LObj o, Vec3L p, CFrameL r) {
            BlockObj b = (BlockObj) o;
            BlockPos np = p.pos();
            if (np.equals(b.pos)) return;
            if (b.level == null) b.pos = np.immutable(); else b.moveTo(np);
        }
    };

    public static final Mover CHUNK = new Mover() {
        public Vec3L position(LObj o) { ChunkObj c = (ChunkObj) o; return new Vec3L(c.cp.getMinBlockX(), 0, c.cp.getMinBlockZ()); }
        public Level level(LObj o) { return ((ChunkObj) o).level; }
        public Vec3L snap(LObj o, Vec3L p) { return new Vec3L(Math.floor(p.x / 16) * 16, 0, Math.floor(p.z / 16) * 16); }
        public List<BlockPos> blocks(LObj o) {
            ChunkObj c = (ChunkObj) o;
            if (c.snapshot != null) throw new LuaError("A copied chunk can't be tweened (Paste it into a real chunk first)");
            List<BlockPos> out = new ArrayList<>();
            for (int y = c.minY(); y <= c.maxY(); y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
                out.add(new BlockPos(c.cp.getMinBlockX() + x, y, c.cp.getMinBlockZ() + z));
            return out;
        }
        public void finish(LObj o, Vec3L p, CFrameL r) { ((ChunkObj) o).moveTo(new Vec3L(p.x + 8, 0, p.z + 8)); }
    };

    public static final Mover STRUCTURE = new Mover() {
        public Vec3L position(LObj o) {
            StructureObj s = (StructureObj) o;
            if (s.placedAt == null) throw new LuaError("Structure:Tween - place the structure first (Structure:Place(dimension, pos))");
            return s.placedAt;
        }
        public Level level(LObj o) { return ((StructureObj) o).placedDim.level(); }
        public Vec3L snap(LObj o, Vec3L p) { return new Vec3L(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)); }
        public List<BlockPos> blocks(LObj o) { List<BlockPos> b = ((StructureObj) o).placedBlocks; return b == null ? List.of() : b; }
        public void finish(LObj o, Vec3L p, CFrameL r) { ((StructureObj) o).moveTo(p); }
    };
}
