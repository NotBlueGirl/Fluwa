package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.luaj.vm2.*;

/**
 * Block:ToBlockEntity([canCollide=true]) -> Entity    turns a placed block into a free-moving block entity
 *     (a block display: keeps state, chest contents / NBT and Fluwa BlockData; can be tweened, teleported, ...).
 * BlockEntity:ToSolidBlock() -> Block                 puts it back into the world at its (rounded) position.
 * BlockEntity:SetCanCollide(bool), BlockEntity:IsBlockEntity()
 */
public final class BlockEntities {
    private BlockEntities() {}
    public static final String KEY = "fluwa_block";

    static LuaValue toEntity(BlockObj b, boolean collide) {
        ServerLevel l = EntityObj.sl(b.level());
        BlockPos pos = b.pos;
        BlockState st = l.getBlockState(pos);
        if (st.isAir()) throw new LuaError("Block:ToBlockEntity - the block is air");
        CompoundTag data = new CompoundTag();
        data.put("state", NbtUtils.writeBlockState(st));
        data.putBoolean("solid", collide);
        BlockEntity be = l.getBlockEntity(pos);
        if (be != null) data.put("nbt", be.saveWithoutMetadata());
        BlockData bd = BlockData.get(l);
        CompoundTag ft = bd.tag(pos, false);
        if (ft != null) data.put("data", ft.copy());

        CompoundTag et = new CompoundTag();
        et.putString("id", "minecraft:block_display");
        et.put("block_state", NbtUtils.writeBlockState(st));
        Entity e = EntityType.loadEntityRecursive(et, l, x -> { x.moveTo(pos.getX(), pos.getY(), pos.getZ(), 0, 0); return x; });
        if (e == null) throw new LuaError("Block:ToBlockEntity - could not create the entity");
        e.getPersistentData().put(KEY, data);

        if (be != null) l.removeBlockEntity(pos);
        l.setBlock(pos, Blocks.AIR.defaultBlockState(), 2 | 16 | 32);
        bd.clear(pos);
        bd.setDirty();
        if (collide) Colliders.SOLID.put(e.getUUID(), st);
        l.addFreshEntity(e); // joined() replicates hitbox / solid flag
        return GameRuntime.cur().wrapEntity(e);
    }

    static CompoundTag data(EntityObj o) {
        CompoundTag pd = o.e().getPersistentData();
        if (!pd.contains(KEY)) throw new LuaError("This entity is not a BlockEntity (use Block:ToBlockEntity())");
        return pd.getCompound(KEY);
    }

    static LuaValue toSolid(EntityObj o) {
        Entity e = o.e();
        ServerLevel l = EntityObj.sl(e.level());
        CompoundTag d = data(o);
        BlockState st = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), d.getCompound("state"));
        BlockPos at = BlockPos.containing(Math.round(e.getX()), Math.round(e.getY()), Math.round(e.getZ()));
        BlockState there = l.getBlockState(at);
        if (!there.isAir() && !there.canBeReplaced()) throw new LuaError("BlockEntity:ToSolidBlock - position " + at.toShortString() + " is occupied");
        l.setBlock(at, st, 3);
        if (d.contains("nbt")) { BlockEntity be = l.getBlockEntity(at); if (be != null) be.load(d.getCompound("nbt")); }
        if (d.contains("data")) { BlockData bd = BlockData.get(l); bd.tag(at, true).merge(d.getCompound("data")); bd.setDirty(); }
        Colliders.SOLID.remove(e.getUUID());
        e.discard();
        o.destroyed = true;
        return GameRuntime.cur().within(() -> new BlockObj(l, at));
    }

    static void setCollide(EntityObj o, boolean on) {
        Entity e = o.e();
        CompoundTag d = data(o);
        d.putBoolean("solid", on);
        if (on) Colliders.SOLID.put(e.getUUID(), NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), d.getCompound("state")));
        else Colliders.SOLID.remove(e.getUUID());
        if (!e.level().isClientSide) net.idea.fluwa.net.FluwaNet.toAll(Hitbox.pkt(e.getUUID()));
    }

    public static void install() {
        LObj.reg(BlockObj.class, "ToBlockEntity", (s, a) -> toEntity((BlockObj) s, a.optboolean(1, true)));
        LObj.reg(EntityObj.class, "ToSolidBlock", (s, a) -> toSolid((EntityObj) s));
        LObj.reg(EntityObj.class, "SetCanCollide", (s, a) -> { setCollide((EntityObj) s, a.optboolean(1, true)); return LuaValue.NONE; });
        LObj.reg(EntityObj.class, "IsBlockEntity", (s, a) -> LuaValue.valueOf(((EntityObj) s).e().getPersistentData().contains(KEY)));
        // custom hitbox (independent of ModelScale)
        LObj.reg(EntityObj.class, "SetHitbox", (s, a) -> {
            Entity e = ((EntityObj) s).e();
            if (a.isnil(1)) Hitbox.set(e, 0, 0);
            else if (a.arg1().isnumber()) Hitbox.set(e, (float) a.checkdouble(1), (float) a.optdouble(2, a.checkdouble(1)));
            else { Vec3L v = Vec3L.check(a.arg1()); Hitbox.set(e, (float) v.x, (float) v.y); }
            return LuaValue.NONE; });
        LObj.reg(EntityObj.class, "GetHitbox", (s, a) -> { Entity e = ((EntityObj) s).e();
            return LuaValue.varargsOf(LuaValue.valueOf(e.getBbWidth()), LuaValue.valueOf(e.getBbHeight())); });
    }
}
