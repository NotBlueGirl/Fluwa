package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import org.luaj.vm2.*;

import java.util.*;

/** 16 x height x 16 column. Copy() returns a detached snapshot that can be pasted elsewhere. */
public class ChunkObj extends LObj {
    final Level level;
    ChunkPos cp;
    BlockState[] snapshot; // copy mode
    int snapMinY, snapH;
    double transparency;
    public static final Map<Long, Signal> CLIENT_LOADED = new HashMap<>();

    public ChunkObj(Level l, ChunkPos p) { super("Chunk"); level = l; cp = p; name = "Chunk[" + p.x + "," + p.z + "]"; }

    int minY() { return snapshot != null ? snapMinY : level.getMinBuildHeight(); }
    int maxY() { return snapshot != null ? snapMinY + snapH - 1 : level.getMaxBuildHeight() - 1; }

    BlockState at(int lx, int y, int lz) {
        if (snapshot != null) return snapshot[((y - snapMinY) * 16 + lz) * 16 + lx];
        return level.getBlockState(new BlockPos(cp.getMinBlockX() + lx, y, cp.getMinBlockZ() + lz));
    }

    void put(int lx, int y, int lz, BlockState st) {
        if (snapshot != null) { snapshot[((y - snapMinY) * 16 + lz) * 16 + lx] = st; return; }
        level.setBlock(new BlockPos(cp.getMinBlockX() + lx, y, cp.getMinBlockZ() + lz), st, 2);
    }

    int regenerate(boolean decorate) {
        if (!(level instanceof net.minecraft.server.level.ServerLevel sl)) throw new LuaError("Chunk:Regenerate is Server-Side only");
        if (snapshot != null) throw new LuaError("A copied chunk can't be regenerated");
        var cs = sl.getChunkSource();
        var gen = cs.getGenerator();
        var rs = cs.randomState();
        var biomes = sl.registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.BIOME);
        var blender = net.minecraft.world.level.levelgen.blending.Blender.empty();
        java.util.concurrent.Executor now = Runnable::run;
        List<net.minecraft.world.level.chunk.ChunkAccess> list = new ArrayList<>();
        for (int dz = -1; dz <= 1; dz++) for (int dx = -1; dx <= 1; dx++) {
            var pc = new net.minecraft.world.level.chunk.ProtoChunk(new ChunkPos(cp.x + dx, cp.z + dz),
                    net.minecraft.world.level.chunk.UpgradeData.EMPTY, sl, biomes, null);
            pc.setStatus(net.minecraft.world.level.chunk.ChunkStatus.FEATURES);
            list.add(pc);
        }
        // structures are read from this temporary region (not from the live level) -> no waiting for the server thread
        var region = new net.minecraft.server.level.WorldGenRegion(sl, list, net.minecraft.world.level.chunk.ChunkStatus.FEATURES, 1);
        var sm = sl.structureManager().forWorldGenRegion(region);
        try {
            for (var pc : list) {
                gen.createBiomes(now, rs, blender, sm, pc).get(30, java.util.concurrent.TimeUnit.SECONDS);
                gen.fillFromNoise(now, blender, rs, sm, pc).get(30, java.util.concurrent.TimeUnit.SECONDS);
            }
        } catch (java.util.concurrent.TimeoutException e) {
            throw new LuaError("Chunk:Regenerate timed out");
        } catch (Exception e) {
            throw new LuaError("Chunk:Regenerate failed: " + (e.getCause() != null ? e.getCause() : e));
        }
        var center = list.get(4);
        for (var c : list) {
            try { gen.buildSurface(region, sm, rs, c); }
            catch (RuntimeException e) { if (c == center) throw e; }
        }
        if (decorate) {
            try {
                gen.applyBiomeDecoration(region, center, sm);
            } catch (RuntimeException e) {
                rt.output(1, "Chunk:Regenerate - decoration skipped: " + e);
            }
        }
        int changed = 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = level.getMinBuildHeight(); y < level.getMaxBuildHeight(); y++)
            for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                p.set(cp.getMinBlockX() + x, y, cp.getMinBlockZ() + z);
                BlockState ns = center.getBlockState(p);
                if (level.getBlockState(p) != ns) { level.setBlock(p, ns, 2 | 16); changed++; }
            }
        return changed;
    }

    ChunkObj copy() {
        ChunkObj c = new ChunkObj(level, cp);
        c.snapMinY = minY(); c.snapH = maxY() - minY() + 1;
        c.snapshot = new BlockState[16 * 16 * c.snapH];
        for (int y = c.snapMinY; y <= maxY(); y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
            c.snapshot[((y - c.snapMinY) * 16 + z) * 16 + x] = at(x, y, z);
        c.name = name + " (copy)";
        return c;
    }

    void paste(ChunkObj src) {
        int lo = Math.max(minY(), src.minY()), hi = Math.min(maxY(), src.maxY());
        for (int y = lo; y <= hi; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
            BlockState s = src.at(x, y, z);
            if (at(x, y, z) != s) put(x, y, z, s);
        }
    }

    ChunkObj moveTo(Vec3L p) {
        ChunkObj dst = new ChunkObj(level, new ChunkPos(p.pos()));
        if (dst.cp.equals(cp)) return this;
        dst.paste(this);
        if (snapshot == null) { BlockState air = Blocks.AIR.defaultBlockState();
            for (int y = minY(); y <= maxY(); y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) put(x, y, z, air); }
        cp = dst.cp; name = dst.name;
        return this;
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Position": return new Vec3L(cp.getMiddleBlockX(), (minY() + maxY()) / 2.0, cp.getMiddleBlockZ());
            case "X": return valueOf(cp.x);
            case "Z": return valueOf(cp.z);
            case "MaxY": return valueOf(maxY());
            case "MinY": return valueOf(minY());
            case "Transparency": return valueOf(transparency);
            case "IsCopy": return valueOf(snapshot != null);
            case "Loaded": return valueOf(snapshot != null || level.hasChunk(cp.x, cp.z));
            case "E_ClientLoaded": return CLIENT_LOADED.computeIfAbsent(cp.toLong(), x -> new Signal("E_ClientLoaded"));
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (k.equals("Transparency")) { transparency = Math.max(0, Math.min(1, v.checkdouble())); return true; }
        return super.setProp(k, v);
    }

    static {
        Class<ChunkObj> C = ChunkObj.class;
        reg(C, "GetBlocks", (s, a) -> {
            ChunkObj c = (ChunkObj) s; List<LuaValue> out = new ArrayList<>();
            boolean withAir = a.optboolean(1, false);
            for (int y = c.minY(); y <= c.maxY(); y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                if (!withAir && c.at(x, y, z).isAir()) continue;
                out.add(new BlockObj(c.level, new BlockPos(c.cp.getMinBlockX() + x, y, c.cp.getMinBlockZ() + z)));
            }
            return list(out); });
        reg(C, "Copy", (s, a) -> ((ChunkObj) s).copy());
        reg(C, "Paste", (s, a) -> { ((ChunkObj) s).paste(checkObj(a.arg1(), ChunkObj.class)); return NONE; });
        // Chunk:Regenerate([decorate=true]) - rebuild terrain with the dimension generator (noise + surface [+ trees/ores])
        reg(C, "Regenerate", (s, a) -> valueOf(((ChunkObj) s).regenerate(a.optboolean(1, true))));
        reg(C, "Solid", (s, a) -> {
            ChunkObj c = (ChunkObj) s; BlockState st = Conv.block(a.checkjstring(1));
            for (int y = c.minY(); y <= c.maxY(); y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) c.put(x, y, z, st);
            return NONE; });
        reg(C, "BlocksReplace", (s, a) -> {
            ChunkObj c = (ChunkObj) s; Conv.Picker pk = new Conv.Picker(a.checkjstring(1), a.arg(2));
            int n = 0;
            for (int y = c.minY(); y <= c.maxY(); y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
                if (!c.at(x, y, z).isAir()) { c.put(x, y, z, pk.next()); n++; }
            return valueOf(n); });
        reg(C, "GetEntities", (s, a) -> {
            ChunkObj c = (ChunkObj) s;
            AABB box = new AABB(c.cp.getMinBlockX(), c.minY(), c.cp.getMinBlockZ(), c.cp.getMaxBlockX() + 1, c.maxY() + 1, c.cp.getMaxBlockZ() + 1);
            List<LuaValue> out = new ArrayList<>();
            for (Entity e : c.level.getEntities((Entity) null, box, e -> true)) out.add(GameRuntime.cur().wrapEntity(e));
            return list(out); });
        reg(C, "GetDistanceFromOtherChunk", (s, a) -> {
            ChunkObj c = (ChunkObj) s, o = checkObj(a.arg1(), ChunkObj.class);
            double d = Math.sqrt(Math.pow(c.cp.x - o.cp.x, 2) + Math.pow(c.cp.z - o.cp.z, 2));
            return varargsOf(valueOf(d), valueOf(d * 16)); });
        reg(C, "MoveTo", (s, a) -> ((ChunkObj) s).moveTo(Vec3L.check(a.arg1())));
        WorldTween.install(C, WorldTween.CHUNK);
        reg(C, "GetBlock", (s, a) -> {
            ChunkObj c = (ChunkObj) s;
            return new BlockObj(c.level, new BlockPos(c.cp.getMinBlockX() + a.checkint(1), a.checkint(2), c.cp.getMinBlockZ() + a.checkint(3))); });
    }
}
