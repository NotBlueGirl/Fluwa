package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.luaj.vm2.*;

import java.util.*;

/** A dimension (Level). Server: full access. Client: read access; writes only for asynced players. */
public class DimensionObj extends LObj {
    public final ResourceKey<Level> key;
    final Map<String, Signal> events = new HashMap<>();
    static final Set<String> EVENTS = Set.of("E_BlockPlaced", "E_WeatherChanged", "E_BlockDestroyed", "E_EntityAdded", "E_Tick",
            "E_EntityDestroyed", "E_ChunkLoaded", "E_ChunkUnloaded", "E_Explosion");
    public String lastWeather;
    final Skybox skybox = new Skybox(this);

    public DimensionObj(ResourceKey<Level> k) { super("Dimension"); key = k; name = k.location().getPath(); }

    public Level level() {
        Level l = GameRuntime.cur().resolveLevel(key);
        if (l == null) throw new LuaError("Dimension " + name + " is not loaded");
        return l;
    }

    void checkWrite() { if (level().isClientSide) GameRuntime.cur().checkClientWrite(); }

    public void fire(String ev, LuaValue... args) { Signal s = events.get(ev); if (s != null && s.hasHandlers()) s.fire(args); }
    public boolean listens(String ev) { Signal s = events.get(ev); return s != null && s.hasHandlers(); }

    @Override public void setName(String n) { throw new LuaError("Dimension.Name is read-only"); }
    @Override public void setParent(LObj p) { throw new LuaError("Dimension.Parent can't be changed"); }

    public String weather() { Level l = level(); return l.getLevelData().isThundering() ? "thunder" : l.getLevelData().isRaining() ? "rain" : "clear"; }

    @Override protected LuaValue getProp(String k) {
        if (k.equals("E_EntityDestoryed")) k = "E_EntityDestroyed"; // spelling from the original doc
        if (EVENTS.contains(k)) return events.computeIfAbsent(k, Signal::new);
        switch (k) {
            case "Id": return valueOf(key.location().toString());
            case "Weather": return valueOf(weather());
            case "Skybox": return skybox;
            case "DayTime": return valueOf(level().getDayTime() % 24000);
            case "MinY": return valueOf(level().getMinBuildHeight());
            case "MaxY": return valueOf(level().getMaxBuildHeight() - 1);
            case "Players": return getPlayers();
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (k.equals("Weather")) { changeWeather(v.checkjstring(), 6000); return true; }
        return super.setProp(k, v);
    }

    void changeWeather(String w, int ticks) {
        ServerLevel sl = EntityObj.sl(level());
        switch (w.toLowerCase(Locale.ROOT)) {
            case "clear", "sun", "sunny" -> sl.setWeatherParameters(ticks, 0, false, false);
            case "rain", "snow" -> sl.setWeatherParameters(0, ticks, true, false);
            case "thunder", "storm" -> sl.setWeatherParameters(0, ticks, true, true);
            default -> throw new LuaError("Unknown weather '" + w + "' (clear, rain, thunder)");
        }
    }

    LuaTable getPlayers() {
        List<LuaValue> out = new ArrayList<>();
        for (var p : level().players()) out.add(GameRuntime.cur().wrap(p));
        return list(out);
    }

    public static Entity spawn(ServerLevel l, String id, Vec3 p) {
        EntityType<?> t = EntityType.byString(Conv.rl(id).toString()).orElseThrow(() -> new LuaError("Unknown entity: " + id));
        Entity e = t.create(l);
        if (e == null) throw new LuaError("Entity " + id + " can't be spawned");
        e.moveTo(p.x, p.y, p.z, l.random.nextFloat() * 360f, 0);
        if (e instanceof Mob m) m.finalizeSpawn(l, l.getCurrentDifficultyAt(e.blockPosition()), MobSpawnType.COMMAND, null, null);
        l.addFreshEntity(e);
        return e;
    }

    interface BoxFn { void at(BlockPos p); }
    static void box(Vec3L a, Vec3L b, BoxFn f) {
        BlockPos mn = Conv.min(a, b), mx = Conv.max(a, b);
        Conv.checkVolume((long) (mx.getX() - mn.getX() + 1) * (mx.getY() - mn.getY() + 1) * (mx.getZ() - mn.getZ() + 1));
        for (BlockPos p : BlockPos.betweenClosed(mn, mx)) f.at(p.immutable());
    }
    static void sphere(Vec3L c, double r, BoxFn f) {
        Conv.checkVolume((long) Math.pow(2 * r + 1, 3));
        int R = (int) Math.ceil(r);
        BlockPos cp = c.pos();
        for (int x = -R; x <= R; x++) for (int y = -R; y <= R; y++) for (int z = -R; z <= R; z++)
            if (x * x + y * y + z * z <= r * r) f.at(cp.offset(x, y, z));
    }

    public RayResult raycast(Vec3L origin, Vec3L dir, double max, boolean entities, Entity ignore) {
        Level l = level();
        Vec3 from = origin.mc(), to = from.add(dir.unit().mc().scale(max));
        BlockHitResult bh = BlockGetter.traverseBlocks(from, to, l, (lv, pos) -> {
            BlockState st = lv.getBlockState(pos);
            if (st.isAir()) return null;
            VoxelShape shape = st.getShape(lv, pos);
            return lv.clipWithInteractionOverride(from, to, pos, shape, st);
        }, lv -> null);
        double bd = bh == null ? Double.MAX_VALUE : bh.getLocation().distanceTo(from);
        if (entities) {
            Vec3 end = bh == null ? to : bh.getLocation();
            EntityHitResult eh = ProjectileUtil.getEntityHitResult(l, ignore, from, end, new AABB(from, end).inflate(1), e -> !e.isSpectator() && e != ignore);
            if (eh != null && eh.getLocation().distanceTo(from) < bd)
                return new RayResult(true, Vec3L.of(eh.getLocation()), null, null, GameRuntime.cur().wrapEntity(eh.getEntity()), eh.getLocation().distanceTo(from));
        }
        if (bh == null) return new RayResult(false, Vec3L.of(to), null, null, null, max);
        var n = bh.getDirection().getNormal();
        return new RayResult(true, Vec3L.of(bh.getLocation()), new Vec3L(n.getX(), n.getY(), n.getZ()), new BlockObj(l, bh.getBlockPos()), null, bd);
    }

    static {
        Class<DimensionObj> C = DimensionObj.class;
        reg(C, "GetBlock", (s, a) -> new BlockObj(((DimensionObj) s).level(), Vec3L.check(a.arg1()).pos()));
        reg(C, "SetBlock", (s, a) -> { DimensionObj d = (DimensionObj) s; d.checkWrite();
            d.level().setBlock(Vec3L.check(a.arg(2)).pos(), Conv.block(a.checkjstring(1)), 3); return NONE; });
        reg(C, "GetChunk", (s, a) -> { DimensionObj d = (DimensionObj) s; ChunkPos cp = new ChunkPos(Vec3L.check(a.arg1()).pos());
            return varargsOf(new ChunkObj(d.level(), cp), valueOf(d.level().hasChunk(cp.x, cp.z))); });
        reg(C, "GetSpawn", (s, a) -> Vec3L.of(((DimensionObj) s).level().getSharedSpawnPos()));
        reg(C, "SetSpawn", (s, a) -> { EntityObj.sl(((DimensionObj) s).level()).setDefaultSpawnPos(Vec3L.check(a.arg1()).pos(), (float) a.optdouble(2, 0)); return NONE; });
        reg(C, "GetBox", (s, a) -> { DimensionObj d = (DimensionObj) s; Level l = d.level(); List<LuaValue> out = new ArrayList<>();
            boolean air = a.optboolean(3, true);
            box(Vec3L.check(a.arg1()), Vec3L.check(a.arg(2)), p -> { if (air || !l.getBlockState(p).isAir()) out.add(new BlockObj(l, p)); });
            return list(out); });
        reg(C, "SetBox", (s, a) -> { DimensionObj d = (DimensionObj) s; d.checkWrite(); Level l = d.level();
            Conv.Picker pk = new Conv.Picker(a.checkjstring(1), a.arg(4));
            box(Vec3L.check(a.arg(2)), Vec3L.check(a.arg(3)), p -> l.setBlock(p, pk.next(), 2)); return NONE; });
        reg(C, "SetSphere", (s, a) -> { DimensionObj d = (DimensionObj) s; d.checkWrite(); Level l = d.level();
            Conv.Picker pk = new Conv.Picker(a.checkjstring(1), a.arg(4));
            sphere(Vec3L.check(a.arg(2)), a.checkdouble(3), p -> l.setBlock(p, pk.next(), 2)); return NONE; });
        reg(C, "GetSphere", (s, a) -> { DimensionObj d = (DimensionObj) s; Level l = d.level(); List<LuaValue> out = new ArrayList<>();
            boolean air = a.optboolean(3, false);
            sphere(Vec3L.check(a.arg1()), a.checkdouble(2), p -> { if (air || !l.getBlockState(p).isAir()) out.add(new BlockObj(l, p)); });
            return list(out); });
        reg(C, "LoadChunk", (s, a) -> { DimensionObj d = (DimensionObj) s; ChunkPos cp = new ChunkPos(Vec3L.check(a.arg1()).pos());
            Level l = d.level();
            if (l instanceof ServerLevel sl && a.optboolean(2, false)) sl.setChunkForced(cp.x, cp.z, true);
            l.getChunk(cp.x, cp.z);
            return new ChunkObj(l, cp); });
        reg(C, "UnforceChunk", (s, a) -> { ChunkPos cp = new ChunkPos(Vec3L.check(a.arg1()).pos());
            EntityObj.sl(((DimensionObj) s).level()).setChunkForced(cp.x, cp.z, false); return NONE; });
        reg(C, "GetEntitiesFromBox|GEFB", (s, a) -> { DimensionObj d = (DimensionObj) s;
            Vec3L v1 = Vec3L.check(a.arg1()), v2 = Vec3L.check(a.arg(2));
            List<LuaValue> out = new ArrayList<>();
            for (Entity e : d.level().getEntities((Entity) null, new AABB(v1.mc(), v2.mc()), e -> true)) out.add(GameRuntime.cur().wrapEntity(e));
            return list(out); });
        reg(C, "PlaySound", (s, a) -> { DimensionObj d = (DimensionObj) s; Vec3L p = Vec3L.check(a.arg(4));
            d.level().playSound(null, p.x, p.y, p.z, Conv.sound(a.checkjstring(1)), SoundSource.MASTER, (float) a.optdouble(2, 1), (float) a.optdouble(3, 1));
            return NONE; });
        reg(C, "Spawn", (s, a) -> { DimensionObj d = (DimensionObj) s; ServerLevel sl = EntityObj.sl(d.level());
            int n = a.optint(3, 1); Vec3 p = Vec3L.check(a.arg(2)).mc();
            if (n <= 1) return GameRuntime.cur().wrapEntity(spawn(sl, a.checkjstring(1), p));
            List<LuaValue> out = new ArrayList<>();
            for (int i = 0; i < Math.min(n, 1000); i++) out.add(GameRuntime.cur().wrapEntity(spawn(sl, a.checkjstring(1), p)));
            return list(out); });
        reg(C, "Raycast", (s, a) -> {
            Entity ign = a.arg(5) instanceof EntityObj eo ? eo.e() : null;
            return ((DimensionObj) s).raycast(Vec3L.check(a.arg1()), Vec3L.check(a.arg(2)), a.optdouble(3, 100), a.optboolean(4, false), ign); });
        reg(C, "Explode", (s, a) -> { ServerLevel sl = EntityObj.sl(((DimensionObj) s).level()); Vec3L p = Vec3L.check(a.arg1());
            boolean drop = a.optboolean(4, true);
            if (!drop) net.idea.fluwa.server.ServerEvents.noDropExplosions++;
            try { sl.explode(null, p.x, p.y, p.z, (float) a.optdouble(2, 4), a.optboolean(3, false), Level.ExplosionInteraction.TNT); }
            finally { if (!drop) net.idea.fluwa.server.ServerEvents.noDropExplosions--; }
            return NONE; });
        reg(C, "Fire", (s, a) -> { DimensionObj d = (DimensionObj) s; d.checkWrite(); Level l = d.level(); BlockPos p = Vec3L.check(a.arg1()).pos();
            if (!l.getBlockState(p).isAir()) p = p.above();
            if (l.getBlockState(p).isAir()) { l.setBlock(p, BaseFireBlock.getState(l, p), 11); return TRUE; }
            return FALSE; });
        reg(C, "Broke|Break", (s, a) -> valueOf(((DimensionObj) s).level().destroyBlock(Vec3L.check(a.arg1()).pos(), a.optboolean(2, true))));
        reg(C, "ClearDrops", (s, a) -> { ServerLevel sl = EntityObj.sl(((DimensionObj) s).level()); List<Entity> rm = new ArrayList<>();
            for (Entity e : sl.getAllEntities()) if (e instanceof ItemEntity) rm.add(e);
            rm.forEach(Entity::discard); return valueOf(rm.size()); });
        reg(C, "GetPlayers", (s, a) -> ((DimensionObj) s).getPlayers());
        reg(C, "PlaceStructure", (s, a) -> { checkObj(a.arg1(), StructureObj.class).place((DimensionObj) s, Vec3L.check(a.arg(2)), a.arg(3)); return NONE; });
        reg(C, "ChangeWeather", (s, a) -> { ((DimensionObj) s).changeWeather(a.checkjstring(1), (int) Math.round(a.optdouble(2, 300) * 20)); return NONE; });
    }

    /** Dimension.Skybox */
    public static class Skybox extends LObj {
        final DimensionObj d;
        Skybox(DimensionObj d) { super("Skybox"); this.d = d; }
        static {
            reg(Skybox.class, "ServerChange", (s, a) -> { Skybox k = (Skybox) s; GameRuntime.cur().skybox(null, k.d, a.optjstring(1, "")); return NONE; });
            reg(Skybox.class, "ClientChange", (s, a) -> { Skybox k = (Skybox) s;
                GameRuntime.cur().skybox(a.isnil(2) ? "" : a.checkjstring(2), k.d, a.optjstring(1, "")); return NONE; });
            reg(Skybox.class, "Reset", (s, a) -> { GameRuntime.cur().skybox(null, ((Skybox) s).d, ""); return NONE; });
        }
    }
}
