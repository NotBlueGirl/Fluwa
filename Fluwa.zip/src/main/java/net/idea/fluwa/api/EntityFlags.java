package net.idea.fluwa.api;

import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Server-authoritative render flags per entity ("hidename", "invisible"), replicated to clients. */
public final class EntityFlags {
    private EntityFlags() {}
    static final Map<UUID, Set<String>> FLAGS = new ConcurrentHashMap<>();

    public static void set(Entity e, String flag, boolean on) {
        UUID id = e.getUUID();
        Set<String> s = FLAGS.computeIfAbsent(id, k -> ConcurrentHashMap.newKeySet());
        if (on) s.add(flag); else s.remove(flag);
        if (s.isEmpty()) FLAGS.remove(id);
        FluwaNet.toAll(new Pkt(Pkt.S_ENTFLAG, List.of(id.toString(), flag), new int[]{on ? 1 : 0}, null));
    }
    public static boolean has(Entity e, String flag) { Set<String> s = FLAGS.get(e.getUUID()); return s != null && s.contains(flag); }

    public static void sendAll(ServerPlayer sp) {
        FLAGS.forEach((id, s) -> { for (String f : s) FluwaNet.toPlayer(sp, new Pkt(Pkt.S_ENTFLAG, List.of(id.toString(), f), new int[]{1}, null)); });
    }
    public static void clear() { FLAGS.clear(); }
}
