package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.luaj.vm2.*;

/** A block at a position in a dimension (live view). Instance:new("Block") creates a detached block template. */
public class BlockObj extends LObj {
    Level level;
    BlockPos pos;
    String templateId = "minecraft:stone";
    /** block-entity data of a detached block (Structure:GetBlock) */
    net.minecraft.nbt.CompoundTag templateNbt;

    public BlockObj(Level l, BlockPos p) { super("Block"); level = l; pos = p.immutable(); }
    public BlockObj() { super("Block"); }
    /** raw position / level (null when the block is a detached template) */
    public BlockPos blockPos() { return pos; }
    public Level rawLevel() { return level; }

    public Level level() { if (level == null) throw new LuaError("Block is not placed (set Position and Parent = Dimension)"); return level; }
    public BlockState state() { return level().getBlockState(pos); }
    BlockData data() { return level() instanceof ServerLevel s ? BlockData.get(s) : null; }
    ServerLevel sl() { return EntityObj.sl(level()); }

    @Override public String getName() { return level == null ? name : state().getBlock().getName().getString(); }

    @Override public void setParent(LObj p) {
        if (level == null && p instanceof DimensionObj d) {
            if (pos == null) throw new LuaError("Set Block.Position before parenting it to a Dimension");
            level = d.level();
            level.setBlock(pos, Conv.block(templateId), 3);
            if (templateNbt != null) { BlockEntity be = level.getBlockEntity(pos); if (be != null) { CompoundTag c = templateNbt.copy(); c.putInt("x", pos.getX()); c.putInt("y", pos.getY()); c.putInt("z", pos.getZ()); be.load(c); be.setChanged(); } }
            return;
        }
        super.setParent(p);
    }

    @Override protected void onDestroy() { if (level != null) { level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3); BlockData d = data(); if (d != null) d.clear(pos); } }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Position": return pos == null ? NIL : Vec3L.of(pos);
            case "CFrame": return pos == null ? NIL : new CFrameL(pos.getX(), pos.getY(), pos.getZ());
        }
        if (level == null) {
            if (k.equals("Id")) { int b = templateId.indexOf('['); return valueOf(b < 0 ? templateId : templateId.substring(0, b)); }
            if (k.equals("State")) return valueOf(templateId);
            if (k.equals("NBT") || k.equals("NBTs")) return templateNbt == null ? NIL : Conv.toLua(templateNbt);
            return super.getProp(k);
        }
        switch (k) {
            case "Id": return valueOf(Conv.id(state()));
            case "State": return valueOf(net.minecraft.commands.arguments.blocks.BlockStateParser.serialize(state()));
            case "Dimension": return GameRuntime.cur().wrap(level);
            case "IsAir": return valueOf(state().isAir());
            case "Hardness": return valueOf(state().getDestroySpeed(level, pos));
            case "Light": return valueOf(level.getMaxLocalRawBrightness(pos));
            case "Screen": { BlockData d = data(); String s = d == null ? null : d.screens.get(pos.asLong()); return s == null ? NIL : valueOf(s); }
            case "CanFall": { BlockData d = data(); return valueOf(d != null && d.gravity.contains(pos.asLong())); }
            case "CanCollide": return valueOf(!state().getCollisionShape(level, pos).isEmpty());
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "Position": case "CFrame": {
                BlockPos np = Vec3L.check(v).pos();
                if (level != null) moveTo(np); else pos = np;
                return true;
            }
            case "Id": case "State":
                if (level == null) templateId = v.checkjstring();
                else level.setBlock(pos, Conv.block(v.checkjstring()), 3);
                return true;
            case "CanFall": gravity(v.toboolean()); return true;
            case "CanCollide": NoCollide.set(sl(), pos, v.toboolean()); return true;
        }
        return super.setProp(k, v);
    }

    void gravity(boolean on) {
        BlockData d = BlockData.get(sl());
        if (on) d.gravity.add(pos.asLong()); else d.gravity.remove(pos.asLong());
        d.setDirty();
    }

    void moveTo(BlockPos np) {
        Level l = level();
        BlockState st = state();
        BlockEntity be = l.getBlockEntity(pos);
        CompoundTag beTag = be == null ? null : be.saveWithoutMetadata();
        if (be != null) l.removeBlockEntity(pos);
        l.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        l.setBlock(np, st, 3);
        if (beTag != null) { BlockEntity nb = l.getBlockEntity(np); if (nb != null) nb.load(beTag); }
        BlockData d = data();
        if (d != null) d.move(pos, np);
        pos = np.immutable();
    }

    LuaTable readNBTs() {
        LuaTable t = new LuaTable();
        BlockEntity be = level().getBlockEntity(pos);
        if (be != null) { CompoundTag c = be.saveWithoutMetadata(); for (String k : c.getAllKeys()) t.set(k, Conv.toLua(c.get(k))); }
        BlockData d = data();
        CompoundTag c = d == null ? null : d.tag(pos, false);
        if (c != null) for (String k : c.getAllKeys()) t.set(k, Conv.toLua(c.get(k)));
        return t;
    }

    /** onlyExisting=true: WriteNBT (changes existing tag), false: SetNBT (creates if missing) */
    boolean writeNBT(String key, LuaValue val, boolean onlyExisting) {
        BlockEntity be = level().getBlockEntity(pos);
        if (be != null) {
            CompoundTag c = be.saveWithoutMetadata();
            if (c.contains(key)) {
                c.put(key, Conv.toTag(val));
                be.load(c);
                be.setChanged();
                level.sendBlockUpdated(pos, state(), state(), 3);
                return true;
            }
        }
        BlockData d = BlockData.get(sl());
        CompoundTag c = d.tag(pos, false);
        if (onlyExisting && (c == null || !c.contains(key))) return false;
        if (c == null) c = d.tag(pos, true);
        if (val.isnil()) c.remove(key); else c.put(key, Conv.toTag(val));
        d.setDirty();
        return true;
    }

    static {
        WorldTween.install(BlockObj.class, WorldTween.BLOCK);
        BlockEntities.install();
        Class<BlockObj> C = BlockObj.class;
        reg(C, "Break", (s, a) -> valueOf(((BlockObj) s).level().destroyBlock(((BlockObj) s).pos, a.optboolean(1, true))));
        reg(C, "ReadNBTs", (s, a) -> ((BlockObj) s).readNBTs());
        reg(C, "ReadNBT", (s, a) -> ((BlockObj) s).readNBTs().get(a.checkjstring(1)));
        reg(C, "WriteNBT", (s, a) -> valueOf(((BlockObj) s).writeNBT(a.checkjstring(1), a.arg(2), true)));
        reg(C, "SetNBT", (s, a) -> valueOf(((BlockObj) s).writeNBT(a.checkjstring(1), a.arg(2), false)));
        reg(C, "Gravity", (s, a) -> { ((BlockObj) s).gravity(a.optboolean(1, true)); return NONE; });
        reg(C, "ConnectScreen", (s, a) -> {
            BlockObj b = (BlockObj) s; BlockData d = BlockData.get(b.sl());
            String n = a.arg1() instanceof LObj o ? o.getName() : a.checkjstring(1);
            d.screens.put(b.pos.asLong(), n); d.setDirty(); return NONE; });
        reg(C, "DisconnectScreen", (s, a) -> {
            BlockObj b = (BlockObj) s; BlockData d = BlockData.get(b.sl());
            d.screens.remove(b.pos.asLong()); d.setDirty(); return NONE; });
        reg(C, "MoveTo", (s, a) -> { ((BlockObj) s).moveTo(Vec3L.check(a.arg1()).pos()); return NONE; });
    }

    @Override public boolean eq_b(LuaValue v) { return v instanceof BlockObj b && b.level == level && java.util.Objects.equals(b.pos, pos); }
    @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }
}
