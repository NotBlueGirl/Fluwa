package net.idea.fluwa.api;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

/** Per-dimension persistent Fluwa block data: custom NBT tags, gravity flags, connected screens. */
public class BlockData extends SavedData {
    public final Map<Long, CompoundTag> tags = new HashMap<>();
    public final Set<Long> gravity = new HashSet<>();
    public final Map<Long, String> screens = new HashMap<>();
    public final Set<Long> noCollide = java.util.concurrent.ConcurrentHashMap.newKeySet();

    public static BlockData get(ServerLevel l) {
        return l.getDataStorage().computeIfAbsent(BlockData::load, BlockData::new, "fluwa_blocks");
    }

    static BlockData load(CompoundTag t) {
        BlockData d = new BlockData();
        CompoundTag tg = t.getCompound("tags");
        for (String k : tg.getAllKeys()) d.tags.put(Long.parseLong(k), tg.getCompound(k));
        for (long l : t.getLongArray("gravity")) d.gravity.add(l);
        for (long l : t.getLongArray("noCollide")) d.noCollide.add(l);
        CompoundTag sc = t.getCompound("screens");
        for (String k : sc.getAllKeys()) d.screens.put(Long.parseLong(k), sc.getString(k));
        return d;
    }

    @Override public CompoundTag save(CompoundTag t) {
        CompoundTag tg = new CompoundTag();
        tags.forEach((k, v) -> tg.put(Long.toString(k), v));
        t.put("tags", tg);
        t.putLongArray("gravity", gravity.stream().mapToLong(Long::longValue).toArray());
        t.putLongArray("noCollide", noCollide.stream().mapToLong(Long::longValue).toArray());
        CompoundTag sc = new CompoundTag();
        screens.forEach((k, v) -> sc.putString(Long.toString(k), v));
        t.put("screens", sc);
        return t;
    }

    public CompoundTag tag(BlockPos p, boolean create) {
        CompoundTag t = tags.get(p.asLong());
        if (t == null && create) { t = new CompoundTag(); tags.put(p.asLong(), t); setDirty(); }
        return t;
    }

    /** Called when a block is moved/removed */
    public void move(BlockPos from, BlockPos to) {
        long f = from.asLong();
        CompoundTag t = tags.remove(f);
        boolean g = gravity.remove(f);
        boolean nc = noCollide.remove(f);
        String s = screens.remove(f);
        if (to != null) {
            long n = to.asLong();
            if (t != null) tags.put(n, t);
            if (g) gravity.add(n);
            if (nc) noCollide.add(n);
            if (s != null) screens.put(n, s);
        }
        setDirty();
    }

    public void clear(BlockPos p) { move(p, null); }
    public static boolean has(CompoundTag t, String k) { return t != null && t.contains(k, Tag.TAG_ANY_NUMERIC) || t != null && t.contains(k); }
}
