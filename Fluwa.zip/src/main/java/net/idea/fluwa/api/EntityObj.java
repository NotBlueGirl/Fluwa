package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.luaj.vm2.*;

/** Any entity (mob, item on floor, ...). Players use PlayerObj which extends this. */
public class EntityObj extends EvObj {
    private Entity ent;
    // ---- server/client state driven by ServerEvents tick (freeze / drown / move)
    public long freezeUntil = -1;
    public boolean freezeCam, frozeNoAi;
    public double fx, fy, fz;
    public float fyaw, fpitch;
    public int drownMode, drownAir;
    public Vec3L lastPos;
    public java.util.Set<Integer> touching = new java.util.HashSet<>();
    static final java.util.List<String> ENTITY_EVENTS = java.util.List.of("E_Move", "E_Death", "E_EffAdd", "E_EffDel", "E_Jump", "E_Interact",
            "E_Damaged", "E_ArmorChanged", "E_Multiply", "E_Tick", "E_ChildAdded", "E_ChildRemoved", "E_AttributeChanged");
    @Override protected java.util.Collection<String> eventNames() { return ENTITY_EVENTS; }
    /** for Instance:new("Entity") before it is parented to a dimension */
    private String pendingType = "minecraft:pig";
    private Vec3L pendingPos;

    public EntityObj(Entity e) { super("Entity"); ent = e; if (e != null) name = e.getName().getString(); }
    protected EntityObj(String cls) { super(cls); }

    public Entity raw() { return ent; }
    /** true only for Instance:new("Entity") objects not yet spawned (players are never pending) */
    protected boolean pending() { return ent == null && !(this instanceof PlayerObj); }

    public Entity e() {
        Entity x = raw();
        if (x == null) throw new LuaError("Entity is not spawned yet (set Parent to a Dimension)");
        if (x.isRemoved() && !(x instanceof net.minecraft.world.entity.player.Player)) throw new LuaError("Entity no longer exists");
        return x;
    }

    public LivingEntity living() {
        if (e() instanceof LivingEntity l) return l;
        throw new LuaError(className + " is not a living entity");
    }

    public static ServerLevel sl(Level l) {
        if (l instanceof ServerLevel s) return s;
        throw new LuaError("This can only be done on the server");
    }

    @Override public String getName() { return ent != null ? ent.getName().getString() : name; }

    @Override public void setName(String n) {
        if (pending()) { name = n; return; }
        e().setCustomName(Component.literal(n));
        e().setCustomNameVisible(true);
    }

    @Override public void setParent(LObj p) {
        if (pending() && p != null && (p instanceof DimensionObj || "Entities".equals(p.className))) {
            DimensionObj d = p instanceof DimensionObj dd ? dd : GameRuntime.cur().wrap(GameRuntime.cur().levels().iterator().next());
            Vec3L pos = pendingPos != null ? pendingPos : Vec3L.of(sl(d.level()).getSharedSpawnPos());
            if (rt != null && !rt.server) ent = GameRuntime.cur().spawnLocal(pendingType, pos.mc());
            else ent = DimensionObj.spawn(sl(d.level()), pendingType, pos.mc());
            if (!"Entity".equals(name)) setName(name);
            GameRuntime.cur().entities.put(ent.getId(), this);
            return;
        }
        super.setParent(p);
    }

    @Override protected void onDestroy() {
        if (ent != null && !(ent instanceof net.minecraft.world.entity.player.Player)) {
            if (isHallucination()) GameRuntime.cur().removeLocal(ent); else ent.discard();
        }
    }

    /** client-only entity (spawned by a client script, the server doesn't know it) */
    public boolean isHallucination() { Entity x = raw(); return x != null && x.level().isClientSide && x.getId() < 0; }

    public void freezeEntity(double secs, boolean cam) {
        Entity en = e();
        fx = en.getX(); fy = en.getY(); fz = en.getZ(); fyaw = en.getYRot(); fpitch = en.getXRot();
        freezeCam = cam;
        freezeUntil = secs > 0 ? rt.tick + Math.round(secs * 20) : Long.MAX_VALUE;
        if (en instanceof Mob m && !m.isNoAi()) { m.setNoAi(true); frozeNoAi = true; }
    }
    public void unfreezeEntity() {
        freezeUntil = -1;
        if (frozeNoAi && raw() instanceof Mob m) m.setNoAi(false);
        frozeNoAi = false;
    }

    /** list of ModelPart objects (mesh parts for a custom model, humanoid parts, or "Model" for the whole model) */
    public static LuaValue modelParts(EntityObj o) {
        Entity en = o.e();
        java.util.List<LuaValue> l = new java.util.ArrayList<>();
        java.util.LinkedHashSet<String> names = new java.util.LinkedHashSet<>(((GameRuntime) o.rt).modelPartNames(en));
        names.add("Model");
        for (String n : names) l.add(new ModelPartObj(o, en.getUUID(), n));
        return list(l);
    }

    /** part of an entity model; Visible is replicated by the server (or local on the client) */
    public static class ModelPartObj extends LObj {
        final java.util.UUID id; final EntityObj owner;
        ModelPartObj(EntityObj owner, java.util.UUID id, String n) { super("ModelPart"); this.owner = owner; this.id = id; name = n; }
        @Override public void setName(String n) { throw new LuaError("ModelPart.Name is read-only"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Visible": return valueOf(!((GameRuntime) rt).partHidden(id, name));
                case "Entity": case "Owner": return owner;
                case "Offset": case "Position": { float[] f = xf(); return new Vec3L(r4(f[0]), r4(f[1]), r4(f[2])); }
                case "Rotation": case "Orientation": { float[] f = xf(); return new Vec3L(r4(f[3]), r4(f[4]), r4(f[5])); }
                case "Scale": case "Size": { float[] f = xf(); return new Vec3L(r4(f[6]), r4(f[7]), r4(f[8])); }
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            if (k.equals("Visible")) { ((GameRuntime) rt).setPartHidden(id, name, !v.toboolean()); return true; }
            switch (k) {
                case "Offset": case "Position": { Vec3L o = Vec3L.check(v); float[] f = xf(); f[0] = (float) o.x; f[1] = (float) o.y; f[2] = (float) o.z; setXf(f); return true; }
                case "Rotation": case "Orientation": { Vec3L o = Vec3L.check(v); float[] f = xf(); f[3] = (float) o.x; f[4] = (float) o.y; f[5] = (float) o.z; setXf(f); return true; }
                case "Scale": case "Size": { float[] f = xf();
                    if (v.isnumber()) { f[6] = f[7] = f[8] = (float) v.todouble(); } else { Vec3L o = Vec3L.check(v); f[6] = (float) o.x; f[7] = (float) o.y; f[8] = (float) o.z; }
                    setXf(f); return true; }
            }
            return super.setProp(k, v);
        }
        float[] xf() { return ((GameRuntime) rt).partTransform(id, name); }
        static double r4(float f) { return Math.round(f * 10000.0) / 10000.0; }   // 0.1f -> 0.1
        void setXf(float[] f) { ((GameRuntime) rt).setPartTransform(id, name, f); }
        static {
            reg(ModelPartObj.class, "Hide", (s, a) -> { ModelPartObj p = (ModelPartObj) s; ((GameRuntime) p.rt).setPartHidden(p.id, p.name, true); return NONE; });
            reg(ModelPartObj.class, "Show", (s, a) -> { ModelPartObj p = (ModelPartObj) s; ((GameRuntime) p.rt).setPartHidden(p.id, p.name, false); return NONE; });
            // SetTransform(offset: Vector3, rotation: Vector3 (degrees), scale: Vector3 | number) - nil keeps the current value
            reg(ModelPartObj.class, "SetTransform", (s, a) -> { ModelPartObj p = (ModelPartObj) s; float[] f = p.xf();
                if (!a.isnil(1)) { Vec3L o = Vec3L.check(a.arg(1)); f[0] = (float) o.x; f[1] = (float) o.y; f[2] = (float) o.z; }
                if (!a.isnil(2)) { Vec3L o = Vec3L.check(a.arg(2)); f[3] = (float) o.x; f[4] = (float) o.y; f[5] = (float) o.z; }
                if (!a.isnil(3)) { if (a.arg(3).isnumber()) f[6] = f[7] = f[8] = (float) a.todouble(3); else { Vec3L o = Vec3L.check(a.arg(3)); f[6] = (float) o.x; f[7] = (float) o.y; f[8] = (float) o.z; } }
                p.setXf(f); return NONE; });
            reg(ModelPartObj.class, "ResetTransform|Reset", (s, a) -> { ModelPartObj p = (ModelPartObj) s; p.setXf(null); return NONE; });
            reg(ModelPartObj.class, "GetTransform", (s, a) -> { float[] f = ((ModelPartObj) s).xf();
                return varargsOf(new Vec3L(r4(f[0]), r4(f[1]), r4(f[2])), new Vec3L(r4(f[3]), r4(f[4]), r4(f[5])), new Vec3L(r4(f[6]), r4(f[7]), r4(f[8]))); });
        }
    }

    static LuaValue item(ItemStack st, EntityObj o) { return st == null || st.isEmpty() ? NIL : ItemObj.of(st, o); }

    @Override protected LuaValue getProp(String k) {
        if (pending()) {
            switch (k) {
                case "Id": case "Type": return valueOf(pendingType);
                case "Position": return pendingPos == null ? NIL : pendingPos;
                case "Spawned": return FALSE;
            }
            return super.getProp(k);
        }
        switch (k) {
            case "Spawned": return TRUE;
            case "Id": case "Type": return valueOf(EntityType.getKey(e().getType()).toString());
            case "UUID": return valueOf(e().getStringUUID());
            case "EntityId": return valueOf(e().getId());
            case "Position": return Vec3L.of(e().position());
            case "CFrame": return CFrameL.fromYawPitch(Vec3L.of(e().position()), e().getYRot(), e().getXRot());
            case "Velocity": return Vec3L.of(e().getDeltaMovement());
            case "HP": case "Health": return valueOf(living().getHealth());
            case "MaxHP": case "MaxHealth": return valueOf(living().getMaxHealth());
            case "Dimension": return GameRuntime.cur().wrap(e().level());
            case "OnGround": return valueOf(e().onGround());
            case "Alive": return valueOf(e().isAlive());
            case "Effects": {
                LuaTable t = new LuaTable(); int i = 1;
                for (MobEffectInstance m : living().getActiveEffects()) t.set(i++, Conv.effectTable(m));
                return t;
            }
            case "NBTs": return Conv.toLua(nbtRoot(false));
            case "Name": return valueOf(getName());
            case "Frozen": return valueOf(freezeUntil >= 0);
            case "Model": { String d = ((GameRuntime) rt).modelDesc(e().getUUID()); // custom model or the entity's own type (default model)
                return valueOf(d != null ? d : net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e().getType()).toString()); }
            case "Parent": // players live in Players, entities in their Dimension
                if (parent == null && rt instanceof GameRuntime gr) { if (this instanceof PlayerObj) return gr.world.players; if (raw() != null) return gr.wrap(e().level()); }
                break;
            case "HasCustomModel": return valueOf(((GameRuntime) rt).modelDesc(e().getUUID()) != null);
            case "IsHallucination": return valueOf(isHallucination());
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (k.equals("Model") && !pending()) {
            if (!rt.server) throw new LuaError("Entity.Model can only be changed on the server (Entity:SetModel)");
            ModelSync.set(e(), v.isnil() ? null : v.checkjstring(), 1); return true;
        }
        if (pending()) {
            switch (k) {
                case "Id": case "Type": pendingType = Conv.rl(v.checkjstring()).toString(); return true;
                case "Position": pendingPos = Vec3L.check(v); return true;
                case "CFrame": pendingPos = CFrameL.check(v).pos(); return true;
            }
            return super.setProp(k, v);
        }
        switch (k) {
            case "Position": { Vec3L p = Vec3L.check(v); teleport(p.x, p.y, p.z, e().getYRot(), e().getXRot()); return true; }
            case "CFrame": { CFrameL c = CFrameL.check(v); teleport(c.x, c.y, c.z, c.mcYaw(), c.mcPitch()); return true; }
            case "Velocity": { e().setDeltaMovement(Vec3L.check(v).mc()); e().hurtMarked = true; return true; }
            case "HP": case "Health": living().setHealth((float) v.checkdouble()); return true;
            case "MaxHP": case "MaxHealth": {
                var a = living().getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH);
                if (a != null) a.setBaseValue(v.checkdouble());
                return true;
            }
        }
        return super.setProp(k, v);
    }

    public void teleport(double x, double y, double z, float yaw, float pitch) {
        Entity en = e();
        if (en instanceof ServerPlayer sp) sp.teleportTo(sp.serverLevel(), x, y, z, yaw, pitch);
        else { en.moveTo(x, y, z, yaw, pitch); en.setYHeadRot(yaw); if (en.level().isClientSide) en.setPos(x, y, z); }
    }

    /** persistent "fluwa" compound (temp = removed on death, players only) */
    public CompoundTag nbtRoot(boolean temp) {
        CompoundTag pd = e().getPersistentData();
        String key = temp ? "fluwa_tmp" : "fluwa";
        if (!pd.contains(key)) pd.put(key, new CompoundTag());
        return pd.getCompound(key);
    }

    static Varargs effects(EntityObj s, Varargs a) {
        LivingEntity l = s.living();
        for (int i = 1; i <= a.narg(); i++) {
            LuaValue t = a.arg(i);
            String nm; double dur = 30; int amp = 0; boolean hide = false;
            if (t.istable()) {
                nm = t.get(1).checkjstring();
                dur = t.get(2).optdouble(30);
                amp = t.get(3).optint(0);
                hide = t.get(4).optboolean(false);
            } else nm = t.checkjstring();
            int ticks = dur < 0 ? MobEffectInstance.INFINITE_DURATION : (int) Math.round(dur * 20);
            l.addEffect(new MobEffectInstance(Conv.effect(nm), ticks, amp, false, !hide, !hide));
        }
        return TRUE;
    }

    static {
        WorldTween.install(EntityObj.class, WorldTween.ENTITY);
        BlockEntities.install();
        reg(EntityObj.class, "Hurt", (s, a) -> { EntityObj o = (EntityObj) s; o.e().hurt(o.e().damageSources().generic(), (float) a.checkdouble(1)); return NONE; });
        reg(EntityObj.class, "Kill", (s, a) -> { ((EntityObj) s).e().kill(); return NONE; });
        reg(EntityObj.class, "Heal", (s, a) -> { ((EntityObj) s).living().heal((float) a.checkdouble(1)); return NONE; });
        reg(EntityObj.class, "PivotTo|Teleport", (s, a) -> { EntityObj o = (EntityObj) s; CFrameL c = CFrameL.check(a.arg1());
            boolean keepRot = !(a.arg1() instanceof CFrameL);
            o.teleport(c.x, c.y, c.z, keepRot ? o.e().getYRot() : c.mcYaw(), keepRot ? o.e().getXRot() : c.mcPitch()); return NONE; });
        reg(EntityObj.class, "Burn", (s, a) -> { ((EntityObj) s).e().setSecondsOnFire(a.optint(1, 5)); return NONE; });
        reg(EntityObj.class, "Stew|Extinguish", (s, a) -> { ((EntityObj) s).e().clearFire(); return NONE; });
        reg(EntityObj.class, "GetEffect|GE", (s, a) -> effects((EntityObj) s, a));
        reg(EntityObj.class, "ClearEffect|CE", (s, a) -> {
            LivingEntity l = ((EntityObj) s).living(); boolean any = false;
            for (int i = 1; i <= a.narg(); i++) any |= l.removeEffect(Conv.effect(a.checkjstring(i)));
            return valueOf(any); });
        reg(EntityObj.class, "ClearAllEffects|CAE", (s, a) -> valueOf(((EntityObj) s).living().removeAllEffects()));
        reg(EntityObj.class, "SetNBT", (s, a) -> {
            EntityObj o = (EntityObj) s; String key = a.checkjstring(1);
            boolean temp = a.optboolean(3, false);
            o.nbtRoot(!temp).remove(key);
            if (a.isnil(2)) o.nbtRoot(temp).remove(key); else o.nbtRoot(temp).put(key, Conv.toTag(a.arg(2)));
            return NONE; });
        reg(EntityObj.class, "ReadNBT", (s, a) -> {
            EntityObj o = (EntityObj) s; String key = a.checkjstring(1);
            if (o.nbtRoot(false).contains(key)) return Conv.toLua(o.nbtRoot(false).get(key));
            if (o.nbtRoot(true).contains(key)) return Conv.toLua(o.nbtRoot(true).get(key));
            return NIL; });
        reg(EntityObj.class, "isAlive|IsAlive", (s, a) -> valueOf(((EntityObj) s).e().isAlive()));
        reg(EntityObj.class, "ApplyImpulse", (s, a) -> { Entity en = ((EntityObj) s).e(); en.setDeltaMovement(en.getDeltaMovement().add(Vec3L.check(a.arg1()).mc())); en.hurtMarked = true; return NONE; });
        reg(EntityObj.class, "Freeze", (s, a) -> { ((EntityObj) s).freezeEntity(a.optdouble(1, 0), a.optboolean(2, false)); return NONE; });
        reg(EntityObj.class, "UnFreeze|Unfreeze", (s, a) -> { ((EntityObj) s).unfreezeEntity(); return NONE; });
        reg(EntityObj.class, "GetModel|GetModelParts", (s, a) -> modelParts((EntityObj) s));
        reg(EntityObj.class, "GetModelPart|GetPart", (s, a) -> { EntityObj o = (EntityObj) s; String n = a.checkjstring(1);
            for (String x : ((GameRuntime) o.rt).modelPartNames(o.e())) if (x.equalsIgnoreCase(n)) return new ModelPartObj(o, o.e().getUUID(), x);
            if (n.equals("Model")) return new ModelPartObj(o, o.e().getUUID(), "Model");
            return a.optboolean(2, false) ? new ModelPartObj(o, o.e().getUUID(), n) : NIL; });
        reg(EntityObj.class, "SetModel", (s, a) -> { EntityObj o = (EntityObj) s;
            if (!o.rt.server) throw new LuaError("Entity:SetModel is only Server-Side");
            ModelSync.set(o.e(), a.isnil(1) ? null : a.checkjstring(1), (float) a.optdouble(2, 1)); return NONE; });
        reg(EntityObj.class, "GetArmor", (s, a) -> { LuaTable t = new LuaTable(); int i = 1;
            for (ItemStack st : ((EntityObj) s).living().getArmorSlots()) t.set(i++, st.isEmpty() ? FALSE : ItemObj.of(st, (EntityObj) s));
            return t; });
        reg(EntityObj.class, "GetMainHand|GMH", (s, a) -> item(((EntityObj) s).living().getMainHandItem(), (EntityObj) s));
        reg(EntityObj.class, "GetSecondaryHand|GSH", (s, a) -> item(((EntityObj) s).living().getOffhandItem(), (EntityObj) s));
        reg(EntityObj.class, "isMHand", (s, a) -> valueOf(!((EntityObj) s).living().getMainHandItem().isEmpty()));
        reg(EntityObj.class, "isSHand", (s, a) -> valueOf(!((EntityObj) s).living().getOffhandItem().isEmpty()));
        reg(EntityObj.class, "DrownStart", (s, a) -> { EntityObj o = (EntityObj) s; o.drownMode = 1; o.drownAir = o.e().getAirSupply(); return NONE; });
        reg(EntityObj.class, "DrownPause", (s, a) -> { EntityObj o = (EntityObj) s; o.drownMode = 2; o.drownAir = o.e().getAirSupply(); return NONE; });
        reg(EntityObj.class, "DrownEnd", (s, a) -> { EntityObj o = (EntityObj) s; o.drownMode = 0; o.e().setAirSupply(o.e().getMaxAirSupply()); return NONE; });
        reg(EntityObj.class, "isDrown", (s, a) -> { EntityObj o = (EntityObj) s; Entity en = o.e();
            return valueOf(o.drownMode == 1 || (en.isUnderWater() && en.getAirSupply() < en.getMaxAirSupply())); });
        reg(EntityObj.class, "HideName", (s, a) -> { EntityObj o = (EntityObj) s; Entity en = o.e();
            en.setCustomNameVisible(false);
            if (o.rt.server) EntityFlags.set(en, "hidename", true); else GameRuntime.cur().localFlag(en.getUUID(), "hidename", true);
            return NONE; });
        reg(EntityObj.class, "ShowName", (s, a) -> { EntityObj o = (EntityObj) s; Entity en = o.e();
            if (en.hasCustomName()) en.setCustomNameVisible(true);
            if (o.rt.server) EntityFlags.set(en, "hidename", false); else GameRuntime.cur().localFlag(en.getUUID(), "hidename", false);
            return NONE; });
        reg(EntityObj.class, "isServer|isClassic", (s, a) -> valueOf(!((EntityObj) s).isHallucination()));
        reg(EntityObj.class, "isClient|isHallucination", (s, a) -> valueOf(((EntityObj) s).isHallucination()));
        reg(EntityObj.class, "GetDistance|DistanceTo", (s, a) -> {
            Entity en = ((EntityObj) s).e(); LuaValue t = a.arg1();
            Vec3 p = t instanceof EntityObj o ? o.e().position() : Vec3L.check(t).mc();
            return valueOf(en.position().distanceTo(p)); });
    }
}
