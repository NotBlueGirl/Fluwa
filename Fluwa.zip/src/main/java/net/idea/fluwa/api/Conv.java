package net.idea.fluwa.api;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.idea.fluwa.Config;
import net.idea.fluwa.lua.*;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.level.block.state.BlockState;
import org.luaj.vm2.*;

import java.util.*;

/** Conversions between Lua values and Minecraft objects. */
public final class Conv {
    private Conv() {}

    public static ResourceLocation rl(String s) {
        String t = s.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        ResourceLocation r = ResourceLocation.tryParse(t.contains(":") ? t : "minecraft:" + t);
        if (r == null) throw new LuaError("Invalid id: " + s);
        return r;
    }

    public static BlockState block(String id) {
        String s = id.trim();
        if (!s.contains(":")) s = "minecraft:" + s.toLowerCase(Locale.ROOT).replace(' ', '_');
        try {
            return BlockStateParser.parseForBlock(BuiltInRegistries.BLOCK.asLookup(), s, false).blockState();
        } catch (CommandSyntaxException e) {
            throw new LuaError("Unknown block '" + id + "': " + e.getMessage());
        }
    }

    public static String id(BlockState st) { return BuiltInRegistries.BLOCK.getKey(st.getBlock()).toString(); }

    public static MobEffect effect(String name) {
        MobEffect e = BuiltInRegistries.MOB_EFFECT.get(rl(name));
        if (e == null || !BuiltInRegistries.MOB_EFFECT.containsKey(rl(name))) throw new LuaError("Unknown effect: " + name);
        return e;
    }

    public static String effectName(MobEffect e) { ResourceLocation k = BuiltInRegistries.MOB_EFFECT.getKey(e); return k == null ? "?" : k.getPath(); }

    public static LuaTable effectTable(MobEffectInstance i) {
        LuaTable t = new LuaTable();
        t.set(1, LuaValue.valueOf(effectName(i.getEffect())));
        t.set(2, LuaValue.valueOf(i.isInfiniteDuration() ? -1 : i.getDuration() / 20.0));
        t.set(3, LuaValue.valueOf(!i.isVisible()));
        t.set(4, LuaValue.valueOf(i.getAmplifier()));
        return t;
    }

    public static SoundEvent sound(String id) {
        ResourceLocation r = rl(id);
        SoundEvent s = BuiltInRegistries.SOUND_EVENT.get(r);
        return s != null ? s : SoundEvent.createVariableRangeEvent(r);
    }

    public static void checkVolume(long n) {
        if (n > Config.maxBlocksPerCall) throw new LuaError("Too many blocks in one call (" + n + " > " + Config.maxBlocksPerCall + "), see config maxBlocksPerCall");
    }

    public static BlockPos min(Vec3L a, Vec3L b) { return BlockPos.containing(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z)); }
    public static BlockPos max(Vec3L a, Vec3L b) { return BlockPos.containing(Math.max(a.x, b.x), Math.max(a.y, b.y), Math.max(a.z, b.z)); }

    // ------------------------------------------------------------ NBT <-> Lua
    public static LuaValue toLua(Tag t) {
        if (t == null) return LuaValue.NIL;
        if (t instanceof NumericTag n) return LuaValue.valueOf(n.getAsDouble());
        if (t instanceof StringTag s) return LuaValue.valueOf(s.getAsString());
        if (t instanceof CompoundTag c) {
            LuaTable r = new LuaTable();
            for (String k : c.getAllKeys()) r.set(k, toLua(c.get(k)));
            return r;
        }
        if (t instanceof CollectionTag<?> l) {
            LuaTable r = new LuaTable();
            int i = 1;
            for (Object o : l) r.set(i++, toLua((Tag) o));
            return r;
        }
        return LuaValue.valueOf(t.getAsString());
    }

    public static Tag toTag(LuaValue v) {
        if (v.isboolean()) return ByteTag.valueOf(v.toboolean());
        if (v.type() == LuaValue.TNUMBER) {
            double d = v.todouble();
            return d == Math.rint(d) && Math.abs(d) < Integer.MAX_VALUE ? IntTag.valueOf((int) d) : DoubleTag.valueOf(d);
        }
        if (v.type() == LuaValue.TSTRING) return StringTag.valueOf(v.tojstring());
        if (v instanceof Vec3L p) { ListTag l = new ListTag(); l.add(DoubleTag.valueOf(p.x)); l.add(DoubleTag.valueOf(p.y)); l.add(DoubleTag.valueOf(p.z)); return l; }
        if (v.istable()) {
            LuaTable t = v.checktable();
            int n = t.length();
            boolean array = n > 0;
            LuaValue k = LuaValue.NIL; int count = 0;
            while (true) { Varargs e = t.next(k); if ((k = e.arg1()).isnil()) break; count++; }
            if (count != n) array = false;
            if (array) {
                ListTag l = new ListTag();
                byte type = -1;
                for (int i = 1; i <= n; i++) {
                    Tag x = toTag(t.get(i));
                    if (type == -1) type = x.getId();
                    if (x.getId() != type) { array = false; break; }
                    l.add(x);
                }
                if (array) return l;
            }
            CompoundTag c = new CompoundTag();
            k = LuaValue.NIL;
            while (true) { Varargs e = t.next(k); if ((k = e.arg1()).isnil()) break; c.put(k.tojstring(), toTag(e.arg(2))); }
            return c;
        }
        if (v.isnil()) return StringTag.valueOf("");
        return StringTag.valueOf(v.tojstring());
    }

    /** Random block picker for SetBox/SetSphere settings: {add = {ids...}, weights = {w...}} */
    public static final class Picker {
        final List<BlockState> states = new ArrayList<>();
        final List<Double> weights = new ArrayList<>();
        double total;
        final Random rnd = new Random();

        public Picker(String id, LuaValue settings) {
            states.add(block(id));
            if (settings != null && settings.istable()) {
                LuaValue add = settings.get("add");
                if (add.istable()) for (int i = 1; i <= add.length(); i++) states.add(block(add.get(i).checkjstring()));
                LuaValue w = settings.get("weights");
                for (int i = 0; i < states.size(); i++) {
                    double wt = 1;
                    if (w.istable()) {
                        // weights may be given for {block_id, add...} or only for add (then block_id has weight 1)
                        int idx = w.length() == states.size() ? i + 1 : i;
                        if (idx >= 1 && !w.get(idx).isnil()) wt = w.get(idx).checkdouble();
                    }
                    weights.add(Math.max(0, wt));
                }
            } else weights.add(1.0);
            for (double d : weights) total += d;
        }

        public BlockState next() {
            if (states.size() == 1 || total <= 0) return states.get(0);
            double r = rnd.nextDouble() * total;
            for (int i = 0; i < states.size(); i++) { r -= weights.get(i); if (r <= 0) return states.get(i); }
            return states.get(states.size() - 1);
        }
    }
}
