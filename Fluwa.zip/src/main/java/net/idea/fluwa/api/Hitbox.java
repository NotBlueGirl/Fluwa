package net.idea.fluwa.api;

import net.idea.fluwa.Fluwa;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.TagParser;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-entity custom hitbox (width x height in blocks), independent of the model scale.
 * Saved in the entity's persistent data, replicated to clients, applied through Forge's EntityEvent.Size.
 * Also replicates "solid" BlockEntities (Block:ToBlockEntity(true)) so clients can collide with them.
 */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class Hitbox {
    private Hitbox() {}

    public static final Map<UUID, float[]> MAP = new ConcurrentHashMap<>();
    static final String KEY = "fluwa_hitbox";

    @SubscribeEvent
    public static void size(EntityEvent.Size e) {
        UUID id = e.getEntity().getUUID();
        if (id == null || MAP.isEmpty()) return;
        float[] h = MAP.get(id);
        if (h != null) e.setNewSize(EntityDimensions.scalable(h[0], h[1]), true);
    }

    /** w/h <= 0 resets to the normal hitbox */
    public static void set(Entity e, float w, float h) {
        CompoundTag pd = e.getPersistentData();
        if (w <= 0 || h <= 0) { MAP.remove(e.getUUID()); pd.remove(KEY); }
        else {
            MAP.put(e.getUUID(), new float[]{w, h});
            CompoundTag t = new CompoundTag(); t.putFloat("w", w); t.putFloat("h", h); pd.put(KEY, t);
        }
        e.refreshDimensions();
        if (!e.level().isClientSide) FluwaNet.toAll(pkt(e.getUUID()));
    }

    public static float[] get(Entity e) { return MAP.get(e.getUUID()); }

    /** entity joined a server level: restore saved hitbox / solid flag */
    public static void joined(Entity e) {
        CompoundTag pd = e.getPersistentData();
        boolean send = false;
        if (pd.contains(KEY)) {
            CompoundTag t = pd.getCompound(KEY);
            MAP.put(e.getUUID(), new float[]{t.getFloat("w"), t.getFloat("h")});
            e.refreshDimensions();
            send = true;
        }
        if (pd.contains(BlockEntities.KEY) && pd.getCompound(BlockEntities.KEY).getBoolean("solid")) {
            Colliders.SOLID.put(e.getUUID(), NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), pd.getCompound(BlockEntities.KEY).getCompound("state")));
            send = true;
        }
        if (send) FluwaNet.toAll(pkt(e.getUUID()));
    }

    public static void left(Entity e) {
        if (e.isRemoved() && e.getRemovalReason() != null && e.getRemovalReason().shouldDestroy()) {
            boolean had = MAP.remove(e.getUUID()) != null | Colliders.SOLID.remove(e.getUUID()) != null;
            if (had && !e.level().isClientSide) FluwaNet.toAll(pkt(e.getUUID()));
        }
    }

    /** s: uuid, "w h" or "", solid state SNBT or "" */
    static Pkt pkt(UUID id) {
        float[] h = MAP.get(id);
        BlockState s = Colliders.SOLID.get(id);
        return new Pkt(Pkt.S_HITBOX, List.of(id.toString(), h == null ? "" : h[0] + " " + h[1], s == null ? "" : NbtUtils.writeBlockState(s).toString()), null, null);
    }

    public static void sendAll(ServerPlayer sp) {
        java.util.Set<UUID> ids = new java.util.HashSet<>(MAP.keySet());
        ids.addAll(Colliders.SOLID.keySet());
        for (UUID id : ids) FluwaNet.toPlayer(sp, pkt(id));
    }

    /** client: apply a hitbox packet; returns the uuid so the caller can refresh the entity */
    public static UUID receive(Pkt p) {
        UUID id = UUID.fromString(p.s(0));
        if (p.s(1).isEmpty()) MAP.remove(id);
        else { String[] a = p.s(1).split(" "); MAP.put(id, new float[]{Float.parseFloat(a[0]), Float.parseFloat(a[1])}); }
        if (p.s(2).isEmpty()) Colliders.SOLID.remove(id);
        else {
            try { Colliders.SOLID.put(id, NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), TagParser.parseTag(p.s(2)))); }
            catch (Exception ex) { Colliders.SOLID.remove(id); }
        }
        return id;
    }
}
