package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import org.luaj.vm2.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Item stack. Items from inventories are live: changing Count changes the real slot.
 * Fluwa data lives in the stack NBT under "fluwa" (custom Id, description, stack/durability overrides, rarity,
 * tags, custom data, icon, model, GUI, Can* flags, UID for events).
 */
public class ItemObj extends EvObj {
    public ItemStack stack;
    /** Player/Entity holding the stack (if known) */
    public EntityObj owner;
    /** dropped item entity (if the item lies in the world) */
    public ItemEntity drop;

    /** event registry: side + UID -> item object with handlers */
    static final Map<String, ItemObj> REG = new ConcurrentHashMap<>();

    static final List<String> EVENTS = List.of("E_Used", "E_Attacked", "E_Damaged", "E_Repaired", "E_Enchant", "E_EnchDel", "E_Removed",
            "E_CountChanged", "E_Dropped", "E_Picked", "E_GUIChanged", "E_NBTChanged", "E_TagAdded", "E_TagRemoved", "E_RarityChanged",
            "E_ModelChanged", "E_IconChanged", "E_DescriptionChanged", "E_Destroyed", "E_Cloned", "E_ChildAdded", "E_ChildRemoved", "E_AttributeChanged");

    public ItemObj(ItemStack s) { super("Item"); stack = s; }
    public ItemObj(ItemEntity e) { this(e.getItem()); drop = e; }
    public static ItemObj of(ItemStack s, EntityObj owner) { ItemObj o = new ItemObj(s); o.owner = owner; return o; }

    @Override protected Collection<String> eventNames() { return EVENTS; }

    @Override public Signal ev(String n) {
        String uid = uid(true);
        REG.put(key(rt != null && rt.server, uid), this);
        return super.ev(n);
    }

    static String key(boolean server, String uid) { return (server ? "S:" : "C:") + uid; }

    // ------------------------------------------------------------------ static NBT helpers (also used by the mixin)
    public static CompoundTag data(ItemStack s) {
        CompoundTag t = s.getTag();
        return t != null && t.contains("fluwa", Tag.TAG_COMPOUND) ? t.getCompound("fluwa") : null;
    }
    CompoundTag fd() { return stack.getOrCreateTagElement("fluwa"); }
    public static boolean flag(ItemStack s, String k) { CompoundTag d = data(s); return d == null || !d.contains(k) || d.getBoolean(k); }

    String uid(boolean create) {
        CompoundTag d = data(stack);
        if (d != null && d.contains("UID")) return d.getString("UID");
        if (!create) return null;
        String u = UUID.randomUUID().toString();
        fd().putString("UID", u);
        return u;
    }

    /** handlers registered for a stack (or null) */
    public static ItemObj find(ItemStack s, boolean server) {
        if (s == null || s.isEmpty()) return null;
        CompoundTag d = data(s);
        if (d == null || !d.contains("UID")) return null;
        ItemObj o = REG.get(key(server, d.getString("UID")));
        if (o == null) return null;
        if (o.rt == null || o.rt.closed) { REG.values().remove(o); return null; }
        return o;
    }

    public static ItemStack create(String id, int count) {
        var rl = Conv.rl(id);
        if (!BuiltInRegistries.ITEM.containsKey(rl)) throw new LuaError("Unknown item: " + id);
        Item it = BuiltInRegistries.ITEM.get(rl);
        return new ItemStack(it, Math.max(1, count));
    }

    String itemType() { return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString(); }
    String id() { CompoundTag d = data(stack); return d != null && d.contains("Id") ? d.getString("Id") : itemType(); }

    void setType(String t) {
        int c = stack.getCount();
        ItemStack n = create(t, c);
        if (stack.getTag() != null) n.setTag(stack.getTag().copy());
        replace(n);
    }
    /** swap the underlying stack (keeps inventory slot / drop entity in sync when possible) */
    void replace(ItemStack n) {
        ItemStack old = stack;
        if (drop != null && !drop.isRemoved()) drop.setItem(n);
        else if (owner != null && owner.raw() instanceof Player p) {
            var inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) if (inv.getItem(i) == old) { inv.setItem(i, n); break; }
        }
        stack = n;
    }

    void setId(String v) {
        var rl = ResourceLocation_try(v);
        if (rl != null && BuiltInRegistries.ITEM.containsKey(rl) && !v.isEmpty() && BuiltInRegistries.ITEM.get(rl) != net.minecraft.world.item.Items.AIR) {
            CompoundTag d = data(stack); if (d != null) d.remove("Id");
            setType(rl.toString());
        } else fd().putString("Id", v);
    }
    static net.minecraft.resources.ResourceLocation ResourceLocation_try(String v) {
        return net.minecraft.resources.ResourceLocation.tryParse(v.contains(":") ? v : "minecraft:" + v);
    }

    String desc() { CompoundTag d = data(stack); return d != null ? d.getString("Desc") : ""; }
    void setDesc(String v) {
        fd().putString("Desc", v);
        var display = stack.getOrCreateTagElement("display");
        ListTag list = new ListTag();
        if (!v.isEmpty()) for (String line : v.split("\n")) list.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(line))));
        if (list.isEmpty()) display.remove("Lore"); else display.put("Lore", list);
        fire("E_DescriptionChanged", valueOf(v));
    }

    int maxDur() { return stack.getMaxDamage(); }
    int dur() { return stack.isDamageableItem() ? stack.getMaxDamage() - stack.getDamageValue() : 0; }

    void setCount(int n) {
        int old = stack.getCount();
        stack.setCount(Math.max(0, n));
        if (old != n) fire("E_CountChanged", valueOf(old), valueOf(n));
    }

    public void damage(int n) {
        if (!flag(stack, "CanDamage")) return;
        if (!stack.isDamageableItem()) throw new LuaError("Item is not damageable (set MaxDurability first)");
        stack.setDamageValue(Math.min(stack.getMaxDamage(), stack.getDamageValue() + n));
        fire("E_Damaged", valueOf(n), valueOf(dur()));
        if (dur() <= 0) { setCount(0); fire("E_Destroyed"); }
    }
    public void repair(int n) {
        if (!flag(stack, "CanRepair")) return;
        stack.setDamageValue(Math.max(0, stack.getDamageValue() - n));
        fire("E_Repaired", valueOf(n), valueOf(dur()));
    }

    LuaTable tags() {
        LuaTable t = new LuaTable();
        CompoundTag d = data(stack);
        if (d != null) { ListTag l = d.getList("Tags", Tag.TAG_STRING); for (int i = 0; i < l.size(); i++) t.set(i + 1, valueOf(l.getString(i))); }
        return t;
    }
    boolean hasTag(String tag) {
        CompoundTag d = data(stack);
        if (d == null) return false;
        ListTag l = d.getList("Tags", Tag.TAG_STRING);
        for (int i = 0; i < l.size(); i++) if (l.getString(i).equals(tag)) return true;
        return false;
    }
    void addTag(String tag) {
        if (hasTag(tag)) return;
        ListTag l = fd().getList("Tags", Tag.TAG_STRING); l.add(StringTag.valueOf(tag)); fd().put("Tags", l);
        fire("E_TagAdded", valueOf(tag));
    }
    void removeTag(String tag) {
        CompoundTag d = data(stack); if (d == null) return;
        ListTag l = d.getList("Tags", Tag.TAG_STRING);
        for (int i = 0; i < l.size(); i++) if (l.getString(i).equals(tag)) { l.remove(i); d.put("Tags", l); fire("E_TagRemoved", valueOf(tag)); return; }
    }
    void setTags(LuaValue v) {
        LuaTable t = v.checktable();
        for (LuaValue x : tags().unpack().narg() > 0 ? toList(tags()) : List.<LuaValue>of()) removeTag(x.tojstring());
        for (LuaValue x : toList(t)) addTag(x.tojstring());
    }
    static List<LuaValue> toList(LuaTable t) { List<LuaValue> l = new ArrayList<>(); for (int i = 1; i <= t.length(); i++) l.add(t.get(i)); return l; }

    LuaValue custom(String k) { CompoundTag d = data(stack); return d != null && d.getCompound("Data").contains(k) ? Conv.toLua(d.getCompound("Data").get(k)) : NIL; }
    void setCustom(String k, LuaValue v) {
        CompoundTag c = fd().getCompound("Data");
        if (v.isnil()) c.remove(k); else c.put(k, Conv.toTag(v));
        fd().put("Data", c);
    }

    String str(String k) { CompoundTag d = data(stack); return d != null && d.contains(k) ? d.getString(k) : null; }
    static LuaValue s(String v) { return v == null ? NIL : valueOf(v); }

    LuaTable enchants() {
        LuaTable t = new LuaTable();
        EnchantmentHelper.getEnchantments(stack).forEach((e, lv) -> t.set(String.valueOf(BuiltInRegistries.ENCHANTMENT.getKey(e)), valueOf(lv)));
        return t;
    }
    static net.minecraft.world.item.enchantment.Enchantment ench(String n) {
        String id = n.contains(":") ? n : "minecraft:" + n.replaceAll("([a-z])([A-Z])", "$1_$2").replace(' ', '_').toLowerCase(Locale.ROOT);
        var e = BuiltInRegistries.ENCHANTMENT.get(Conv.rl(id));
        if (e == null) throw new LuaError("Unknown enchantment " + n);
        return e;
    }
    String enchName(net.minecraft.world.item.enchantment.Enchantment e) { return String.valueOf(BuiltInRegistries.ENCHANTMENT.getKey(e)); }

    void setGui(LuaValue v) {
        String g = v.isnil() ? null : v instanceof LObj o ? o.getName() : v.checkjstring();
        if (g == null) { CompoundTag d = data(stack); if (d != null) d.remove("GUI"); } else fd().putString("GUI", g);
        fire("E_GUIChanged", v);
    }
    LuaValue gui() {
        String g = str("GUI");
        if (g == null) return NIL;
        if (rt != null && !rt.server) { LuaValue ui = rt.g.get("UI"); if (ui instanceof LObj u) { LuaValue c = u.get(g); if (!c.isnil()) return c; } }
        return valueOf(g);
    }

    LuaValue model() {
        String m = str("Model");
        if (m == null) return NIL;
        try { return Projector.imp(rt, m, NIL, false); } catch (LuaError e) { return valueOf(m); }
    }

    String slot() {
        if (drop != null) return "drop";
        if (owner == null || !(owner.raw() instanceof LivingEntity le)) return "none";
        if (le.getMainHandItem() == stack) return "mainhand";
        if (le.getOffhandItem() == stack) return "offhand";
        int i = 0;
        for (ItemStack a : le.getArmorSlots()) { if (a == stack) return "armor" + i; i++; }
        if (le instanceof Player p) {
            var inv = p.getInventory().items;
            for (int k = 0; k < inv.size(); k++) if (inv.get(k) == stack) return k < 9 ? "hotbar" + k : "inventory" + k;
        }
        return "none";
    }

    LuaTable serialize() { return (LuaTable) Conv.toLua(stack.save(new CompoundTag())); }
    void deserialize(LuaValue t) {
        Tag tag = Conv.toTag(t);
        if (!(tag instanceof CompoundTag c)) throw new LuaError("Item:Deserialize expects a table");
        if (!c.contains("id")) c.putString("id", itemType());
        if (!c.contains("Count")) c.putByte("Count", (byte) stack.getCount());
        ItemStack n = ItemStack.of(c);
        if (n.isEmpty()) throw new LuaError("Bad item data");
        replace(n);
    }

    // ------------------------------------------------------------------ parenting
    @Override public void setParent(LObj p) {
        if (p instanceof PlayerObj po) { give(po.p()); owner = po; return; }
        if (p instanceof EntityObj eo && eo.raw() instanceof LivingEntity le) {
            if (le.getMainHandItem().isEmpty()) le.setItemInHand(InteractionHand.MAIN_HAND, stack);
            else le.setItemInHand(InteractionHand.OFF_HAND, stack);
            owner = eo; return;
        }
        if (p instanceof DimensionObj d) { dropAt(EntityObj.sl(d.level()), Vec3L.of(EntityObj.sl(d.level()).getSharedSpawnPos()).mc()); return; }
        super.setParent(p);
    }
    void give(Player p) {
        String u = uid(true);
        ItemStack copy = stack.copy();
        if (!p.getInventory().add(copy)) p.drop(copy, false);
        for (ItemStack s : p.getInventory().items) { CompoundTag d = data(s); if (d != null && u.equals(d.getString("UID"))) { stack = s; break; } }
        drop = null;
    }
    void dropAt(ServerLevel l, net.minecraft.world.phys.Vec3 pos) {
        ItemEntity e = new ItemEntity(l, pos.x, pos.y, pos.z, stack.copy());
        e.setDefaultPickUpDelay();
        l.addFreshEntity(e);
        drop = e; stack = e.getItem(); owner = null;
    }

    @Override protected void onDestroy() {
        stack.setCount(0);
        if (drop != null && !drop.isRemoved()) drop.discard();
        fire("E_Destroyed");
    }

    @Override public String getName() { return stack.getHoverName().getString(); }
    @Override public void setName(String n) { stack.setHoverName(Component.literal(n)); }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Id": return valueOf(id());
            case "Type": return valueOf(itemType());
            case "Count": case "Amount": return valueOf(stack.getCount());
            case "MaxCount": case "MaxStack": return valueOf(stack.getMaxStackSize());
            case "Stackable": return valueOf(stack.getMaxStackSize() > 1);
            case "Damage": return valueOf(stack.getDamageValue());
            case "MaxDamage": case "MaxDurability": return valueOf(stack.getMaxDamage());
            case "Durability": return valueOf(dur());
            case "Empty": return valueOf(stack.isEmpty());
            case "NBTs": return stack.getTag() == null ? new LuaTable() : Conv.toLua(stack.getTag());
            case "Description": return valueOf(desc());
            case "Enchantments": return enchants();
            case "GUI": return gui();
            case "Model": return model();
            case "Icon": return s(str("Icon"));
            case "Rarity": return valueOf(stack.getRarity().name().toLowerCase(Locale.ROOT));
            case "Tags": return tags();
            case "CustomData": { CompoundTag d = data(stack); return d == null ? new LuaTable() : Conv.toLua(d.getCompound("Data")); }
            case "Owner": return owner != null ? owner : NIL;
            case "Slot": return valueOf(slot());
            case "Dimension": {
                Entity e = drop != null ? drop : owner != null ? owner.raw() : null;
                return e == null ? NIL : GameRuntime.cur().wrap(e.level());
            }
            case "Position": return drop != null ? Vec3L.of(drop.position()) : owner != null && owner.raw() != null ? Vec3L.of(owner.raw().position()) : NIL;
            case "CFrame": return drop != null ? CFrameL.fromYawPitch(Vec3L.of(drop.position()), drop.getYRot(), 0) : NIL;
            case "Visible": return valueOf(flag(stack, "Visible"));
            case "CanDrop": case "CanUse": case "CanAttack": case "CanEnchant": case "CanDamage": case "CanRepair": return valueOf(flag(stack, k));
            case "Entity": return drop != null ? GameRuntime.cur().wrapEntity(drop) : NIL;
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "Count": case "Amount": setCount(v.checkint()); return true;
            case "Damage": stack.setDamageValue(v.checkint()); return true;
            case "Id": setId(v.checkjstring()); return true;
            case "Type": setType(v.checkjstring()); return true;
            case "Stackable": fd().putInt("MaxStack", v.toboolean() ? 64 : 1); return true;
            case "MaxStack": case "MaxCount": fd().putInt("MaxStack", Math.max(1, Math.min(99, v.checkint()))); return true;
            case "MaxDurability": case "MaxDamage": {
                int m = Math.max(0, v.checkint()); int d = dur();
                fd().putInt("MaxDur", m);
                if (m > 0) stack.setDamageValue(Math.max(0, m - (d > 0 ? Math.min(d, m) : m)));
                return true;
            }
            case "Durability": {
                if (!stack.isDamageableItem()) throw new LuaError("Set Item.MaxDurability first");
                int n = Math.max(0, Math.min(maxDur(), v.checkint())); int old = dur();
                stack.setDamageValue(maxDur() - n);
                if (n < old) fire("E_Damaged", valueOf(old - n), valueOf(n)); else if (n > old) fire("E_Repaired", valueOf(n - old), valueOf(n));
                return true;
            }
            case "Description": setDesc(v.checkjstring()); return true;
            case "Icon": fd().putString("Icon", v.checkjstring()); fire("E_IconChanged", v); return true;
            case "Rarity": setRarity(v.checkjstring()); return true;
            case "Tags": setTags(v); return true;
            case "CustomData": {
                CompoundTag c = Conv.toTag(v) instanceof CompoundTag ct ? ct : new CompoundTag();
                fd().put("Data", c); return true;
            }
            case "Position": case "CFrame": {
                if (drop == null) throw new LuaError("Item." + k + " can be set only for dropped items");
                CFrameL c = CFrameL.check(v); drop.moveTo(c.x, c.y, c.z, drop.getYRot(), 0); return true;
            }
            case "Visible": fd().putBoolean("Visible", v.toboolean()); if (drop != null) drop.setInvisible(!v.toboolean()); return true;
            case "CanDrop": case "CanUse": case "CanAttack": case "CanEnchant": case "CanDamage": case "CanRepair": fd().putBoolean(k, v.toboolean()); return true;
            case "NBTs": case "Enchantments": case "GUI": case "Model": case "Owner": case "Slot": case "Dimension":
                throw new LuaError("Item." + k + " is read-only");
        }
        return super.setProp(k, v);
    }

    void setRarity(String r) {
        Rarity ra;
        try { ra = Rarity.valueOf(r.toUpperCase(Locale.ROOT)); } catch (IllegalArgumentException e) { throw new LuaError("Rarity must be common/uncommon/rare/epic"); }
        fd().putString("Rarity", ra.name());
        fire("E_RarityChanged", valueOf(ra.name().toLowerCase(Locale.ROOT)));
    }

    @Override protected LuaValue cloneObj() { return cloneItem(); }
    ItemObj cloneItem() {
        ItemStack c = stack.copy();
        CompoundTag d = data(c); if (d != null) d.remove("UID");
        ItemObj o = new ItemObj(c);
        fire("E_Cloned", o);
        return o;
    }

    static ItemObj I(LuaValue s) { return (ItemObj) s; }

    static {
        Class<ItemObj> C = ItemObj.class;
        reg(C, "SetNBT", (s, a) -> { I(s).stack.getOrCreateTag().put(a.checkjstring(1), Conv.toTag(a.arg(2))); I(s).fire("E_NBTChanged", a.arg(1), a.arg(2)); return NONE; });
        reg(C, "ReadNBT|GetNBT", (s, a) -> { var t = I(s).stack.getTag(); return t == null || !t.contains(a.checkjstring(1)) ? NIL : Conv.toLua(t.get(a.checkjstring(1))); });
        reg(C, "GetNBTs", (s, a) -> I(s).getProp("NBTs"));
        reg(C, "SetLore", (s, a) -> {
            StringBuilder b = new StringBuilder();
            for (int i = 1; i <= a.narg(); i++) { if (i > 1) b.append('\n'); b.append(a.checkjstring(i)); }
            I(s).setDesc(b.toString()); return NONE; });
        reg(C, "Enchant", (s, a) -> {
            ItemObj o = I(s);
            if (!flag(o.stack, "CanEnchant")) return FALSE;
            var e = ench(a.checkjstring(1)); int lv = a.optint(2, 1);
            Map<net.minecraft.world.item.enchantment.Enchantment, Integer> m = new LinkedHashMap<>(EnchantmentHelper.getEnchantments(o.stack));
            m.put(e, lv); EnchantmentHelper.setEnchantments(m, o.stack);
            o.fire("E_Enchant", valueOf(o.enchName(e)), valueOf(lv)); return TRUE; });
        reg(C, "GetEnch", (s, a) -> valueOf(EnchantmentHelper.getEnchantments(I(s).stack).containsKey(ench(a.checkjstring(1)))));
        reg(C, "GetEnchLevel", (s, a) -> valueOf(EnchantmentHelper.getEnchantments(I(s).stack).getOrDefault(ench(a.checkjstring(1)), 0)));
        reg(C, "DelEnch", (s, a) -> {
            ItemObj o = I(s); var e = ench(a.checkjstring(1));
            Map<net.minecraft.world.item.enchantment.Enchantment, Integer> m = new LinkedHashMap<>(EnchantmentHelper.getEnchantments(o.stack));
            if (m.remove(e) == null) return FALSE;
            EnchantmentHelper.setEnchantments(m, o.stack);
            o.fire("E_EnchDel", valueOf(o.enchName(e))); return TRUE; });
        reg(C, "Remove", (s, a) -> { ItemObj o = I(s); int n = Math.min(o.stack.getCount(), a.optint(1, 1));
            o.setCount(o.stack.getCount() - n); o.fire("E_Removed", valueOf(n)); return NONE; });
        reg(C, "SetDesc", (s, a) -> { I(s).setDesc(a.checkjstring(1)); return NONE; });
        reg(C, "GetDesc", (s, a) -> valueOf(I(s).desc()));
        reg(C, "Damage", (s, a) -> { I(s).damage(a.optint(1, 1)); return NONE; });
        reg(C, "Repair", (s, a) -> { I(s).repair(a.optint(1, 1)); return NONE; });
        reg(C, "Use", (s, a) -> {
            ItemObj o = I(s);
            if (!flag(o.stack, "CanUse")) return FALSE;
            if (o.owner != null && o.owner.raw() instanceof ServerPlayer sp) {
                InteractionHand h = sp.getOffhandItem() == o.stack ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
                sp.gameMode.useItem(sp, sp.level(), o.stack, h);
            }
            o.fire("E_Used", o.owner != null ? o.owner : NIL); return TRUE; });
        reg(C, "Attack", (s, a) -> {
            ItemObj o = I(s);
            if (!flag(o.stack, "CanAttack")) return FALSE;
            LuaValue target = a.arg1();
            if (target instanceof EntityObj t && o.owner != null && o.owner.raw() instanceof Player p) p.attack(t.e());
            o.fire("E_Attacked", o.owner != null ? o.owner : NIL, target); return TRUE; });
        reg(C, "SetGUI", (s, a) -> { I(s).setGui(a.arg1()); return NONE; });
        reg(C, "GetGUI", (s, a) -> I(s).gui());
        reg(C, "Clone", (s, a) -> I(s).cloneItem());
        reg(C, "SetCount", (s, a) -> { I(s).setCount(a.checkint(1)); return NONE; });
        reg(C, "GetCount", (s, a) -> valueOf(I(s).stack.getCount()));
        reg(C, "SetId", (s, a) -> { if (s.rt != null && !s.rt.server) throw new LuaError("Item:SetId is only Server-Side"); I(s).setId(a.checkjstring(1)); return NONE; });
        reg(C, "GetId", (s, a) -> valueOf(I(s).id()));
        reg(C, "SetType", (s, a) -> { I(s).setType(a.checkjstring(1)); return NONE; });
        reg(C, "GetType", (s, a) -> valueOf(I(s).itemType()));
        reg(C, "SetStackable", (s, a) -> { I(s).setProp("Stackable", a.arg1()); return NONE; });
        reg(C, "IsStackable|isStackable", (s, a) -> valueOf(I(s).stack.getMaxStackSize() > 1));
        reg(C, "SetMaxStack", (s, a) -> { I(s).setProp("MaxStack", a.arg1()); return NONE; });
        reg(C, "GetMaxStack", (s, a) -> valueOf(I(s).stack.getMaxStackSize()));
        reg(C, "SetDurability", (s, a) -> { I(s).setProp("Durability", a.arg1()); return NONE; });
        reg(C, "GetDurability", (s, a) -> valueOf(I(s).dur()));
        reg(C, "SetMaxDurability", (s, a) -> { I(s).setProp("MaxDurability", a.arg1()); return NONE; });
        reg(C, "GetMaxDurability", (s, a) -> valueOf(I(s).maxDur()));
        reg(C, "SetModel", (s, a) -> { ItemObj o = I(s); String m = a.optjstring(1, "");
            if (m.isEmpty()) { CompoundTag d = data(o.stack); if (d != null) d.remove("Model"); } else o.fd().putString("Model", m);
            o.fire("E_ModelChanged", a.arg1()); return NONE; });
        reg(C, "GetModel", (s, a) -> I(s).model());
        reg(C, "SetIcon", (s, a) -> { I(s).setProp("Icon", a.arg1()); return NONE; });
        reg(C, "GetIcon", (s, a) -> s(I(s).str("Icon")));
        reg(C, "SetRarity", (s, a) -> { I(s).setRarity(a.checkjstring(1)); return NONE; });
        reg(C, "GetRarity", (s, a) -> I(s).getProp("Rarity"));
        reg(C, "SetTags", (s, a) -> { I(s).setTags(a.arg1()); return NONE; });
        reg(C, "GetTags", (s, a) -> I(s).tags());
        reg(C, "HasTag", (s, a) -> valueOf(I(s).hasTag(a.checkjstring(1))));
        reg(C, "AddTag", (s, a) -> { I(s).addTag(a.checkjstring(1)); return NONE; });
        reg(C, "RemoveTag", (s, a) -> { I(s).removeTag(a.checkjstring(1)); return NONE; });
        reg(C, "SetCustomData", (s, a) -> { I(s).setCustom(a.checkjstring(1), a.arg(2)); return NONE; });
        reg(C, "GetCustomData", (s, a) -> I(s).custom(a.checkjstring(1)));
        reg(C, "Serialize", (s, a) -> I(s).serialize());
        reg(C, "Deserialize", (s, a) -> { I(s).deserialize(a.arg1()); return NONE; });
        reg(C, "Compare", (s, a) -> { ItemObj o = I(s), b = checkObj(a.arg1(), ItemObj.class);
            ItemStack x = o.stack.copy(), y = b.stack.copy();
            CompoundTag dx = data(x), dy = data(y); if (dx != null) dx.remove("UID"); if (dy != null) dy.remove("UID");
            return valueOf(ItemStack.isSameItemSameTags(x, y) && x.getCount() == y.getCount()); });
    }

    // ------------------------------------------------------------------ hooks used by events / mixin
    public static int maxStack(ItemStack s) { CompoundTag d = data(s); return d != null && d.contains("MaxStack") ? d.getInt("MaxStack") : -1; }
    public static int maxDur(ItemStack s) { CompoundTag d = data(s); return d != null && d.contains("MaxDur") ? d.getInt("MaxDur") : -1; }
    public static Rarity rarity(ItemStack s) {
        CompoundTag d = data(s);
        if (d == null || !d.contains("Rarity")) return null;
        try { return Rarity.valueOf(d.getString("Rarity")); } catch (Exception e) { return null; }
    }
    public static String icon(ItemStack s) { CompoundTag d = data(s); return d != null && d.contains("Icon") ? d.getString("Icon") : null; }
    public static String guiName(ItemStack s) { CompoundTag d = data(s); return d != null && d.contains("GUI") ? d.getString("GUI") : null; }
}
