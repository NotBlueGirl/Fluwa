package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.Team;
import org.luaj.vm2.*;

import java.util.*;

/** Player. Resolved by UUID, so the same object survives respawns and dimension changes. */
public class PlayerObj extends EntityObj {
    public final UUID uuid;
    public final String profileName;
    /** server-side display name overrides (Player.Name = ...) */
    public static final Map<UUID, String> NAME_OVERRIDES = new HashMap<>();

    // ---- server-side state driven by ServerEvents tick (freeze / drown state lives in EntityObj)
    public boolean asynced;
    public int asyncTick = 20;
    public boolean forcedSleep;
    public String networkOwner;

    static final String[] EVENTS = {"E_Respawn", "E_Feed", "E_Join", "E_Leave", "E_Chatted", "E_Death", "E_Tick", "E_Sleep", "E_Wake",
            "E_Damaged", "E_EffAdd", "E_EffDel", "E_ArmorChanged", "E_PickItem", "E_DropItem", "E_DimensionChanged", "E_ChunkChange",
            "E_Interact", "E_Move", "E_Jump", "E_Attack", "E_Respawned"};

    public PlayerObj(UUID id, String name) {
        super("Player");
        uuid = id; profileName = name; this.name = name;
    }


    @Override public Player raw() { return GameRuntime.cur().resolvePlayer(uuid); }
    public Player p() { Player p = raw(); if (p == null) throw new LuaError("Player " + profileName + " is not online"); return p; }
    @Override public net.minecraft.world.entity.Entity e() { return p(); }

    public ServerPlayer sp() {
        if (p() instanceof ServerPlayer s) return s;
        throw new LuaError("This Player method is only Server-Side");
    }

    @Override public String getName() {
        String o = NAME_OVERRIDES.get(uuid);
        return o != null ? o : profileName;
    }
    @Override public void setName(String n) {
        ServerPlayer s = sp();
        if (n == null || n.isEmpty() || n.equals(profileName)) NAME_OVERRIDES.remove(uuid); else NAME_OVERRIDES.put(uuid, n);
        s.refreshDisplayName();
        s.refreshTabListName();
    }
    @Override public void setParent(LObj p) { throw new LuaError("Player.Parent can't be changed"); }
    @Override protected void onDestroy() { throw new LuaError("Players can't be destroyed, use Player:Kick()"); }

    @Override protected LuaValue getProp(String k) {
        if (k.startsWith("E_") || k.equals("Chatted") || k.equals("CharacterAdded") || k.equals("Died")) {
            String key = switch (k) { case "Chatted" -> "E_Chatted"; case "CharacterAdded" -> "E_Respawn"; case "Died" -> "E_Death"; default -> k; };
            if (!Arrays.asList(EVENTS).contains(key)) return null;
            return events.computeIfAbsent(key, Signal::new);
        }
        switch (k) {
            case "Name": return valueOf(getName());
            case "UserName": return valueOf(profileName);
            case "PlayerGui": case "CoreGui": return ((GameRuntime) rt).clientObject(k, this);
            case "Online": return valueOf(raw() != null);
            case "Hungry": case "Hunger": return valueOf(p().getFoodData().getFoodLevel());
            case "Saturation": return valueOf(p().getFoodData().getSaturationLevel());
            case "Ping": return valueOf(ping());
            case "XP": return valueOf(p().experienceLevel);
            case "XPPoints": return valueOf(p().totalExperience);
            case "GameMode": {
                Player p = p();
                if (p instanceof ServerPlayer s) return valueOf(s.gameMode.getGameModeForPlayer().getName());
                return valueOf(p.isCreative() ? "creative" : p.isSpectator() ? "spectator" : "survival");
            }
            case "ResourcePack": return ((GameRuntime) rt).clientInfo("ResourcePack");
            case "Shader": return ((GameRuntime) rt).clientInfo("Shader");
            case "Asynced": return valueOf(asynced);
            case "Frozen": return valueOf(freezeUntil >= 0);
            case "IsCreator": return valueOf(raw() instanceof ServerPlayer s && net.idea.fluwa.server.ScriptManager.isCreator(s));
            case "NBTs": {
                LuaTable t = (LuaTable) Conv.toLua(nbtRoot(false));
                LuaTable tmp = (LuaTable) Conv.toLua(nbtRoot(true));
                LuaValue key = NIL;
                while (true) { Varargs e = tmp.next(key); if ((key = e.arg1()).isnil()) break; t.set(key, e.arg(2)); }
                return t;
            }
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "Hungry": case "Hunger": p().getFoodData().setFoodLevel(Math.max(0, Math.min(20, v.checkint()))); return true;
            case "Saturation": p().getFoodData().setSaturation((float) v.checkdouble()); return true;
            case "XP": sp().setExperienceLevels(v.checkint()); return true;
            case "GameMode": {
                GameType gt = GameType.byName(v.checkjstring().toLowerCase(Locale.ROOT), null);
                if (gt == null) throw new LuaError("Unknown gamemode " + v);
                sp().setGameMode(gt); return true;
            }
            case "Dimension": {
                DimensionObj d = checkObj(v, DimensionObj.class);
                ServerPlayer s = sp();
                s.teleportTo(EntityObj.sl(d.level()), s.getX(), s.getY(), s.getZ(), s.getYRot(), s.getXRot());
                return true;
            }
            case "ResourcePack": case "Shader": case "Ping": case "Effects": case "NBTs":
                throw new LuaError("Player." + k + " is read-only");
        }
        return super.setProp(k, v);
    }

    public int ping() {
        Player p = p();
        if (p instanceof ServerPlayer s) return s.latency;
        return ((GameRuntime) rt).clientPing(uuid);
    }

    static LuaTable items(List<ItemStack> l, int from, int to, EntityObj owner) {
        LuaTable t = new LuaTable();
        for (int i = from; i < to && i < l.size(); i++) t.set(i - from + 1, ItemObj.of(l.get(i), owner));
        return t;
    }

    static PlayerTeam hiddenTeam(Scoreboard sb) {
        PlayerTeam t = sb.getPlayerTeam("fluwa_hidden");
        if (t == null) { t = sb.addPlayerTeam("fluwa_hidden"); t.setNameTagVisibility(Team.Visibility.NEVER); }
        return t;
    }

    public void freeze(double secs, boolean cam) {
        Player p = p();
        fx = p.getX(); fy = p.getY(); fz = p.getZ(); fyaw = p.getYRot(); fpitch = p.getXRot();
        freezeCam = cam;
        freezeUntil = secs > 0 ? rt.tick + Math.round(secs * 20) : Long.MAX_VALUE;
        ((GameRuntime) rt).sendPlayerState(this);
    }

    // ---- attributes: custom (any Lua value, optional change callback) or Minecraft attributes (MaxHealth, MovementSpeed, minecraft:generic.armor ...)
    final Map<String, LuaValue> attrCb = new HashMap<>();

    static net.minecraft.world.entity.ai.attributes.AttributeInstance mcAttr(Player p, String n) {
        String snake = n.replaceAll("([a-z0-9])([A-Z])", "$1_$2").replace(' ', '_').toLowerCase(Locale.ROOT);
        for (String s : new String[]{n.toLowerCase(Locale.ROOT), "minecraft:" + snake, "minecraft:generic." + snake, "minecraft:player." + snake, "forge:" + snake}) {
            net.minecraft.resources.ResourceLocation rl = net.minecraft.resources.ResourceLocation.tryParse(s);
            if (rl == null || !net.minecraft.core.registries.BuiltInRegistries.ATTRIBUTE.containsKey(rl)) continue;
            var inst = p.getAttribute(net.minecraft.core.registries.BuiltInRegistries.ATTRIBUTE.get(rl));
            if (inst != null) return inst;
        }
        return null;
    }
    boolean hasCustom(String n) { return attrs != null && !attrs.get(n).isnil(); }
    void attrChanged(String n, LuaValue nv, LuaValue old) {
        fire("E_AttributeChanged", valueOf(n));
        LuaValue cb = attrCb.get(n);
        if (cb != null && cb.isfunction() && rt != null) rt.callAsync(cb, varargsOf(nv, old, valueOf(n)), "Attribute callback");
    }

    static {
        Class<PlayerObj> C = PlayerObj.class;
        // GetAttribute(name) -> true, value | false
        reg(C, "GetAttribute", (s, a) -> { PlayerObj o = (PlayerObj) s; String n = a.checkjstring(1);
            if (o.hasCustom(n)) return varargsOf(TRUE, o.attrs.get(n));
            var mi = o.raw() == null ? null : mcAttr(o.p(), n);
            return mi != null ? varargsOf(TRUE, valueOf(mi.getValue())) : FALSE; });
        // AddAttribute(name, value, [callback(newValue, oldValue, name)]) -> true
        reg(C, "AddAttribute", (s, a) -> { PlayerObj o = (PlayerObj) s; String n = a.checkjstring(1);
            var mi = o.hasCustom(n) ? null : mcAttr(o.p(), n);
            LuaValue old;
            if (mi != null) { old = valueOf(mi.getBaseValue()); mi.setBaseValue(a.checkdouble(2)); }
            else { if (o.attrs == null) o.attrs = new LuaTable(); old = o.attrs.get(n); o.attrs.set(n, a.arg(2)); }
            if (a.arg(3).isfunction()) o.attrCb.put(n, a.arg(3)); else o.attrCb.remove(n);
            o.fire("E_AttributeChanged", valueOf(n));
            return TRUE; });
        // EditAttribute(name, value) -> true if changed, false if the player has no such attribute
        reg(C, "EditAttribute", (s, a) -> { PlayerObj o = (PlayerObj) s; String n = a.checkjstring(1);
            if (o.hasCustom(n)) { LuaValue old = o.attrs.get(n); o.attrs.set(n, a.arg(2)); o.attrChanged(n, a.arg(2), old); return TRUE; }
            var mi = mcAttr(o.p(), n);
            if (mi == null) return FALSE;
            double old = mi.getBaseValue(); mi.setBaseValue(a.checkdouble(2));
            o.attrChanged(n, valueOf(mi.getBaseValue()), valueOf(old));
            return TRUE; });
        // DelAttribute(name) -> true if removed (Minecraft attributes are reset to their default)
        reg(C, "DelAttribute", (s, a) -> { PlayerObj o = (PlayerObj) s; String n = a.checkjstring(1);
            o.attrCb.remove(n);
            if (o.hasCustom(n)) { o.attrs.set(n, NIL); o.fire("E_AttributeChanged", valueOf(n)); return TRUE; }
            var mi = mcAttr(o.p(), n);
            if (mi == null) return FALSE;
            mi.setBaseValue(mi.getAttribute().getDefaultValue());
            o.fire("E_AttributeChanged", valueOf(n));
            return TRUE; });
        reg(C, "Kick", (s, a) -> { ((PlayerObj) s).sp().connection.disconnect(Component.literal(a.optjstring(1, "Kicked by script"))); return NONE; });
        reg(C, "Ping", (s, a) -> valueOf(((PlayerObj) s).ping()));
        reg(C, "Async", (s, a) -> { PlayerObj o = (PlayerObj) s; o.sp(); o.asynced = true; ((GameRuntime) o.rt).sendPlayerState(o); return NONE; });
        reg(C, "Sync", (s, a) -> { PlayerObj o = (PlayerObj) s; o.sp(); o.asynced = false; ((GameRuntime) o.rt).sendPlayerState(o); return NONE; });
        reg(C, "AsyncTick", (s, a) -> { PlayerObj o = (PlayerObj) s; o.asyncTick = Math.max(1, Math.min(200, a.checkint(1))); ((GameRuntime) o.rt).sendPlayerState(o); return NONE; });
        reg(C, "Feed", (s, a) -> {
            Player p = ((PlayerObj) s).p(); int n = a.checkint(1);
            if (n >= 0) p.getFoodData().eat(n, a.optint(2, 0) / 10f); else p.getFoodData().setFoodLevel(Math.max(0, p.getFoodData().getFoodLevel() + n));
            return NONE; });
        reg(C, "Say", (s, a) -> {
            ServerPlayer sp = ((PlayerObj) s).sp(); String msg = a.checkjstring(1);
            sp.server.getPlayerList().broadcastSystemMessage(Component.translatable("chat.type.text", sp.getDisplayName(), msg), false);
            return NONE; });
        reg(C, "SendMessage|Message", (s, a) -> { ((PlayerObj) s).p().sendSystemMessage(Component.literal(a.checkjstring(1))); return NONE; });
        reg(C, "ActionBar", (s, a) -> { ((PlayerObj) s).p().displayClientMessage(Component.literal(a.checkjstring(1)), true); return NONE; });
        reg(C, "Title", (s, a) -> {
            ServerPlayer sp = ((PlayerObj) s).sp();
            sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket(a.optint(3, 10), a.optint(4, 60), a.optint(5, 20)));
            if (!a.isnil(2)) sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(Component.literal(a.checkjstring(2))));
            sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(Component.literal(a.checkjstring(1))));
            return NONE; });
        reg(C, "Command", (s, a) -> {
            ServerPlayer sp = ((PlayerObj) s).sp(); String cmd = a.checkjstring(1);
            return valueOf(sp.server.getCommands().performPrefixedCommand(sp.createCommandSourceStack(), cmd.startsWith("/") ? cmd.substring(1) : cmd)); });
        reg(C, "PlaySound|PS", (s, a) -> {
            LuaValue t = a.arg1(); Player p = ((PlayerObj) s).p();
            String id = t.istable() ? t.get(1).checkjstring() : t.checkjstring();
            float vol = (float) (t.istable() ? t.get(2).optdouble(1) : a.optdouble(2, 1));
            float pitch = (float) (t.istable() ? t.get(3).optdouble(1) : a.optdouble(3, 1));
            if (p instanceof ServerPlayer sp) sp.playNotifySound(Conv.sound(id), SoundSource.MASTER, vol, pitch);
            else p.playSound(Conv.sound(id), vol, pitch);
            return NONE; });
        reg(C, "PlayLocalSound|PLS", (s, a) -> { if (a.arg1().istable()) a = a.arg1().checktable().unpack();
            ((GameRuntime) s.rt).playLocalSound((PlayerObj) s, a.checkjstring(1), (float) a.optdouble(2, 1), (float) a.optdouble(3, 1)); return NONE; });
        reg(C, "Freeze", (s, a) -> { PlayerObj o = (PlayerObj) s; o.sp(); o.freeze(a.optdouble(1, 0), a.optboolean(2, false)); return NONE; });
        reg(C, "UnFreeze|Unfreeze", (s, a) -> { PlayerObj o = (PlayerObj) s; o.freezeUntil = -1; ((GameRuntime) o.rt).sendPlayerState(o); return NONE; });
        reg(C, "GetExp|GiveExp", (s, a) -> { ((PlayerObj) s).p().giveExperiencePoints(a.checkint(1)); return NONE; });
        reg(C, "Sleep", (s, a) -> { PlayerObj o = (PlayerObj) s; ServerPlayer sp = o.sp();
            o.forcedSleep = true; sp.startSleeping(sp.blockPosition()); o.fire("E_Sleep"); return NONE; });
        reg(C, "WakeUp", (s, a) -> { PlayerObj o = (PlayerObj) s; ServerPlayer sp = o.sp();
            o.forcedSleep = false; if (sp.isSleeping()) sp.stopSleepInBed(true, true); return NONE; });
        reg(C, "SetNetworkOwner", (s, a) -> { ((PlayerObj) s).networkOwner = a.isnil(1) ? null : a.arg1().tojstring(); return NONE; });
        reg(C, "GetNetworkOwner", (s, a) -> { String n = ((PlayerObj) s).networkOwner; return n == null ? NIL : valueOf(n); });
        reg(C, "GetMouse", (s, a) -> ((GameRuntime) s.rt).clientObject("Mouse", (PlayerObj) s));
        reg(C, "GetCamera", (s, a) -> ((GameRuntime) s.rt).clientObject("Camera", (PlayerObj) s));
        reg(C, "GetModel", (s, a) -> s.rt.server ? EntityObj.modelParts((PlayerObj) s) : ((GameRuntime) s.rt).clientObject("Model", (PlayerObj) s));
        reg(C, "GetInv|GetInventory", (s, a) -> items(((PlayerObj) s).p().getInventory().items, 0, 36, (PlayerObj) s));
        reg(C, "GetHotBar|GHB", (s, a) -> items(((PlayerObj) s).p().getInventory().items, 0, 9, (PlayerObj) s));
        reg(C, "GetArmor", (s, a) -> items(((PlayerObj) s).p().getInventory().armor, 0, 4, (PlayerObj) s));
        reg(C, "GetMainHand|GMH", (s, a) -> { ItemStack i = ((PlayerObj) s).p().getMainHandItem(); return i.isEmpty() ? NIL : ItemObj.of(i, (PlayerObj) s); });
        reg(C, "GetSecondaryHand|GSH", (s, a) -> { ItemStack i = ((PlayerObj) s).p().getOffhandItem(); return i.isEmpty() ? NIL : ItemObj.of(i, (PlayerObj) s); });
        reg(C, "GiveItem", (s, a) -> {
            Player p = ((PlayerObj) s).p();
            ItemStack st = a.arg1() instanceof ItemObj io ? io.stack.copy() : ItemObj.create(a.checkjstring(1), a.optint(2, 1));
            boolean ok = p.getInventory().add(st);
            if (!ok) p.drop(st, false);
            return valueOf(ok); });
        reg(C, "ClearInventory", (s, a) -> { ((PlayerObj) s).p().getInventory().clearContent(); return NONE; });
        reg(C, "DrownStart", (s, a) -> { PlayerObj o = (PlayerObj) s; o.drownMode = 1; o.drownAir = o.p().getAirSupply(); return NONE; });
        reg(C, "DrownPause", (s, a) -> { PlayerObj o = (PlayerObj) s; o.drownMode = 2; o.drownAir = o.p().getAirSupply(); return NONE; });
        reg(C, "DrownEnd", (s, a) -> { PlayerObj o = (PlayerObj) s; o.drownMode = 0; o.p().setAirSupply(o.p().getMaxAirSupply()); return NONE; });
        reg(C, "HideName", (s, a) -> { ServerPlayer sp = ((PlayerObj) s).sp(); Scoreboard sb = sp.getScoreboard();
            sb.addPlayerToTeam(sp.getScoreboardName(), hiddenTeam(sb)); return NONE; });
        reg(C, "ShowName", (s, a) -> { ServerPlayer sp = ((PlayerObj) s).sp(); Scoreboard sb = sp.getScoreboard();
            PlayerTeam t = sb.getPlayerTeam("fluwa_hidden");
            if (t != null && t.getPlayers().contains(sp.getScoreboardName())) sb.removePlayerFromTeam(sp.getScoreboardName(), t);
            return NONE; });
        // ---- check methods
        reg(C, "isHungry", (s, a) -> valueOf(((PlayerObj) s).p().getFoodData().getFoodLevel() <= a.optint(1, 0)));
        reg(C, "isSleep", (s, a) -> valueOf(((PlayerObj) s).p().isSleeping()));
        reg(C, "isMHand", (s, a) -> valueOf(!((PlayerObj) s).p().getMainHandItem().isEmpty()));
        reg(C, "isSHand", (s, a) -> valueOf(!((PlayerObj) s).p().getOffhandItem().isEmpty()));
        reg(C, "isDrown", (s, a) -> { PlayerObj o = (PlayerObj) s; Player p = o.p();
            return valueOf(o.drownMode == 1 || (p.isUnderWater() && p.getAirSupply() < p.getMaxAirSupply())); });
        reg(C, "isRun", (s, a) -> valueOf(((PlayerObj) s).p().isSprinting()));
        reg(C, "isShift", (s, a) -> valueOf(((PlayerObj) s).p().isShiftKeyDown()));
        reg(C, "isSit", (s, a) -> valueOf(((PlayerObj) s).p().isPassenger()));
        reg(C, "isFly", (s, a) -> valueOf(((PlayerObj) s).p().getAbilities().flying));
        reg(C, "isSwim", (s, a) -> valueOf(((PlayerObj) s).p().isSwimming()));
        reg(C, "isOnGround", (s, a) -> valueOf(((PlayerObj) s).p().onGround()));
    }

    public BlockPos blockPos() { return p().blockPosition(); }
}
