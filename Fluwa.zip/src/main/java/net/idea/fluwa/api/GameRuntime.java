package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.*;

/** Runtime with access to the game world (shared base of server and client runtimes). */
public abstract class GameRuntime extends FluwaRuntime implements RemoteEvent.HasBridge {
    /** current client runtime (set by client code; null on dedicated servers) */
    public static volatile GameRuntime CLIENT;
    public final Map<UUID, PlayerObj> players = new HashMap<>();
    public final Map<ResourceKey<Level>, DimensionObj> dims = new HashMap<>();
    public final Map<Integer, EntityObj> entities = new WeakHashMap<>();
    public WorldObj world;

    protected GameRuntime(boolean server) { super(server); }

    public abstract Player resolvePlayer(UUID id);
    public abstract Level resolveLevel(ResourceKey<Level> key);
    public abstract Collection<? extends Player> allPlayers();
    public abstract Collection<? extends Level> levels();
    public MinecraftServer server() { return null; }

    // ---- side specific hooks (overridden by server / client runtime)
    public org.luaj.vm2.LuaValue clientInfo(String what) { return org.luaj.vm2.LuaValue.NIL; }
    public int clientPing(UUID id) { return 0; }
    public void sendPlayerState(PlayerObj p) {}
    public void playLocalSound(PlayerObj p, String id, float vol, float pitch) {
        throw new org.luaj.vm2.LuaError("Player:PlayLocalSound is only Client-Side");
    }
    public org.luaj.vm2.LuaValue localPlayer() { return org.luaj.vm2.LuaValue.NIL; }
    /** the local player's object (client), also available before the player entity exists */
    public net.idea.fluwa.lua.LObj localPlayerObj() { return null; }
    public Iterable<Entity> clientEntities() { return java.util.List.of(); }
    /** client runtime: world writes allowed only when the local player is asynced */
    public void checkClientWrite() {}
    /** target: null = everyone, "" = creators, otherwise player name */
    public void skybox(String target, DimensionObj d, String file) { throw new org.luaj.vm2.LuaError("Skybox:ServerChange/ClientChange are only Server-Side"); }
    public org.luaj.vm2.LuaValue clientObject(String what, PlayerObj p) {
        throw new org.luaj.vm2.LuaError("Player:Get" + what + "() is only Client-Side");
    }

    /** client-only entities (hallucinations) */
    public Entity spawnLocal(String type, net.minecraft.world.phys.Vec3 pos) { throw new org.luaj.vm2.LuaError("Local entities can only be spawned on the client"); }
    public void removeLocal(Entity e) { e.discard(); }
    public net.idea.fluwa.mesh.Mesh meshOf(UUID id) { ModelSync.Model m = ModelSync.model(id); return m == null ? null : m.mesh(); }
    public boolean partHidden(UUID id, String part) { return ModelSync.hidden(id, part); }
    /** description of a custom model ("car.glb", "minecraft:zombie") or null for the normal model */
    public String modelDesc(UUID id) { return ModelSync.get(id); }
    public float[] partTransform(UUID id, String part) { return ModelSync.transform(id, part); }
    public java.util.List<String> modelPartNames(net.minecraft.world.entity.Entity e) { return ModelSync.partNames(e); }
    public void setPartTransform(UUID id, String part, float[] xf) { ModelSync.setTransform(id, part, xf); }
    public void setPartHidden(UUID id, String part, boolean hidden) { ModelSync.setHidden(id, part, hidden); }
    public void localFlag(UUID id, String flag, boolean on) {}

    public static GameRuntime cur() {
        FluwaRuntime r = FluwaRuntime.current();
        if (r instanceof GameRuntime g) return g;
        throw new org.luaj.vm2.LuaError("No game runtime");
    }

    public PlayerObj wrap(Player p) {
        if (p == null) return null;
        return players.computeIfAbsent(p.getUUID(), u -> within(() -> new PlayerObj(u, p.getGameProfile().getName())));
    }

    public DimensionObj wrap(Level l) {
        if (l == null) return null;
        return dims.computeIfAbsent(l.dimension(), k -> within(() -> new DimensionObj(k)));
    }

    /** entity by UUID in any loaded dimension (client runtime: the client level) */
    public Entity entityByUuid(UUID id) {
        for (Level l : levels()) if (l instanceof net.minecraft.server.level.ServerLevel sl) { Entity e = sl.getEntity(id); if (e != null) return e; }
        return null;
    }

    public EntityObj wrapEntity(Entity e) {
        if (e == null) return null;
        if (e instanceof Player p) return wrap(p);
        EntityObj o = entities.get(e.getId());
        if (o == null || o.raw() != e) { o = within(() -> new EntityObj(e)); entities.put(e.getId(), o); }
        return o;
    }

    public DimensionObj dimByName(String name) {
        String n = name.contains(":") ? name : "minecraft:" + name;
        for (Level l : levels()) if (l.dimension().location().toString().equals(n)) return wrap(l);
        return null;
    }

    @Override public void close() {
        super.close();
        players.clear(); dims.clear(); entities.clear();
    }
}
