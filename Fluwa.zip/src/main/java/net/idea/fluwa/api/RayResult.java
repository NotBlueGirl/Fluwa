package net.idea.fluwa.api;

import net.idea.fluwa.lua.*;
import org.luaj.vm2.*;

/** Result of Dimension:Raycast(...) */
public class RayResult extends LObj {
    final boolean hit; final Vec3L position, normal; final LuaValue block, entity; final double distance;

    public RayResult(boolean hit, Vec3L pos, Vec3L normal, LuaValue block, LuaValue entity, double dist) {
        super("RayObject");
        this.hit = hit; position = pos; this.normal = normal; this.block = block; this.entity = entity; distance = dist;
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Hit": return valueOf(hit);
            case "Position": return position == null ? NIL : position;
            case "Normal": return normal == null ? NIL : normal;
            case "Block": case "Instance": return block == null ? (entity == null ? NIL : entity) : block;
            case "Entity": return entity == null ? NIL : entity;
            case "Distance": return valueOf(distance);
        }
        return super.getProp(k);
    }
}
