package net.idea.fluwa.api;

import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;

import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Block.CanCollide = false: positions without collision, per side and dimension (used by BlockStateBaseMixin). */
public final class NoCollide {
    private NoCollide() {}
    public static final Map<ResourceKey<Level>, Set<Long>> SERVER = new ConcurrentHashMap<>();
    public static final Map<ResourceKey<Level>, Set<Long>> CLIENT = new ConcurrentHashMap<>();
    private static volatile boolean any;

    public static void refresh() {
        boolean a = false;
        for (Set<Long> s : SERVER.values()) a |= !s.isEmpty();
        for (Set<Long> s : CLIENT.values()) a |= !s.isEmpty();
        any = a;
    }

    /** hot path: called for every collision shape lookup */
    public static boolean blocked(BlockGetter g, BlockPos pos) {
        if (!any) return false;
        Level l = g instanceof Level lv ? lv : g instanceof LevelChunk c ? c.getLevel() : null;
        if (l == null) return false;
        Set<Long> s = (l.isClientSide ? CLIENT : SERVER).get(l.dimension());
        return s != null && s.contains(pos.asLong());
    }

    public static void set(ServerLevel l, BlockPos p, boolean collide) {
        BlockData d = BlockData.get(l);
        boolean changed = collide ? d.noCollide.remove(p.asLong()) : d.noCollide.add(p.asLong());
        if (!changed) return;
        d.setDirty();
        SERVER.put(l.dimension(), d.noCollide);
        refresh();
        FluwaNet.toAll(packet(l.dimension(), d.noCollide));
    }

    public static Pkt packet(ResourceKey<Level> dim, Set<Long> s) {
        ByteBuffer b = ByteBuffer.allocate(s.size() * 8);
        for (long v : s) b.putLong(v);
        return new Pkt(Pkt.S_NOCOLLIDE, List.of(dim.location().toString()), null, b.array());
    }

    public static void onLevelLoad(ServerLevel l) { SERVER.put(l.dimension(), BlockData.get(l).noCollide); refresh(); }

    public static void sendAll(ServerPlayer p) {
        SERVER.forEach((k, v) -> { if (!v.isEmpty()) FluwaNet.toPlayer(p, packet(k, v)); });
    }

    /** client side */
    public static void receive(String dim, byte[] data) {
        Set<Long> s = ConcurrentHashMap.newKeySet();
        ByteBuffer b = ByteBuffer.wrap(data);
        while (b.remaining() >= 8) s.add(b.getLong());
        CLIENT.put(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(dim)), s);
        refresh();
    }

    public static void clearClient() { CLIENT.clear(); refresh(); }
    public static void clearServer() { SERVER.clear(); refresh(); }
}
