package net.idea.fluwa.api;

import net.idea.fluwa.Config;
import net.idea.fluwa.lua.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelResource;
import org.luaj.vm2.*;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.synth.ImprovedNoise;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** World == Workspace. Children: Lighting, Terrain, Entities, Players, Dimensions. */
public class WorldObj extends LObj {
    public final PlayersObj players = new PlayersObj();
    public final LObj dimensions = new Container("Dimensions") {
        @Override public List<LObj> listChildren() { List<LObj> l = new ArrayList<>(); for (Level lv : gr().levels()) l.add(gr().wrap(lv)); return l; }
    };
    public final LObj entities = new Container("Entities") {
        @Override public List<LObj> listChildren() {
            List<LObj> l = new ArrayList<>();
            for (Level lv : gr().levels()) for (Entity e : allEntities(lv)) if (!(e instanceof Player)) l.add(gr().wrapEntity(e));
            return l;
        }
    };
    public final net.idea.fluwa.lighting.LightingObj lighting = new net.idea.fluwa.lighting.LightingObj(this);
    public final Terrain terrain = new Terrain();
    public final TimeObj time = new TimeObj();
    /** extra day-time ticks per tick (World.Time:Speed/Slow) */
    public double timeExtra, timeAcc;

    public WorldObj() {
        super("Workspace");
        name = "World";
        for (LObj c : new LObj[]{lighting, terrain, entities, players, dimensions}) { c.setParent(this); }
    }

    GameRuntime gr() { return (GameRuntime) rt; }

    static Iterable<Entity> allEntities(Level l) {
        if (l instanceof ServerLevel s) return s.getAllEntities();
        return gr0().clientEntities();
    }
    static GameRuntime gr0() { return GameRuntime.cur(); }

    MinecraftServer srv() { MinecraftServer s = gr().server(); if (s == null) throw new LuaError("Only Server-Side"); return s; }
    public Level overworld() { return gr().levels().iterator().next(); }

    @Override public void setName(String n) { throw new LuaError("World.Name is read-only"); }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Dimensions": return list(dimensions.listChildren());
            case "DayTime": return valueOf(overworld().getDayTime() % 24000);
            case "FullTime": return valueOf(overworld().getDayTime() / 24000);
            case "GameTime": return valueOf(overworld().getGameTime());
            case "Time": return time;
            case "Structures": {
                List<LuaValue> l = new ArrayList<>();
                srv().getStructureManager().listTemplates().forEach(r -> l.add(valueOf(r.toString())));
                return list(l);
            }
            case "Seed": return valueOf(String.valueOf(srv().getWorldData().worldGenOptions().seed()));
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (k.equals("DayTime")) { setDay(v.checklong()); return true; }
        return super.setProp(k, v);
    }

    public void setDay(long t) { for (ServerLevel l : srv().getAllLevels()) l.setDayTime(t); }
    void addDay(long t) { for (ServerLevel l : srv().getAllLevels()) l.setDayTime(l.getDayTime() + t); }

    /** called every server tick */
    public void tickTime() {
        if (timeExtra == 0) return;
        timeAcc += timeExtra;
        long whole = (long) timeAcc;
        if (whole != 0) { timeAcc -= whole; addDay(whole); }
    }

    static void copyDir(Path src, Path dst) throws IOException {
        try (var st = Files.walk(src)) {
            for (Path p : (Iterable<Path>) st::iterator) {
                if (p.getFileName().toString().equals("session.lock")) continue;
                Path t = dst.resolve(src.relativize(p).toString());
                if (Files.isDirectory(p)) Files.createDirectories(t); else Files.copy(p, t, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    static {
        Class<WorldObj> C = WorldObj.class;
        reg(C, "GetPlayerFromName", (s, a) -> ((WorldObj) s).players.byName(a.checkjstring(1)));
        reg(C, "GetPlayers", (s, a) -> list(((WorldObj) s).players.listChildren()));
        reg(C, "GetDimension", (s, a) -> { DimensionObj d = ((WorldObj) s).gr().dimByName(a.checkjstring(1)); return d == null ? NIL : d; });
        reg(C, "GetStructure", (s, a) -> {
            var id = Conv.rl(a.checkjstring(1));
            var t = ((WorldObj) s).srv().getStructureManager().get(id);
            return t.isPresent() ? new StructureObj(t.get(), id) : NIL; });
        reg(C, "Copy", (s, a) -> {
            if (!Config.fullOsAccess) throw new LuaError("World:Copy requires fullOsAccess=true in config/fluwa-common.toml");
            MinecraftServer srv = ((WorldObj) s).srv();
            srv.saveEverything(true, true, true);
            Path src = srv.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize();
            Path dst = Paths.get(a.checkjstring(1)).toAbsolutePath().normalize();
            try { copyDir(src, dst); } catch (IOException e) { throw new LuaError("World:Copy failed: " + e.getMessage()); }
            return valueOf(dst.toString()); });
    }

    // ================================================================ children
    public static class Container extends LObj {
        public Container(String n) { super(n); }
        @Override public void setName(String n) { throw new LuaError(className + ".Name is read-only"); }
    }

    public class PlayersObj extends Container {
        public final Signal join = new Signal("E_Join"), leave = new Signal("E_Leave");
        PlayersObj() { super("Players"); }
        @Override public List<LObj> listChildren() { List<LObj> l = new ArrayList<>(); for (Player p : gr().allPlayers()) l.add(gr().wrap(p)); return l; }
        @Override public LObj findChild(String n) { LuaValue v = byName(n); return v.isnil() ? null : (LObj) v; }
        LuaValue byName(String n) {
            for (Player p : gr().allPlayers()) { PlayerObj o = gr().wrap(p); if (o.profileName.equalsIgnoreCase(n) || o.getName().equalsIgnoreCase(n)) return o; }
            return NIL;
        }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "E_Join": case "PlayerAdded": return join;
                case "E_Leave": case "PlayerRemoving": return leave;
                case "Count": return valueOf(gr().allPlayers().size());
                case "LocalPlayer": return gr().localPlayer();
            }
            return super.getProp(k);
        }
        static {
            reg(PlayersObj.class, "GetPlayers", (s, a) -> list(s.listChildren()));
            reg(PlayersObj.class, "GetPlayerFromName", (s, a) -> ((PlayersObj) s).byName(a.checkjstring(1)));
        }
    }

    public class Terrain extends Container {
        Terrain() { super("Terrain"); }
        DimensionObj dim(LuaValue v) { return v instanceof DimensionObj d ? d : gr().wrap(overworld()); }
        static {
            reg(Terrain.class, "Fill", (s, a) -> { Terrain t = (Terrain) s; DimensionObj d = t.dim(a.arg(5));
                Conv.Picker pk = new Conv.Picker(a.checkjstring(1), a.arg(4)); Level l = d.level(); d.checkWrite();
                DimensionObj.box(Vec3L.check(a.arg(2)), Vec3L.check(a.arg(3)), p -> l.setBlock(p, pk.next(), 2)); return NONE; });
            reg(Terrain.class, "FillSphere", (s, a) -> { Terrain t = (Terrain) s; DimensionObj d = t.dim(a.arg(5));
                Conv.Picker pk = new Conv.Picker(a.checkjstring(1), a.arg(4)); Level l = d.level(); d.checkWrite();
                DimensionObj.sphere(Vec3L.check(a.arg(2)), a.checkdouble(3), p -> l.setBlock(p, pk.next(), 2)); return NONE; });
            reg(Terrain.class, "Clear", (s, a) -> { Terrain t = (Terrain) s; DimensionObj d = t.dim(a.arg(3)); Level l = d.level(); d.checkWrite();
                var air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
                DimensionObj.box(Vec3L.check(a.arg1()), Vec3L.check(a.arg(2)), p -> l.setBlock(p, air, 2)); return NONE; });
            reg(Terrain.class, "Generate", (s, a) -> { Terrain t = (Terrain) s;
                return generate(t.dim(a.arg(4)), Vec3L.check(a.arg1()), Vec3L.check(a.arg(2)), a.arg(3)); });
        }
    }

    /** settings: {seed, scale=48, amplitude=12, base=64, octaves=4, surface="grass_block", under="dirt", deep="stone", depth=3, water=nil, waterBlock="water"} */
    static LuaValue generate(DimensionObj d, Vec3L a, Vec3L b, LuaValue st) {
        Level l = d.level(); d.checkWrite();
        LuaValue s = st.istable() ? st : new LuaTable();
        long seed = (long) s.get("seed").optdouble(l instanceof net.minecraft.server.level.ServerLevel sl ? sl.getSeed() : 0);
        double scale = s.get("scale").optdouble(48), ampl = s.get("amplitude").optdouble(12);
        int base = s.get("base").optint(64), oct = s.get("octaves").optint(4), depth = s.get("depth").optint(3);
        BlockState top = Conv.block(s.get("surface").optjstring("grass_block")), under = Conv.block(s.get("under").optjstring("dirt")),
                deep = Conv.block(s.get("deep").optjstring("stone")), air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        LuaValue wv = s.get("water");
        BlockState water = Conv.block(s.get("waterBlock").optjstring("water"));
        BlockPos mn = Conv.min(a, b), mx = Conv.max(a, b);
        Conv.checkVolume((long) (mx.getX() - mn.getX() + 1) * (mx.getY() - mn.getY() + 1) * (mx.getZ() - mn.getZ() + 1));
        ImprovedNoise n = new ImprovedNoise(RandomSource.create(seed));
        int count = 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int x = mn.getX(); x <= mx.getX(); x++) for (int z = mn.getZ(); z <= mx.getZ(); z++) {
            double v = 0, am = 1, fr = 1 / scale, norm = 0;
            for (int i = 0; i < oct; i++) { v += n.noise(x * fr, 0, z * fr) * am; norm += am; am *= 0.5; fr *= 2; }
            int h = base + (int) Math.round(v / norm * ampl);
            for (int y = mn.getY(); y <= mx.getY(); y++) {
                BlockState bs = y > h ? (!wv.isnil() && y <= wv.toint() ? water : air) : y == h ? top : y > h - depth ? under : deep;
                l.setBlock(p.set(x, y, z), bs, 2);
                count++;
            }
        }
        return valueOf(count);
    }




    public class TimeObj extends LObj {
        TimeObj() { super("Time"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Rate": return valueOf(20 + timeExtra * 20);
                case "Paused": return valueOf(!srv().getGameRules().getBoolean(GameRules.RULE_DAYLIGHT));
                case "Ticks": return valueOf(overworld().getDayTime() % 24000);
            }
            return super.getProp(k);
        }
        static {
            Class<TimeObj> T = TimeObj.class;
            reg(T, "Add", (s, a) -> { WorldObj.this0(s).addDay(a.checklong(1)); return NONE; });
            reg(T, "Set", (s, a) -> { WorldObj w = this0(s); long day = w.overworld().getDayTime() / 24000 * 24000; w.setDay(day + a.checklong(1)); return NONE; });
            reg(T, "Secs", (s, a) -> valueOf((this0(s).overworld().getDayTime() % 24000) / 20.0));
            reg(T, "AddSec", (s, a) -> { this0(s).addDay(Math.round(a.checkdouble(1) * 20)); return NONE; });
            reg(T, "Pause", (s, a) -> { WorldObj w = this0(s); w.srv().getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false, w.srv()); return NONE; });
            reg(T, "Go", (s, a) -> { WorldObj w = this0(s); w.srv().getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(true, w.srv()); return NONE; });
            reg(T, "Speed", (s, a) -> { this0(s).timeExtra = a.checkdouble(1) / 20.0; return NONE; });
            reg(T, "Slow", (s, a) -> { this0(s).timeExtra = -Math.min(20, a.checkdouble(1)) / 20.0; return NONE; });
            reg(T, "Normal", (s, a) -> { this0(s).timeExtra = 0; return NONE; });
        }
    }

    static WorldObj this0(LObj time) { return ((GameRuntime) time.rt).world; }
}
