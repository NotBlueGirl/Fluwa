package net.idea.fluwa.mesh;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Cache of loaded models by absolute path (+ modification time). */
public final class MeshCache {
    private MeshCache() {}
    record E(long mtime, long size, Mesh mesh) {}
    static final Map<Path, E> CACHE = new ConcurrentHashMap<>();

    /** @return shared (do not modify) mesh */
    public static Mesh get(Path p) throws IOException {
        Path a = p.toAbsolutePath().normalize();
        long mt = Files.getLastModifiedTime(a).toMillis(), sz = Files.size(a);
        E e = CACHE.get(a);
        if (e != null && e.mtime == mt && e.size == sz) return e.mesh;
        Mesh m = MeshLoader.load(a);
        CACHE.put(a, new E(mt, sz, m));
        return m;
    }

    public static List<String> keys() { List<String> l = new ArrayList<>(); for (Path p : CACHE.keySet()) l.add(p.getFileName().toString()); return l; }
    public static void clear() { CACHE.clear(); }
}
