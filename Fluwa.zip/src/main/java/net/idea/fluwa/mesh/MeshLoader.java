package net.idea.fluwa.mesh;

import com.google.gson.*;

import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.function.Function;
import java.util.zip.Inflater;

/** Loads .obj, .gltf, .glb and .fbx (binary 7.x and ASCII) into a {@link Mesh}. */
public final class MeshLoader {
    private MeshLoader() {}

    public static final List<String> FORMATS = List.of(".obj", ".gltf", ".glb", ".fbx");

    public static boolean supported(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String f : FORMATS) if (n.endsWith(f)) return true;
        return false;
    }

    /** Load a model file. Sibling files (textures, .bin, .mtl) are resolved inside the same folder only. */
    public static Mesh load(Path file) throws IOException {
        Path dir = file.toAbsolutePath().getParent();
        Function<String, byte[]> res = rel -> {
            try {
                Path p = dir.resolve(rel.replace('\\', '/')).normalize();
                if (!p.startsWith(dir) || !Files.isRegularFile(p)) return null;
                return Files.readAllBytes(p);
            } catch (Exception e) { return null; }
        };
        Mesh m = load(file.getFileName().toString(), Files.readAllBytes(file), res);
        m.source = file.getFileName().toString();
        return m;
    }

    public static Mesh load(String name, byte[] data, Function<String, byte[]> res) throws IOException {
        String n = name.toLowerCase(Locale.ROOT);
        Mesh m;
        if (n.endsWith(".obj")) m = obj(new String(data, StandardCharsets.UTF_8), name, res);
        else if (n.endsWith(".glb")) m = glb(data, res);
        else if (n.endsWith(".gltf")) m = gltf(JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject(), null, res);
        else if (n.endsWith(".fbx")) m = fbx(data, name, res);
        else throw new IOException("Unsupported model format: " + name + " (supported: " + String.join(", ", FORMATS) + ")");
        m.source = name;
        for (Mesh.Node nd : m.nodes) nd.saveRest();
        if (m.vertexCount() == 0) throw new IOException("Model " + name + " has no triangles");
        return m;
    }

    static String base(String name) { int i = name.lastIndexOf('.'); return i < 0 ? name : name.substring(0, i); }

    static byte[] siblingTexture(String name, Function<String, byte[]> res) {
        if (res == null) return new byte[0];
        for (String ext : new String[]{".png", ".jpg", ".jpeg"}) { byte[] b = res.apply(base(name) + ext); if (b != null) return b; }
        return new byte[0];
    }

    // =============================================================== OBJ
    static Mesh obj(String src, String name, Function<String, byte[]> res) {
        Mesh m = new Mesh(); m.format = "obj";
        List<float[]> v = new ArrayList<>(), vt = new ArrayList<>(), vn = new ArrayList<>();
        Map<String, Integer> kd = new HashMap<>();
        String texFile = null;
        List<Float> out = new ArrayList<>();
        String part = "Default"; int color = 0xFFFFFFFF;
        int total = 0;
        for (String line : src.split("\\r?\\n")) {
            String[] t = line.trim().split("\\s+");
            if (t.length < 2) continue;
            try {
                switch (t[0]) {
                    case "v" -> v.add(new float[]{f(t[1]), f(t[2]), f(t[3])});
                    case "vt" -> vt.add(new float[]{f(t[1]), t.length > 2 ? f(t[2]) : 0});
                    case "vn" -> vn.add(new float[]{f(t[1]), f(t[2]), f(t[3])});
                    case "o", "g" -> {
                        String nn = line.trim().substring(1).trim();
                        if (!out.isEmpty()) { addPart(m, part, out, color); out = new ArrayList<>(); }
                        part = nn.isEmpty() ? "Part" + m.parts.size() : nn;
                    }
                    case "mtllib" -> {
                        byte[] b = res == null ? null : res.apply(line.trim().substring(6).trim());
                        if (b != null) {
                            String cur = null;
                            for (String ml : new String(b, StandardCharsets.UTF_8).split("\\r?\\n")) {
                                String[] q = ml.trim().split("\\s+");
                                if (q.length < 2) continue;
                                if (q[0].equals("newmtl")) cur = q[1];
                                else if (q[0].equals("Kd") && cur != null && q.length >= 4)
                                    kd.put(cur, 0xFF000000 | (c255(q[1]) << 16) | (c255(q[2]) << 8) | c255(q[3]));
                                else if (q[0].equals("map_Kd") && texFile == null) texFile = ml.trim().substring(6).trim();
                            }
                        }
                    }
                    case "usemtl" -> {
                        int c = kd.getOrDefault(t[1], 0xFFFFFFFF);
                        if (c != color && !out.isEmpty()) { addPart(m, part, out, color); out = new ArrayList<>(); }
                        color = c;
                    }
                    case "f" -> {
                        int n = t.length - 1;
                        float[][] vs = new float[n][];
                        for (int i = 0; i < n; i++) {
                            String[] ix = t[i + 1].split("/");
                            float[] pos = v.get(idx(ix[0], v.size()));
                            float[] uv = ix.length > 1 && !ix[1].isEmpty() ? vt.get(idx(ix[1], vt.size())) : new float[]{0, 0};
                            float[] nm = ix.length > 2 && !ix[2].isEmpty() ? vn.get(idx(ix[2], vn.size())) : null;
                            vs[i] = new float[]{pos[0], pos[1], pos[2], uv[0], 1 - uv[1], nm == null ? Float.NaN : nm[0], nm == null ? 0 : nm[1], nm == null ? 0 : nm[2]};
                        }
                        for (int i = 1; i + 1 < n; i++) Mesh.tri(out, vs[0], vs[i], vs[i + 1]);
                        total += n;
                    }
                }
            } catch (RuntimeException ignored) { /* skip broken lines */ }
            if (total > 3_000_000) break;
        }
        if (!out.isEmpty()) addPart(m, part, out, color);
        byte[] tex = texFile == null || res == null ? null : res.apply(texFile);
        m.texture = tex != null ? tex : siblingTexture(name, res);
        return m;
    }
    static int c255(String s) { return Math.max(0, Math.min(255, Math.round(Float.parseFloat(s) * 255))); }
    static void addPart(Mesh m, String name, List<Float> v, int color) {
        Mesh.Part p = new Mesh.Part(); p.name = name; p.v = Mesh.arr(v); p.color = color; m.parts.add(p);
    }
    static float f(String s) { return Float.parseFloat(s); }
    static int idx(String s, int size) { int i = Integer.parseInt(s); return i < 0 ? size + i : i - 1; }

    // =============================================================== glTF 2.0 / GLB
    static Mesh glb(byte[] d, Function<String, byte[]> res) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        if (d.length < 20 || b.getInt(0) != 0x46546C67) throw new IOException("Not a GLB file");
        int len = Math.min(b.getInt(8), d.length), pos = 12;
        JsonObject json = null; byte[] bin = null;
        while (pos + 8 <= len) {
            int cl = b.getInt(pos), ct = b.getInt(pos + 4);
            if (cl < 0 || pos + 8 + cl > len) break;
            byte[] chunk = Arrays.copyOfRange(d, pos + 8, pos + 8 + cl);
            if (ct == 0x4E4F534A) json = JsonParser.parseString(new String(chunk, StandardCharsets.UTF_8)).getAsJsonObject();
            else if (ct == 0x004E4942) bin = chunk;
            pos += 8 + cl;
        }
        if (json == null) throw new IOException("GLB has no JSON chunk");
        return gltf(json, bin, res);
    }

    static JsonArray arr(JsonObject o, String k) { return o.has(k) && o.get(k).isJsonArray() ? o.getAsJsonArray(k) : new JsonArray(); }
    static int i(JsonObject o, String k, int def) { return o.has(k) ? o.get(k).getAsInt() : def; }

    static Mesh gltf(JsonObject j, byte[] glbBin, Function<String, byte[]> res) throws IOException {
        Mesh m = new Mesh(); m.format = glbBin != null ? "glb" : "gltf";
        // buffers
        JsonArray bufs = arr(j, "buffers");
        byte[][] buffers = new byte[bufs.size()][];
        for (int k = 0; k < bufs.size(); k++) {
            JsonObject bo = bufs.get(k).getAsJsonObject();
            if (!bo.has("uri")) { buffers[k] = glbBin; continue; }
            buffers[k] = uri(bo.get("uri").getAsString(), res);
        }
        JsonArray views = arr(j, "bufferViews"), accs = arr(j, "accessors");
        Accessor acc = new Accessor(views, accs, buffers);
        // texture: first base color texture
        int texImage = -1;
        JsonArray mats = arr(j, "materials"), textures = arr(j, "textures"), images = arr(j, "images");
        int[] matColor = new int[mats.size()];
        for (int k = 0; k < mats.size(); k++) {
            matColor[k] = 0xFFFFFFFF;
            JsonObject mo = mats.get(k).getAsJsonObject();
            if (!mo.has("pbrMetallicRoughness")) continue;
            JsonObject pbr = mo.getAsJsonObject("pbrMetallicRoughness");
            if (pbr.has("baseColorFactor")) {
                JsonArray c = pbr.getAsJsonArray("baseColorFactor");
                matColor[k] = (cl(c.get(3).getAsFloat()) << 24) | (cl(c.get(0).getAsFloat()) << 16) | (cl(c.get(1).getAsFloat()) << 8) | cl(c.get(2).getAsFloat());
            }
            if (texImage < 0 && pbr.has("baseColorTexture")) {
                int ti = pbr.getAsJsonObject("baseColorTexture").get("index").getAsInt();
                if (ti < textures.size()) texImage = i(textures.get(ti).getAsJsonObject(), "source", -1);
            }
        }
        if (texImage < 0 && images.size() > 0) texImage = 0;
        if (texImage >= 0 && texImage < images.size()) {
            JsonObject im = images.get(texImage).getAsJsonObject();
            try {
                if (im.has("bufferView")) m.texture = acc.view(im.get("bufferView").getAsInt());
                else if (im.has("uri")) m.texture = uri(im.get("uri").getAsString(), res);
            } catch (Exception ignored) {}
            if (m.texture == null) m.texture = new byte[0];
        }
        // nodes
        JsonArray nodes = arr(j, "nodes");
        for (int k = 0; k < nodes.size(); k++) {
            JsonObject no = nodes.get(k).getAsJsonObject();
            Mesh.Node n = new Mesh.Node();
            n.name = no.has("name") ? no.get("name").getAsString() : "Node" + k;
            if (no.has("matrix")) {
                JsonArray mm = no.getAsJsonArray("matrix"); float[] c = new float[16];
                for (int q = 0; q < 16; q++) c[q] = mm.get(q).getAsFloat();
                n.t = new float[]{c[12], c[13], c[14]};
                float sx = len(c[0], c[1], c[2]), sy = len(c[4], c[5], c[6]), sz = len(c[8], c[9], c[10]);
                n.s = new float[]{sx, sy, sz};
                double[] rows = {c[0] / sx, c[4] / sy, c[8] / sz, c[1] / sx, c[5] / sy, c[9] / sz, c[2] / sx, c[6] / sy, c[10] / sz};
                n.r = Mesh.quatFromRows(rows);
            } else {
                if (no.has("translation")) n.t = floats(no.getAsJsonArray("translation"));
                if (no.has("rotation")) n.r = floats(no.getAsJsonArray("rotation"));
                if (no.has("scale")) n.s = floats(no.getAsJsonArray("scale"));
            }
            m.nodes.add(n);
        }
        for (int k = 0; k < nodes.size(); k++)
            for (JsonElement c : arr(nodes.get(k).getAsJsonObject(), "children")) { int ci = c.getAsInt(); if (ci >= 0 && ci < m.nodes.size()) m.nodes.get(ci).parent = k; }
        // meshes referenced by nodes (instanced per node)
        JsonArray meshes = arr(j, "meshes");
        Set<Integer> used = new HashSet<>();
        for (int k = 0; k < nodes.size(); k++) {
            JsonObject no = nodes.get(k).getAsJsonObject();
            if (!no.has("mesh")) continue;
            int mi = no.get("mesh").getAsInt();
            used.add(mi);
            if (mi < meshes.size()) addMesh(m, meshes.get(mi).getAsJsonObject(), k, acc, matColor);
        }
        for (int mi = 0; mi < meshes.size(); mi++) if (!used.contains(mi) && nodes.size() == 0) addMesh(m, meshes.get(mi).getAsJsonObject(), -1, acc, matColor);
        // animations
        for (JsonElement ae : arr(j, "animations")) {
            JsonObject ao = ae.getAsJsonObject();
            Mesh.Anim a = new Mesh.Anim();
            a.name = ao.has("name") ? ao.get("name").getAsString() : "Animation" + m.anims.size();
            JsonArray samplers = arr(ao, "samplers");
            for (JsonElement ce : arr(ao, "channels")) {
                JsonObject co = ce.getAsJsonObject();
                JsonObject tgt = co.getAsJsonObject("target");
                if (tgt == null || !tgt.has("node")) continue;
                String path = tgt.get("path").getAsString();
                int p = switch (path) { case "translation" -> 0; case "rotation" -> 1; case "scale" -> 2; default -> -1; };
                if (p < 0) continue;
                JsonObject so = samplers.get(co.get("sampler").getAsInt()).getAsJsonObject();
                Mesh.Channel c = new Mesh.Channel();
                c.node = tgt.get("node").getAsInt(); c.path = p;
                c.step = so.has("interpolation") && so.get("interpolation").getAsString().equals("STEP");
                c.times = acc.floats(so.get("input").getAsInt());
                float[] out = acc.floats(so.get("output").getAsInt());
                if (so.has("interpolation") && so.get("interpolation").getAsString().equals("CUBICSPLINE")) {
                    int comps = p == 1 ? 4 : 3; float[] o2 = new float[c.times.length * comps];
                    for (int q = 0; q < c.times.length; q++) System.arraycopy(out, (q * 3 + 1) * comps, o2, q * comps, comps);
                    out = o2;
                }
                c.values = out;
                for (float t : c.times) a.duration = Math.max(a.duration, t);
                a.ch.add(c);
            }
            if (!a.ch.isEmpty()) m.anims.add(a);
        }
        return m;
    }
    static float len(float a, float b, float c) { float l = (float) Math.sqrt(a * a + b * b + c * c); return l == 0 ? 1 : l; }
    static int cl(float f) { return Math.max(0, Math.min(255, Math.round(f * 255))); }
    static float[] floats(JsonArray a) { float[] r = new float[a.size()]; for (int k = 0; k < r.length; k++) r[k] = a.get(k).getAsFloat(); return r; }

    static byte[] uri(String uri, Function<String, byte[]> res) throws IOException {
        if (uri.startsWith("data:")) {
            int c = uri.indexOf(',');
            return Base64.getDecoder().decode(uri.substring(c + 1));
        }
        byte[] b = res == null ? null : res.apply(java.net.URLDecoder.decode(uri, StandardCharsets.UTF_8));
        if (b == null) throw new IOException("glTF resource not found next to the model: " + uri);
        return b;
    }

    static void addMesh(Mesh m, JsonObject mesh, int node, Accessor acc, int[] matColor) throws IOException {
        String base = mesh.has("name") ? mesh.get("name").getAsString() : (node >= 0 ? m.nodes.get(node).name : "Mesh");
        JsonArray prims = arr(mesh, "primitives");
        for (int pi = 0; pi < prims.size(); pi++) {
            JsonObject pr = prims.get(pi).getAsJsonObject();
            int mode = i(pr, "mode", 4);
            if (mode != 4 && mode != 5 && mode != 6) continue;
            JsonObject at = pr.getAsJsonObject("attributes");
            if (at == null || !at.has("POSITION")) continue;
            float[] pos = acc.floats(at.get("POSITION").getAsInt());
            float[] nor = at.has("NORMAL") ? acc.floats(at.get("NORMAL").getAsInt()) : null;
            float[] uv = at.has("TEXCOORD_0") ? acc.floats(at.get("TEXCOORD_0").getAsInt()) : null;
            int vc = pos.length / 3;
            int[] idx;
            if (pr.has("indices")) { float[] fi = acc.floats(pr.get("indices").getAsInt()); idx = new int[fi.length]; for (int k = 0; k < fi.length; k++) idx[k] = (int) fi[k]; }
            else { idx = new int[vc]; for (int k = 0; k < vc; k++) idx[k] = k; }
            List<int[]> tris = new ArrayList<>();
            if (mode == 4) for (int k = 0; k + 2 < idx.length; k += 3) tris.add(new int[]{idx[k], idx[k + 1], idx[k + 2]});
            else if (mode == 5) for (int k = 0; k + 2 < idx.length; k++) tris.add(k % 2 == 0 ? new int[]{idx[k], idx[k + 1], idx[k + 2]} : new int[]{idx[k + 1], idx[k], idx[k + 2]});
            else for (int k = 1; k + 1 < idx.length; k++) tris.add(new int[]{idx[0], idx[k], idx[k + 1]});
            List<Float> out = new ArrayList<>(tris.size() * 24);
            for (int[] t : tris) {
                float[][] vs = new float[3][];
                boolean bad = false;
                for (int q = 0; q < 3; q++) {
                    int a = t[q];
                    if (a < 0 || a >= vc) { bad = true; break; }
                    vs[q] = new float[]{pos[a * 3], pos[a * 3 + 1], pos[a * 3 + 2],
                            uv == null ? 0 : uv[a * 2], uv == null ? 0 : uv[a * 2 + 1],
                            nor == null ? Float.NaN : nor[a * 3], nor == null ? 0 : nor[a * 3 + 1], nor == null ? 0 : nor[a * 3 + 2]};
                }
                if (!bad) Mesh.tri(out, vs[0], vs[1], vs[2]);
            }
            Mesh.Part p = new Mesh.Part();
            p.name = prims.size() > 1 ? base + "_" + pi : base;
            p.node = node;
            p.v = Mesh.arr(out);
            int mat = i(pr, "material", -1);
            if (mat >= 0 && mat < matColor.length) p.color = matColor[mat];
            m.parts.add(p);
        }
    }

    static final class Accessor {
        final JsonArray views, accs; final byte[][] bufs;
        Accessor(JsonArray v, JsonArray a, byte[][] b) { views = v; accs = a; bufs = b; }

        byte[] view(int vi) {
            JsonObject v = views.get(vi).getAsJsonObject();
            byte[] b = bufs[i(v, "buffer", 0)];
            int off = i(v, "byteOffset", 0), len = v.get("byteLength").getAsInt();
            return Arrays.copyOfRange(b, off, off + len);
        }

        float[] floats(int ai) throws IOException {
            JsonObject a = accs.get(ai).getAsJsonObject();
            int count = a.get("count").getAsInt();
            int comps = switch (a.get("type").getAsString()) { case "SCALAR" -> 1; case "VEC2" -> 2; case "VEC3" -> 3; case "VEC4" -> 4; case "MAT2" -> 4; case "MAT3" -> 9; default -> 16; };
            int ct = a.get("componentType").getAsInt();
            boolean norm = a.has("normalized") && a.get("normalized").getAsBoolean();
            int size = switch (ct) { case 5120, 5121 -> 1; case 5122, 5123 -> 2; default -> 4; };
            float[] out = new float[count * comps];
            if (!a.has("bufferView")) return out;
            JsonObject v = views.get(a.get("bufferView").getAsInt()).getAsJsonObject();
            byte[] b = bufs[i(v, "buffer", 0)];
            if (b == null) throw new IOException("glTF buffer missing");
            int base = i(v, "byteOffset", 0) + i(a, "byteOffset", 0);
            int stride = i(v, "byteStride", 0); if (stride == 0) stride = size * comps;
            ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
            for (int e = 0; e < count; e++) for (int c = 0; c < comps; c++) {
                int p = base + e * stride + c * size;
                if (p + size > b.length) throw new IOException("glTF accessor out of range");
                float f = switch (ct) {
                    case 5126 -> bb.getFloat(p);
                    case 5125 -> (float) (bb.getInt(p) & 0xFFFFFFFFL);
                    case 5123 -> norm ? (bb.getShort(p) & 0xFFFF) / 65535f : bb.getShort(p) & 0xFFFF;
                    case 5122 -> norm ? Math.max(bb.getShort(p) / 32767f, -1) : bb.getShort(p);
                    case 5121 -> norm ? (b[p] & 0xFF) / 255f : b[p] & 0xFF;
                    default -> norm ? Math.max(b[p] / 127f, -1) : b[p];
                };
                out[e * comps + c] = f;
            }
            return out;
        }
    }

    // =============================================================== FBX
    static final class FNode {
        String name; final List<Object> props = new ArrayList<>(); final List<FNode> kids = new ArrayList<>();
        FNode kid(String n) { for (FNode k : kids) if (k.name.equals(n)) return k; return null; }
        List<FNode> all(String n) { List<FNode> l = new ArrayList<>(); for (FNode k : kids) if (k.name.equals(n)) l.add(k); return l; }
        Object p(int i) { return i < props.size() ? props.get(i) : null; }
        double[] doubles() {
            Object o = p(0);
            if (o instanceof double[] d) return d;
            if (o instanceof float[] f) { double[] d = new double[f.length]; for (int i = 0; i < f.length; i++) d[i] = f[i]; return d; }
            if (o instanceof int[] ia) { double[] d = new double[ia.length]; for (int i = 0; i < ia.length; i++) d[i] = ia[i]; return d; }
            if (o instanceof long[] la) { double[] d = new double[la.length]; for (int i = 0; i < la.length; i++) d[i] = la[i]; return d; }
            double[] d = new double[props.size()]; for (int i = 0; i < d.length; i++) d[i] = props.get(i) instanceof Number nn ? nn.doubleValue() : 0; return d;
        }
        int[] ints() { double[] d = doubles(); int[] r = new int[d.length]; for (int i = 0; i < d.length; i++) r[i] = (int) d[i]; return r; }
        String str(int i) { Object o = p(i); return o instanceof String s ? s : o == null ? "" : o.toString(); }
        long id() { Object o = p(0); return o instanceof Number n ? n.longValue() : 0; }
    }

    static Mesh fbx(byte[] d, String name, Function<String, byte[]> res) throws IOException {
        FNode root;
        String head = new String(d, 0, Math.min(d.length, 20), StandardCharsets.ISO_8859_1);
        if (head.startsWith("Kaydara FBX Binary")) root = fbxBinary(d);
        else root = fbxAscii(new String(d, StandardCharsets.UTF_8));
        Mesh m = new Mesh(); m.format = "fbx";
        FNode objects = root.kid("Objects");
        if (objects == null) throw new IOException("FBX has no Objects section");
        // unit scale (cm -> m by default)
        double unit = 1;
        FNode gs = root.kid("GlobalSettings");
        if (gs != null && gs.kid("Properties70") != null) for (FNode p : gs.kid("Properties70").all("P"))
            if (p.str(0).equals("UnitScaleFactor") && p.p(4) instanceof Number n) unit = n.doubleValue();
        double sc = unit / 100.0;
        // connections child -> parent
        Map<Long, List<Long>> parentOf = new HashMap<>();
        FNode conns = root.kid("Connections");
        if (conns != null) for (FNode c : conns.all("C")) if (c.p(1) instanceof Number a && c.p(2) instanceof Number b)
            parentOf.computeIfAbsent(a.longValue(), k -> new ArrayList<>()).add(b.longValue());
        Map<Long, FNode> models = new HashMap<>();
        for (FNode mo : objects.all("Model")) models.put(mo.id(), mo);
        for (FNode g : objects.all("Geometry")) {
            FNode vn = g.kid("Vertices"), pn = g.kid("PolygonVertexIndex");
            if (vn == null || pn == null) continue;
            double[] verts = vn.doubles(); int[] poly = pn.ints();
            FNode uvL = g.kid("LayerElementUV"), nL = g.kid("LayerElementNormal");
            double[] uvs = null, nrm = null; int[] uvIdx = null, nIdx = null; String uvMap = "", nMap = "";
            if (uvL != null && uvL.kid("UV") != null) {
                uvs = uvL.kid("UV").doubles();
                if (uvL.kid("UVIndex") != null) uvIdx = uvL.kid("UVIndex").ints();
                uvMap = uvL.kid("MappingInformationType") == null ? "" : uvL.kid("MappingInformationType").str(0);
            }
            if (nL != null && nL.kid("Normals") != null) {
                nrm = nL.kid("Normals").doubles();
                if (nL.kid("NormalsIndex") != null) nIdx = nL.kid("NormalsIndex").ints();
                nMap = nL.kid("MappingInformationType") == null ? "" : nL.kid("MappingInformationType").str(0);
            }
            // model transform
            double[] tr = {0, 0, 0}, rot = {0, 0, 0}, scl = {1, 1, 1};
            String pname = g.str(1).replace("Geometry::", "").replace("\u0000\u0001Geometry", "");
            for (long pid : parentOf.getOrDefault(g.id(), List.of())) {
                FNode mo = models.get(pid);
                if (mo == null) continue;
                pname = mo.str(1).split("\u0000")[0].replace("Model::", "");
                FNode p70 = mo.kid("Properties70");
                if (p70 != null) for (FNode p : p70.all("P")) {
                    double[] v3 = {num(p.p(4)), num(p.p(5)), num(p.p(6))};
                    switch (p.str(0)) { case "Lcl Translation" -> tr = v3; case "Lcl Rotation" -> rot = v3; case "Lcl Scaling" -> scl = v3; }
                }
                break;
            }
            double[] R = mulR(mulR(rz(Math.toRadians(rot[2])), ry(Math.toRadians(rot[1]))), rx(Math.toRadians(rot[0])));
            List<Float> out = new ArrayList<>();
            List<float[]> polyV = new ArrayList<>();
            int pvi = 0;
            for (int k = 0; k < poly.length; k++) {
                int vi = poly[k]; boolean end = vi < 0; if (end) vi = ~vi;
                if (vi * 3 + 2 >= verts.length) { pvi++; continue; }
                double x = verts[vi * 3] * scl[0], y = verts[vi * 3 + 1] * scl[1], z = verts[vi * 3 + 2] * scl[2];
                float px = (float) ((R[0] * x + R[1] * y + R[2] * z + tr[0]) * sc), py = (float) ((R[3] * x + R[4] * y + R[5] * z + tr[1]) * sc), pz = (float) ((R[6] * x + R[7] * y + R[8] * z + tr[2]) * sc);
                float u = 0, v = 0, nx = Float.NaN, ny = 0, nz = 0;
                if (uvs != null) {
                    int ui = uvMap.startsWith("ByPolygonVertex") ? pvi : vi;
                    if (uvIdx != null && ui < uvIdx.length) ui = uvIdx[ui];
                    if (ui >= 0 && ui * 2 + 1 < uvs.length) { u = (float) uvs[ui * 2]; v = 1 - (float) uvs[ui * 2 + 1]; }
                }
                if (nrm != null) {
                    int ni = nMap.startsWith("ByPolygonVertex") ? pvi : vi;
                    if (nIdx != null && ni < nIdx.length) ni = nIdx[ni];
                    if (ni >= 0 && ni * 3 + 2 < nrm.length) {
                        double a = nrm[ni * 3], b = nrm[ni * 3 + 1], c = nrm[ni * 3 + 2];
                        nx = (float) (R[0] * a + R[1] * b + R[2] * c); ny = (float) (R[3] * a + R[4] * b + R[5] * c); nz = (float) (R[6] * a + R[7] * b + R[8] * c);
                    }
                }
                polyV.add(new float[]{px, py, pz, u, v, nx, ny, nz});
                pvi++;
                if (end) {
                    for (int q = 1; q + 1 < polyV.size(); q++) Mesh.tri(out, polyV.get(0), polyV.get(q), polyV.get(q + 1));
                    polyV.clear();
                }
            }
            if (!out.isEmpty()) addPart(m, pname.isBlank() ? "Mesh" + m.parts.size() : pname.trim(), out, 0xFFFFFFFF);
        }
        // embedded texture
        for (FNode vid : objects.all("Video")) {
            FNode c = vid.kid("Content");
            if (c != null && c.p(0) instanceof byte[] b && b.length > 8) { m.texture = b; break; }
        }
        if (m.texture.length == 0) {
            for (FNode tex : objects.all("Texture")) {
                FNode fn = tex.kid("RelativeFilename") != null ? tex.kid("RelativeFilename") : tex.kid("FileName");
                if (fn == null || res == null) continue;
                String f = fn.str(0).replace('\\', '/');
                byte[] b = res.apply(f);
                if (b == null) b = res.apply(f.substring(f.lastIndexOf('/') + 1));
                if (b != null) { m.texture = b; break; }
            }
        }
        if (m.texture.length == 0) m.texture = siblingTexture(name, res);
        return m;
    }
    static double num(Object o) { return o instanceof Number n ? n.doubleValue() : 0; }
    static double[] rx(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[]{1, 0, 0, 0, c, -s, 0, s, c}; }
    static double[] ry(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[]{c, 0, s, 0, 1, 0, -s, 0, c}; }
    static double[] rz(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[]{c, -s, 0, s, c, 0, 0, 0, 1}; }
    static double[] mulR(double[] a, double[] b) {
        double[] r = new double[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) { double s = 0; for (int k = 0; k < 3; k++) s += a[i * 3 + k] * b[k * 3 + j]; r[i * 3 + j] = s; }
        return r;
    }

    static FNode fbxBinary(byte[] d) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int version = b.getInt(23);
        boolean wide = version >= 7500;
        FNode root = new FNode(); root.name = "";
        int[] pos = {27};
        while (pos[0] < d.length) {
            FNode n = fbxNode(b, d, pos, wide, 0);
            if (n == null) break;
            root.kids.add(n);
        }
        return root;
    }

    static FNode fbxNode(ByteBuffer b, byte[] d, int[] pos, boolean wide, int depth) throws IOException {
        if (depth > 64) throw new IOException("FBX nesting too deep");
        int p = pos[0];
        int hdr = wide ? 25 : 13;
        if (p + hdr > d.length) return null;
        long end = wide ? b.getLong(p) : b.getInt(p) & 0xFFFFFFFFL;
        long nprops = wide ? b.getLong(p + 8) : b.getInt(p + 4) & 0xFFFFFFFFL;
        int nameLen = d[p + (wide ? 24 : 12)] & 0xFF;
        if (end == 0) { pos[0] = p + hdr; return null; }
        if (end > d.length || end <= p) throw new IOException("Broken FBX file");
        FNode n = new FNode();
        n.name = new String(d, p + hdr, nameLen, StandardCharsets.ISO_8859_1);
        int q = p + hdr + nameLen;
        for (long i = 0; i < nprops; i++) {
            char t = (char) d[q++];
            switch (t) {
                case 'Y' -> { n.props.add((int) b.getShort(q)); q += 2; }
                case 'C' -> { n.props.add(d[q] != 0 ? 1 : 0); q += 1; }
                case 'I' -> { n.props.add(b.getInt(q)); q += 4; }
                case 'F' -> { n.props.add(b.getFloat(q)); q += 4; }
                case 'D' -> { n.props.add(b.getDouble(q)); q += 8; }
                case 'L' -> { n.props.add(b.getLong(q)); q += 8; }
                case 'S', 'R' -> {
                    int len = b.getInt(q); q += 4;
                    if (len < 0 || q + len > d.length) throw new IOException("Broken FBX string");
                    if (t == 'S') n.props.add(new String(d, q, len, StandardCharsets.UTF_8)); else n.props.add(Arrays.copyOfRange(d, q, q + len));
                    q += len;
                }
                case 'f', 'd', 'l', 'i', 'b' -> {
                    int len = b.getInt(q), enc = b.getInt(q + 4), clen = b.getInt(q + 8); q += 12;
                    int es = t == 'd' || t == 'l' ? 8 : t == 'b' ? 1 : 4;
                    if (len < 0 || len > 50_000_000 || clen < 0 || q + clen > d.length) throw new IOException("Broken FBX array");
                    byte[] raw;
                    if (enc == 1) {
                        Inflater inf = new Inflater(); inf.setInput(d, q, clen);
                        raw = new byte[len * es];
                        try { int got = 0; while (got < raw.length && !inf.finished()) { int r = inf.inflate(raw, got, raw.length - got); if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break; got += r; } }
                        catch (java.util.zip.DataFormatException e) { throw new IOException("Broken FBX zlib data"); }
                        finally { inf.end(); }
                    } else raw = Arrays.copyOfRange(d, q, q + len * es);
                    q += clen;
                    ByteBuffer rb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
                    switch (t) {
                        case 'f' -> { float[] a = new float[len]; for (int k = 0; k < len; k++) a[k] = rb.getFloat(k * 4); n.props.add(a); }
                        case 'd' -> { double[] a = new double[len]; for (int k = 0; k < len; k++) a[k] = rb.getDouble(k * 8); n.props.add(a); }
                        case 'l' -> { long[] a = new long[len]; for (int k = 0; k < len; k++) a[k] = rb.getLong(k * 8); n.props.add(a); }
                        case 'i' -> { int[] a = new int[len]; for (int k = 0; k < len; k++) a[k] = rb.getInt(k * 4); n.props.add(a); }
                        default -> { int[] a = new int[len]; for (int k = 0; k < len; k++) a[k] = raw[k]; n.props.add(a); }
                    }
                }
                default -> throw new IOException("Unknown FBX property type " + t);
            }
        }
        pos[0] = q;
        while (pos[0] < end) {
            FNode c = fbxNode(b, d, pos, wide, depth + 1);
            if (c == null) break;
            n.kids.add(c);
        }
        pos[0] = (int) end;
        return n;
    }

    /** ASCII FBX: tokenizer for  Name: props { children }  and  *N { a: values } arrays */
    static FNode fbxAscii(String s) throws IOException {
        FNode root = new FNode(); root.name = "";
        Deque<FNode> stack = new ArrayDeque<>(); stack.push(root);
        int i = 0, n = s.length();
        FNode last = null;
        while (i < n) {
            char c = s.charAt(i);
            if (c == ';') { while (i < n && s.charAt(i) != '\n') i++; continue; }
            if (Character.isWhitespace(c) || c == ',') { i++; continue; }
            if (c == '{') { if (last != null) stack.push(last); i++; continue; }
            if (c == '}') { if (stack.size() > 1) stack.pop(); last = null; i++; continue; }
            if (c == '"') {
                int j = s.indexOf('"', i + 1); if (j < 0) j = n;
                if (last != null) last.props.add(s.substring(i + 1, j));
                i = j + 1; continue;
            }
            int j = i;
            while (j < n && !Character.isWhitespace(s.charAt(j)) && ",{}\"".indexOf(s.charAt(j)) < 0) j++;
            String tok = s.substring(i, j);
            i = j;
            if (tok.endsWith(":")) {
                FNode nd = new FNode(); nd.name = tok.substring(0, tok.length() - 1);
                if (nd.name.equals("a") && last == null && !stack.isEmpty()) { // array content belongs to the current node
                    FNode cur = stack.peek();
                    List<Double> vals = new ArrayList<>();
                    while (i < n && s.charAt(i) != '}') {
                        char ch = s.charAt(i);
                        if (Character.isWhitespace(ch) || ch == ',') { i++; continue; }
                        int k = i; while (k < n && !Character.isWhitespace(s.charAt(k)) && s.charAt(k) != ',' && s.charAt(k) != '}') k++;
                        try { vals.add(Double.parseDouble(s.substring(i, k))); } catch (NumberFormatException ignored) {}
                        i = k;
                    }
                    double[] arr = new double[vals.size()]; for (int k = 0; k < arr.length; k++) arr[k] = vals.get(k);
                    cur.props.clear(); cur.props.add(arr);
                    continue;
                }
                stack.peek().kids.add(nd);
                last = nd;
                continue;
            }
            if (last != null) {
                if (tok.startsWith("*")) { /* array length marker */ continue; }
                try { last.props.add(tok.contains(".") || tok.contains("e") ? (Object) Double.parseDouble(tok) : (Object) Long.parseLong(tok)); }
                catch (NumberFormatException e) { last.props.add(tok); }
            }
        }
        return root;
    }

    // =============================================================== primitives (Projector:Create)
    public static Mesh primitive(String cls, int segments) {
        Mesh m = new Mesh(); m.format = "primitive"; m.source = cls;
        List<Float> out = new ArrayList<>();
        int seg = Math.max(3, Math.min(128, segments));
        switch (cls.toLowerCase(Locale.ROOT)) {
            case "plane" -> quad(out, new float[]{-.5f, 0, -.5f}, new float[]{-.5f, 0, .5f}, new float[]{.5f, 0, .5f}, new float[]{.5f, 0, -.5f});
            case "sphere", "ball" -> {
                for (int a = 0; a < seg; a++) for (int b = 0; b < seg * 2; b++) {
                    float[] p00 = sph(a, b, seg), p10 = sph(a + 1, b, seg), p11 = sph(a + 1, b + 1, seg), p01 = sph(a, b + 1, seg);
                    Mesh.tri(out, p00, p10, p11); Mesh.tri(out, p00, p11, p01);
                }
            }
            case "cylinder", "cone" -> {
                boolean cone = cls.equalsIgnoreCase("cone");
                for (int k = 0; k < seg; k++) {
                    double a0 = 2 * Math.PI * k / seg, a1 = 2 * Math.PI * (k + 1) / seg;
                    float x0 = (float) Math.cos(a0) * .5f, z0 = (float) Math.sin(a0) * .5f, x1 = (float) Math.cos(a1) * .5f, z1 = (float) Math.sin(a1) * .5f;
                    float u0 = (float) k / seg, u1 = (float) (k + 1) / seg;
                    float[] b0 = {x0, -.5f, z0, u0, 1, Float.NaN, 0, 0}, b1 = {x1, -.5f, z1, u1, 1, Float.NaN, 0, 0};
                    float[] t0 = cone ? new float[]{0, .5f, 0, u0, 0, Float.NaN, 0, 0} : new float[]{x0, .5f, z0, u0, 0, Float.NaN, 0, 0};
                    float[] t1 = cone ? new float[]{0, .5f, 0, u1, 0, Float.NaN, 0, 0} : new float[]{x1, .5f, z1, u1, 0, Float.NaN, 0, 0};
                    Mesh.tri(out, b0, t0, t1); if (!cone) Mesh.tri(out, b0, t1, b1); else Mesh.tri(out, b0, t1, b1);
                    Mesh.tri(out, new float[]{0, -.5f, 0, .5f, .5f, Float.NaN, 0, 0}, b0, b1);
                    if (!cone) Mesh.tri(out, new float[]{0, .5f, 0, .5f, .5f, Float.NaN, 0, 0}, t1, t0);
                }
            }
            default -> { // Cube / Part / Block
                float h = .5f;
                float[][] c = {{-h, -h, -h}, {h, -h, -h}, {h, h, -h}, {-h, h, -h}, {-h, -h, h}, {h, -h, h}, {h, h, h}, {-h, h, h}};
                int[][] f = {{4, 5, 6, 7}, {1, 0, 3, 2}, {5, 1, 2, 6}, {0, 4, 7, 3}, {7, 6, 2, 3}, {0, 1, 5, 4}};
                for (int[] q : f) quad(out, c[q[0]], c[q[1]], c[q[2]], c[q[3]]);
            }
        }
        Mesh.Part p = new Mesh.Part(); p.name = cls; p.v = Mesh.arr(out); m.parts.add(p);
        return m;
    }
    static float[] sph(int a, int b, int seg) {
        double th = Math.PI * a / seg, ph = Math.PI * b / seg;
        float x = (float) (Math.sin(th) * Math.cos(ph)), y = (float) Math.cos(th), z = (float) (Math.sin(th) * Math.sin(ph));
        return new float[]{x * .5f, y * .5f, z * .5f, (float) b / (seg * 2), (float) a / seg, x, y, z};
    }
    static void quad(List<Float> out, float[] a, float[] b, float[] c, float[] d) {
        float[] A = {a[0], a[1], a[2], 0, 1, Float.NaN, 0, 0}, B = {b[0], b[1], b[2], 1, 1, Float.NaN, 0, 0}, C = {c[0], c[1], c[2], 1, 0, Float.NaN, 0, 0}, D = {d[0], d[1], d[2], 0, 0, Float.NaN, 0, 0};
        Mesh.tri(out, A, B, C); Mesh.tri(out, A, C, D);
    }
}
