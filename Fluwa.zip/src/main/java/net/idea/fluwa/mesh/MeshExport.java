package net.idea.fluwa.mesh;

import com.google.gson.*;

import java.io.ByteArrayOutputStream;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Writes a Mesh (current pose baked) as .obj, .gltf (embedded buffer) or .glb */
public final class MeshExport {
    private MeshExport() {}

    public static byte[] export(Mesh m, String format) {
        return switch (format.toLowerCase(Locale.ROOT).replace(".", "")) {
            case "obj" -> obj(m).getBytes(StandardCharsets.UTF_8);
            case "gltf" -> gltf(m, false);
            case "glb" -> gltf(m, true);
            default -> throw new IllegalArgumentException("Export supports obj, gltf, glb (fbx export is not supported)");
        };
    }

    public static String obj(Mesh m) {
        StringBuilder sb = new StringBuilder("# exported by Fluwa Projector\n");
        List<float[]> posed = m.posed();
        int base = 1;
        for (int pi = 0; pi < m.parts.size(); pi++) {
            float[] v = posed.get(pi);
            sb.append("o ").append(m.parts.get(pi).name.replace(' ', '_')).append('\n');
            for (int i = 0; i + 7 < v.length; i += 8) sb.append("v ").append(v[i]).append(' ').append(v[i + 1]).append(' ').append(v[i + 2]).append('\n');
            for (int i = 0; i + 7 < v.length; i += 8) sb.append("vt ").append(v[i + 3]).append(' ').append(1 - v[i + 4]).append('\n');
            for (int i = 0; i + 7 < v.length; i += 8) sb.append("vn ").append(v[i + 5]).append(' ').append(v[i + 6]).append(' ').append(v[i + 7]).append('\n');
            int n = v.length / 8;
            for (int t = 0; t + 2 < n; t += 3) {
                sb.append("f");
                for (int k = 0; k < 3; k++) { int id = base + t + k; sb.append(' ').append(id).append('/').append(id).append('/').append(id); }
                sb.append('\n');
            }
            base += n;
        }
        return sb.toString();
    }

    public static byte[] gltf(Mesh m, boolean glb) {
        List<float[]> posed = m.posed();
        ByteArrayOutputStream bin = new ByteArrayOutputStream();
        JsonArray views = new JsonArray(), accs = new JsonArray(), meshes = new JsonArray(), nodes = new JsonArray(), sceneNodes = new JsonArray();
        boolean tex = m.texture.length > 0;
        for (int pi = 0; pi < m.parts.size(); pi++) {
            float[] v = posed.get(pi);
            int n = v.length / 8;
            if (n == 0) continue;
            float[] min = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE}, max = {-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
            ByteBuffer pos = ByteBuffer.allocate(n * 12).order(ByteOrder.LITTLE_ENDIAN), nor = ByteBuffer.allocate(n * 12).order(ByteOrder.LITTLE_ENDIAN), uv = ByteBuffer.allocate(n * 8).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < 3; k++) { float f = v[i * 8 + k]; pos.putFloat(f); min[k] = Math.min(min[k], f); max[k] = Math.max(max[k], f); }
                uv.putFloat(v[i * 8 + 3]); uv.putFloat(v[i * 8 + 4]);
                for (int k = 5; k < 8; k++) nor.putFloat(v[i * 8 + k]);
            }
            int pa = view(bin, views, pos.array(), 34962); accs.add(acc(pa, n, "VEC3", min, max));
            int na = view(bin, views, nor.array(), 34962); accs.add(acc(na, n, "VEC3", null, null));
            int ua = view(bin, views, uv.array(), 34962); accs.add(acc(ua, n, "VEC2", null, null));
            int ai = accs.size();
            JsonObject attrs = new JsonObject();
            attrs.addProperty("POSITION", ai - 3); attrs.addProperty("NORMAL", ai - 2); attrs.addProperty("TEXCOORD_0", ai - 1);
            JsonObject prim = new JsonObject(); prim.add("attributes", attrs); prim.addProperty("material", pi);
            JsonArray prims = new JsonArray(); prims.add(prim);
            JsonObject mesh = new JsonObject(); mesh.addProperty("name", m.parts.get(pi).name); mesh.add("primitives", prims);
            meshes.add(mesh);
            JsonObject node = new JsonObject(); node.addProperty("name", m.parts.get(pi).name); node.addProperty("mesh", meshes.size() - 1);
            nodes.add(node); sceneNodes.add(nodes.size() - 1);
        }
        JsonArray mats = new JsonArray();
        for (Mesh.Part p : m.parts) {
            JsonObject pbr = new JsonObject();
            JsonArray c = new JsonArray();
            c.add((p.color >> 16 & 255) / 255f); c.add((p.color >> 8 & 255) / 255f); c.add((p.color & 255) / 255f); c.add((p.color >>> 24) / 255f);
            pbr.add("baseColorFactor", c);
            if (tex) { JsonObject t = new JsonObject(); t.addProperty("index", 0); pbr.add("baseColorTexture", t); }
            pbr.addProperty("metallicFactor", 0);
            JsonObject mo = new JsonObject(); mo.addProperty("name", p.name); mo.add("pbrMetallicRoughness", pbr); mo.addProperty("doubleSided", true);
            mats.add(mo);
        }
        JsonObject j = new JsonObject();
        JsonObject asset = new JsonObject(); asset.addProperty("version", "2.0"); asset.addProperty("generator", "Fluwa Projector");
        j.add("asset", asset);
        JsonObject scene = new JsonObject(); scene.add("nodes", sceneNodes);
        JsonArray scenes = new JsonArray(); scenes.add(scene);
        j.addProperty("scene", 0); j.add("scenes", scenes); j.add("nodes", nodes); j.add("meshes", meshes); j.add("materials", mats);
        if (tex) {
            int iv = view(bin, views, m.texture, -1);
            JsonObject img = new JsonObject(); img.addProperty("bufferView", iv); img.addProperty("mimeType", "image/png");
            JsonArray imgs = new JsonArray(); imgs.add(img); j.add("images", imgs);
            JsonObject t = new JsonObject(); t.addProperty("source", 0);
            JsonArray ts = new JsonArray(); ts.add(t); j.add("textures", ts);
        }
        j.add("bufferViews", views); j.add("accessors", accs);
        byte[] data = bin.toByteArray();
        JsonObject buf = new JsonObject(); buf.addProperty("byteLength", data.length);
        if (!glb) buf.addProperty("uri", "data:application/octet-stream;base64," + Base64.getEncoder().encodeToString(data));
        JsonArray bufs = new JsonArray(); bufs.add(buf); j.add("buffers", bufs);
        byte[] json = new Gson().toJson(j).getBytes(StandardCharsets.UTF_8);
        if (!glb) return json;
        int jl = (json.length + 3) & ~3, bl = (data.length + 3) & ~3;
        ByteBuffer o = ByteBuffer.allocate(12 + 8 + jl + 8 + bl).order(ByteOrder.LITTLE_ENDIAN);
        o.putInt(0x46546C67).putInt(2).putInt(o.capacity());
        o.putInt(jl).putInt(0x4E4F534A).put(json); for (int k = json.length; k < jl; k++) o.put((byte) ' ');
        o.putInt(bl).putInt(0x004E4942).put(data); for (int k = data.length; k < bl; k++) o.put((byte) 0);
        return o.array();
    }

    static int view(ByteArrayOutputStream bin, JsonArray views, byte[] data, int target) {
        while (bin.size() % 4 != 0) bin.write(0);
        JsonObject v = new JsonObject();
        v.addProperty("buffer", 0); v.addProperty("byteOffset", bin.size()); v.addProperty("byteLength", data.length);
        if (target > 0) v.addProperty("target", target);
        bin.writeBytes(data);
        views.add(v);
        return views.size() - 1;
    }

    static JsonObject acc(int view, int count, String type, float[] min, float[] max) {
        JsonObject a = new JsonObject();
        a.addProperty("bufferView", view); a.addProperty("componentType", 5126); a.addProperty("count", count); a.addProperty("type", type);
        if (min != null) { JsonArray mn = new JsonArray(), mx = new JsonArray(); for (int k = 0; k < 3; k++) { mn.add(min[k]); mx.add(max[k]); } a.add("min", mn); a.add("max", mx); }
        return a;
    }
}
