package net.idea.fluwa.mesh;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Format-independent 3D model used by SetModel/GetModel and the Projector service.
 * Parts are triangle lists (8 floats per vertex: x y z u v nx ny nz) attached to nodes (bones);
 * nodes form a hierarchy with TRS transforms; animations drive node TRS.
 */
public final class Mesh {
    public static final class Part {
        public String name = "Part";
        public int node = -1;            // owning node (-1 = root)
        public float[] v = new float[0];  // triangles
        public int color = 0xFFFFFFFF;    // ARGB tint (material base color)
        public boolean visible = true;
        public Part copy() { Part p = new Part(); p.name = name; p.node = node; p.v = v.clone(); p.color = color; p.visible = visible; return p; }
        public int vertexCount() { return v.length / 8; }
    }

    public static final class Node {
        public String name = "Node";
        public int parent = -1;
        public float[] t = {0, 0, 0}, r = {0, 0, 0, 1}, s = {1, 1, 1};
        /** rest pose (for StopAnimation) */
        public float[] t0, r0, s0;
        public Node copy() { Node n = new Node(); n.name = name; n.parent = parent; n.t = t.clone(); n.r = r.clone(); n.s = s.clone();
            n.t0 = t0 == null ? null : t0.clone(); n.r0 = r0 == null ? null : r0.clone(); n.s0 = s0 == null ? null : s0.clone(); return n; }
        public void saveRest() { t0 = t.clone(); r0 = r.clone(); s0 = s.clone(); }
        public void restore() { if (t0 != null) { t = t0.clone(); r = r0.clone(); s = s0.clone(); } }
    }

    public static final class Channel {
        public int node, path;            // path 0 translation, 1 rotation (quat), 2 scale
        public float[] times = new float[0], values = new float[0];
        public boolean step;
    }

    public static final class Anim {
        public String name = "Animation";
        public float duration;
        public final List<Channel> ch = new ArrayList<>();
    }

    public final List<Part> parts = new ArrayList<>();
    public final List<Node> nodes = new ArrayList<>();
    public final List<Anim> anims = new ArrayList<>();
    public byte[] texture = new byte[0];   // PNG (or other ImageIO/NativeImage readable) bytes
    public String format = "mesh", source = "";

    public Mesh copy() {
        Mesh m = new Mesh();
        for (Part p : parts) m.parts.add(p.copy());
        for (Node n : nodes) m.nodes.add(n.copy());
        m.anims.addAll(anims); // animations are immutable after load
        m.texture = texture; m.format = format; m.source = source;
        return m;
    }

    public int vertexCount() { int n = 0; for (Part p : parts) n += p.vertexCount(); return n; }
    public int triangleCount() { return vertexCount() / 3; }

    public int findNode(String name) { for (int i = 0; i < nodes.size(); i++) if (nodes.get(i).name.equals(name)) return i; return -1; }
    public Anim findAnim(String name) {
        if (anims.isEmpty()) return null;
        if (name == null || name.isEmpty()) return anims.get(0);
        for (Anim a : anims) if (a.name.equalsIgnoreCase(name)) return a;
        return null;
    }

    // ------------------------------------------------------------------ math (column-major 4x4 like OpenGL)
    public static float[] trs(float[] t, float[] q, float[] s) {
        float x = q[0], y = q[1], z = q[2], w = q[3];
        float[] m = new float[16];
        m[0] = (1 - 2 * (y * y + z * z)) * s[0]; m[1] = (2 * (x * y + z * w)) * s[0]; m[2] = (2 * (x * z - y * w)) * s[0];
        m[4] = (2 * (x * y - z * w)) * s[1]; m[5] = (1 - 2 * (x * x + z * z)) * s[1]; m[6] = (2 * (y * z + x * w)) * s[1];
        m[8] = (2 * (x * z + y * w)) * s[2]; m[9] = (2 * (y * z - x * w)) * s[2]; m[10] = (1 - 2 * (x * x + y * y)) * s[2];
        m[12] = t[0]; m[13] = t[1]; m[14] = t[2]; m[15] = 1;
        return m;
    }
    public static float[] mul(float[] a, float[] b) {
        float[] r = new float[16];
        for (int c = 0; c < 4; c++) for (int rr = 0; rr < 4; rr++) {
            float s = 0; for (int k = 0; k < 4; k++) s += a[k * 4 + rr] * b[c * 4 + k];
            r[c * 4 + rr] = s;
        }
        return r;
    }
    public static final float[] IDENTITY = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};

    /** global matrix of every node (index = node), computed from current TRS */
    public float[][] globals() {
        float[][] g = new float[nodes.size()][];
        for (int i = 0; i < nodes.size(); i++) global(i, g, 0);
        return g;
    }
    private float[] global(int i, float[][] g, int depth) {
        if (g[i] != null) return g[i];
        Node n = nodes.get(i);
        float[] local = trs(n.t, n.r, n.s);
        g[i] = n.parent >= 0 && n.parent != i && depth < 256 ? mul(global(n.parent, g, depth + 1), local) : local;
        return g[i];
    }

    /** transformed copy of a part's vertices (positions + normals) */
    public static float[] apply(float[] v, float[] m) {
        if (m == null || Arrays.equals(m, IDENTITY)) return v;
        float[] o = v.clone();
        for (int i = 0; i + 7 < v.length; i += 8) {
            float x = v[i], y = v[i + 1], z = v[i + 2];
            o[i] = m[0] * x + m[4] * y + m[8] * z + m[12];
            o[i + 1] = m[1] * x + m[5] * y + m[9] * z + m[13];
            o[i + 2] = m[2] * x + m[6] * y + m[10] * z + m[14];
            float nx = v[i + 5], ny = v[i + 6], nz = v[i + 7];
            float a = m[0] * nx + m[4] * ny + m[8] * nz, b = m[1] * nx + m[5] * ny + m[9] * nz, c = m[2] * nx + m[6] * ny + m[10] * nz;
            float l = (float) Math.sqrt(a * a + b * b + c * c); if (l > 0) { a /= l; b /= l; c /= l; }
            o[i + 5] = a; o[i + 6] = b; o[i + 7] = c;
        }
        return o;
    }

    /** all vertices in model space (current pose) */
    public List<float[]> posed() {
        float[][] g = globals();
        List<float[]> out = new ArrayList<>();
        for (Part p : parts) out.add(p.node >= 0 && p.node < g.length ? apply(p.v, g[p.node]) : p.v);
        return out;
    }

    /** {minX,minY,minZ,maxX,maxY,maxZ} in model space */
    public float[] bounds() {
        float[] b = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        for (float[] v : posed()) for (int i = 0; i + 7 < v.length; i += 8) for (int k = 0; k < 3; k++) { b[k] = Math.min(b[k], v[i + k]); b[k + 3] = Math.max(b[k + 3], v[i + k]); }
        if (b[0] > b[3]) return new float[6];
        return b;
    }

    // ------------------------------------------------------------------ animation sampling
    public void sample(Anim a, float time) {
        for (Channel c : a.ch) {
            if (c.node < 0 || c.node >= nodes.size() || c.times.length == 0) continue;
            int comps = c.path == 1 ? 4 : 3;
            float[] tm = c.times;
            int i = 0;
            while (i + 1 < tm.length && tm[i + 1] <= time) i++;
            float[] out = new float[comps];
            if (time <= tm[0] || i + 1 >= tm.length || c.step) System.arraycopy(c.values, Math.min(i, tm.length - 1) * comps, out, 0, comps);
            else {
                float f = (time - tm[i]) / Math.max(1e-6f, tm[i + 1] - tm[i]);
                if (c.path == 1) out = slerp(c.values, i * 4, (i + 1) * 4, f);
                else for (int k = 0; k < 3; k++) out[k] = c.values[i * 3 + k] + (c.values[(i + 1) * 3 + k] - c.values[i * 3 + k]) * f;
            }
            Node n = nodes.get(c.node);
            if (c.path == 0) n.t = out; else if (c.path == 1) n.r = out; else n.s = out;
        }
    }
    static float[] slerp(float[] v, int a, int b, float t) {
        float ax = v[a], ay = v[a + 1], az = v[a + 2], aw = v[a + 3], bx = v[b], by = v[b + 1], bz = v[b + 2], bw = v[b + 3];
        float d = ax * bx + ay * by + az * bz + aw * bw;
        if (d < 0) { d = -d; bx = -bx; by = -by; bz = -bz; bw = -bw; }
        float k0, k1;
        if (d > 0.9995f) { k0 = 1 - t; k1 = t; }
        else { float th = (float) Math.acos(d), sn = (float) Math.sin(th); k0 = (float) Math.sin((1 - t) * th) / sn; k1 = (float) Math.sin(t * th) / sn; }
        float[] r = {ax * k0 + bx * k1, ay * k0 + by * k1, az * k0 + bz * k1, aw * k0 + bw * k1};
        float l = (float) Math.sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2] + r[3] * r[3]);
        if (l > 0) for (int i = 0; i < 4; i++) r[i] /= l;
        return r;
    }

    /** quaternion from XYZ euler (radians) */
    public static float[] quatEuler(double x, double y, double z) {
        double cx = Math.cos(x / 2), sx = Math.sin(x / 2), cy = Math.cos(y / 2), sy = Math.sin(y / 2), cz = Math.cos(z / 2), sz = Math.sin(z / 2);
        // R = Rx * Ry * Rz
        double w = cx * cy * cz - sx * sy * sz;
        double qx = sx * cy * cz + cx * sy * sz;
        double qy = cx * sy * cz - sx * cy * sz;
        double qz = cx * cy * sz + sx * sy * cz;
        return new float[]{(float) qx, (float) qy, (float) qz, (float) w};
    }
    /** quaternion from a row-major 3x3 rotation matrix */
    public static float[] quatFromRows(double[] m) {
        double tr = m[0] + m[4] + m[8], qw, qx, qy, qz;
        if (tr > 0) { double s = Math.sqrt(tr + 1) * 2; qw = 0.25 * s; qx = (m[7] - m[5]) / s; qy = (m[2] - m[6]) / s; qz = (m[3] - m[1]) / s; }
        else if (m[0] > m[4] && m[0] > m[8]) { double s = Math.sqrt(1 + m[0] - m[4] - m[8]) * 2; qw = (m[7] - m[5]) / s; qx = 0.25 * s; qy = (m[1] + m[3]) / s; qz = (m[2] + m[6]) / s; }
        else if (m[4] > m[8]) { double s = Math.sqrt(1 + m[4] - m[0] - m[8]) * 2; qw = (m[2] - m[6]) / s; qx = (m[1] + m[3]) / s; qy = 0.25 * s; qz = (m[5] + m[7]) / s; }
        else { double s = Math.sqrt(1 + m[8] - m[0] - m[4]) * 2; qw = (m[3] - m[1]) / s; qx = (m[2] + m[6]) / s; qy = (m[5] + m[7]) / s; qz = 0.25 * s; }
        return new float[]{(float) qx, (float) qy, (float) qz, (float) qw};
    }
    /** row-major 3x3 from quaternion */
    public static double[] rowsFromQuat(float[] q) {
        double x = q[0], y = q[1], z = q[2], w = q[3];
        return new double[]{1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w),
                2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w),
                2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)};
    }

    // ------------------------------------------------------------------ binary form (network / cache)
    public byte[] toBytes() {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (DataOutputStream o = new DataOutputStream(new DeflaterOutputStream(bo, new Deflater(6)))) {
                o.writeInt(0x464D5348); o.writeUTF(format); o.writeUTF(source);
                o.writeInt(nodes.size());
                for (Node n : nodes) { o.writeUTF(n.name); o.writeInt(n.parent); for (float f : n.t) o.writeFloat(f); for (float f : n.r) o.writeFloat(f); for (float f : n.s) o.writeFloat(f); }
                o.writeInt(parts.size());
                for (Part p : parts) { o.writeUTF(p.name); o.writeInt(p.node); o.writeInt(p.color); o.writeBoolean(p.visible); o.writeInt(p.v.length); for (float f : p.v) o.writeFloat(f); }
                o.writeInt(anims.size());
                for (Anim a : anims) {
                    o.writeUTF(a.name); o.writeFloat(a.duration); o.writeInt(a.ch.size());
                    for (Channel c : a.ch) { o.writeInt(c.node); o.writeByte(c.path); o.writeBoolean(c.step);
                        o.writeInt(c.times.length); for (float f : c.times) o.writeFloat(f); o.writeInt(c.values.length); for (float f : c.values) o.writeFloat(f); }
                }
                o.writeInt(texture.length); o.write(texture);
            }
            return bo.toByteArray();
        } catch (IOException e) { throw new UncheckedIOException(e); }
    }

    public static Mesh fromBytes(byte[] b) throws IOException {
        try (DataInputStream in = new DataInputStream(new InflaterInputStream(new ByteArrayInputStream(b)))) {
            if (in.readInt() != 0x464D5348) throw new IOException("not a Fluwa mesh");
            Mesh m = new Mesh();
            m.format = in.readUTF(); m.source = in.readUTF();
            int nn = lim(in.readInt(), 100_000);
            for (int i = 0; i < nn; i++) { Node n = new Node(); n.name = in.readUTF(); n.parent = in.readInt();
                for (int k = 0; k < 3; k++) n.t[k] = in.readFloat(); for (int k = 0; k < 4; k++) n.r[k] = in.readFloat(); for (int k = 0; k < 3; k++) n.s[k] = in.readFloat();
                n.saveRest(); m.nodes.add(n); }
            int np = lim(in.readInt(), 100_000);
            for (int i = 0; i < np; i++) { Part p = new Part(); p.name = in.readUTF(); p.node = in.readInt(); p.color = in.readInt(); p.visible = in.readBoolean();
                p.v = new float[lim(in.readInt(), 40_000_000)]; for (int k = 0; k < p.v.length; k++) p.v[k] = in.readFloat(); m.parts.add(p); }
            int na = lim(in.readInt(), 10_000);
            for (int i = 0; i < na; i++) { Anim a = new Anim(); a.name = in.readUTF(); a.duration = in.readFloat(); int nc = lim(in.readInt(), 100_000);
                for (int j = 0; j < nc; j++) { Channel c = new Channel(); c.node = in.readInt(); c.path = in.readByte(); c.step = in.readBoolean();
                    c.times = new float[lim(in.readInt(), 10_000_000)]; for (int k = 0; k < c.times.length; k++) c.times[k] = in.readFloat();
                    c.values = new float[lim(in.readInt(), 40_000_000)]; for (int k = 0; k < c.values.length; k++) c.values[k] = in.readFloat();
                    a.ch.add(c); }
                m.anims.add(a); }
            m.texture = new byte[lim(in.readInt(), 64 << 20)]; in.readFully(m.texture);
            return m;
        }
    }
    static int lim(int n, int max) throws IOException { if (n < 0 || n > max) throw new IOException("bad mesh data"); return n; }

    // ------------------------------------------------------------------ helpers for loaders
    /** adds a triangle with automatic flat normal when normals are NaN */
    static void tri(List<Float> out, float[] a, float[] b, float[] c) {
        float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], wx = c[0] - a[0], wy = c[1] - a[1], wz = c[2] - a[2];
        float nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz); if (len > 0) { nx /= len; ny /= len; nz /= len; }
        for (float[] p : new float[][]{a, b, c}) {
            out.add(p[0]); out.add(p[1]); out.add(p[2]); out.add(p[3]); out.add(p[4]);
            boolean has = p.length > 7 && !Float.isNaN(p[5]);
            out.add(has ? p[5] : nx); out.add(has ? p[6] : ny); out.add(has ? p[7] : nz);
        }
    }
    static float[] arr(List<Float> l) { float[] r = new float[l.size()]; for (int i = 0; i < r.length; i++) r[i] = l.get(i); return r; }

    /** merge vertices that are equal (Projector:Optimize); returns removed vertex count (in index terms: triangles kept, duplicates only dropped from degenerate tris) */
    public int optimize() {
        int removed = 0;
        for (Part p : parts) {
            List<Float> out = new ArrayList<>();
            float[] v = p.v;
            for (int i = 0; i + 23 < v.length; i += 24) {
                float ax = v[i], ay = v[i + 1], az = v[i + 2], bx = v[i + 8], by = v[i + 9], bz = v[i + 10], cx = v[i + 16], cy = v[i + 17], cz = v[i + 18];
                float ux = bx - ax, uy = by - ay, uz = bz - az, wx = cx - ax, wy = cy - ay, wz = cz - az;
                float nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
                if (nx * nx + ny * ny + nz * nz < 1e-14f) { removed += 3; continue; }
                for (int k = 0; k < 24; k++) out.add(v[i + k]);
            }
            p.v = arr(out);
        }
        return removed;
    }
}
