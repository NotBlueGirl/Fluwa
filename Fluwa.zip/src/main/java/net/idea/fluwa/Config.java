package net.idea.fluwa;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;

import java.util.ArrayList;
import java.util.List;

/** config/fluwa-common.toml */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    private static final ForgeConfigSpec.IntValue TIMEOUT = B.comment("Max milliseconds a script may run without yielding (wait()) before it is stopped")
            .defineInRange("scriptTimeoutMs", 3000, 50, 600000);
    private static final ForgeConfigSpec.BooleanValue FULL_OS = B.comment("getAccess(\"OS\") also exposes os.getenv/os.tmpname and allows World:Copy(path). Keep false on public servers!")
            .define("fullOsAccess", false);
    private static final ForgeConfigSpec.IntValue CREATOR_LEVEL = B.comment("Permission level treated as Creator (can open ZSpace with F8 and edit scripts)")
            .defineInRange("creatorPermissionLevel", 2, 0, 4);
    private static final ForgeConfigSpec.ConfigValue<List<? extends String>> CO_CREATORS = B.comment("Player names that are Co-Creators (can use ZSpace without OP)")
            .defineListAllowEmpty("coCreators", List.of(), o -> o instanceof String);
    private static final ForgeConfigSpec.IntValue MAX_VOLUME = B.comment("Max blocks a single SetBox/SetSphere/GetBox/... call may touch")
            .defineInRange("maxBlocksPerCall", 1_000_000, 1000, 50_000_000);
    private static final ForgeConfigSpec.BooleanValue EXAMPLES = B.comment("Create example scripts in new worlds")
            .define("createExampleScripts", true);

    private static final ForgeConfigSpec.BooleanValue HTTP = B.comment("Chromium: allow scripts to make HTTP(S) requests (like Roblox HttpEnabled)")
            .define("httpEnabled", false);
    private static final ForgeConfigSpec.ConfigValue<List<? extends String>> HTTP_DOMAINS = B.comment("Chromium: if not empty, only these domains (and their subdomains) may be requested")
            .defineListAllowEmpty("httpAllowedDomains", List.of(), o -> o instanceof String);
    private static final ForgeConfigSpec.BooleanValue HTTP_LOCAL = B.comment("Chromium: allow requests to localhost / LAN addresses")
            .define("httpAllowLocal", false);
    private static final ForgeConfigSpec.ConfigValue<String> LUART = B.comment("LuaRT (Windows): path to luart.exe; empty = search PATH. Needs fullOsAccess=true")
            .define("luartPath", "");
    private static final ForgeConfigSpec.ConfigValue<String> FASM = B.comment("FASM: path to fasm / fasm.exe; empty = search PATH. Needs fullOsAccess=true")
            .define("fasmPath", "");

    private static final ForgeConfigSpec.BooleanValue NET = B.comment("NET: allow scripts to open TCP/UDP/WebSocket sockets and servers (getAccess(\"NET\")). Keep false on public servers!")
            .define("netEnabled", false);
    private static final ForgeConfigSpec.IntValue NET_MAX = B.comment("NET: max simultaneously open sockets / servers per runtime")
            .defineInRange("netMaxSockets", 32, 1, 1024);
    private static final ForgeConfigSpec.BooleanValue MCEF = B.comment("Chromium: use the MCEF mod (real Chromium) for Browser objects when it is installed")
            .define("useMcef", true);

    private static final ForgeConfigSpec.BooleanValue ASYNC_EVENTS = B.comment("Event handlers run in their own Lua thread (like Roblox), so wait() works inside events. false = old synchronous handlers")
            .define("asyncEventHandlers", true);
    private static final ForgeConfigSpec.BooleanValue FORGE_UNLOCKED = B.comment("Forge module: deep reflection - scripts may read/write/call private, protected and final members of any Java class",
                    "(Forge:GetClass / Forge:Java / event:Call on non-public members). Mod Creator mode: gives scripts full JVM access! Set false on public servers.")
            .define("forgeUnlocked", true);

    private static final ForgeConfigSpec.BooleanValue MENU_GUI_MAKER = B.comment("Main menu (no world): F8 opens GUI Maker (designs are saved to .minecraft/fluwa/guis)")
            .define("mainMenuGuiMaker", true);

    static final ForgeConfigSpec SPEC = B.build();
    public static boolean mainMenuGuiMaker = true;

    public static boolean asyncEventHandlers = true;
    public static boolean forgeUnlocked = true;

    public static boolean netEnabled = false;
    public static int netMaxSockets = 32;
    public static boolean useMcef = true;

    public static boolean httpEnabled = false;
    public static List<String> httpAllowedDomains = new ArrayList<>();
    public static boolean httpAllowLocal = false;
    public static String luartPath = "";
    public static String fasmPath = "";

    public static int scriptTimeoutMs = 3000;
    public static boolean fullOsAccess = false;
    public static int creatorPermissionLevel = 2;
    public static List<String> coCreators = new ArrayList<>();
    public static int maxBlocksPerCall = 1_000_000;
    public static boolean createExampleScripts = true;

    @SubscribeEvent
    static void onLoad(final ModConfigEvent event) {
        if (event.getConfig().getSpec() != SPEC) return;
        scriptTimeoutMs = TIMEOUT.get();
        netEnabled = NET.get(); netMaxSockets = NET_MAX.get(); useMcef = MCEF.get();
        fullOsAccess = FULL_OS.get();
        creatorPermissionLevel = CREATOR_LEVEL.get();
        coCreators = new ArrayList<>(CO_CREATORS.get());
        maxBlocksPerCall = MAX_VOLUME.get();
        createExampleScripts = EXAMPLES.get();
        httpEnabled = HTTP.get();
        httpAllowedDomains = new ArrayList<>(HTTP_DOMAINS.get());
        httpAllowLocal = HTTP_LOCAL.get();
        luartPath = LUART.get();
        fasmPath = FASM.get();
        asyncEventHandlers = ASYNC_EVENTS.get();
        forgeUnlocked = FORGE_UNLOCKED.get();
        mainMenuGuiMaker = MENU_GUI_MAKER.get();
    }
}
