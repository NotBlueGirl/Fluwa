package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

/** CFrame: position + 3x3 rotation matrix (row-major), Roblox conventions (LookVector = -Z column). */
public final class CFrameL extends LObj {
    public final double x, y, z;
    public final double[] r; // r00 r01 r02 r10 r11 r12 r20 r21 r22
    static final LuaTable MT = new LuaTable();
    static final double[] ID = {1, 0, 0, 0, 1, 0, 0, 0, 1};

    public CFrameL(double x, double y, double z, double[] r) {
        super("CFrame");
        this.x = x; this.y = y; this.z = z; this.r = r;
        setmetatable(MT);
    }
    public CFrameL(double x, double y, double z) { this(x, y, z, ID); }

    public Vec3L pos() { return new Vec3L(x, y, z); }
    public Vec3L right() { return new Vec3L(r[0], r[3], r[6]); }
    public Vec3L up() { return new Vec3L(r[1], r[4], r[7]); }
    public Vec3L look() { return new Vec3L(-r[2], -r[5], -r[8]); }

    public static CFrameL lookAt(Vec3L at, Vec3L target) {
        Vec3L f = target.sub(at).unit();
        if (f.mag() == 0) return new CFrameL(at.x, at.y, at.z);
        Vec3L upW = Math.abs(f.y) > 0.9999 ? new Vec3L(0, 0, f.y > 0 ? 1 : -1) : new Vec3L(0, 1, 0);
        Vec3L rt = f.cross(upW).unit();
        Vec3L u = rt.cross(f).unit();
        return new CFrameL(at.x, at.y, at.z, new double[]{rt.x, u.x, -f.x, rt.y, u.y, -f.y, rt.z, u.z, -f.z});
    }

    /** Minecraft yaw/pitch (degrees) -> CFrame */
    public static CFrameL fromYawPitch(Vec3L p, float yaw, float pitch) {
        double ry = Math.toRadians(yaw), rp = Math.toRadians(pitch);
        Vec3L f = new Vec3L(-Math.sin(ry) * Math.cos(rp), -Math.sin(rp), Math.cos(ry) * Math.cos(rp));
        return lookAt(p, p.add(f));
    }
    public float mcYaw() { Vec3L l = look(); return (float) Math.toDegrees(Math.atan2(-l.x, l.z)); }
    public float mcPitch() { Vec3L l = look(); return (float) Math.toDegrees(Math.asin(Math.max(-1, Math.min(1, -l.y)))); }

    static double[] mm(double[] a, double[] b) {
        double[] o = new double[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
            o[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j];
        return o;
    }
    static double[] tr(double[] a) { return new double[]{a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8]}; }
    Vec3L rot(Vec3L v) { return new Vec3L(r[0] * v.x + r[1] * v.y + r[2] * v.z, r[3] * v.x + r[4] * v.y + r[5] * v.z, r[6] * v.x + r[7] * v.y + r[8] * v.z); }
    public Vec3L point(Vec3L v) { return rot(v).add(pos()); }
    public CFrameL times(CFrameL o) { Vec3L p = point(o.pos()); return new CFrameL(p.x, p.y, p.z, mm(r, o.r)); }
    public CFrameL inverse() {
        double[] t = tr(r);
        CFrameL rotOnly = new CFrameL(0, 0, 0, t);
        Vec3L p = rotOnly.rot(pos()).scale(-1);
        return new CFrameL(p.x, p.y, p.z, t);
    }

    public static double[] angles(double ax, double ay, double az) {
        double cx = Math.cos(ax), sx = Math.sin(ax), cy = Math.cos(ay), sy = Math.sin(ay), cz = Math.cos(az), sz = Math.sin(az);
        double[] rx = {1, 0, 0, 0, cx, -sx, 0, sx, cx};
        double[] ry = {cy, 0, sy, 0, 1, 0, -sy, 0, cy};
        double[] rz = {cz, -sz, 0, sz, cz, 0, 0, 0, 1};
        return mm(mm(rx, ry), rz);
    }

    public static CFrameL check(LuaValue v) {
        if (v instanceof CFrameL c) return c;
        Vec3L p = Vec3L.check(v);
        return new CFrameL(p.x, p.y, p.z);
    }

    @Override protected boolean threadSafe() { return true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Position": case "p": return pos();
            case "X": return valueOf(x);
            case "Y": return valueOf(y);
            case "Z": return valueOf(z);
            case "LookVector": case "lookVector": return look();
            case "RightVector": return right();
            case "UpVector": return up();
            case "Rotation": return new CFrameL(0, 0, 0, r);
        }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) { throw new LuaError("CFrame is immutable"); }
    @Override public String tojstring() {
        StringBuilder sb = new StringBuilder(Vec3L.fmt(x) + ", " + Vec3L.fmt(y) + ", " + Vec3L.fmt(z));
        for (double d : r) sb.append(", ").append(Vec3L.fmt(Math.round(d * 1e6) / 1e6));
        return sb.toString();
    }
    @Override public boolean eq_b(LuaValue v) { return v instanceof CFrameL o && o.x == x && o.y == y && o.z == z && java.util.Arrays.equals(o.r, r); }
    @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }
    @Override public LuaValue cloneObj() { return new CFrameL(x, y, z, r.clone()); }

    static {
        MT.set("__mul", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) {
            CFrameL c = (CFrameL) a;
            if (b instanceof CFrameL o) return c.times(o);
            return c.point(Vec3L.check(b));
        } });
        MT.set("__add", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) {
            CFrameL c = (CFrameL) a; Vec3L v = Vec3L.check(b); return new CFrameL(c.x + v.x, c.y + v.y, c.z + v.z, c.r); } });
        MT.set("__sub", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) {
            CFrameL c = (CFrameL) a; Vec3L v = Vec3L.check(b); return new CFrameL(c.x - v.x, c.y - v.y, c.z - v.z, c.r); } });
        MT.set("__eq", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return valueOf(a.eq_b(b)); } });
        MT.set("__tostring", new OneArgFunction() { public LuaValue call(LuaValue a) { return valueOf(a.tojstring()); } });
        reg(CFrameL.class, "Inverse", (s, a) -> ((CFrameL) s).inverse());
        reg(CFrameL.class, "ToWorldSpace", (s, a) -> ((CFrameL) s).times(check(a.arg1())));
        reg(CFrameL.class, "ToObjectSpace", (s, a) -> ((CFrameL) s).inverse().times(check(a.arg1())));
        reg(CFrameL.class, "PointToWorldSpace", (s, a) -> ((CFrameL) s).point(Vec3L.check(a.arg1())));
        reg(CFrameL.class, "PointToObjectSpace", (s, a) -> ((CFrameL) s).inverse().point(Vec3L.check(a.arg1())));
        reg(CFrameL.class, "Lerp", (s, a) -> {
            CFrameL c = (CFrameL) s, o = check(a.arg1()); double t = a.checkdouble(2);
            Vec3L p = c.pos().add(o.pos().sub(c.pos()).scale(t));
            return new CFrameL(p.x, p.y, p.z, t < 0.5 ? c.r : o.r);
        });
        reg(CFrameL.class, "GetComponents", (s, a) -> {
            CFrameL c = (CFrameL) s; LuaValue[] v = new LuaValue[12];
            v[0] = valueOf(c.x); v[1] = valueOf(c.y); v[2] = valueOf(c.z);
            for (int i = 0; i < 9; i++) v[3 + i] = valueOf(c.r[i]);
            return varargsOf(v);
        });
        reg(CFrameL.class, "ToEulerAnglesXYZ", (s, a) -> {
            double[] m = ((CFrameL) s).r;
            double ry = Math.asin(Math.max(-1, Math.min(1, m[2])));
            double rx = Math.atan2(-m[5], m[8]), rz = Math.atan2(-m[1], m[0]);
            return varargsOf(valueOf(rx), valueOf(ry), valueOf(rz));
        });
    }

    public static LuaTable lib() {
        LuaTable t = new LuaTable();
        t.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            if (a.arg1().istable() && !(a.arg1() instanceof LObj) && a.narg() > 0 && a.arg1().get("new").isfunction()) a = a.subargs(2);
            if (a.narg() == 0) return new CFrameL(0, 0, 0);
            if (a.arg1().isnumber()) {
                if (a.narg() >= 12) { double[] r = new double[9]; for (int i = 0; i < 9; i++) r[i] = a.checkdouble(4 + i);
                    return new CFrameL(a.checkdouble(1), a.checkdouble(2), a.checkdouble(3), r); }
                return new CFrameL(a.checkdouble(1), a.optdouble(2, 0), a.optdouble(3, 0));
            }
            Vec3L p = Vec3L.check(a.arg1());
            if (!a.isnil(2)) return lookAt(p, Vec3L.check(a.arg(2)));
            return new CFrameL(p.x, p.y, p.z);
        } });
        VarArgFunction ang = new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            return new CFrameL(0, 0, 0, angles(a.optdouble(1 + o, 0), a.optdouble(2 + o, 0), a.optdouble(3 + o, 0))); } };
        t.set("Angles", ang);
        t.set("fromEulerAnglesXYZ", ang);
        t.set("lookAt", new VarArgFunction() { public Varargs invoke(Varargs a) { return lookAt(Vec3L.check(a.arg1()), Vec3L.check(a.arg(2))); } });
        t.set("identity", new CFrameL(0, 0, 0));
        return t;
    }
}
