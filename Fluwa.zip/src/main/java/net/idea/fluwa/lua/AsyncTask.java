package net.idea.fluwa.lua;

import org.luaj.vm2.*;

import java.util.concurrent.*;

/**
 * Background job (HTTP request, external process...). Scripts poll task.Done or call task:Await(),
 * which wait()s until the job finishes, so the game never freezes and the script timeout is not hit.
 */
public final class AsyncTask extends LObj {
    static final ExecutorService POOL = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "Fluwa-Async"); t.setDaemon(true); return t; });

    private volatile boolean done, ok;
    private volatile LuaValue result = NIL;
    private volatile String error;

    private AsyncTask(String n) { super("AsyncTask"); name = n; }

    public static AsyncTask run(String name, Callable<LuaValue> job) {
        AsyncTask t = new AsyncTask(name);
        POOL.submit(() -> {
            try { LuaValue r = job.call(); t.result = r == null ? NIL : r; t.ok = true; }
            catch (Throwable e) { t.error = e.getMessage() == null ? e.toString() : e.getMessage(); }
            t.done = true;
        });
        return t;
    }

    /** Run a job and wait for it inside the calling script (yields with wait()). */
    public static LuaValue await(String name, Callable<LuaValue> job) { return run(name, job).await(); }

    public LuaValue await() {
        FluwaRuntime r = FluwaRuntime.current() != null ? FluwaRuntime.current() : rt;
        LuaValue w = r == null ? NIL : r.waitFn;
        if (w == null || w.isnil()) throw new LuaError(name + ": wait() is not available");
        while (!done) w.call(valueOf(0));
        if (!ok) throw new LuaError(name + ": " + error);
        return result;
    }

    @Override protected boolean threadSafe() { return true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Done": return valueOf(done);
            case "Ok": case "Success": return valueOf(done && ok);
            case "Result": return result;
            case "Error": return error == null ? NIL : valueOf(error);
        }
        return super.getProp(k);
    }

    static {
        reg(AsyncTask.class, "Await|Wait", (s, a) -> ((AsyncTask) s).await());
    }
}
