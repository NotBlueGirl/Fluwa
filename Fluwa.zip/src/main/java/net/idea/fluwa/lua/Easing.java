package net.idea.fluwa.lua;

import org.luaj.vm2.LuaValue;

/** Roblox easing styles / directions shared by GUI tweens and world tweens (Blocks, Entities, Chunks, Structures). */
public final class Easing {
    private Easing() {}

    /** "Enum.EasingStyle.Quad" / "Quad" -> "Quad" */
    public static String name(LuaValue v, String def) {
        if (v == null || v.isnil()) return def;
        return v.tojstring().replaceFirst("^Enum\\.[A-Za-z]+\\.", "");
    }

    public static double in(double t, String s) {
        return switch (s) {
            case "Linear" -> t;
            case "Sine" -> 1 - Math.cos(t * Math.PI / 2);
            case "Back" -> 2.70158 * t * t * t - 1.70158 * t * t;
            case "Quart" -> t * t * t * t;
            case "Quint" -> t * t * t * t * t;
            case "Cubic" -> t * t * t;
            case "Exponential" -> t == 0 ? 0 : Math.pow(2, 10 * t - 10);
            case "Circular" -> 1 - Math.sqrt(Math.max(0, 1 - t * t));
            case "Elastic" -> t == 0 || t == 1 ? t : -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * (2 * Math.PI) / 3);
            case "Bounce" -> 1 - bounce(1 - t);
            default -> t * t; // Quad
        };
    }

    static double bounce(double t) {
        double n = 7.5625, d = 2.75;
        if (t < 1 / d) return n * t * t;
        if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
        if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
        return n * (t -= 2.625 / d) * t + 0.984375;
    }

    /** t in 0..1 -> eased value (Out is the Roblox default direction) */
    public static double ease(double t, String dir, String style) {
        return switch (dir) {
            case "In" -> in(t, style);
            case "InOut" -> t < 0.5 ? in(t * 2, style) / 2 : 1 - in((1 - t) * 2, style) / 2;
            default -> 1 - in(1 - t, style); // Out
        };
    }
}
