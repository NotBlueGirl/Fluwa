package net.idea.fluwa.lua;

import com.mojang.logging.LogUtils;
import net.idea.fluwa.Config;
import org.luaj.vm2.*;
import org.luaj.vm2.compiler.LuaC;
import org.luaj.vm2.lib.*;
import org.luaj.vm2.lib.jse.*;
import org.slf4j.Logger;

import java.util.*;
import java.util.function.Supplier;

/**
 * One isolated Lua VM (server side or client side). Owns globals, the coroutine scheduler,
 * module cache (CAR), services (getAccess) and the Instance factory.
 */
public abstract class FluwaRuntime {
    public static final Logger LOG = LogUtils.getLogger();
    private static final InheritableThreadLocal<FluwaRuntime> CUR = new InheritableThreadLocal<>();
    public static FluwaRuntime current() { return CUR.get(); }

    public final Globals g;
    public final boolean server;
    protected final LuaTable osLib;
    private final LuaValue WAIT = LuaValue.userdataOf(new Object());
    private final Map<LuaThread, Long> managed = Collections.synchronizedMap(new WeakHashMap<>());
    private final List<Task> tasks = new ArrayList<>();
    private final Map<String, LuaValue> modules = new HashMap<>();
    private final Set<String> loading = new HashSet<>();
    private final Set<Signal> trackedSignals = Collections.newSetFromMap(new WeakHashMap<>());
    protected final Map<String, Supplier<LObj>> factory = new HashMap<>();
    protected final Map<String, Supplier<LuaValue>> services = new LinkedHashMap<>();
    private final Map<String, LuaValue> serviceCache = new HashMap<>();
    public final Map<String, RemoteEvent> remotes = new HashMap<>();
    public long tick;
    /** original wait() from the prelude (for AsyncTask:Await) */
    public LuaValue waitFn;
    /** prelude internals for event handler threads */
    private LuaValue newRunner, IDLE = LuaValue.NIL;
    /** Event:Wait() implementation (Lua) */
    public LuaValue sigWaitFn;
    private final ArrayDeque<LuaThread> runnerPool = new ArrayDeque<>();
    private static final int RUNNER_POOL = 32;
    public Thread mainThread;
    private final java.util.concurrent.LinkedBlockingQueue<Runnable> mainQueue = new java.util.concurrent.LinkedBlockingQueue<>();
    private static final java.util.concurrent.ExecutorService HELPER = java.util.concurrent.Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "Fluwa-resume"); t.setDaemon(true); return t; });
    private volatile long sliceStart;
    private int depth;
    public boolean closed;

    record Task(LuaThread co, long due, Varargs args) {}

    protected FluwaRuntime(boolean server) {
        this.server = server;
        FluwaRuntime prev = CUR.get();
        CUR.set(this);
        try {
            g = new Globals();
            g.load(new JseBaseLib());
            g.load(new PackageLib());
            g.load(new Bit32Lib());
            g.load(new TableLib());
            g.load(new StringLib());
            g.load(new CoroutineLib());
            g.load(new JseMathLib());
            g.load(new JseOsLib());
            g.load(new DebugLib());
            LoadState.install(g);
            LuaC.install(g);
            // ---- sandbox: OS locked until getAccess("OS"); no files, no require (CAR instead)
            LuaTable fullOs = (LuaTable) g.get("os");
            osLib = new LuaTable();
            for (String k : new String[]{"time", "clock", "date", "difftime"}) osLib.set(k, fullOs.get(k));
            if (Config.fullOsAccess) for (String k : new String[]{"getenv", "tmpname"}) osLib.set(k, fullOs.get(k));
            for (String k : new String[]{"os", "io", "luajava", "dofile", "loadfile", "require", "package", "module"}) g.set(k, LuaValue.NIL);
            installCore();
        } finally { CUR.set(prev); }
    }

    /** Must be called once after construction (subclass fields are ready by then). */
    public FluwaRuntime init() {
        mainThread = Thread.currentThread();
        FluwaRuntime prev = CUR.get();
        CUR.set(this);
        try { setupGlobals(); runPrelude(); } finally { CUR.set(prev); }
        return this;
    }

    // ================================================================ abstract side hooks
    protected abstract void setupGlobals();
    /** Output from print()/errors. level: 0 info, 1 warn, 2 error */
    public abstract void output(int level, String msg);
    /** Find source of a script/module by name (CAR) or null */
    protected abstract String findModule(String name);

    // ================================================================ core globals
    private void installCore() {
        g.set("Vector3", Vec3L.lib());
        g.set("Vec3", g.get("Vector3"));
        g.set("CFrame", CFrameL.lib());
        g.set("UDim2", UDim2L.lib());
        g.set("Color", ColorL.lib());
        g.set("Color3", SeqL.color3Lib());
        g.set("Vector2", Vec2L.lib());
        g.set("UDim", UDimL.lib());
        g.set("ColorSequence", SeqL.lib(true));
        g.set("NumberSequence", SeqL.lib(false));
        g.set("Enum", SeqL.enumLib());
        g.set("print", new VarArgFunction() { public Varargs invoke(Varargs a) { output(0, join(a)); return NONE; } });
        g.set("warn", new VarArgFunction() { public Varargs invoke(Varargs a) { output(1, join(a)); return NONE; } });
        g.set("tick", new ZeroArgFunction() { public LuaValue call() { return valueOf(System.currentTimeMillis() / 1000.0); } });
        g.set("__fluwa_clock", new ZeroArgFunction() { public LuaValue call() { return valueOf(tick / 20.0); } });
        g.set("__fluwa_wait", WAIT);
        g.set("__fluwa_hook", new VarArgFunction() { public Varargs invoke(Varargs a) {
            if (depth > 0 && System.currentTimeMillis() - sliceStart > Config.scriptTimeoutMs)
                throw new LuaError("Script timeout: exceeded " + Config.scriptTimeoutMs + " ms without yielding (use wait())");
            if (closed) throw new LuaError("Runtime stopped");
            return NONE; } });
        g.set("__fluwa_resume", new VarArgFunction() { public Varargs invoke(Varargs a) {
            return pumpResume((LuaThread) a.checkthread(1), a.subargs(2)); } });
        // a managed coroutine always runs on its own Java thread; on the game thread we are inside a synchronous callback
        // (ConnectSync handler, marshalled call...) where yielding would dead-lock the server
        g.set("__fluwa_managed", new OneArgFunction() { public LuaValue call(LuaValue c) {
            return valueOf(managed.containsKey(c) && (mainThread == null || Thread.currentThread() != mainThread)); } });
        g.set("__fluwa_schedule", new VarArgFunction() { public Varargs invoke(Varargs a) {
            LuaThread co = (LuaThread) a.checkthread(1);
            schedule(co, a.checkdouble(2), a.subargs(3));
            return NONE; } });
        // CAR - Check And Require: loads modules; errors are reported as warnings and the module is skipped (nil)
        g.set("CAR", new VarArgFunction() { public Varargs invoke(Varargs a) {
            LuaValue[] out = new LuaValue[a.narg()];
            for (int i = 1; i <= a.narg(); i++) out[i - 1] = car(a.checkjstring(i));
            return varargsOf(out); } });
        // getAccess - like game:GetService
        VarArgFunction ga = new VarArgFunction() { public Varargs invoke(Varargs a) {
            String n = (a.arg1().isstring() ? a.arg1() : a.arg(2)).checkjstring();
            return getService(n); } };
        g.set("getAccess", ga);
        g.set("GetAccess", ga);
        // Instance
        LuaTable inst = new LuaTable();
        inst.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            if (a.arg1().istable() && !(a.arg1() instanceof LObj)) a = a.subargs(2); // Instance:new(...)
            String type = a.checkjstring(1);
            Supplier<LObj> f = factory.get(type);
            if (f == null) throw new LuaError("Unable to create an Instance of type \"" + type + "\" on the " + (server ? "server" : "client"));
            LObj o = f.get();
            if (!a.isnil(2)) o.setParent(LObj.checkObj(a.arg(2), LObj.class));
            return o; } });
        g.set("Instance", inst);
        // Events: virtual folder with every network Event by Name
        g.set("Events", new LObj("Events") {
            @Override public java.util.List<LObj> listChildren() { return new ArrayList<>(remotes.values()); }
            @Override public void setName(String n) { throw new LuaError("Events.Name is read-only"); }
        });
        // values / events available on both sides
        factory.put("Folder", () -> new LObj("Folder"));
        factory.put("IntValue", () -> new ValueObj("IntValue", LuaValue.valueOf(0)));
        factory.put("NumberValue", () -> new ValueObj("NumberValue", LuaValue.valueOf(0)));
        factory.put("BoolValue", () -> new ValueObj("BoolValue", LuaValue.FALSE));
        factory.put("StringValue", () -> new ValueObj("StringValue", LuaValue.valueOf("")));
        factory.put("TableValue", () -> new ValueObj("TableValue", new LuaTable()));
        factory.put("StrValue", () -> new ValueObj("StrValue", LuaValue.valueOf("")));
        factory.put("NumValue", () -> new ValueObj("NumValue", LuaValue.valueOf(0)));
        factory.put("ObjValue", () -> new ValueObj("ObjValue", LuaValue.NIL));
        factory.put("ObjectValue", () -> new ValueObj("ObjValue", LuaValue.NIL));
        factory.put("Vector3Value", () -> new ValueObj("Vector3Value", new Vec3L(0, 0, 0)));
        factory.put("Event", () -> new RemoteEvent());
        factory.put("RemoteEvent", () -> new RemoteEvent());
        factory.put("BindableEvent", () -> new BindableEvent());
        // v0.5 lighting objects (both sides; server ones replicate to every client)
        for (String fx : net.idea.fluwa.lighting.FxObj.CLASSES) factory.put(fx, () -> net.idea.fluwa.lighting.FxObj.create(fx));
        factory.put("LightPoint", net.idea.fluwa.lighting.LightObj.LightPoint::new);
        factory.put("LightBeam", net.idea.fluwa.lighting.LightObj.LightBeam::new);
        Services.registerCommon(this);
    }

    private void runPrelude() {
        String prelude = """
            local sethook, hook = debug.sethook, __fluwa_hook
            local create, wrap, yield, running = coroutine.create, coroutine.wrap, coroutine.yield, coroutine.running
            local WAIT, managed, clock, schedule, resume = __fluwa_wait, __fluwa_managed, __fluwa_clock, __fluwa_schedule, __fluwa_resume
            local function hooked(f) return function(...) sethook(hook, "", 20000) return f(...) end end
            coroutine.create = function(f) return create(hooked(f)) end
            coroutine.resume = resume
            coroutine.wrap = function(f)
              local c = create(hooked(f))
              return function(...)
                local r = table.pack(resume(c, ...))
                if not r[1] then error(r[2], 2) end
                return table.unpack(r, 2, r.n)
              end
            end
            function wait(s)
              local c, main = running()
              if main or not managed(c) then error("wait() can only be used in a script body, an event handler or inside spawn()/delay() (not inside coroutine.wrap/resume or ConnectSync handlers)", 2) end
              local t0 = clock()
              yield(WAIT, tonumber(s) or 0)
              return clock() - t0
            end
            function spawn(f, ...) local c = coroutine.create(f) schedule(c, 0, ...) return c end
            function delay(s, f, ...) local c = coroutine.create(f) schedule(c, tonumber(s) or 0, ...) return c end
            task = { wait = wait, spawn = spawn, delay = delay }
            -- v0.5.1: event handlers run in their own (pooled) threads, so wait() works inside them
            local IDLE = {}
            local function invoke(f, ...) f(...) end
            local function runner(f, ...)
              invoke(f, ...)
              while true do invoke(yield(IDLE)) end
            end
            local function newRunner() return create(hooked(runner)) end
            local PARK = {}
            local function sigWait(sig)
              local c, main = running()
              if main or not managed(c) then error("Event:Wait() can only be used in a script body, an event handler or inside spawn()/delay()", 2) end
              local conn
              conn = sig:ConnectSync(function(...) conn:Disconnect() schedule(c, 0, ...) end)
              return yield(PARK)
            end
            sethook(hook, "", 20000)
            debug = nil
            __fluwa_hook, __fluwa_wait, __fluwa_managed, __fluwa_schedule, __fluwa_clock, __fluwa_resume = nil, nil, nil, nil, nil, nil
            return newRunner, IDLE, sigWait
            """;
        Varargs pr = g.load(prelude, "=prelude").invoke();
        newRunner = pr.arg1().isfunction() ? pr.arg1() : null;
        IDLE = pr.arg(2);
        sigWaitFn = pr.arg(3).isfunction() ? pr.arg(3) : null;
        waitFn = g.get("wait");
    }

    static String join(Varargs a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= a.narg(); i++) { if (i > 1) sb.append('\t'); sb.append(a.arg(i).tojstring()); }
        return sb.toString();
    }

    // ================================================================ execution
    /** true if the last call(...) ended with an error */
    public boolean lastCallFailed;
    private final Map<String, long[]> errorSeen = new HashMap<>();

    /** Error output with anti-spam: the same error is shown at most once per 5 s (with a repeat counter). */
    public void reportError(String msg) {
        long now = System.currentTimeMillis();
        if (errorSeen.size() > 200) errorSeen.clear();
        long[] st = errorSeen.get(msg);             // {lastShownAt, suppressed}
        if (st != null && now - st[0] < 5000) { st[1]++; return; }
        String extra = st != null && st[1] > 0 ? "  (repeated " + st[1] + " more times)" : "";
        errorSeen.put(msg, new long[]{now, 0});
        output(2, msg + extra);
    }

    public Varargs call(LuaValue fn, Varargs args, String ctx) {
        lastCallFailed = false;
        if (closed) return LuaValue.NONE;
        FluwaRuntime prev = CUR.get();
        CUR.set(this);
        if (depth++ == 0) sliceStart = System.currentTimeMillis();
        try {
            Varargs r = fn.invoke(args);
            lastCallFailed = false;
            return r;
        } catch (LuaError e) {
            lastCallFailed = true;
            reportError("[" + ctx + "] " + e.getMessage());
            return LuaValue.NONE;
        } catch (Exception e) {
            lastCallFailed = true;
            reportError("[" + ctx + "] Internal error: " + e);
            LOG.error("Fluwa internal error", e);
            return LuaValue.NONE;
        } finally { depth--; CUR.set(prev); }
    }

    /**
     * Run an event handler / callback in its own managed Lua thread (like Roblox): it runs synchronously until it
     * finishes or yields, so wait() / task.wait() can be used inside events. Threads are pooled, so handlers that
     * never wait cost about the same as a plain call. Errors before the first yield set lastCallFailed.
     */
    public void callAsync(LuaValue fn, Varargs args, String ctx) {
        lastCallFailed = false;
        if (closed) return;
        if (newRunner == null || !net.idea.fluwa.Config.asyncEventHandlers) { call(fn, args, ctx); return; }
        FluwaRuntime prev = CUR.get();
        CUR.set(this);
        if (depth++ == 0) sliceStart = System.currentTimeMillis();
        try {
            LuaThread co;
            synchronized (runnerPool) { co = runnerPool.poll(); }
            if (co == null) co = (LuaThread) newRunner.call();
            managed.put(co, tick);
            Varargs r = pumpResume(co, LuaValue.varargsOf(fn, args));
            if (!r.arg1().toboolean()) {
                lastCallFailed = true;
                managed.remove(co);
                reportError("[" + ctx + "] " + r.arg(2).tojstring());
            } else afterResume(co, r);
        } catch (LuaError e) {
            lastCallFailed = true;
            reportError("[" + ctx + "] " + e.getMessage());
        } catch (Exception e) {
            lastCallFailed = true;
            reportError("[" + ctx + "] Internal error: " + e);
            LOG.error("Fluwa internal error", e);
        } finally { depth--; CUR.set(prev); }
    }

    /** bookkeeping after a successful resume: wait() -> reschedule, handler finished -> back to the pool */
    private void afterResume(LuaThread co, Varargs r) {
        boolean suspended = "suspended".equals(co.getStatus());
        if (suspended && r.arg(2) == WAIT) schedule(co, r.arg(3).optdouble(0), LuaValue.NONE);
        else if (suspended && r.arg(2) == IDLE) { synchronized (runnerPool) { if (runnerPool.size() < RUNNER_POOL && !closed) runnerPool.push(co); } }
        else if (!suspended) managed.remove(co);
    }

    /** Run without catching (for code that wants the error, e.g. CAR) */
    public <T> T within(Supplier<T> s) {
        FluwaRuntime prev = CUR.get();
        CUR.set(this);
        try { return s.get(); } finally { CUR.set(prev); }
    }

    /** Compile and start a script as a managed coroutine (so wait() works in its body). */
    public boolean runScript(String name, String source) {
        try {
            // v0.5.2: every file gets its own `script` object (script.Parent = its folder in the ZSpace tree)
            ScriptObj so = within(() -> { try { return ScriptObj.forChunk(this, name, source); } catch (RuntimeException e) { return null; } });
            String src = so == null ? source : (source.startsWith("#") ? "local script = ...; --" + source : "local script = ...; " + source);
            LuaValue fn = within(() -> g.load(src, "@" + name));
            LuaThread co = within(() -> (LuaThread) g.get("coroutine").get("create").call(fn));
            schedule(co, 0, so == null ? LuaValue.NONE : so);
            resumeDue(); // start immediately
            return true;
        } catch (LuaError e) {
            output(2, "[" + name + "] " + e.getMessage());
            return false;
        }
    }

    /** true when the calling Lua code runs in a managed coroutine (wait() is allowed) */
    public boolean canWait() {
        if (mainThread != null && Thread.currentThread() == mainThread) return false;
        LuaThread t = g.running;
        return t != null && managed.containsKey(t);
    }

    public void schedule(LuaThread co, double seconds, Varargs args) {
        managed.put(co, tick);
        tasks.add(new Task(co, tick + Math.max(0, Math.round(seconds * 20)), args));
    }

    public void onTick() {
        if (closed) return;
        tick++;
        drainPosted();
        resumeDue();
        if (!tickers.isEmpty()) for (Runnable r : new ArrayList<>(tickers)) {
            try { r.run(); }
            catch (LuaError e) { reportError(e.getMessage()); }
            catch (Exception e) { reportError("Internal error: " + e); LOG.error("Fluwa internal error", e); }
        }
    }
    /** per-tick hooks of services (Projector replication, UI tweens...) run on the game thread */
    public final List<Runnable> tickers = new java.util.concurrent.CopyOnWriteArrayList<>();
    /** per-runtime service state (Projector registry, NET sockets...) */
    public final Map<String, Object> state = new java.util.concurrent.ConcurrentHashMap<>();

    // ---- 0.3: thread-safe "run on next tick" queue (network sockets, browsers, async loaders)
    private final java.util.concurrent.ConcurrentLinkedQueue<Runnable> posted = new java.util.concurrent.ConcurrentLinkedQueue<>();
    /** Queue r to run on the game thread at the next tick (safe from any thread). */
    public void post(Runnable r) { if (!closed) posted.add(r); }
    /** Fire a signal on the next tick (safe from any thread). */
    public void postFire(Signal s, LuaValue... args) { post(() -> s.fire(args)); }
    private void drainPosted() {
        for (int i = 0; i < 5000; i++) {
            Runnable r = posted.poll();
            if (r == null) break;
            FluwaRuntime prev = CUR.get();
            CUR.set(this);
            try { r.run(); }
            catch (LuaError e) { reportError(e.getMessage()); }
            catch (Exception e) { reportError("Internal error: " + e); LOG.error("Fluwa internal error", e); }
            finally { CUR.set(prev); }
        }
    }
    /** close hooks (sockets, browsers...) */
    private final List<Runnable> closeHooks = new ArrayList<>();
    public void onClose(Runnable r) { synchronized (closeHooks) { closeHooks.add(r); } }

    private void resumeDue() {
        if (tasks.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        tasks.removeIf(t -> { if (t.due <= tick) { due.add(t); return true; } return false; });
        for (Task t : due) resume(t);
    }

    private void resume(Task t) {
        FluwaRuntime prev = CUR.get();
        CUR.set(this);
        if (depth++ == 0) sliceStart = System.currentTimeMillis();
        try {
            Varargs r = pumpResume(t.co, t.args);
            if (!r.arg1().toboolean()) {
                managed.remove(t.co);
                reportError(r.arg(2).tojstring());
            } else afterResume(t.co, r);
        } catch (Exception e) {
            output(2, "Internal error: " + e);
            LOG.error("Fluwa internal error", e);
        } finally { depth--; CUR.set(prev); }
    }

    // ================================================================ threading
    /** Execute on the main thread (blocking the calling coroutine thread until done). */
    public <T> T onMain(Supplier<T> s) {
        if (mainThread == null || Thread.currentThread() == mainThread) return s.get();
        java.util.concurrent.FutureTask<T> ft = new java.util.concurrent.FutureTask<>(s::get);
        mainQueue.add(ft);
        try { return ft.get(); }
        catch (java.util.concurrent.ExecutionException e) {
            Throwable c = e.getCause();
            if (c instanceof RuntimeException re) throw re;
            if (c instanceof Error er) throw er;
            throw new LuaError(String.valueOf(c));
        } catch (InterruptedException e) { throw new LuaError("interrupted"); }
    }

    /**
     * Resume a coroutine. On the main thread the resume happens on a helper thread while the main thread
     * keeps executing game calls posted by the coroutine (Minecraft needs world access on its own thread).
     */
    public Varargs pumpResume(LuaThread co, Varargs args) {
        if (mainThread == null || Thread.currentThread() != mainThread) return co.resume(args);
        final FluwaRuntime self = this;
        java.util.concurrent.CompletableFuture<Varargs> f = new java.util.concurrent.CompletableFuture<>();
        HELPER.execute(() -> {
            CUR.set(self);
            try { f.complete(co.resume(args)); } catch (Throwable t) { f.completeExceptionally(t); }
            finally { CUR.set(null); mainQueue.add(() -> {}); }
        });
        while (!f.isDone()) {
            try { Runnable r = mainQueue.poll(20, java.util.concurrent.TimeUnit.MILLISECONDS); if (r != null) r.run(); }
            catch (InterruptedException e) { break; }
        }
        try { return f.join(); }
        catch (java.util.concurrent.CompletionException e) {
            if (e.getCause() instanceof RuntimeException re) throw re;
            throw new LuaError(String.valueOf(e.getCause()));
        }
    }

    // ================================================================ CAR / services
    public LuaValue car(String name) {
        String key = name.replace('\\', '/');
        if (modules.containsKey(key)) return modules.get(key);
        if (loading.contains(key)) { output(1, "CAR: cyclic require of '" + name + "' skipped"); return LuaValue.NIL; }
        String src = findModule(key);
        if (src == null) { output(1, "CAR: module '" + name + "' not found - skipped"); return LuaValue.NIL; }
        loading.add(key);
        try {
            LuaValue fn = g.load(src, "@" + key);
            LuaValue res = fn.call();
            if (res.isnil()) res = LuaValue.TRUE;
            modules.put(key, res);
            return res;
        } catch (LuaError e) {
            output(1, "CAR: module '" + name + "' failed and was skipped: " + e.getMessage());
            return LuaValue.NIL;
        } finally { loading.remove(key); }
    }

    public void registerService(String name, Supplier<LuaValue> s) { services.put(name, s); }

    public LuaValue getService(String n) {
        if (serviceCache.containsKey(n)) return serviceCache.get(n);
        Supplier<LuaValue> s = services.get(n);
        if (s == null) throw new LuaError("'" + n + "' is not a valid service. Available: " + String.join(", ", services.keySet()));
        LuaValue v = s.get();
        serviceCache.put(n, v);
        return v;
    }

    public LuaTable osLib() { return osLib; }

    // ================================================================ lifecycle
    void trackSignal(Signal s) { trackedSignals.add(s); }

    public void close() {
        closed = true;
        synchronized (closeHooks) { for (Runnable r : closeHooks) { try { r.run(); } catch (Exception ignored) {} } closeHooks.clear(); }
        posted.clear();
        for (Signal s : new ArrayList<>(trackedSignals)) s.removeRuntime(this);
        tasks.clear();
        managed.clear();
        synchronized (runnerPool) { runnerPool.clear(); }
    }

    public RemoteEvent remote(String name) { return remotes.get(name); }
}
