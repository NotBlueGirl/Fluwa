package net.idea.fluwa.lua;

import com.google.gson.*;
import com.google.gson.stream.JsonReader;
import net.idea.fluwa.Config;
import net.idea.fluwa.lua.WebDom.Node;
import org.luaj.vm2.*;

import java.io.StringReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.regex.*;

/**
 * Chromium Browser object (lite engine): loads http(s) pages (httpEnabled), local pages from fluwa/web, or HTML strings,
 * keeps a small DOM (selectors, text/HTML editing, forms, links, cookies), understands a tiny subset of JavaScript
 * (document/location/console/postMessage expressions) and is rendered by the client inside UI / ScreenGUI / Overlay.
 */
public class Browser extends EvObj {
    static final List<String> EVENTS = List.of("E_LoadStart", "E_Loaded", "E_Navigate", "E_Error", "E_Console", "E_Message", "E_Request",
            "E_Response", "E_Download", "E_Crash", "E_ChildAdded", "E_ChildRemoved", "E_AttributeChanged");
    static final HttpClient HTTP = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(10)).build();

    public final boolean headless;
    public Node dom = WebDom.parse("");
    public String url = "about:blank", title = "", userAgent = "Mozilla/5.0 (Fluwa " + Services.VERSION + "; lite) Chromium-lite";
    public UDim2L size = new UDim2L(0, 800, 0, 600), position = new UDim2L(0, 0, 0, 0);
    public double transparency, zoom = 1, scrollY, scrollX;
    public boolean transparent, visible = true, focused, devTools, loading;
    public Node focusNode;
    public int version;
    /** css rules: selector -> declarations */
    public final List<Map.Entry<String, Map<String, String>>> css = new ArrayList<>();
    final List<String> injectedCss = new ArrayList<>();
    final List<String> history = new ArrayList<>();
    int histIdx = -1;
    long loadToken;
    final Map<String, String[]> cookies = new LinkedHashMap<>(); // name -> {value, domain, path}
    // ---- filled by the client renderer
    public int ax, ay, aw, ah, contentH;
    public long drawnFrame;
    public double fps;
    public final List<Object[]> hits = new ArrayList<>(); // {x1, y1, x2, y2, Node} in content coordinates

    /** client hook: open the HTML source viewer (DevTools) */
    public static java.util.function.BiConsumer<String, String> CLIENT_DEVTOOLS;

    public Browser(boolean headless) { super("Browser"); this.headless = headless; name = headless ? "HeadlessBrowser" : "Browser"; }

    @Override protected Collection<String> eventNames() { return EVENTS; }

    public static boolean mcef() {
        try { Class.forName("com.cinemamod.mcef.MCEF"); return true; } catch (Throwable t) { return false; }
    }

    // ------------------------------------------------------------------ loading
    Path webDir() {
        if (rt != null && rt.server && net.idea.fluwa.server.ScriptManager.root != null) return net.idea.fluwa.server.ScriptManager.root.resolve("web");
        return net.minecraftforge.fml.loading.FMLPaths.GAMEDIR.get().resolve("fluwa").resolve("web");
    }

    public void navigate(String u, boolean push) { request("GET", u, null, null, push); }

    void request(String method, String u, String body, String contentType, boolean push) {
        String target = resolve(u);
        long token = ++loadToken;
        loading = true;
        fire("E_LoadStart", valueOf(target));
        fire("E_Navigate", valueOf(target));
        if (push) { while (history.size() > histIdx + 1) history.remove(history.size() - 1); history.add(target); histIdx = history.size() - 1; }
        if (target.equals("about:blank")) { setPage(target, "", token); return; }
        if (!target.startsWith("http://") && !target.startsWith("https://")) {
            String path = target.startsWith("fluwa://") ? target.substring(8) : target.startsWith("file:") ? target.replaceFirst("^file:/*", "") : target;
            try {
                Path dir = webDir().toAbsolutePath().normalize(), f = dir.resolve(path).normalize();
                if (!f.startsWith(dir)) throw new LuaError("Local pages must stay inside fluwa/web");
                if (Files.isDirectory(f)) f = f.resolve("index.html");
                setPage("fluwa://" + dir.relativize(f).toString().replace('\\', '/'), Files.readString(f), token);
            } catch (Exception e) { loading = false; fire("E_Error", valueOf(404), valueOf("Can't open " + path + ": " + e.getMessage())); }
            return;
        }
        URI uri = Chromium.check(target);
        LuaTable hdr = new LuaTable();
        hdr.set("User-Agent", userAgent);
        String ck = cookieHeader(uri);
        if (!ck.isEmpty()) hdr.set("Cookie", ck);
        fire("E_Request", valueOf(method), valueOf(target), hdr);
        String ua = userAgent;
        AsyncTask.run("Browser " + target, () -> {
            try {
                Chromium.checkAddress(uri);
                HttpRequest.Builder b = HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(20))
                        .method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body));
                b.header("User-Agent", ua);
                if (!ck.isEmpty()) b.header("Cookie", ck);
                if (contentType != null) b.header("Content-Type", contentType);
                HttpResponse<byte[]> res = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
                String ctype = res.headers().firstValue("content-type").orElse("text/html");
                List<String> setCookies = res.headers().allValues("set-cookie");
                byte[] data = res.body();
                String finalUrl = res.uri().toString();
                rt.post(() -> {
                    if (token != loadToken) return;
                    for (String c : setCookies) parseSetCookie(c, res.uri());
                    fire("E_Response", valueOf(res.statusCode()), valueOf(finalUrl));
                    if (res.statusCode() >= 400) fire("E_Error", valueOf(res.statusCode()), valueOf("HTTP " + res.statusCode()));
                    if (!ctype.contains("html") && !ctype.startsWith("text/") && !ctype.contains("json") && !ctype.contains("xml")) { download(finalUrl, data); return; }
                    String html = new String(data, StandardCharsets.UTF_8);
                    if (!ctype.contains("html")) html = "<pre>" + WebDom.esc(html) + "</pre>";
                    setPage(finalUrl, html, token);
                });
            } catch (Exception e) {
                rt.post(() -> { if (token == loadToken) { loading = false; fire("E_Error", valueOf(0), valueOf(String.valueOf(e.getMessage()))); } });
            }
            return NIL;
        });
    }

    void download(String u, byte[] data) {
        loading = false;
        try {
            String fn = u.replaceAll("[?#].*$", "").replaceAll("^.*/", "");
            if (fn.isBlank()) fn = "download.bin";
            fn = fn.replaceAll("[\\\\/:*?\"<>|]", "_");
            Path dir = webDir().getParent().resolve("downloads");
            Files.createDirectories(dir);
            Path f = dir.resolve(fn);
            Files.write(f, data);
            fire("E_Download", valueOf(f.toString()));
        } catch (Exception e) { fire("E_Error", valueOf(0), valueOf("Download failed: " + e.getMessage())); }
    }

    public void loadHTML(String html) { loadToken++; setPage("about:html", html, loadToken); }

    void setPage(String u, String html, long token) {
        url = u;
        dom = WebDom.parse(html);
        Node t = dom.find("title");
        title = t == null ? "" : t.text.trim();
        scrollY = 0; focusNode = null;
        rebuildCss();
        version++;
        loading = false;
        // inline scripts through the lite JS interpreter
        List<Node> scripts = WebDom.select(dom, "script", 100);
        for (Node s : scripts) if (s.attr("src").isEmpty() && !s.text.isBlank()) runScript(s.text);
        fire("E_Loaded", valueOf(url));
    }

    void rebuildCss() {
        css.clear();
        List<String> sheets = new ArrayList<>();
        for (Node s : WebDom.select(dom, "style", 50)) sheets.add(s.text);
        sheets.addAll(injectedCss);
        Pattern rule = Pattern.compile("([^{}]+)\\{([^}]*)\\}");
        for (String sh : sheets) {
            Matcher m = rule.matcher(sh.replaceAll("(?s)/\\*.*?\\*/", ""));
            while (m.find()) {
                Map<String, String> decl = new LinkedHashMap<>();
                for (String d : m.group(2).split(";")) { int i = d.indexOf(':'); if (i > 0) decl.put(d.substring(0, i).trim().toLowerCase(Locale.ROOT), d.substring(i + 1).trim()); }
                String sel = m.group(1).trim();
                if (!sel.startsWith("@")) css.add(Map.entry(sel, decl));
            }
        }
    }

    /** computed style (css rules + inline style) */
    public Map<String, String> style(Node n) {
        Map<String, String> m = new HashMap<>();
        for (var r : css) { try { if (WebDom.matches(n, r.getKey())) m.putAll(r.getValue()); } catch (Exception ignored) {} }
        m.putAll(n.style());
        return m;
    }

    String resolve(String u) {
        u = u.trim();
        if (u.isEmpty() || u.equals("about:blank")) return "about:blank";
        if (u.matches("(?i)^(https?|fluwa|file|about):.*")) return u;
        if (u.startsWith("//")) return "https:" + u;
        if (url.startsWith("http")) { try { return URI.create(url).resolve(u).toString(); } catch (Exception ignored) {} }
        if (url.startsWith("fluwa://") && !u.startsWith("/")) { String base = url.substring(8); int i = base.lastIndexOf('/'); return "fluwa://" + (i < 0 ? "" : base.substring(0, i + 1)) + u; }
        if (u.matches("^[\\w.-]+\\.(com|org|net|ru|io|dev|gg|me|info)(/.*)?$")) return "https://" + u;
        return "fluwa://" + u.replaceFirst("^/", "");
    }

    // ------------------------------------------------------------------ cookies
    String cookieHeader(URI u) {
        StringBuilder b = new StringBuilder();
        cookies.forEach((k, v) -> {
            if (!v[1].isEmpty() && !(u.getHost().equals(v[1]) || u.getHost().endsWith("." + v[1].replaceFirst("^\\.", "")))) return;
            if (!v[2].isEmpty() && !(u.getPath() == null ? "/" : u.getPath()).startsWith(v[2])) return;
            if (b.length() > 0) b.append("; ");
            b.append(k).append('=').append(v[0]);
        });
        return b.toString();
    }
    void parseSetCookie(String h, URI u) {
        String[] parts = h.split(";");
        int i = parts[0].indexOf('=');
        if (i <= 0) return;
        String domain = u.getHost(), path = "/";
        for (int k = 1; k < parts.length; k++) {
            String p = parts[k].trim(); int j = p.indexOf('=');
            if (j > 0 && p.substring(0, j).equalsIgnoreCase("domain")) domain = p.substring(j + 1).replaceFirst("^\\.", "");
            if (j > 0 && p.substring(0, j).equalsIgnoreCase("path")) path = p.substring(j + 1);
        }
        cookies.put(parts[0].substring(0, i).trim(), new String[]{parts[0].substring(i + 1).trim(), domain, path});
    }

    // ------------------------------------------------------------------ interaction
    public void changed() { version++; }

    /** element click: links, buttons, form submit, inputs focus, onclick (lite JS) */
    public void clickNode(Node n) {
        if (n == null) return;
        String oc = n.attr("onclick");
        if (!oc.isEmpty()) runScript(oc);
        for (Node p = n; p != null; p = p.parent) {
            if (p.tag.equals("a") && !p.attr("href").isEmpty()) {
                String href = p.attr("href");
                if (href.startsWith("#")) return;
                if (href.startsWith("javascript:")) { runScript(href.substring(11)); return; }
                navigate(href, true); return;
            }
            if (p.tag.equals("input") || p.tag.equals("textarea") || p.tag.equals("select")) {
                String type = p.attr("type").toLowerCase(Locale.ROOT);
                if (type.equals("checkbox") || type.equals("radio")) {
                    if (p.attrs.containsKey("checked") && type.equals("checkbox")) p.attrs.remove("checked"); else p.attrs.put("checked", "checked");
                    changed(); return;
                }
                if (type.equals("submit") || type.equals("button")) { if (type.equals("submit")) submit(p); return; }
                focusNode = p; changed(); return;
            }
            if (p.tag.equals("button")) { String t = p.attr("type"); if (!t.equalsIgnoreCase("button")) submit(p); return; }
        }
    }

    void submit(Node from) {
        Node form = from;
        while (form != null && !form.tag.equals("form")) form = form.parent;
        if (form == null) return;
        String os = form.attr("onsubmit");
        if (!os.isEmpty()) runScript(os);
        StringBuilder q = new StringBuilder();
        for (Node in : WebDom.select(form, "input, textarea, select", 200)) {
            String n = in.attr("name");
            if (n.isEmpty()) continue;
            String type = in.attr("type").toLowerCase(Locale.ROOT);
            if ((type.equals("checkbox") || type.equals("radio")) && !in.attrs.containsKey("checked")) continue;
            if (type.equals("submit") && in != from) continue;
            String v = in.tag.equals("textarea") ? in.text : in.attr("value");
            if (q.length() > 0) q.append('&');
            q.append(URLEncoder.encode(n, StandardCharsets.UTF_8)).append('=').append(URLEncoder.encode(v, StandardCharsets.UTF_8));
        }
        String action = form.attr("action").isEmpty() ? url : form.attr("action");
        if (form.attr("method").equalsIgnoreCase("post")) request("POST", action, q.toString(), "application/x-www-form-urlencoded", true);
        else navigate(action.replaceAll("\\?.*$", "") + (q.length() > 0 ? "?" + q : ""), true);
    }

    /** click at browser pixel coordinates (uses the last client layout) */
    public boolean clickAt(double x, double y, int button) {
        double cy = y / zoom + scrollY, cx = x / zoom;
        Node best = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Object[] h = hits.get(i);
            if (cx >= (int) h[0] && cy >= (int) h[1] && cx < (int) h[2] && cy < (int) h[3]) { best = (Node) h[4]; break; }
        }
        if (best == null) { focusNode = null; return false; }
        if (button == 0) clickNode(best);
        return true;
    }

    public void scroll(double dx, double dy) {
        scrollX = Math.max(0, scrollX + dx);
        scrollY = Math.max(0, Math.min(Math.max(0, contentH - ah / Math.max(0.1, zoom)), scrollY + dy));
    }

    public void typeText(String s) {
        Node f = focusNode;
        if (f == null) return;
        if (f.tag.equals("textarea")) f.text += s; else f.attrs.put("value", f.attr("value") + s);
        changed();
    }
    public void keyPress(String key) {
        Node f = focusNode;
        switch (key.toLowerCase(Locale.ROOT)) {
            case "enter", "return" -> { if (f != null) { if (f.tag.equals("textarea")) typeText("\n"); else submit(f); } }
            case "backspace" -> {
                if (f == null) return;
                if (f.tag.equals("textarea")) { if (!f.text.isEmpty()) f.text = f.text.substring(0, f.text.length() - 1); }
                else { String v = f.attr("value"); if (!v.isEmpty()) f.attrs.put("value", v.substring(0, v.length() - 1)); }
                changed();
            }
            case "tab" -> {
                List<Node> ins = WebDom.select(dom, "input, textarea", 500);
                if (!ins.isEmpty()) { int i = ins.indexOf(f); focusNode = ins.get((i + 1) % ins.size()); changed(); }
            }
            case "escape" -> focusNode = null;
            case "pageup" -> scroll(0, -ah * 0.8);
            case "pagedown", "space" -> { if (f == null) scroll(0, ah * 0.8); else typeText(" "); }
            case "up" -> scroll(0, -30);
            case "down" -> scroll(0, 30);
            case "home" -> scrollY = 0;
            case "end" -> scroll(0, 1e9);
            default -> { if (key.length() == 1) typeText(key); }
        }
    }

    // ------------------------------------------------------------------ lite JavaScript
    int scriptWarn;
    void runScript(String js) {
        int skipped = 0;
        for (String st : statements(js)) {
            try { if (evalJs(st, true) == null) skipped++; } catch (Exception e) { skipped++; }
        }
        if (skipped > 0 && scriptWarn++ < 20) fire("E_Console", valueOf("warn"), valueOf("[lite engine] " + skipped + " JS statement(s) not supported (install MCEF for full Chromium)"));
    }

    static List<String> statements(String js) {
        js = js.replaceAll("(?m)//[^\\n\"']*$", "").replaceAll("(?s)/\\*.*?\\*/", "");
        List<String> out = new ArrayList<>();
        StringBuilder b = new StringBuilder();
        int depth = 0; char q = 0;
        for (int i = 0; i < js.length(); i++) {
            char c = js.charAt(i);
            if (q != 0) { b.append(c); if (c == '\\' && i + 1 < js.length()) b.append(js.charAt(++i)); else if (c == q) q = 0; continue; }
            if (c == '"' || c == '\'' || c == '`') { q = c; b.append(c); continue; }
            if (c == '(' || c == '{' || c == '[') depth++;
            if (c == ')' || c == '}' || c == ']') depth--;
            if ((c == ';' || c == '\n') && depth <= 0) { if (!b.toString().isBlank()) out.add(b.toString().trim()); b.setLength(0); continue; }
            b.append(c);
        }
        if (!b.toString().isBlank()) out.add(b.toString().trim());
        return out;
    }

    static final Pattern P_MSG = Pattern.compile("^(?:window\\.)?(?:parent\\.)?(?:fluwa\\.(?:send|postMessage)|postMessage|chrome\\.webview\\.postMessage|lua\\.send)\\s*\\((.*)\\)$", Pattern.DOTALL);
    static final Pattern P_CONSOLE = Pattern.compile("^console\\.(log|info|warn|error|debug)\\s*\\((.*)\\)$", Pattern.DOTALL);
    static final Pattern P_ALERT = Pattern.compile("^(?:window\\.)?alert\\s*\\((.*)\\)$", Pattern.DOTALL);
    static final Pattern P_ASSIGN = Pattern.compile("^(?:(?:var|let|const)\\s+)?([\\w.$\\[\\]\"'()#\\s:>,=-]+?)\\s*=\\s*(.+)$", Pattern.DOTALL);
    static final Pattern P_ELEM = Pattern.compile("^document\\.(querySelector|getElementById|querySelectorAll)\\s*\\(\\s*(\"[^\"]*\"|'[^']*')\\s*\\)(?:\\[(\\d+)\\])?(.*)$", Pattern.DOTALL);
    final Map<String, LuaValue> vars = new HashMap<>();

    /** returns null when the statement is not understood */
    LuaValue evalJs(String s, boolean statement) {
        s = s.trim();
        if (s.isEmpty()) return NIL;
        if (s.startsWith("(") && s.endsWith(")") && balanced(s.substring(1, s.length() - 1))) return evalJs(s.substring(1, s.length() - 1), statement);
        Matcher m;
        if ((m = P_MSG.matcher(s)).matches()) { LuaValue v = arg(m.group(1)); if (v == null) return null; fire("E_Message", v); return NIL; }
        if ((m = P_CONSOLE.matcher(s)).matches()) { LuaValue v = arg(m.group(2)); fire("E_Console", valueOf(m.group(1).equals("log") ? "info" : m.group(1)), valueOf(v == null ? m.group(2) : str(v))); return NIL; }
        if ((m = P_ALERT.matcher(s)).matches()) { LuaValue v = arg(m.group(1)); fire("E_Console", valueOf("alert"), valueOf(v == null ? m.group(1) : str(v))); return NIL; }
        switch (s) {
            case "location.reload()", "window.location.reload()" -> { navigate(url, false); return NIL; }
            case "history.back()", "window.history.back()" -> { back(); return NIL; }
            case "history.forward()", "window.history.forward()" -> { forward(); return NIL; }
            case "document.title" -> { return valueOf(title); }
            case "document.URL", "location.href", "window.location.href", "document.location.href", "location" -> { return valueOf(url); }
            case "document.body.innerText", "document.body.textContent" -> { Node b = dom.find("body"); return valueOf((b == null ? dom : b).innerText()); }
            case "document.body.innerHTML" -> { Node b = dom.find("body"); return valueOf((b == null ? dom : b).innerHTML()); }
            case "document.documentElement.outerHTML" -> { return valueOf(dom.innerHTML()); }
            case "navigator.userAgent" -> { return valueOf(userAgent); }
            case "document.cookie" -> { StringBuilder b = new StringBuilder(); cookies.forEach((k, v) -> { if (b.length() > 0) b.append("; "); b.append(k).append('=').append(v[0]); }); return valueOf(b.toString()); }
        }
        if ((m = P_ELEM.matcher(s)).matches()) return elemExpr(m, null);
        // assignments
        if (!s.startsWith("if") && !s.startsWith("function") && (m = P_ASSIGN.matcher(s)).matches() && !m.group(1).contains("(") || (m = P_ASSIGN.matcher(s)).matches() && m.group(1).startsWith("document.")) {
            String lhs = m.group(1).trim(), rhs = m.group(2).trim();
            if (lhs.endsWith("=") || lhs.endsWith("!") || lhs.endsWith("<") || lhs.endsWith(">")) return null;
            LuaValue v = arg(rhs);
            if (v == null) return null;
            switch (lhs) {
                case "document.title" -> { title = str(v); return v; }
                case "location.href", "window.location", "window.location.href", "location", "document.location" -> { navigate(str(v), true); return v; }
                case "document.cookie" -> { String c = str(v); int i = c.indexOf('='); if (i > 0) cookies.put(c.substring(0, i).trim(), new String[]{c.substring(i + 1).split(";")[0].trim(), "", "/"}); return v; }
            }
            Matcher em = P_ELEM.matcher(lhs);
            if (em.matches()) return elemExpr(em, v);
            if (lhs.matches("^(?:var|let|const\\s+)?[A-Za-z_$][\\w$]*$")) { vars.put(lhs.replaceFirst("^(var|let|const)\\s+", ""), v); return v; }
            return null;
        }
        return literal(s);
    }

    static boolean balanced(String s) { int d = 0; for (char c : s.toCharArray()) { if (c == '(') d++; if (c == ')' && --d < 0) return false; } return d == 0; }

    LuaValue elemExpr(Matcher m, LuaValue assign) {
        String fn = m.group(1), sel = unq(m.group(2));
        int idx = m.group(3) == null ? 0 : Integer.parseInt(m.group(3));
        String rest = m.group(4).trim();
        if (fn.equals("getElementById")) sel = "#" + sel;
        List<Node> l = WebDom.select(dom, sel, idx + 1);
        if (fn.equals("querySelectorAll") && m.group(3) == null) {
            if (rest.equals(".length")) return valueOf(WebDom.select(dom, sel, 10000).size());
            return null;
        }
        Node n = l.size() > idx ? l.get(idx) : null;
        if (rest.isEmpty()) return n == null ? NIL : new Element(this, n);
        if (n == null) return NIL;
        Matcher c;
        if (assign != null) {
            switch (rest) {
                case ".innerText", ".textContent" -> n.setText(str(assign));
                case ".innerHTML" -> n.setHTML(str(assign));
                case ".value" -> { if (n.tag.equals("textarea")) n.text = str(assign); else n.attrs.put("value", str(assign)); }
                case ".className" -> n.attrs.put("class", str(assign));
                case ".id" -> n.attrs.put("id", str(assign));
                case ".style.cssText" -> n.attrs.put("style", str(assign));
                case ".src", ".href", ".title", ".alt", ".placeholder" -> n.attrs.put(rest.substring(1), str(assign));
                default -> {
                    if (rest.startsWith(".style.")) { setStyle(n, cssName(rest.substring(7)), str(assign)); }
                    else return null;
                }
            }
            changed();
            return assign;
        }
        switch (rest) {
            case ".innerText", ".textContent" -> { return valueOf(n.innerText()); }
            case ".innerHTML" -> { return valueOf(n.innerHTML()); }
            case ".outerHTML" -> { return valueOf(n.outerHTML()); }
            case ".value" -> { return valueOf(n.tag.equals("textarea") ? n.text : n.attr("value")); }
            case ".checked" -> { return valueOf(n.attrs.containsKey("checked")); }
            case ".className" -> { return valueOf(n.attr("class")); }
            case ".id" -> { return valueOf(n.id()); }
            case ".tagName" -> { return valueOf(n.tag.toUpperCase(Locale.ROOT)); }
            case ".click()" -> { clickNode(n); return NIL; }
            case ".remove()" -> { n.remove(); changed(); return NIL; }
            case ".focus()" -> { focusNode = n; return NIL; }
        }
        if ((c = Pattern.compile("^\\.getAttribute\\s*\\((.+)\\)$").matcher(rest)).matches()) { LuaValue a = arg(c.group(1)); return a == null ? null : valueOf(n.attr(str(a))); }
        if ((c = Pattern.compile("^\\.setAttribute\\s*\\(\\s*(\"[^\"]*\"|'[^']*')\\s*,\\s*(.+)\\)$").matcher(rest)).matches()) {
            LuaValue a = arg(c.group(2)); if (a == null) return null; n.attrs.put(unq(c.group(1)), str(a)); changed(); return NIL;
        }
        if ((c = Pattern.compile("^\\.classList\\.(add|remove|toggle)\\s*\\(\\s*(\"[^\"]*\"|'[^']*')\\s*\\)$").matcher(rest)).matches()) {
            Set<String> cl = n.classes(); String k = unq(c.group(2));
            switch (c.group(1)) { case "add" -> cl.add(k); case "remove" -> cl.remove(k); default -> { if (!cl.remove(k)) cl.add(k); } }
            n.attrs.put("class", String.join(" ", cl)); changed(); return NIL;
        }
        return null;
    }

    static String cssName(String js) { return js.replaceAll("([A-Z])", "-$1").toLowerCase(Locale.ROOT); }
    static void setStyle(Node n, String prop, String val) {
        Map<String, String> st = n.style(); st.put(prop, val);
        StringBuilder b = new StringBuilder(); st.forEach((k, v) -> b.append(k).append(':').append(v).append(';'));
        n.attrs.put("style", b.toString());
    }

    static String unq(String s) { s = s.trim(); if (s.length() >= 2 && (s.charAt(0) == '"' || s.charAt(0) == '\'' || s.charAt(0) == '`')) s = s.substring(1, s.length() - 1); return s.replace("\\n", "\n").replace("\\\"", "\"").replace("\\'", "'"); }

    /** argument / right-hand side: literal, JSON, string concatenation or known expression */
    LuaValue arg(String s) {
        s = s.trim();
        if (s.isEmpty()) return NIL;
        List<String> parts = splitPlus(s);
        if (parts.size() > 1) {
            StringBuilder b = new StringBuilder(); boolean num = true; double sum = 0;
            for (String p : parts) { LuaValue v = arg(p); if (v == null) return null; if (v.isnumber() && !v.isstring()) sum += v.todouble(); else num = false; b.append(str(v)); }
            return num ? valueOf(sum) : valueOf(b.toString());
        }
        LuaValue lit = literal(s);
        if (lit != null) return lit;
        if (vars.containsKey(s)) return vars.get(s);
        return evalJs(s, false);
    }

    static List<String> splitPlus(String s) {
        List<String> out = new ArrayList<>(); StringBuilder b = new StringBuilder(); int d = 0; char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (q != 0) { b.append(c); if (c == '\\' && i + 1 < s.length()) b.append(s.charAt(++i)); else if (c == q) q = 0; continue; }
            if (c == '"' || c == '\'' || c == '`') q = c;
            if (c == '(' || c == '[' || c == '{') d++;
            if (c == ')' || c == ']' || c == '}') d--;
            if (c == '+' && d == 0) { out.add(b.toString()); b.setLength(0); continue; }
            b.append(c);
        }
        out.add(b.toString());
        return out;
    }

    static LuaValue literal(String s) {
        if (s.matches("^(\"([^\"\\\\]|\\\\.)*\"|'([^'\\\\]|\\\\.)*'|`[^`]*`)$")) return valueOf(unq(s));
        if (s.matches("^-?\\d+(\\.\\d+)?$")) return valueOf(Double.parseDouble(s));
        if (s.equals("true") || s.equals("false")) return valueOf(s.equals("true"));
        if (s.equals("null") || s.equals("undefined")) return NIL;
        if ((s.startsWith("{") && s.endsWith("}")) || (s.startsWith("[") && s.endsWith("]"))) {
            try { JsonReader r = new JsonReader(new StringReader(s)); r.setLenient(true); return Chromium.fromJson(JsonParser.parseReader(r)); }
            catch (Exception e) { return null; }
        }
        if (s.startsWith("JSON.stringify(") && s.endsWith(")")) {
            LuaValue v = literal(s.substring(15, s.length() - 1).trim());
            return v == null ? null : valueOf(new Gson().toJson(Chromium.toJson(v, 0)));
        }
        return null;
    }

    static String str(LuaValue v) {
        if (v.isnil()) return "undefined";
        if (v.istable()) return new Gson().toJson(Chromium.toJson(v, 0));
        if (v.isnumber() && !v.isstring()) { double d = v.todouble(); return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d); }
        return v.tojstring();
    }

    // ------------------------------------------------------------------ navigation helpers
    void back() { if (histIdx > 0) { histIdx--; navigate(history.get(histIdx), false); } }
    void forward() { if (histIdx < history.size() - 1) { histIdx++; navigate(history.get(histIdx), false); } }

    public void postMessage(LuaValue data) {
        String s = str(data);
        boolean any = false;
        for (Node n : WebDom.select(dom, "[data-fluwa-message]", 100)) { n.setText(s); any = true; }
        if (any) changed();
        fire("E_Console", valueOf("info"), valueOf("[lite engine] message received: " + s));
    }

    LuaTable domTable(Node n, int depth) {
        LuaTable t = new LuaTable();
        t.set("Tag", n.tag); t.set("Id", n.id()); t.set("Class", n.attr("class"));
        t.set("Text", n.innerText());
        LuaTable at = new LuaTable(); n.attrs.forEach(at::set); t.set("Attributes", at);
        if (depth < 6) {
            LuaTable ch = new LuaTable(); int i = 1;
            for (Node k : n.kids) if (!k.isText() && !k.tag.startsWith("#")) ch.set(i++, domTable(k, depth + 1));
            t.set("Children", ch);
        }
        t.set("Element", new Element(this, n));
        return t;
    }

    @Override protected void onDestroy() { loadToken++; loading = false; dom = WebDom.parse(""); }

    // ------------------------------------------------------------------ properties
    static UDim2L udim(LuaValue v) {
        if (v instanceof UDim2L u) return u;
        if (v instanceof Vec2L p) return new UDim2L(0, p.x, 0, p.y);
        if (v.istable()) return new UDim2L(0, v.get(1).optdouble(v.get("X").optdouble(0)), 0, v.get(2).optdouble(v.get("Y").optdouble(0)));
        throw new LuaError("Expected UDim2, Vec2 or {x, y}");
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "URL": case "Url": return valueOf(url);
            case "Title": return valueOf(title);
            case "HTML": return valueOf(dom.innerHTML());
            case "Text": return valueOf(dom.innerText());
            case "Size": return size;
            case "Position": return position;
            case "Transparency": return valueOf(transparency);
            case "Transparent": return valueOf(transparent);
            case "Zoom": return valueOf(zoom);
            case "Loading": return valueOf(loading);
            case "Cookies": { LuaTable t = new LuaTable(); cookies.forEach((n, v) -> t.set(n, v[0])); return t; }
            case "UserAgent": return valueOf(userAgent);
            case "Visible": return valueOf(visible);
            case "Focused": return valueOf(focused);
            case "DevTools": return valueOf(devTools);
            case "FPS": return valueOf(Math.round(fps));
            case "GPU": return FALSE;
            case "Headless": return valueOf(headless);
            case "Engine": return valueOf(mcef() ? "lite (MCEF detected)" : "lite");
            case "CanGoBack": return valueOf(histIdx > 0);
            case "CanGoForward": return valueOf(histIdx < history.size() - 1);
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "Size": size = udim(v); return true;
            case "Position": position = udim(v); return true;
            case "Transparency": transparency = Math.max(0, Math.min(1, v.checkdouble())); return true;
            case "Transparent": transparent = v.toboolean(); return true;
            case "Zoom": zoom = Math.max(0.25, Math.min(5, v.checkdouble())); return true;
            case "UserAgent": userAgent = v.checkjstring(); return true;
            case "Visible": visible = v.toboolean(); return true;
            case "Focused": focused = v.toboolean(); return true;
            case "DevTools": devTools = v.toboolean(); if (devTools) openDevTools(); return true;
            case "URL": case "Url": navigate(v.checkjstring(), true); return true;
            case "HTML": loadHTML(v.checkjstring()); return true;
            case "Title": case "Loading": case "Cookies": case "FPS": case "GPU": throw new LuaError("Browser." + k + " is read-only");
        }
        return super.setProp(k, v);
    }

    void openDevTools() {
        if (CLIENT_DEVTOOLS != null && !headless && rt != null && !rt.server) CLIENT_DEVTOOLS.accept("DevTools · " + url, dom.innerHTML());
        else rt.output(0, "[Browser DevTools] " + url + "\n" + dom.innerHTML());
    }

    public void apply(LuaValue s) {
        if (!s.istable()) return;
        LuaValue v;
        if (!(v = first(s, "size", "Size")).isnil()) size = udim(v);
        if (!(v = first(s, "position", "Position")).isnil()) position = udim(v);
        if (!(v = first(s, "transparent", "Transparent")).isnil()) transparent = v.toboolean();
        if (!(v = first(s, "transparency", "Transparency")).isnil()) transparency = v.checkdouble();
        if (!(v = first(s, "zoom", "Zoom")).isnil()) zoom = v.checkdouble();
        if (!(v = first(s, "userAgent", "UserAgent")).isnil()) userAgent = v.checkjstring();
        if (!(v = first(s, "visible", "Visible")).isnil()) visible = v.toboolean();
        if (!(v = first(s, "name", "Name")).isnil()) name = v.tojstring();
        if (!(v = first(s, "html", "HTML")).isnil()) loadHTML(v.checkjstring());
        if (!(v = first(s, "url", "URL")).isnil()) navigate(v.checkjstring(), true);
    }
    static LuaValue first(LuaValue t, String a, String b) { LuaValue v = t.get(a); return v.isnil() ? t.get(b) : v; }

    static Browser B(LuaValue s) { return (Browser) s; }

    static {
        Class<Browser> C = Browser.class;
        reg(C, "Navigate|Go", (s, a) -> { B(s).navigate(a.checkjstring(1), true); return s; });
        reg(C, "LoadHTML", (s, a) -> { B(s).loadHTML(a.checkjstring(1)); return s; });
        reg(C, "ExecuteJS|EJS", (s, a) -> {
            Browser b = B(s); LuaValue last = NIL; boolean ok = true;
            for (String st : statements(a.checkjstring(1))) { LuaValue v; try { v = b.evalJs(st, true); } catch (Exception e) { v = null; } if (v == null) ok = false; else last = v; }
            if (!ok) b.fire("E_Console", valueOf("warn"), valueOf("[lite engine] ExecuteJS: part of the script is not supported"));
            return last; });
        reg(C, "InjectCSS", (s, a) -> { Browser b = B(s); b.injectedCss.add(a.checkjstring(1)); b.rebuildCss(); b.changed(); return NONE; });
        reg(C, "SetSize", (s, a) -> { B(s).size = a.arg1() instanceof UDim2L u ? u : new UDim2L(0, a.checkdouble(1), 0, a.checkdouble(2)); return NONE; });
        reg(C, "SetPosition", (s, a) -> { B(s).position = a.arg1() instanceof UDim2L u ? u : new UDim2L(0, a.checkdouble(1), 0, a.checkdouble(2)); return NONE; });
        reg(C, "SetTransparent", (s, a) -> { B(s).transparent = a.optboolean(1, true); return NONE; });
        reg(C, "SetZoom", (s, a) -> { B(s).setProp("Zoom", a.arg1()); return NONE; });
        reg(C, "Reload", (s, a) -> { Browser b = B(s); if (b.url.equals("about:html")) b.setPage(b.url, b.dom.innerHTML(), ++b.loadToken); else b.navigate(b.url, false); return NONE; });
        reg(C, "Back", (s, a) -> { B(s).back(); return NONE; });
        reg(C, "Forward", (s, a) -> { B(s).forward(); return NONE; });
        reg(C, "Stop", (s, a) -> { Browser b = B(s); b.loadToken++; b.loading = false; return NONE; });
        reg(C, "Close", (s, a) -> { s.destroy(); return NONE; });
        reg(C, "Click", (s, a) -> valueOf(B(s).clickAt(a.checkdouble(1), a.checkdouble(2), buttonOf(a.arg(3)))));
        reg(C, "Scroll", (s, a) -> { B(s).scroll(a.optdouble(1, 0), a.optdouble(2, 0)); return NONE; });
        reg(C, "KeyPress", (s, a) -> { B(s).keyPress(a.checkjstring(1)); return NONE; });
        reg(C, "TypeText", (s, a) -> { B(s).typeText(a.checkjstring(1)); return NONE; });
        reg(C, "GetDOM", (s, a) -> {
            Browser b = B(s);
            if (a.isnil(1)) return b.domTable(b.dom.find("html") != null ? b.dom.find("html") : b.dom, 0);
            LuaTable t = new LuaTable(); int i = 1;
            for (Node n : WebDom.select(b.dom, a.checkjstring(1), 1000)) t.set(i++, b.domTable(n, 3));
            return t; });
        reg(C, "QuerySelector", (s, a) -> { List<Node> l = WebDom.select(B(s).dom, a.checkjstring(1), 1); return l.isEmpty() ? NIL : new Element(B(s), l.get(0)); });
        reg(C, "QuerySelectorAll", (s, a) -> { List<LuaValue> l = new ArrayList<>(); for (Node n : WebDom.select(B(s).dom, a.checkjstring(1), 1000)) l.add(new Element(B(s), n)); return list(l); });
        reg(C, "SetCookie", (s, a) -> { B(s).cookies.put(a.checkjstring(1), new String[]{a.checkjstring(2), a.optjstring(3, ""), a.optjstring(4, "/")}); return NONE; });
        reg(C, "GetCookie", (s, a) -> { String[] c = B(s).cookies.get(a.checkjstring(1)); return c == null ? NIL : valueOf(c[0]); });
        reg(C, "ClearCookies", (s, a) -> { B(s).cookies.clear(); return NONE; });
        reg(C, "SetUserAgent", (s, a) -> { B(s).userAgent = a.checkjstring(1); return NONE; });
        reg(C, "OpenDevTools", (s, a) -> { B(s).devTools = true; B(s).openDevTools(); return NONE; });
        reg(C, "Print", (s, a) -> { Browser b = B(s); b.rt.output(0, "[Browser] " + b.title + " (" + b.url + ")\n" + b.dom.innerText()); return valueOf(b.dom.innerText()); });
        reg(C, "PostMessage", (s, a) -> { B(s).postMessage(a.arg1()); return NONE; });
    }

    static int buttonOf(LuaValue v) {
        if (v.isnil()) return 0;
        if (v.isnumber()) return v.toint() <= 1 ? 0 : v.toint() - 1;
        return switch (v.tojstring().toLowerCase(Locale.ROOT)) { case "right" -> 1; case "middle" -> 2; default -> 0; };
    }

    // ================================================================== ChromiumElement
    public static class Element extends EvObj {
        final Browser b; final Node n;
        public Element(Browser b, Node n) { super("ChromiumElement"); this.b = b; this.n = n; name = n.tag; }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Tag": case "TagName": return valueOf(n.tag);
                case "Id": return valueOf(n.id());
                case "Class": case "ClassName": return valueOf(n.attr("class"));
                case "Text": return valueOf(n.innerText());
                case "HTML": return valueOf(n.innerHTML());
                case "Value": return valueOf(n.tag.equals("textarea") ? n.text : n.attr("value"));
                case "Browser": return b;
                case "Attributes": { LuaTable t = new LuaTable(); n.attrs.forEach(t::set); return t; }
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            switch (k) {
                case "Text": n.setText(v.tojstring()); b.changed(); return true;
                case "HTML": n.setHTML(v.tojstring()); b.changed(); return true;
                case "Value": if (n.tag.equals("textarea")) n.text = v.tojstring(); else n.attrs.put("value", v.tojstring()); b.changed(); return true;
            }
            return super.setProp(k, v);
        }
        static Element E(LuaValue s) { return (Element) s; }
        static {
            Class<Element> C = Element.class;
            reg(C, "Click", (s, a) -> { E(s).b.clickNode(E(s).n); return NONE; });
            reg(C, "SetText", (s, a) -> { E(s).n.setText(a.checkjstring(1)); E(s).b.changed(); return NONE; });
            reg(C, "GetText", (s, a) -> valueOf(E(s).n.innerText()));
            reg(C, "SetHTML", (s, a) -> { E(s).n.setHTML(a.checkjstring(1)); E(s).b.changed(); return NONE; });
            reg(C, "GetHTML", (s, a) -> valueOf(E(s).n.innerHTML()));
            reg(C, "SetStyle", (s, a) -> {
                String css = a.checkjstring(1);
                if (a.narg() >= 2 && !css.contains(":")) setStyle(E(s).n, css, a.checkjstring(2));
                else for (String d : css.split(";")) { int i = d.indexOf(':'); if (i > 0) setStyle(E(s).n, d.substring(0, i).trim().toLowerCase(Locale.ROOT), d.substring(i + 1).trim()); }
                E(s).b.changed(); return NONE; });
            reg(C, "GetAttribute", (s, a) -> { String v = E(s).n.attrs.get(a.checkjstring(1).toLowerCase(Locale.ROOT)); return v == null ? NIL : valueOf(v); });
            reg(C, "SetAttribute", (s, a) -> { Element e = E(s);
                if (a.isnil(2)) e.n.attrs.remove(a.checkjstring(1).toLowerCase(Locale.ROOT)); else e.n.attrs.put(a.checkjstring(1).toLowerCase(Locale.ROOT), a.arg(2).tojstring());
                e.b.changed(); return NONE; });
            reg(C, "Remove", (s, a) -> { E(s).n.remove(); E(s).b.changed(); return NONE; });
            reg(C, "QuerySelector", (s, a) -> { List<Node> l = WebDom.select(E(s).n, a.checkjstring(1), 1); return l.isEmpty() ? NIL : new Element(E(s).b, l.get(0)); });
            reg(C, "GetParent", (s, a) -> E(s).n.parent == null || E(s).n.parent.tag.startsWith("#") ? NIL : new Element(E(s).b, E(s).n.parent));
            reg(C, "GetChildren", (s, a) -> { List<LuaValue> l = new ArrayList<>(); for (Node k : E(s).n.kids) if (!k.isText() && !k.tag.startsWith("#")) l.add(new Element(E(s).b, k)); return list(l); });
        }
    }
}
