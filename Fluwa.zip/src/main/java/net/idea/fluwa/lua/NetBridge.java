package net.idea.fluwa.lua;

import org.luaj.vm2.LuaValue;

/** Implemented by the networking layer. */
public interface NetBridge {
    /** client -> server */
    void fireServer(String event, LuaValue arg);
    /** server -> one player. kind: 0 = OnPlayerFire, 1 = OnMeFire */
    void firePlayer(LObj player, String event, int kind, LuaValue arg);
    /** server -> all players */
    void fireAllPlayers(String event, LuaValue arg);
    /** server -> players in radius */
    void fireRadius(String event, LuaValue arg, double radius, Vec3L center, LObj dimension);

    NetBridge NONE = new NetBridge() {
        public void fireServer(String e, LuaValue a) { throw new org.luaj.vm2.LuaError("Not connected"); }
        public void firePlayer(LObj p, String e, int k, LuaValue a) { throw new org.luaj.vm2.LuaError("Not a server"); }
        public void fireAllPlayers(String e, LuaValue a) { throw new org.luaj.vm2.LuaError("Not a server"); }
        public void fireRadius(String e, LuaValue a, double r, Vec3L c, LObj d) { throw new org.luaj.vm2.LuaError("Not a server"); }
    };
}
