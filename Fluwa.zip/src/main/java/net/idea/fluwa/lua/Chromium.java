package net.idea.fluwa.lua;

import com.google.gson.*;
import net.idea.fluwa.Config;
import org.luaj.vm2.*;

import java.net.*;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.function.*;

/**
 * getAccess("Chromium") - web access for scripts.
 * Both sides: Request/Get/Post (+Async), JSONEncode/JSONDecode, HtmlToText.
 * Client only: Open(url) (system browser after confirmation), ShowPage(url) (in-game text browser).
 * HTTP is off by default: httpEnabled=true in config/fluwa-common.toml.
 */
public final class Chromium extends LObj {
    /** set by the client: open url in system browser (with confirm screen) / show a text page */
    public static Consumer<String> CLIENT_OPEN;
    public static BiConsumer<String, String> CLIENT_PAGE;

    private static final HttpClient HTTP = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(10)).build();
    private static final int MAX_BODY = 5 << 20;

    final FluwaRuntime r;
    Chromium(FluwaRuntime r) { super("Service"); this.r = r; name = "Chromium"; }

    @Override protected boolean threadSafe() { return true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Available": case "HttpEnabled": return valueOf(Config.httpEnabled);
            case "UserAgent": return valueOf("Fluwa/" + Services.VERSION);
            case "MCEF": return valueOf(Browser.mcef());
            case "Engine": return valueOf("lite");
        }
        return super.getProp(k);
    }

    // ------------------------------------------------------------------ HTTP
    static URI check(String url) {
        if (!Config.httpEnabled) throw new LuaError("HTTP requests are disabled: set httpEnabled=true in config/fluwa-common.toml");
        URI u;
        try { u = new URI(url); } catch (URISyntaxException e) { throw new LuaError("Invalid URL: " + url); }
        String sch = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (!sch.equals("http") && !sch.equals("https")) throw new LuaError("Only http:// and https:// URLs are allowed");
        String host = u.getHost();
        if (host == null) throw new LuaError("Invalid URL (no host): " + url);
        host = host.toLowerCase(Locale.ROOT);
        if (!Config.httpAllowedDomains.isEmpty()) {
            boolean ok = false;
            for (String d : Config.httpAllowedDomains) { d = d.toLowerCase(Locale.ROOT); if (host.equals(d) || host.endsWith("." + d)) ok = true; }
            if (!ok) throw new LuaError("Domain " + host + " is not in httpAllowedDomains");
        }
        return u;
    }

    static void checkAddress(URI u) throws UnknownHostException {
        if (Config.httpAllowLocal) return;
        for (InetAddress a : InetAddress.getAllByName(u.getHost()))
            if (a.isLoopbackAddress() || a.isSiteLocalAddress() || a.isLinkLocalAddress() || a.isAnyLocalAddress() || a.isMulticastAddress())
                throw new LuaError("Requests to local/LAN addresses are blocked (httpAllowLocal=false): " + u.getHost());
    }

    /** opts: {Url, Method="GET", Headers={}, Body="", Timeout=15} -> task with Result = {StatusCode, Success, Body, Headers} */
    static AsyncTask request(LuaValue opts) {
        String url = opts.get("Url").optjstring(opts.get("url").optjstring(null));
        if (url == null) throw new LuaError("Request: Url is required");
        URI u = check(url);
        String method = opts.get("Method").optjstring("GET").toUpperCase(Locale.ROOT);
        String body = opts.get("Body").optjstring(null);
        int timeout = opts.get("Timeout").optint(15);
        Map<String, String> headers = new LinkedHashMap<>();
        LuaValue h = opts.get("Headers");
        if (h.istable()) for (LuaValue k = h.next(NIL).arg1(); !k.isnil(); k = h.next(k).arg1()) headers.put(k.tojstring(), h.get(k).tojstring());
        return AsyncTask.run("Chromium " + method + " " + url, () -> {
            checkAddress(u);
            HttpRequest.Builder b = HttpRequest.newBuilder(u).timeout(Duration.ofSeconds(timeout))
                    .method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body));
            b.header("User-Agent", "Fluwa/" + Services.VERSION);
            headers.forEach(b::header);
            HttpResponse<byte[]> res = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
            byte[] bytes = res.body();
            if (bytes.length > MAX_BODY) bytes = Arrays.copyOf(bytes, MAX_BODY);
            LuaTable t = new LuaTable();
            t.set("StatusCode", valueOf(res.statusCode()));
            t.set("Success", valueOf(res.statusCode() >= 200 && res.statusCode() < 300));
            t.set("Body", LuaString.valueOf(bytes));
            LuaTable hd = new LuaTable();
            res.headers().map().forEach((k, v) -> hd.set(k, String.join(", ", v)));
            t.set("Headers", hd);
            t.set("Url", res.uri().toString());
            return t;
        });
    }

    static LuaTable opts(String url, String method, String body, String contentType, LuaValue headers) {
        LuaTable o = new LuaTable();
        o.set("Url", url); o.set("Method", method);
        if (body != null) o.set("Body", body);
        LuaTable h = headers.istable() ? (LuaTable) headers : new LuaTable();
        if (contentType != null && h.get("Content-Type").isnil()) h.set("Content-Type", contentType);
        o.set("Headers", h);
        return o;
    }

    static Varargs bodyStatus(LuaValue res) { return varargsOf(res.get("Body"), res.get("StatusCode")); }

    // ------------------------------------------------------------------ JSON
    public static JsonElement toJson(LuaValue v, int depth) {
        if (depth > 64) throw new LuaError("JSONEncode: table is too deep (cycle?)");
        if (v.isnil()) return JsonNull.INSTANCE;
        if (v.isboolean()) return new JsonPrimitive(v.toboolean());
        if (v.type() == TNUMBER) { double d = v.todouble(); return d == Math.rint(d) && Math.abs(d) < 1e15 ? new JsonPrimitive((long) d) : new JsonPrimitive(d); }
        if (v.isstring()) return new JsonPrimitive(v.tojstring());
        if (v instanceof Vec3L p) { JsonObject o = new JsonObject(); o.addProperty("X", p.x); o.addProperty("Y", p.y); o.addProperty("Z", p.z); return o; }
        if (v.istable()) {
            LuaTable t = (LuaTable) v;
            int n = t.length(); int count = 0;
            for (LuaValue k = t.next(NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) count++;
            if (n > 0 && n == count) { JsonArray a = new JsonArray(); for (int i = 1; i <= n; i++) a.add(toJson(t.get(i), depth + 1)); return a; }
            JsonObject o = new JsonObject();
            for (LuaValue k = t.next(NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) o.add(k.tojstring(), toJson(t.get(k), depth + 1));
            return o;
        }
        return new JsonPrimitive(v.tojstring());
    }

    public static LuaValue fromJson(JsonElement e) {
        if (e == null || e.isJsonNull()) return NIL;
        if (e.isJsonPrimitive()) {
            JsonPrimitive p = e.getAsJsonPrimitive();
            if (p.isBoolean()) return valueOf(p.getAsBoolean());
            if (p.isNumber()) return valueOf(p.getAsDouble());
            return valueOf(p.getAsString());
        }
        LuaTable t = new LuaTable();
        if (e.isJsonArray()) { int i = 1; for (JsonElement x : e.getAsJsonArray()) t.set(i++, fromJson(x)); }
        else for (var en : e.getAsJsonObject().entrySet()) t.set(en.getKey(), fromJson(en.getValue()));
        return t;
    }

    /** very small HTML -> text converter for ShowPage / HtmlToText */
    public static String htmlToText(String html) {
        String s = html.replaceAll("(?is)<(script|style|head)[^>]*>.*?</\\1>", "");
        s = s.replaceAll("(?i)<br\\s*/?>", "\n").replaceAll("(?i)</(p|div|h[1-6]|li|tr|title)>", "\n").replaceAll("(?i)<li[^>]*>", " • ");
        s = s.replaceAll("(?s)<[^>]+>", "");
        s = s.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&amp;", "&");
        s = s.replaceAll("[ \\t\\x0B\\f\\r]+", " ").replaceAll("\\n\\s*\\n+", "\n\n");
        return s.trim();
    }

    static {
        reg(Chromium.class, "Request", (s, a) -> request(a.checktable(1)).await());
        reg(Chromium.class, "RequestAsync", (s, a) -> request(a.checktable(1)));
        reg(Chromium.class, "Get", (s, a) -> bodyStatus(request(opts(a.checkjstring(1), "GET", null, null, a.arg(2))).await()));
        reg(Chromium.class, "GetAsync", (s, a) -> request(opts(a.checkjstring(1), "GET", null, null, a.arg(2))));
        reg(Chromium.class, "Post", (s, a) -> bodyStatus(request(opts(a.checkjstring(1), "POST", a.checkjstring(2), a.optjstring(3, "application/json"), a.arg(4))).await()));
        reg(Chromium.class, "PostAsync", (s, a) -> request(opts(a.checkjstring(1), "POST", a.checkjstring(2), a.optjstring(3, "application/json"), a.arg(4))));
        reg(Chromium.class, "JSONEncode", (s, a) -> valueOf(new Gson().toJson(toJson(a.arg1(), 0))));
        reg(Chromium.class, "JSONDecode", (s, a) -> {
            try { return fromJson(JsonParser.parseString(a.checkjstring(1))); }
            catch (JsonParseException e) { throw new LuaError("JSONDecode: " + e.getMessage()); } });
        reg(Chromium.class, "HtmlToText", (s, a) -> valueOf(htmlToText(a.checkjstring(1))));
        reg(Chromium.class, "UrlEncode", (s, a) -> valueOf(URLEncoder.encode(a.checkjstring(1), java.nio.charset.StandardCharsets.UTF_8)));
        reg(Chromium.class, "Open", (s, a) -> {
            if (CLIENT_OPEN == null || ((Chromium) s).r.server) throw new LuaError("Chromium:Open is Client-Side only");
            String url = a.checkjstring(1);
            if (!url.startsWith("http://") && !url.startsWith("https://")) throw new LuaError("Only http(s) URLs can be opened");
            CLIENT_OPEN.accept(url); return NONE; });
        reg(Chromium.class, "ShowPage", (s, a) -> {
            if (CLIENT_PAGE == null || ((Chromium) s).r.server) throw new LuaError("Chromium:ShowPage is Client-Side only");
            String url = a.checkjstring(1);
            LuaValue res = request(opts(url, "GET", null, null, NIL)).await();
            CLIENT_PAGE.accept(url, htmlToText(res.get("Body").tojstring()));
            return res.get("StatusCode"); });
        // ---- 0.3: Browser objects (lite engine; rendered by the client inside UI / ScreenGUI / Overlay)
        reg(Chromium.class, "CreateBrowser|CB", (s, a) -> {
            Chromium c = (Chromium) s;
            if (c.r.server) throw new LuaError("Chromium:CreateBrowser is Client-Side (use Chromium:CreateHeadless on the server)");
            LuaValue parent = a.arg1(), settings = a.arg(2);
            if (parent.istable() && !(parent instanceof LObj)) { settings = parent; parent = NIL; }
            Browser b = new Browser(false);
            b.apply(settings);
            if (parent instanceof LObj p) b.setParent(p);
            return b; });
        reg(Chromium.class, "CreateHeadless", (s, a) -> {
            Chromium c = (Chromium) s;
            if (!c.r.server) throw new LuaError("Chromium:CreateHeadless is only Server-Side");
            Browser b = new Browser(true);
            b.apply(a.arg1());
            return b; });
        reg(Chromium.class, "LoadURL", (s, a) -> {
            Browser b = new Browser(((Chromium) s).r.server);
            b.navigate(a.checkjstring(1), true);
            if (a.arg(2) instanceof LObj p) b.setParent(p);
            return b; });
        reg(Chromium.class, "LoadHTML", (s, a) -> {
            Browser b = new Browser(((Chromium) s).r.server);
            b.loadHTML(a.checkjstring(1));
            if (a.arg(2) instanceof LObj p) b.setParent(p);
            return b; });
        reg(Chromium.class, "ShowText", (s, a) -> {
            if (CLIENT_PAGE == null || ((Chromium) s).r.server) throw new LuaError("Chromium:ShowText is Client-Side only");
            CLIENT_PAGE.accept(a.checkjstring(1), a.checkjstring(2)); return NONE; });
    }
}
