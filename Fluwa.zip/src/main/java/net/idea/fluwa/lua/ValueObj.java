package net.idea.fluwa.lua;

import org.luaj.vm2.*;

/** IntValue / NumberValue / NumValue / BoolValue / StringValue / StrValue / TableValue / Vector3Value / ObjValue (can be parented to a Player) */
public class ValueObj extends LObj {
    private LuaValue value;
    private final Signal changed = new Signal("Changed");

    public ValueObj(String cls, LuaValue init) { super(cls); value = init; }

    /** ObjValue: path of the referenced object, resolved lazily ("Workspace.Lighting") */
    private String ref;
    public void setRef(String r) {
        ref = r == null || r.isBlank() ? null : r.trim(); if (ref == null) value = NIL;
        if (hooked()) HOOK.valueChanged(this);
    }
    public String getRef() { return ref; }
    public LuaValue raw() { return value; }

    @Override protected LuaValue getProp(String k) {
        if (k.equals("Value")) {
            if (ref != null && value.isnil()) { LuaValue r = ItemTree.resolve(rt, ref); if (!r.isnil()) value = r; }
            return value;
        }
        if (k.equals("Changed") || k.equals("E_Changed")) return changed;
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (!k.equals("Value")) return super.setProp(k, v);
        LuaValue nv = switch (className) {
            case "IntValue" -> valueOf((long) v.checkdouble());
            case "NumberValue", "NumValue" -> valueOf(v.checkdouble());
            case "StrValue" -> valueOf(v.tojstring());
            case "ObjValue", "ObjectValue" -> { if (!v.isnil()) checkObj(v, LObj.class); ref = null; yield v; }
            case "BoolValue" -> valueOf(v.toboolean());
            case "StringValue" -> valueOf(v.tojstring());
            case "TableValue" -> v.checktable();
            case "Vector3Value" -> Vec3L.check(v);
            default -> v;
        };
        boolean diff = !nv.raweq(value);
        value = nv;
        if (diff && hooked()) HOOK.valueChanged(this);
        if (diff) changed.fire(nv);
        return true;
    }

    @Override protected LuaValue cloneObj() { ValueObj o = new ValueObj(className, value); o.name = name; return o; }
}
