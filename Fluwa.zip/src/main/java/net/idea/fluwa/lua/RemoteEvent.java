package net.idea.fluwa.lua;

import org.luaj.vm2.*;

/**
 * Network event (doc: "Event"). Identified by Name on both sides, so create it with the same Name
 * on server and client (easiest: in InitScripts, which run on both sides).
 */
public class RemoteEvent extends LObj {
    public final Signal onServerFire = new Signal("OnServerFire");
    public final Signal onMeFire = new Signal("OnMeFire");
    public final Signal onPlayerFire = new Signal("OnPlayerFire");

    public RemoteEvent() { super("Event"); register(); }

    private void register() { if (rt != null) rt.remotes.put(name, this); }

    @Override public void setName(String n) {
        if (rt != null && rt.remotes.get(name) == this) rt.remotes.remove(name);
        super.setName(n);
        register();
    }

    @Override protected void onDestroy() { if (rt != null && rt.remotes.get(name) == this) rt.remotes.remove(name); }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "OnServerFire": case "OnServerEvent": return onServerFire;
            case "OnMeFire": return onMeFire;
            case "OnPlayerFire": case "OnClientEvent": return onPlayerFire;
        }
        return super.getProp(k);
    }

    public static NetBridge bridge(FluwaRuntime rt) { return rt instanceof HasBridge h ? h.bridge() : NetBridge.NONE; }
    public interface HasBridge { NetBridge bridge(); }

    static void requireSide(LObj s, boolean server, String m) {
        if (s.rt.server != server) throw new LuaError("Event:" + m + " can only be used " + (server ? "on the server" : "on the client"));
    }

    static {
        reg(RemoteEvent.class, "FireServer|FS", (s, a) -> {
            requireSide(s, false, "FireServer");
            bridge(s.rt).fireServer(s.name, a.arg1()); return NONE; });
        reg(RemoteEvent.class, "FirePlayer|FP|FireClient", (s, a) -> {
            requireSide(s, true, "FirePlayer");
            bridge(s.rt).firePlayer(checkObj(a.arg1(), LObj.class), s.name, 0, a.arg(2)); return NONE; });
        reg(RemoteEvent.class, "FireAllPlayers|FAP|FireAllClients", (s, a) -> {
            requireSide(s, true, "FireAllPlayers");
            bridge(s.rt).fireAllPlayers(s.name, a.arg1()); return NONE; });
        reg(RemoteEvent.class, "FireAll|FA", (s, a) -> {
            requireSide(s, true, "FireAll");
            bridge(s.rt).fireRadius(s.name, a.arg1(), a.checkdouble(2), Vec3L.check(a.arg(3)), a.isnil(4) ? null : checkObj(a.arg(4), LObj.class));
            return NONE; });
    }
}
