package net.idea.fluwa.lua;

import org.luaj.vm2.*;

import java.util.*;

/** LObj with lazily created E_* event signals (0.3 objects: UI, Item, NET, Browser, Projector...). */
public class EvObj extends LObj {
    protected final Map<String, Signal> events = new HashMap<>();

    public EvObj(String cls) { super(cls); }

    /** null = any E_* name is accepted */
    protected Collection<String> eventNames() { return null; }

    public Signal ev(String n) { return events.computeIfAbsent(n, Signal::new); }
    public boolean listens(String n) { Signal s = events.get(n); return s != null && s.hasHandlers(); }
    public void fire(String n, LuaValue... a) { Signal s = events.get(n); if (s != null && s.hasHandlers()) s.fire(a); }
    /** fire from any thread (queued to the runtime's next tick) */
    public void fireAsync(String n, LuaValue... a) { if (rt != null) rt.post(() -> fire(n, a)); }

    @Override protected LuaValue getProp(String k) {
        if (k.startsWith("E_")) {
            Collection<String> ok = eventNames();
            if (ok == null || ok.contains(k)) return ev(k);
        }
        return super.getProp(k);
    }

    @Override protected void onChildAdded(LObj c) { super.onChildAdded(c); fire("E_ChildAdded", c); }
    @Override protected void onChildRemoved(LObj c) { super.onChildRemoved(c); fire("E_ChildRemoved", c); }

    // ---- attributes (SetAttribute/GetAttribute/GetAttributes)
    protected LuaTable attrs;
    static {
        reg(EvObj.class, "SetAttribute", (s, a) -> { EvObj o = (EvObj) s; if (o.attrs == null) o.attrs = new LuaTable();
            o.attrs.set(a.checkjstring(1), a.arg(2)); o.fire("E_AttributeChanged", a.arg1()); return NONE; });
        reg(EvObj.class, "GetAttribute", (s, a) -> { EvObj o = (EvObj) s; return o.attrs == null ? NIL : o.attrs.get(a.checkjstring(1)); });
        reg(EvObj.class, "GetAttributes", (s, a) -> { EvObj o = (EvObj) s; LuaTable t = new LuaTable();
            if (o.attrs != null) for (LuaValue k = o.attrs.next(NIL).arg1(); !k.isnil(); k = o.attrs.next(k).arg1()) t.set(k, o.attrs.get(k));
            return t; });
        reg(EvObj.class, "SetParent", (s, a) -> { s.setParent(a.isnil(1) ? null : checkObj(a.arg1(), LObj.class)); return NONE; });
        reg(EvObj.class, "GetParent", (s, a) -> s.parent == null ? NIL : s.parent);
        reg(EvObj.class, "SetName", (s, a) -> { s.setName(a.checkjstring(1)); return NONE; });
        reg(EvObj.class, "GetName", (s, a) -> valueOf(s.getName()));
    }

    public static LuaValue opt(LuaValue v) { return v == null ? NIL : v; }
}
