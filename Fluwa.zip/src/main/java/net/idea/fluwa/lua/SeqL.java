package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

import java.util.*;

/**
 * ColorSequence / NumberSequence (UIGradient.Color / UIGradient.Transparency).
 * ColorSequence.new(color) | ColorSequence.new(c0, c1) | ColorSequence.new({ {0, c0}, {0.5, c1}, {1, c2} })
 * NumberSequence.new(n) | NumberSequence.new(n0, n1) | NumberSequence.new({ {0, 0}, {1, 1} })
 */
public final class SeqL extends LObj {
    public final boolean color;
    public final double[] t;   // keypoint times 0..1
    public final double[] v;   // number: value; color: packed rgb as double
    public SeqL(boolean color, double[] t, double[] v) { super(color ? "ColorSequence" : "NumberSequence"); this.color = color; this.t = t; this.v = v; }

    public static SeqL check(LuaValue x, boolean color) {
        if (x instanceof SeqL s && s.color == color) return s;
        if (!color && x.isnumber()) return new SeqL(false, new double[]{0, 1}, new double[]{x.todouble(), x.todouble()});
        if (color && (x instanceof ColorL || x.isnumber() || x.isstring())) { int c = ColorL.check(x); return new SeqL(true, new double[]{0, 1}, new double[]{c, c}); }
        if (x.istable()) return of(color, x.checktable().unpack());
        throw new LuaError("Expected " + (color ? "ColorSequence" : "NumberSequence"));
    }

    static SeqL of(boolean color, Varargs a) {
        if (a.narg() == 1 && a.arg1().istable() && !(a.arg1() instanceof LObj)) {
            LuaTable kp = a.arg1().checktable();
            int n = kp.length();
            if (n < 1) throw new LuaError("Sequence needs keypoints");
            double[] t = new double[n], v = new double[n];
            for (int i = 0; i < n; i++) {
                LuaValue k = kp.get(i + 1);
                LuaValue time = k.get(1).isnil() ? k.get("Time") : k.get(1), val = k.get(2).isnil() ? k.get("Value") : k.get(2);
                t[i] = time.checkdouble();
                v[i] = color ? ColorL.check(val) : val.checkdouble();
            }
            return new SeqL(color, t, v);
        }
        LuaValue a0 = a.arg1(), a1 = a.isnil(2) ? a0 : a.arg(2);
        return new SeqL(color, new double[]{0, 1}, new double[]{color ? ColorL.check(a0) : a0.checkdouble(), color ? ColorL.check(a1) : a1.checkdouble()});
    }

    /** value at time x (0..1) */
    public double num(double x) {
        if (x <= t[0]) return v[0];
        for (int i = 1; i < t.length; i++) if (x <= t[i]) { double f = (x - t[i - 1]) / Math.max(1e-9, t[i] - t[i - 1]); return v[i - 1] + (v[i] - v[i - 1]) * f; }
        return v[v.length - 1];
    }
    public int rgb(double x) {
        int a = (int) v[0], b = a; double f = 0;
        if (x <= t[0]) return (int) v[0];
        boolean found = false;
        for (int i = 1; i < t.length; i++) if (x <= t[i]) { a = (int) v[i - 1]; b = (int) v[i]; f = (x - t[i - 1]) / Math.max(1e-9, t[i] - t[i - 1]); found = true; break; }
        if (!found) return (int) v[v.length - 1];
        int r = (int) ((a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * f);
        int g = (int) ((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * f);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * f);
        return (r << 16) | (g << 8) | bl;
    }

    @Override protected boolean threadSafe() { return true; }
    @Override protected LuaValue getProp(String k) {
        if (k.equals("Keypoints")) {
            LuaTable r = new LuaTable();
            for (int i = 0; i < t.length; i++) {
                LuaTable kp = new LuaTable();
                kp.set("Time", valueOf(t[i]));
                int c = (int) v[i];
                kp.set("Value", color ? new ColorL(c >> 16 & 255, c >> 8 & 255, c & 255) : valueOf(v[i]));
                r.set(i + 1, kp);
            }
            return r;
        }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) { throw new LuaError(className + " is immutable"); }
    @Override public String tojstring() { return className + "(" + t.length + " keypoints)"; }

    public static LuaTable lib(boolean color) {
        LuaTable t = new LuaTable();
        t.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            if (a.arg1().istable() && a.arg1().get("new").isfunction()) a = a.subargs(2);
            return of(color, a); } });
        return t;
    }

    /** Enum.X.Y -> "Y" (enums are plain strings in Fluwa, comparisons like v == Enum.TextXAlignment.Left work) */
    public static LuaTable enumLib() {
        LuaTable root = new LuaTable();
        LuaTable mt = new LuaTable();
        mt.set("__index", new TwoArgFunction() { public LuaValue call(LuaValue self, LuaValue k) {
            LuaTable e = new LuaTable();
            LuaTable m2 = new LuaTable();
            m2.set("__index", new TwoArgFunction() { public LuaValue call(LuaValue s2, LuaValue item) { return valueOf(item.tojstring()); } });
            m2.set("__tostring", new OneArgFunction() { public LuaValue call(LuaValue s2) { return valueOf("Enum." + k.tojstring()); } });
            e.setmetatable(m2);
            ((LuaTable) self).rawset(k, e);
            return e; } });
        root.setmetatable(mt);
        return root;
    }

    /** Roblox-style Color3: components 0..1. fromRGB 0..255, fromHex, fromHSV */
    public static LuaTable color3Lib() {
        LuaTable t = new LuaTable();
        t.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            return new ColorL((int) Math.round(a.optdouble(1 + o, 0) * 255), (int) Math.round(a.optdouble(2 + o, 0) * 255), (int) Math.round(a.optdouble(3 + o, 0) * 255)); } });
        t.set("fromRGB", new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            return new ColorL(a.optint(1 + o, 0), a.optint(2 + o, 0), a.optint(3 + o, 0)); } });
        OneArgFunction hex = new OneArgFunction() { public LuaValue call(LuaValue s) { int c = ColorL.parse(s.checkjstring()); return new ColorL(c >> 16 & 255, c >> 8 & 255, c & 255); } };
        t.set("fromHex", hex); t.set("hex", hex);
        t.set("fromHSV", new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            int c = java.awt.Color.HSBtoRGB((float) a.optdouble(1 + o, 0), (float) a.optdouble(2 + o, 0), (float) a.optdouble(3 + o, 0)) & 0xFFFFFF;
            return new ColorL(c >> 16 & 255, c >> 8 & 255, c & 255); } });
        return t;
    }
}
