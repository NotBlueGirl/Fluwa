package net.idea.fluwa.lua;

/** Local (same-side) event: BindableEvent:Fire(...), .Event:Connect(fn) */
public class BindableEvent extends LObj {
    final Signal event = new Signal("Event");
    public BindableEvent() { super("BindableEvent"); }
    @Override protected org.luaj.vm2.LuaValue getProp(String k) {
        if (k.equals("Event")) return event;
        return super.getProp(k);
    }
    static { reg(BindableEvent.class, "Fire", (s, a) -> { ((BindableEvent) s).event.fire(a); return NONE; }); }
}
