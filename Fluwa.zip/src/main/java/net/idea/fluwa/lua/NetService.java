package net.idea.fluwa.lua;

import com.google.gson.*;
import net.idea.fluwa.Config;
import org.luaj.vm2.*;

import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/**
 * getAccess("NET") - low level networking separate from Event: TCP / UDP servers and clients, HTTP, WebSocket,
 * JSON, hashing, Base64, DNS, ping. Sockets need netEnabled=true, HTTP needs httpEnabled=true (config/fluwa-common.toml).
 * Protocols: "TCP" (raw chunks), "LINE" (newline separated text over TCP), "UDP".
 */
public final class NetService extends EvObj {
    final FluwaRuntime r;
    int timeoutMs = 10000;
    final Set<Closeable> open = ConcurrentHashMap.newKeySet();

    public NetService(FluwaRuntime r) {
        super("Service"); this.r = r; name = "NET";
        r.onClose(this::closeAll);
    }
    @Override protected boolean threadSafe() { return true; }

    void closeAll() { for (Closeable c : new ArrayList<>(open)) { try { c.close(); } catch (Exception ignored) {} } open.clear(); }

    static void checkNet() {
        if (!Config.netEnabled) throw new LuaError("NET sockets are disabled: set netEnabled=true in config/fluwa-common.toml");
    }
    void track(Closeable c) {
        if (open.size() >= Config.netMaxSockets) throw new LuaError("Too many open NET sockets (netMaxSockets=" + Config.netMaxSockets + ")");
        open.add(c);
    }
    static String proto(String p) {
        String s = p == null ? "TCP" : p.toUpperCase(Locale.ROOT);
        if (!s.equals("TCP") && !s.equals("UDP") && !s.equals("LINE")) throw new LuaError("Unknown protocol " + p + " (TCP, LINE, UDP)");
        return s;
    }

    static void daemon(String n, Runnable r) { Thread t = new Thread(r, n); t.setDaemon(true); t.start(); }

    // ================================================================ packet
    public static final class Packet extends LObj {
        byte[] buf = new byte[0]; int read; String sender = "", receiver = "", protocol = "TCP"; final double time = System.currentTimeMillis() / 1000.0;
        public Packet() { super("NetPacket"); }
        Packet(byte[] b, String from, String proto) { this(); buf = b; sender = from; protocol = proto; }
        @Override protected boolean threadSafe() { return true; }
        void put(byte[] b) { byte[] n = Arrays.copyOf(buf, buf.length + b.length); System.arraycopy(b, 0, n, buf.length, b.length); buf = n; }
        ByteBuffer need(int n) { if (read + n > buf.length) throw new LuaError("NetPacket: not enough data"); ByteBuffer bb = ByteBuffer.wrap(buf, read, n); read += n; return bb; }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Data": return LuaString.valueOf(buf);
                case "Size": return valueOf(buf.length);
                case "Sender": return valueOf(sender);
                case "Receiver": return valueOf(receiver);
                case "Protocol": return valueOf(protocol);
                case "Timestamp": return valueOf(time);
                case "Position": return valueOf(read);
            }
            return super.getProp(k);
        }
        static {
            reg(Packet.class, "Read", (s, a) -> {
                Packet p = (Packet) s; String t = a.optjstring(1, "string").toLowerCase(Locale.ROOT);
                switch (t) {
                    case "string", "all", "text" -> { String v = new String(p.buf, p.read, p.buf.length - p.read, StandardCharsets.UTF_8); p.read = p.buf.length; return valueOf(v); }
                    case "line" -> { int i = p.read; while (i < p.buf.length && p.buf[i] != '\n') i++;
                        String v = new String(p.buf, p.read, i - p.read, StandardCharsets.UTF_8).replace("\r", ""); p.read = Math.min(p.buf.length, i + 1); return valueOf(v); }
                    case "string16", "utf" -> { int n = p.need(2).getShort() & 0xFFFF; ByteBuffer b = p.need(n); return valueOf(new String(p.buf, b.position(), n, StandardCharsets.UTF_8)); }
                    case "byte" -> { return valueOf(p.need(1).get() & 255); }
                    case "bool", "boolean" -> { return valueOf(p.need(1).get() != 0); }
                    case "short" -> { return valueOf(p.need(2).getShort()); }
                    case "int" -> { return valueOf(p.need(4).getInt()); }
                    case "long" -> { return valueOf((double) p.need(8).getLong()); }
                    case "float" -> { return valueOf(p.need(4).getFloat()); }
                    case "double" -> { return valueOf(p.need(8).getDouble()); }
                    case "number" -> { String v = new String(p.buf, p.read, p.buf.length - p.read, StandardCharsets.UTF_8).trim().split("\\s+")[0];
                        p.read = p.buf.length; try { return valueOf(Double.parseDouble(v)); } catch (NumberFormatException e) { return NIL; } }
                    case "json" -> { String v = new String(p.buf, p.read, p.buf.length - p.read, StandardCharsets.UTF_8); p.read = p.buf.length;
                        try { return Chromium.fromJson(JsonParser.parseString(v)); } catch (JsonParseException e) { throw new LuaError("NetPacket: bad JSON"); } }
                }
                throw new LuaError("NetPacket:Read unknown type " + t); });
            reg(Packet.class, "Write", (s, a) -> { Packet p = (Packet) s; p.put(bytes(a.arg1(), a.optjstring(2, null))); return s; });
            reg(Packet.class, "GetSize", (s, a) -> valueOf(((Packet) s).buf.length));
            reg(Packet.class, "Clear", (s, a) -> { Packet p = (Packet) s; p.buf = new byte[0]; p.read = 0; return NONE; });
            reg(Packet.class, "Reset", (s, a) -> { ((Packet) s).read = 0; return NONE; });
        }
    }

    static byte[] bytes(LuaValue v, String type) {
        if (v instanceof Packet p) return p.buf.clone();
        if (type != null) {
            ByteBuffer b;
            switch (type.toLowerCase(Locale.ROOT)) {
                case "byte" -> { return new byte[]{(byte) v.checkint()}; }
                case "bool", "boolean" -> { return new byte[]{(byte) (v.toboolean() ? 1 : 0)}; }
                case "short" -> b = ByteBuffer.allocate(2).putShort((short) v.checkint());
                case "int" -> b = ByteBuffer.allocate(4).putInt(v.checkint());
                case "long" -> b = ByteBuffer.allocate(8).putLong(v.checklong());
                case "float" -> b = ByteBuffer.allocate(4).putFloat((float) v.checkdouble());
                case "double" -> b = ByteBuffer.allocate(8).putDouble(v.checkdouble());
                case "string16", "utf" -> { byte[] s = v.tojstring().getBytes(StandardCharsets.UTF_8); b = ByteBuffer.allocate(2 + s.length).putShort((short) s.length).put(s); }
                case "line" -> { return (v.tojstring() + "\n").getBytes(StandardCharsets.UTF_8); }
                case "json" -> { return new Gson().toJson(Chromium.toJson(v, 0)).getBytes(StandardCharsets.UTF_8); }
                default -> { return v.tojstring().getBytes(StandardCharsets.UTF_8); }
            }
            return b.array();
        }
        if (v.istable() && !(v instanceof LObj)) return new Gson().toJson(Chromium.toJson(v, 0)).getBytes(StandardCharsets.UTF_8);
        if (v.type() == TSTRING) return copy(v.checkstring());
        return v.tojstring().getBytes(StandardCharsets.UTF_8);
    }
    static byte[] copy(LuaString s) { byte[] b = new byte[s.m_length]; System.arraycopy(s.m_bytes, s.m_offset, b, 0, s.m_length); return b; }

    // ================================================================ client (one connection)
    public final class Client extends EvObj {
        final String host, protocol; final int port;
        Socket sock; DatagramSocket udp; SocketAddress udpTo; Server owner;
        volatile boolean connected; int timeout = timeoutMs; long ping = -1;
        Client(String host, int port, String protocol) { super("NetClient"); this.host = host; this.port = port; this.protocol = protocol; name = host + ":" + port; }
        @Override protected boolean threadSafe() { return true; }

        void startReader() {
            daemon("Fluwa NET " + name, () -> {
                try (InputStream in = sock.getInputStream()) {
                    if ("LINE".equals(protocol)) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                        String ln;
                        while ((ln = br.readLine()) != null) deliver(ln.getBytes(StandardCharsets.UTF_8));
                    } else {
                        byte[] b = new byte[65536]; int n;
                        while ((n = in.read(b)) > 0) deliver(Arrays.copyOf(b, n));
                    }
                    closed("EOF");
                } catch (IOException e) { closed(connected ? e.getMessage() : "closed"); }
            });
        }
        void deliver(byte[] data) {
            Packet p = new Packet(data, host + ":" + port, protocol);
            p.receiver = owner != null ? "server:" + owner.port : "client";
            if (owner != null) owner.fireAsync("E_Packet", this, p);
            fireAsync("E_Packet", p);
        }
        void closed(String reason) {
            if (!connected) return;
            connected = false;
            open.remove(sockCloser);
            if (owner != null) { owner.clients.remove(this); owner.fireAsync("E_ClientDisconnect", this); }
            fireAsync("E_Disconnect", valueOf(reason == null ? "closed" : reason));
        }
        final Closeable sockCloser = () -> close("closed");
        void close(String reason) {
            try { if (sock != null) sock.close(); } catch (IOException ignored) {}
            if (udp != null && owner == null) udp.close();
            closed(reason);
        }
        void send(byte[] b) {
            if (!connected) throw new LuaError("NetClient is not connected");
            try {
                if (udp != null) udp.send(new DatagramPacket(b, b.length, udpTo));
                else { if ("LINE".equals(protocol) && (b.length == 0 || b[b.length - 1] != '\n')) b = Arrays.copyOf(b, b.length + 1); if ("LINE".equals(protocol)) b[b.length - 1] = '\n';
                    synchronized (this) { sock.getOutputStream().write(b); sock.getOutputStream().flush(); } }
            } catch (IOException e) { fireAsync("E_Error", valueOf(e.toString())); close(e.getMessage()); }
        }
        long measurePing() {
            long t = System.nanoTime();
            try (Socket s = new Socket()) { s.connect(new InetSocketAddress(host, port), timeout); ping = (System.nanoTime() - t) / 1_000_000; }
            catch (IOException e) { ping = -1; }
            return ping;
        }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Host": return valueOf(host);
                case "Port": return valueOf(port);
                case "Protocol": return valueOf(protocol);
                case "IsConnected": return valueOf(connected);
                case "Ping": return valueOf(ping);
                case "Timeout": return valueOf(timeout / 1000.0);
                case "LocalIP": return valueOf(sock != null ? sock.getLocalAddress().getHostAddress() : udp != null ? udp.getLocalAddress().getHostAddress() : "");
                case "RemoteIP": return valueOf(sock != null && sock.getInetAddress() != null ? sock.getInetAddress().getHostAddress() : host);
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            if (k.equals("Timeout")) { setTimeout(v.checkdouble()); return true; }
            return super.setProp(k, v);
        }
        void setTimeout(double s) { timeout = (int) (s * 1000); try { if (sock != null) sock.setSoTimeout(0); } catch (IOException ignored) {} }
    }

    // ================================================================ server
    public final class Server extends EvObj {
        final int port; final String protocol;
        ServerSocket ss; DatagramSocket udp;
        volatile boolean running; int maxClients = 64, timeout = timeoutMs;
        final List<Client> clients = new CopyOnWriteArrayList<>();
        final Map<String, Client> udpPeers = new ConcurrentHashMap<>();
        final Closeable closer = this::stop;
        Server(int port, String protocol) { super("NetServer"); this.port = port; this.protocol = protocol; name = protocol + ":" + port; }
        @Override protected boolean threadSafe() { return true; }

        void start() {
            if (running) return;
            checkNet(); track(closer);
            try {
                if ("UDP".equals(protocol)) { udp = new DatagramSocket(port); running = true; daemon("Fluwa NET UDP " + port, this::udpLoop); }
                else { ss = new ServerSocket(port); running = true; daemon("Fluwa NET accept " + port, this::acceptLoop); }
            } catch (IOException e) { open.remove(closer); throw new LuaError("NET: can't listen on port " + port + ": " + e.getMessage()); }
        }
        void acceptLoop() {
            while (running) {
                try {
                    Socket s = ss.accept();
                    if (clients.size() >= maxClients) { s.close(); continue; }
                    Client c = new Client(s.getInetAddress().getHostAddress(), s.getPort(), protocol);
                    c.sock = s; c.owner = this; c.connected = true;
                    clients.add(c);
                    fireAsync("E_ClientConnect", c);
                    c.startReader();
                } catch (IOException e) { if (running) fireAsync("E_Error", valueOf(e.toString())); }
            }
        }
        void udpLoop() {
            byte[] b = new byte[65507];
            while (running) {
                try {
                    DatagramPacket dp = new DatagramPacket(b, b.length);
                    udp.receive(dp);
                    String key = dp.getAddress().getHostAddress() + ":" + dp.getPort();
                    Client c = udpPeers.computeIfAbsent(key, k -> {
                        Client n = new Client(dp.getAddress().getHostAddress(), dp.getPort(), "UDP");
                        n.udp = udp; n.udpTo = dp.getSocketAddress(); n.owner = this; n.connected = true;
                        clients.add(n); fireAsync("E_ClientConnect", n); return n;
                    });
                    c.deliver(Arrays.copyOf(dp.getData(), dp.getLength()));
                } catch (IOException e) { if (running) fireAsync("E_Error", valueOf(e.toString())); }
            }
        }
        void stop() {
            if (!running) return;
            running = false;
            try { if (ss != null) ss.close(); } catch (IOException ignored) {}
            if (udp != null) udp.close();
            for (Client c : clients) c.close("server stopped");
            clients.clear(); udpPeers.clear();
            open.remove(closer);
        }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Port": return valueOf(ss != null ? ss.getLocalPort() : port);
                case "Protocol": return valueOf(protocol);
                case "IsRunning": return valueOf(running);
                case "Clients": return list(clients);
                case "MaxClients": return valueOf(maxClients);
                case "Timeout": return valueOf(timeout / 1000.0);
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            switch (k) {
                case "MaxClients": maxClients = Math.max(1, v.checkint()); return true;
                case "Timeout": timeout = (int) (v.checkdouble() * 1000); return true;
            }
            return super.setProp(k, v);
        }
    }

    // ================================================================ HTTP response
    public static final class Response extends LObj {
        int status; Map<String, List<String>> headers = Map.of(); byte[] body = new byte[0]; String url = ""; double time;
        Response() { super("HTTPResponse"); }
        @Override protected boolean threadSafe() { return true; }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Status": case "StatusCode": return valueOf(status);
                case "Success": return valueOf(status >= 200 && status < 300);
                case "Headers": { LuaTable t = new LuaTable(); headers.forEach((a, b) -> t.set(a, String.join(", ", b))); return t; }
                case "Body": return LuaString.valueOf(body);
                case "URL": return valueOf(url);
                case "Time": return valueOf(time);
            }
            return super.getProp(k);
        }
        static {
            reg(Response.class, "JSON", (s, a) -> { try { return Chromium.fromJson(JsonParser.parseString(new String(((Response) s).body, StandardCharsets.UTF_8))); }
                catch (JsonParseException e) { throw new LuaError("Response is not JSON"); } });
            reg(Response.class, "Text", (s, a) -> valueOf(new String(((Response) s).body, StandardCharsets.UTF_8)));
            reg(Response.class, "Binary", (s, a) -> LuaString.valueOf(((Response) s).body));
            reg(Response.class, "GetHeader", (s, a) -> { String n = a.checkjstring(1);
                for (var e : ((Response) s).headers.entrySet()) if (e.getKey().equalsIgnoreCase(n)) return valueOf(String.join(", ", e.getValue()));
                return NIL; });
        }
    }

    // ================================================================ WebSocket
    public final class WS extends EvObj implements WebSocket.Listener {
        final String url; volatile WebSocket ws; volatile boolean isOpen; long ping = -1; volatile long pingSent;
        final StringBuilder partial = new StringBuilder();
        final Closeable closer = () -> close("closed");
        WS(String url) { super("WebSocket"); this.url = url; name = url; }
        @Override protected boolean threadSafe() { return true; }
        @Override public void onOpen(WebSocket w) { isOpen = true; fireAsync("E_Open"); w.request(1); }
        @Override public CompletionStage<?> onText(WebSocket w, CharSequence d, boolean last) {
            partial.append(d);
            if (last) { String m = partial.toString(); partial.setLength(0); fireAsync("E_Message", valueOf(m)); }
            w.request(1); return null;
        }
        @Override public CompletionStage<?> onBinary(WebSocket w, ByteBuffer d, boolean last) {
            byte[] b = new byte[d.remaining()]; d.get(b); fireAsync("E_Message", LuaString.valueOf(b)); w.request(1); return null;
        }
        @Override public CompletionStage<?> onPong(WebSocket w, ByteBuffer m) { ping = (System.nanoTime() - pingSent) / 1_000_000; w.request(1); return null; }
        @Override public CompletionStage<?> onClose(WebSocket w, int code, String reason) { isOpen = false; open.remove(closer); fireAsync("E_Close", valueOf(reason == null || reason.isEmpty() ? "code " + code : reason)); return null; }
        @Override public void onError(WebSocket w, Throwable e) { isOpen = false; open.remove(closer); fireAsync("E_Error", valueOf(String.valueOf(e.getMessage()))); }
        void close(String r) { if (ws != null && isOpen) { try { ws.sendClose(WebSocket.NORMAL_CLOSURE, r); } catch (Exception ignored) {} } isOpen = false; open.remove(closer); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "URL": return valueOf(url);
                case "IsOpen": return valueOf(isOpen);
                case "Ping": return valueOf(ping);
            }
            return super.getProp(k);
        }
    }

    static final HttpClient HTTP = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(10)).build();

    Response http(String method, String url, LuaValue headers, LuaValue body) throws Exception {
        URI u = Chromium.check(url);
        Chromium.checkAddress(u);
        HttpRequest.Builder b = HttpRequest.newBuilder(u).timeout(Duration.ofMillis(timeoutMs));
        byte[] data = body.isnil() ? null : bytes(body, null);
        b.method(method.toUpperCase(Locale.ROOT), data == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(data));
        b.header("User-Agent", "Fluwa/" + Services.VERSION);
        if (body.istable() && !(body instanceof LObj)) b.header("Content-Type", "application/json");
        if (headers.istable()) for (LuaValue k = headers.next(NIL).arg1(); !k.isnil(); k = headers.next(k).arg1()) b.setHeader(k.tojstring(), headers.get(k).tojstring());
        long t = System.nanoTime();
        HttpResponse<byte[]> res = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
        Response r = new Response();
        r.status = res.statusCode(); r.headers = res.headers().map(); r.body = res.body(); r.url = res.uri().toString(); r.time = (System.nanoTime() - t) / 1e9;
        return r;
    }

    static String hex(byte[] b) { StringBuilder s = new StringBuilder(); for (byte x : b) s.append(String.format("%02x", x)); return s.toString(); }

    static {
        Class<NetService> C = NetService.class;
        reg(C, "CreateServer|CS|TCPSocket", (s, a) -> { NetService n = (NetService) s; checkNet();
            String p = a.optjstring(2, "TCP");
            return n.new Server(a.checkint(1), proto(p)); });
        reg(C, "UDPSocket", (s, a) -> { checkNet(); NetService.Server sv = ((NetService) s).new Server(a.checkint(1), "UDP"); return sv; });
        reg(C, "Connect|Conn", (s, a) -> {
            NetService n = (NetService) s; checkNet();
            String host = a.checkjstring(1); int port = a.checkint(2); String p = proto(a.optjstring(3, "TCP"));
            Client c = n.new Client(host, port, p);
            return AsyncTask.await("NET:Connect " + host + ":" + port, () -> {
                n.track(c.sockCloser);
                try {
                    if (p.equals("UDP")) { c.udp = new DatagramSocket(); c.udpTo = new InetSocketAddress(host, port); c.connected = true;
                        DatagramSocket ds = c.udp;
                        daemon("Fluwa NET UDP client", () -> { byte[] b = new byte[65507];
                            while (!ds.isClosed()) { try { DatagramPacket dp = new DatagramPacket(b, b.length); ds.receive(dp); c.deliver(Arrays.copyOf(dp.getData(), dp.getLength())); } catch (IOException e) { break; } } }); }
                    else { Socket so = new Socket(); so.connect(new InetSocketAddress(host, port), c.timeout); c.sock = so; c.connected = true; c.startReader(); }
                } catch (IOException e) { n.open.remove(c.sockCloser); throw new LuaError("NET:Connect failed: " + e.getMessage()); }
                c.fireAsync("E_Connect");
                return c;
            }); });
        reg(C, "HTTP|Request", (s, a) -> { NetService n = (NetService) s;
            String m = a.checkjstring(1), url = a.checkjstring(2); LuaValue h = a.arg(3), b = a.arg(4);
            return AsyncTask.await("NET:HTTP " + url, () -> n.http(m, url, h, b)); });
        reg(C, "WebSocket|WS", (s, a) -> { NetService n = (NetService) s; checkNet();
            String url = a.checkjstring(1);
            if (!url.startsWith("ws://") && !url.startsWith("wss://")) throw new LuaError("WebSocket URL must start with ws:// or wss://");
            WS w = n.new WS(url);
            n.track(w.closer);
            HTTP.newWebSocketBuilder().connectTimeout(Duration.ofMillis(n.timeoutMs)).buildAsync(URI.create(url), w)
                .whenComplete((ws, err) -> { if (err != null) { n.open.remove(w.closer); w.fireAsync("E_Error", valueOf(String.valueOf(err.getMessage()))); } else w.ws = ws; });
            return w; });
        reg(C, "JSONEncode|JE", (s, a) -> valueOf(new Gson().toJson(Chromium.toJson(a.arg1(), 0))));
        reg(C, "JSONDecode|JD", (s, a) -> { try { return Chromium.fromJson(JsonParser.parseString(a.checkjstring(1))); }
            catch (JsonParseException e) { throw new LuaError("JSONDecode: " + e.getMessage()); } });
        reg(C, "Hash", (s, a) -> {
            String algo = a.checkjstring(1).toUpperCase(Locale.ROOT).replace("-", ""); byte[] d = bytes(a.arg(2), null);
            if (algo.equals("CRC32")) { var c = new java.util.zip.CRC32(); c.update(d); return valueOf(String.format("%08x", c.getValue())); }
            String j = switch (algo) { case "MD5" -> "MD5"; case "SHA1" -> "SHA-1"; case "SHA256" -> "SHA-256"; case "SHA384" -> "SHA-384"; case "SHA512" -> "SHA-512"; default -> throw new LuaError("Unknown hash " + algo + " (md5, sha1, sha256, sha384, sha512, crc32)"); };
            try { return valueOf(hex(MessageDigest.getInstance(j).digest(d))); } catch (Exception e) { throw new LuaError(e.toString()); } });
        reg(C, "Base64Encode", (s, a) -> valueOf(Base64.getEncoder().encodeToString(bytes(a.arg1(), null))));
        reg(C, "Base64Decode", (s, a) -> { try { return LuaString.valueOf(Base64.getDecoder().decode(a.checkjstring(1).trim())); } catch (IllegalArgumentException e) { throw new LuaError("Base64Decode: bad input"); } });
        reg(C, "Ping", (s, a) -> { NetService n = (NetService) s; checkNet(); String host = a.checkjstring(1); int port = a.optint(2, 80);
            return AsyncTask.await("NET:Ping", () -> { long t = System.nanoTime();
                try (Socket so = new Socket()) { so.connect(new InetSocketAddress(host, port), n.timeoutMs); return valueOf((System.nanoTime() - t) / 1e6); }
                catch (IOException e) { return valueOf(-1); } }); });
        reg(C, "ResolveDNS", (s, a) -> { String h = a.checkjstring(1);
            return AsyncTask.await("NET:ResolveDNS", () -> { try { return valueOf(InetAddress.getByName(h).getHostAddress()); } catch (UnknownHostException e) { return NIL; } }); });
        reg(C, "GetLocalIP", (s, a) -> AsyncTask.await("NET:GetLocalIP", () -> {
            try (DatagramSocket d = new DatagramSocket()) { d.connect(InetAddress.getByName("8.8.8.8"), 53); String ip = d.getLocalAddress().getHostAddress(); if (!ip.equals("0.0.0.0")) return valueOf(ip); }
            catch (Exception ignored) {}
            return valueOf(InetAddress.getLocalHost().getHostAddress()); }));
        reg(C, "GetPublicIP", (s, a) -> { checkNet(); NetService n = (NetService) s;
            return AsyncTask.await("NET:GetPublicIP", () -> { HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create("https://api.ipify.org")).timeout(Duration.ofMillis(n.timeoutMs)).build(), HttpResponse.BodyHandlers.ofString());
                return valueOf(r.body().trim()); }); });
        reg(C, "SetTimeout", (s, a) -> { ((NetService) s).timeoutMs = (int) Math.max(100, a.checkdouble(1) * 1000); return NONE; });
        reg(C, "GetTimeout", (s, a) -> valueOf(((NetService) s).timeoutMs / 1000.0));
        reg(C, "CloseAll", (s, a) -> { ((NetService) s).closeAll(); return NONE; });
        reg(C, "NewPacket|Packet", (s, a) -> { Packet p = new Packet(); for (int i = 1; i <= a.narg(); i++) p.put(bytes(a.arg(i), null)); return p; });

        // NetServer
        reg(Server.class, "Start", (s, a) -> { ((Server) s).start(); return s; });
        reg(Server.class, "Stop", (s, a) -> { ((Server) s).stop(); return NONE; });
        reg(Server.class, "Broadcast", (s, a) -> { byte[] b = bytes(a.arg1(), a.optjstring(2, null)); for (Client c : ((Server) s).clients) c.send(b); return NONE; });
        reg(Server.class, "SendTo", (s, a) -> { checkObj(a.arg1(), Client.class).send(bytes(a.arg(2), a.optjstring(3, null))); return NONE; });
        reg(Server.class, "Kick", (s, a) -> { Client c = checkObj(a.arg1(), Client.class); if (!a.isnil(2)) { try { c.send(a.checkjstring(2).getBytes(StandardCharsets.UTF_8)); } catch (LuaError ignored) {} } c.close(a.optjstring(2, "kicked")); return NONE; });
        reg(Server.class, "GetClients", (s, a) -> list(((Server) s).clients));
        // NetClient
        reg(Client.class, "Send", (s, a) -> { ((Client) s).send(bytes(a.arg1(), a.optjstring(2, null))); return NONE; });
        reg(Client.class, "Close|Disconnect", (s, a) -> { ((Client) s).close("closed by script"); return NONE; });
        reg(Client.class, "GetPing", (s, a) -> { Client c = (Client) s; return AsyncTask.await("NET:GetPing", () -> valueOf(c.measurePing())); });
        reg(Client.class, "SetTimeout", (s, a) -> { ((Client) s).setTimeout(a.checkdouble(1)); return NONE; });
        // WebSocket
        reg(WS.class, "Send", (s, a) -> { WS w = (WS) s; if (w.ws == null || !w.isOpen) throw new LuaError("WebSocket is not open");
            LuaValue v = a.arg1();
            if (v.istable() && !(v instanceof LObj)) w.ws.sendText(new Gson().toJson(Chromium.toJson(v, 0)), true); else w.ws.sendText(v.tojstring(), true);
            return NONE; });
        reg(WS.class, "Close", (s, a) -> { ((WS) s).close(a.optjstring(1, "closed")); return NONE; });
        reg(WS.class, "Ping", (s, a) -> { WS w = (WS) s; if (w.ws == null || !w.isOpen) return valueOf(-1);
            w.pingSent = System.nanoTime(); w.ws.sendPing(ByteBuffer.allocate(0)); return valueOf(w.ping); });
    }
}
