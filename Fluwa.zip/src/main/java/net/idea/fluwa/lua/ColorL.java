package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

/** Color.new(r, g, b) with 0..255 components, Color.fromRGB, Color.hex("#ff8800"). Numbers 0xRRGGBB are accepted too. */
public final class ColorL extends LObj {
    public final int r, g, b;

    public ColorL(int r, int g, int b) { super("Color"); this.r = clamp(r); this.g = clamp(g); this.b = clamp(b); }
    static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    public int rgb() { return (r << 16) | (g << 8) | b; }

    public static int check(LuaValue v) {
        if (v instanceof ColorL c) return c.rgb();
        if (v.isnumber()) return v.toint() & 0xFFFFFF;
        if (v.isstring()) return parse(v.tojstring());
        if (v.istable()) return new ColorL(v.get(1).toint(), v.get(2).toint(), v.get(3).toint()).rgb();
        throw new LuaError("Expected Color");
    }
    static int parse(String s) {
        try { return Integer.parseInt(s.replace("#", ""), 16) & 0xFFFFFF; } catch (NumberFormatException e) { throw new LuaError("Bad color " + s); }
    }

    @Override protected boolean threadSafe() { return true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) { case "R": return valueOf(r); case "G": return valueOf(g); case "B": return valueOf(b); case "Hex": return valueOf(String.format("#%06x", rgb())); }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) { throw new LuaError("Color is immutable"); }
    @Override public String tojstring() { return r + ", " + g + ", " + b; }
    @Override public boolean eq_b(LuaValue v) { return v instanceof ColorL o && o.rgb() == rgb(); }
    @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }

    public static LuaTable lib() {
        LuaTable t = new LuaTable();
        VarArgFunction nw = new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            return new ColorL(a.optint(1 + o, 0), a.optint(2 + o, 0), a.optint(3 + o, 0)); } };
        t.set("new", nw);
        t.set("fromRGB", nw);
        t.set("hex", new OneArgFunction() { public LuaValue call(LuaValue s) { int c = parse(s.checkjstring()); return new ColorL(c >> 16 & 255, c >> 8 & 255, c & 255); } });
        return t;
    }
}
