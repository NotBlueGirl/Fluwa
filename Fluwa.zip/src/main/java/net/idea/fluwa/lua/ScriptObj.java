package net.idea.fluwa.lua;

import org.luaj.vm2.*;

/**
 * v0.5.2 `script` - the object of the running script file, placed in the ZSpace tree:
 *   ServerScripts/Shop/Main.lua  ->  script.Name = "Main", script.Parent = ServerScripts.Shop (Folder),
 *   script.Parent.Parent = ServerScripts, script.Parent.Parent.Parent = game.
 * Sibling values / folders / scripts are reachable as script.Parent.Coins, script.Parent:WaitForChild("Config").
 */
public class ScriptObj extends LObj {
    public final String path, section, source;

    public ScriptObj(String cls, String path, String section, String source) {
        super(cls);
        this.path = path; this.section = section; this.source = source;
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Source": return valueOf(source);
            case "Path": return valueOf(path);
            case "Section": return valueOf(section);
            case "RunContext": return valueOf(rt != null && rt.server ? "Server" : "Client");
        }
        return super.getProp(k);
    }

    @Override public boolean isA(String cls) {
        return super.isA(cls) || cls.equals("BaseScript") || cls.equals("LuaSourceContainer") || (cls.equals("Script") && className.equals("LocalScript"));
    }

    /** sections whose files become script objects */
    static final java.util.Set<String> SECTIONS = java.util.Set.of("InitScripts", "ServerScripts", "ClientScripts", "UI", "Workspace");

    /** creates (or reuses) the script object for a chunk name like "ServerScripts/Shop/Main.lua"; null if it is not a file */
    static ScriptObj forChunk(FluwaRuntime rt, String name, String source) {
        String n = name.startsWith("ZSpace/") ? name.substring(7) : name;
        if (!n.endsWith(".lua")) n = n + ".lua";
        String[] seg = n.split("/");
        if (seg.length < 2 || !SECTIONS.contains(seg[0])) return null;
        LObj cur = ItemTree.root(rt, seg[0]);
        for (int i = 1; i < seg.length - 1; i++) {
            LObj c = cur.findChild(seg[i]);
            if (c == null) { c = new LObj("Folder"); c.name = seg[i]; c.setParent(cur); }
            cur = c;
        }
        String file = seg[seg.length - 1];
        String base = file.endsWith(".lua") ? file.substring(0, file.length() - 4) : file;
        String cls = seg[0].equals("ServerScripts") || (seg[0].equals("InitScripts") && rt.server) ? "Script" : "LocalScript";
        LObj ex = cur.findChild(base);
        if (ex instanceof ScriptObj so && so.path.equals(n)) so.setParent(null); // re-run: replace the old object
        ScriptObj s = new ScriptObj(cls, n, seg[0], source);
        s.name = base;
        s.setParent(cur);
        return s;
    }
}
