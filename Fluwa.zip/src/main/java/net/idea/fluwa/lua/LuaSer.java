package net.idea.fluwa.lua;

import org.luaj.vm2.*;

import java.io.*;

/**
 * Serialises event arguments: nil, boolean, number, string, Vector3, CFrame, (nested) tables and object references:
 * placed Blocks (dimension + position), Entities / Players (UUID) and hierarchy objects (full name path) are
 * turned back into the same objects on the other side (nil if they don't exist there).
 */
public final class LuaSer {
    private LuaSer() {}

    public static byte[] encode(LuaValue v) {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            DataOutputStream o = new DataOutputStream(bo);
            write(o, v, 0);
            return bo.toByteArray();
        } catch (IOException e) { throw new LuaError(e.getMessage()); }
    }

    /** runtime used to resolve object references while decoding (set by decode(bytes, rt)) */
    private static final ThreadLocal<net.idea.fluwa.api.GameRuntime> RT = new ThreadLocal<>();

    public static LuaValue decode(byte[] b, net.idea.fluwa.api.GameRuntime rt) {
        net.idea.fluwa.api.GameRuntime old = RT.get();
        RT.set(rt);
        try { return decode(b); } finally { RT.set(old); }
    }

    public static LuaValue decode(byte[] b) {
        try { return read(new DataInputStream(new ByteArrayInputStream(b))); }
        catch (IOException e) { return LuaValue.NIL; }
    }

    private static void write(DataOutputStream o, LuaValue v, int depth) throws IOException {
        if (depth > 32) throw new LuaError("Event argument nested too deeply");
        if (v.isnil()) o.writeByte(0);
        else if (v.isboolean()) { o.writeByte(1); o.writeBoolean(v.toboolean()); }
        else if (v.type() == LuaValue.TNUMBER) { o.writeByte(2); o.writeDouble(v.todouble()); }
        else if (v.type() == LuaValue.TSTRING) { o.writeByte(3); o.writeUTF(v.tojstring()); }
        else if (v instanceof Vec3L p) { o.writeByte(4); o.writeDouble(p.x); o.writeDouble(p.y); o.writeDouble(p.z); }
        else if (v instanceof CFrameL c) { o.writeByte(5); o.writeDouble(c.x); o.writeDouble(c.y); o.writeDouble(c.z); for (double d : c.r) o.writeDouble(d); }
        else if (v.istable()) {
            o.writeByte(6);
            LuaTable t = v.checktable();
            LuaValue k = LuaValue.NIL;
            int n = 0;
            while (true) { Varargs e = t.next(k); if ((k = e.arg1()).isnil()) break; n++; }
            o.writeInt(n);
            k = LuaValue.NIL;
            while (true) { Varargs e = t.next(k); if ((k = e.arg1()).isnil()) break; write(o, k, depth + 1); write(o, e.arg(2), depth + 1); }
        } else if (v instanceof net.idea.fluwa.api.BlockObj b && b.rawLevel() != null) {
            o.writeByte(7); o.writeUTF(b.rawLevel().dimension().location().toString());
            o.writeInt(b.blockPos().getX()); o.writeInt(b.blockPos().getY()); o.writeInt(b.blockPos().getZ());
        } else if (v instanceof net.idea.fluwa.api.EntityObj e && e.raw() != null) {
            o.writeByte(8); o.writeUTF(e.raw().getUUID().toString());
        } else if (v instanceof LObj obj) {
            o.writeByte(9); o.writeUTF(obj.fullName()); o.writeUTF(obj.getName());
        }
        else throw new LuaError("Can't send " + v.typename() + " over the network");
    }

    private static LuaValue read(DataInputStream i) throws IOException {
        switch (i.readByte()) {
            case 0: return LuaValue.NIL;
            case 1: return LuaValue.valueOf(i.readBoolean());
            case 2: return LuaValue.valueOf(i.readDouble());
            case 3: return LuaValue.valueOf(i.readUTF());
            case 4: return new Vec3L(i.readDouble(), i.readDouble(), i.readDouble());
            case 5: { double x = i.readDouble(), y = i.readDouble(), z = i.readDouble(); double[] r = new double[9];
                for (int k = 0; k < 9; k++) r[k] = i.readDouble(); return new CFrameL(x, y, z, r); }
            case 6: { int n = i.readInt(); LuaTable t = new LuaTable();
                for (int k = 0; k < n; k++) { LuaValue key = read(i); LuaValue val = read(i); if (!key.isnil()) t.set(key, val); }
                return t; }
            case 7: { String dim = i.readUTF(); int x = i.readInt(), y = i.readInt(), z = i.readInt();
                return resolveBlock(dim, x, y, z); }
            case 8: return resolveEntity(i.readUTF());
            case 9: { String path = i.readUTF(), name = i.readUTF(); LuaValue o = resolvePath(path); return o.isnil() ? LuaValue.valueOf(name) : o; }
        }
        return LuaValue.NIL;
    }

    private static LuaValue resolveBlock(String dim, int x, int y, int z) {
        net.idea.fluwa.api.GameRuntime rt = RT.get();
        if (rt == null) return new Vec3L(x, y, z);
        for (net.minecraft.world.level.Level l : rt.levels())
            if (l.dimension().location().toString().equals(dim)) return new net.idea.fluwa.api.BlockObj(l, new net.minecraft.core.BlockPos(x, y, z));
        return LuaValue.NIL;
    }

    private static LuaValue resolveEntity(String uuid) {
        net.idea.fluwa.api.GameRuntime rt = RT.get();
        if (rt == null) return LuaValue.NIL;
        java.util.UUID id;
        try { id = java.util.UUID.fromString(uuid); } catch (Exception e) { return LuaValue.NIL; }
        net.minecraft.world.entity.Entity e = rt.entityByUuid(id);
        LuaValue w = e == null ? null : rt.wrapEntity(e);
        return w == null ? LuaValue.NIL : w;
    }

    private static LuaValue resolvePath(String path) {
        net.idea.fluwa.api.GameRuntime rt = RT.get();
        if (rt == null || path == null || path.isEmpty()) return LuaValue.NIL;
        LuaValue g = rt.g.get("game");
        String[] seg = path.split("\\.");
        LuaValue cur = LuaValue.NIL;
        int start = 0;
        if (g instanceof LObj game) {
            if (seg[0].equals(game.getName())) { cur = game; start = 1; }
            else cur = game;
        }
        if (cur.isnil()) { cur = rt.g.get(seg[0]); start = 1; }
        for (int k = start; k < seg.length && cur instanceof LObj o; k++) {
            LObj c = o.findChild(seg[k]);
            if (c == null && k == 0) { LuaValue gv = rt.g.get(seg[0]); cur = gv instanceof LObj ? gv : LuaValue.NIL; continue; }
            cur = c == null ? LuaValue.NIL : c;
        }
        return cur instanceof LObj ? cur : LuaValue.NIL;
    }
}
