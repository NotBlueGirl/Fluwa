package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

/** Vector3 (Roblox semantics). Accepted everywhere a Vector3 is expected: Vector3, CFrame, {x,y,z}, {X=..,Y=..,Z=..} */
public final class Vec3L extends LObj {
    public final double x, y, z;
    static final LuaTable MT = new LuaTable();

    public Vec3L(double x, double y, double z) {
        super("Vector3");
        this.x = x; this.y = y; this.z = z;
        setmetatable(MT);
    }

    public static Vec3L of(net.minecraft.world.phys.Vec3 v) { return new Vec3L(v.x, v.y, v.z); }
    public static Vec3L of(net.minecraft.core.BlockPos p) { return new Vec3L(p.getX(), p.getY(), p.getZ()); }
    public net.minecraft.world.phys.Vec3 mc() { return new net.minecraft.world.phys.Vec3(x, y, z); }
    public net.minecraft.core.BlockPos pos() { return net.minecraft.core.BlockPos.containing(x, y, z); }

    public double mag() { return Math.sqrt(x * x + y * y + z * z); }
    public Vec3L add(Vec3L o) { return new Vec3L(x + o.x, y + o.y, z + o.z); }
    public Vec3L sub(Vec3L o) { return new Vec3L(x - o.x, y - o.y, z - o.z); }
    public Vec3L scale(double k) { return new Vec3L(x * k, y * k, z * k); }
    public double dot(Vec3L o) { return x * o.x + y * o.y + z * o.z; }
    public Vec3L cross(Vec3L o) { return new Vec3L(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x); }
    public Vec3L unit() { double m = mag(); return m == 0 ? new Vec3L(0, 0, 0) : scale(1 / m); }

    public static Vec3L check(LuaValue v) {
        if (v instanceof Vec3L p) return p;
        if (v instanceof CFrameL c) return c.pos();
        if (v.istable()) {
            LuaValue X = v.get(1).isnil() ? (v.get("X").isnil() ? v.get("x") : v.get("X")) : v.get(1);
            LuaValue Y = v.get(2).isnil() ? (v.get("Y").isnil() ? v.get("y") : v.get("Y")) : v.get(2);
            LuaValue Z = v.get(3).isnil() ? (v.get("Z").isnil() ? v.get("z") : v.get("Z")) : v.get(3);
            return new Vec3L(X.checkdouble(), Y.checkdouble(), Z.checkdouble());
        }
        throw new LuaError("Expected Vector3, got " + v.typename());
    }

    public static Vec3L opt(LuaValue v) { return v.isnil() ? null : check(v); }

    @Override protected boolean threadSafe() { return true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "X": case "x": return valueOf(x);
            case "Y": case "y": return valueOf(y);
            case "Z": case "z": return valueOf(z);
            case "Magnitude": case "magnitude": return valueOf(mag());
            case "Unit": case "unit": return unit();
        }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) { throw new LuaError("Vector3 is immutable"); }
    @Override public String tojstring() { return fmt(x) + ", " + fmt(y) + ", " + fmt(z); }
    static String fmt(double d) { return d == Math.rint(d) && Math.abs(d) < 1e15 ? String.valueOf((long) d) : String.valueOf(d); }

    @Override public boolean eq_b(LuaValue v) { return v instanceof Vec3L o && o.x == x && o.y == y && o.z == z; }
    @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }
    @Override public LuaValue cloneObj() { return new Vec3L(x, y, z); }

    static LuaValue num(LuaValue a, LuaValue b, char op) {
        if (a.isnumber()) { Vec3L v = check(b); double k = a.todouble();
            return op == '*' ? v.scale(k) : new Vec3L(k / v.x, k / v.y, k / v.z); }
        Vec3L v = check(a);
        if (b.isnumber()) { double k = b.todouble(); return op == '*' ? v.scale(k) : v.scale(1 / k); }
        Vec3L w = check(b);
        return op == '*' ? new Vec3L(v.x * w.x, v.y * w.y, v.z * w.z) : new Vec3L(v.x / w.x, v.y / w.y, v.z / w.z);
    }

    static {
        MT.set("__add", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return check(a).add(check(b)); } });
        MT.set("__sub", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return check(a).sub(check(b)); } });
        MT.set("__mul", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return num(a, b, '*'); } });
        MT.set("__div", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return num(a, b, '/'); } });
        MT.set("__unm", new OneArgFunction() { public LuaValue call(LuaValue a) { return check(a).scale(-1); } });
        MT.set("__eq", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return valueOf(a.eq_b(b)); } });
        MT.set("__tostring", new OneArgFunction() { public LuaValue call(LuaValue a) { return valueOf(a.tojstring()); } });
        reg(Vec3L.class, "Dot", (s, a) -> valueOf(((Vec3L) s).dot(check(a.arg1()))));
        reg(Vec3L.class, "Cross", (s, a) -> ((Vec3L) s).cross(check(a.arg1())));
        reg(Vec3L.class, "Lerp", (s, a) -> { Vec3L v = (Vec3L) s, w = check(a.arg1()); double t = a.checkdouble(2); return v.add(w.sub(v).scale(t)); });
        reg(Vec3L.class, "FuzzyEq", (s, a) -> valueOf(((Vec3L) s).sub(check(a.arg1())).mag() <= a.optdouble(2, 1e-5)));
        reg(Vec3L.class, "Floor", (s, a) -> { Vec3L v = (Vec3L) s; return new Vec3L(Math.floor(v.x), Math.floor(v.y), Math.floor(v.z)); });
    }

    /** Global "Vector3" library table */
    public static LuaTable lib() {
        LuaTable t = new LuaTable();
        t.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0; // allow Vector3:new(...)
            return new Vec3L(a.optdouble(1 + o, 0), a.optdouble(2 + o, 0), a.optdouble(3 + o, 0)); } });
        t.set("zero", new Vec3L(0, 0, 0));
        t.set("one", new Vec3L(1, 1, 1));
        t.set("xAxis", new Vec3L(1, 0, 0));
        t.set("yAxis", new Vec3L(0, 1, 0));
        t.set("zAxis", new Vec3L(0, 0, 1));
        return t;
    }
}
