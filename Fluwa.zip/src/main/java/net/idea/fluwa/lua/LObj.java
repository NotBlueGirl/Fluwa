package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.VarArgFunction;

import java.util.*;

/**
 * Base class of every Fluwa object visible from Lua (Roblox-like "Instance").
 * Universal members: Name, ClassName, Parent, Destroy(), GetChildren(), FindFirstChild(), IsA(),
 * ChildAdded / ChildRemoved events.
 */
public class LObj extends LuaUserdata {

    @FunctionalInterface
    public interface M { Varargs call(LObj self, Varargs a); }

    private static final Map<Class<?>, Map<String, M>> METHODS = new java.util.concurrent.ConcurrentHashMap<>();
    private static final Map<Class<?>, Map<String, LuaValue>> FN_CACHE = new java.util.concurrent.ConcurrentHashMap<>();

    /** Register a method callable as obj:Name(...). Several aliases may be given: "GetEffect|GE". */
    public static void reg(Class<?> cls, String names, M m) {
        for (String n : names.split("\\|")) METHODS.computeIfAbsent(cls, k -> new HashMap<>()).put(n, m);
    }

    public final FluwaRuntime rt = FluwaRuntime.current();
    public final String className;
    public String name;
    public LObj parent;
    public final List<LObj> children = new ArrayList<>();
    public boolean destroyed;
    private Signal childAdded, childRemoved;
    /** Free-form user fields (obj.MyField = 5) */
    protected Map<String, LuaValue> userFields;

    public LObj(String className) {
        super(new Object());
        this.className = className;
        this.name = className;
    }

    // ------------------------------------------------------------ indexing
    /** Pure value objects (Vector3, CFrame...) can be used from any thread without marshalling. */
    protected boolean threadSafe() { return false; }

    /** Runs s on the runtime's main (game) thread; scripts in coroutines run on helper threads. */
    protected <T> T main(java.util.function.Supplier<T> s) {
        if (threadSafe()) return s.get();
        FluwaRuntime r = rt != null ? rt : FluwaRuntime.current();
        return r == null ? s.get() : r.onMain(s);
    }

    @Override
    public LuaValue get(LuaValue key) {
        if (!key.isstring()) return NIL;
        String k = key.tojstring();
        if (k.equals("WaitForChild")) return WAIT_FOR_CHILD;
        LuaValue f = methodFn(k);
        if (f != null) return f;
        return main(() -> doGet(k));
    }

    private LuaValue doGet(String k) {
        checkAlive(k);
        LuaValue p = getProp(k);
        if (p != null) return p;
        if (userFields != null && userFields.containsKey(k)) return userFields.get(k);
        LObj c = findChild(k);
        if (c != null) return c;
        throw new LuaError(k + " is not a valid member of " + className + " \"" + name + "\"");
    }

    @Override
    public void set(LuaValue key, LuaValue value) {
        String k = key.checkjstring();
        main(() -> { doSet(k, value); return null; });
    }

    private void doSet(String k, LuaValue value) {
        checkAlive(k);
        if (setProp(k, value)) return;
        if (methodFn(k) != null || getProp(k) != null)
            throw new LuaError(k + " of " + className + " is read-only");
        if (userFields == null) userFields = new HashMap<>();
        userFields.put(k, value);
    }

    private void checkAlive(String k) {
        if (destroyed && !k.equals("Name") && !k.equals("ClassName") && !k.equals("Parent"))
            throw new LuaError("Object " + name + " was destroyed");
    }

    private LuaValue methodFn(String k) {
        for (Class<?> c = getClass(); c != null && LObj.class.isAssignableFrom(c); c = c.getSuperclass()) {
            Map<String, M> ms = METHODS.get(c);
            if (ms == null) continue;
            M m = ms.get(k);
            if (m == null) continue;
            final Class<?> owner = c;
            return FN_CACHE.computeIfAbsent(c, x -> new HashMap<>()).computeIfAbsent(k, x -> new VarArgFunction() {
                @Override
                public Varargs invoke(Varargs args) {
                    LuaValue s = args.arg1();
                    if (!(s instanceof LObj o) || !owner.isInstance(o))
                        throw new LuaError("Expected ':' not '.' calling member function " + k);
                    Varargs sub = args.subargs(2);
                    return o.main(() -> {
                        if (o.destroyed) throw new LuaError("Object " + o.name + " was destroyed");
                        Varargs r = m.call(o, sub);
                        return r == null ? NONE : r;
                    });
                }
            });
        }
        return null;
    }

    /** @return property value or null if no such property */
    protected LuaValue getProp(String k) {
        switch (k) {
            case "Name": return valueOf(getName());
            case "ClassName": return valueOf(className);
            case "Parent": return parent == null ? NIL : parent;
            case "ChildAdded": if (childAdded == null) childAdded = new Signal("ChildAdded"); return childAdded;
            case "ChildRemoved": if (childRemoved == null) childRemoved = new Signal("ChildRemoved"); return childRemoved;
        }
        return null;
    }

    /** @return true if handled */
    protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "Name": setName(v.checkjstring()); return true;
            case "Parent": setParent(v.isnil() ? null : (LObj) checkObj(v, LObj.class)); return true;
        }
        return false;
    }

    public String getName() { return name; }
    public LObj getParentObj() { return parent; }
    public boolean isDestroyed() { return destroyed; }
    public void setName(String n) { String o = name; name = n; renamed(o); }

    // ------------------------------------------------------------ hierarchy
    /** server hook: values / folders below a Player are replicated to that player's client (PlayerValues) */
    public interface TreeHook {
        Object before(LObj o);
        void after(LObj o, Object before);
        void valueChanged(ValueObj v);
    }
    public static volatile TreeHook HOOK;
    boolean hooked() { return HOOK != null && rt != null && rt.server && (this instanceof ValueObj || className.equals("Folder")); }

    public void setParent(LObj p) {
        if (p == this) throw new LuaError("Attempt to set parent of " + name + " to itself");
        for (LObj x = p; x != null; x = x.parent) if (x == this) throw new LuaError("Cyclic parenting");
        boolean hk = hooked();
        Object before = hk ? HOOK.before(this) : null;
        if (parent != null) { parent.children.remove(this); parent.onChildRemoved(this); }
        parent = p;
        if (p != null) { p.children.add(this); p.onChildAdded(this); }
        if (hk) HOOK.after(this, before);
    }

    /** rename that keeps replicated values in sync */
    protected final void renamed(String old) {
        if (!hooked() || old.equals(name)) return;
        String now = name;
        name = old; Object before = HOOK.before(this); name = now;
        HOOK.after(this, before);
    }

    protected void onChildAdded(LObj c) { if (childAdded != null) childAdded.fire(c); }
    protected void onChildRemoved(LObj c) { if (childRemoved != null) childRemoved.fire(c); }

    /** Children list; containers backed by the game (Players, Dimensions...) override this. */
    public List<LObj> listChildren() { return new ArrayList<>(children); }

    public LObj findChild(String n) {
        for (LObj c : listChildren()) if (n.equals(c.getName())) return c;
        return null;
    }

    public void destroy() {
        if (destroyed) return;
        for (LObj c : new ArrayList<>(children)) c.destroy();
        onDestroy();
        setParent(null);
        destroyed = true;
    }

    protected void onDestroy() {}

    public boolean isA(String cls) { return className.equals(cls) || "Instance".equals(cls); }

    @Override public String tojstring() { return main(this::getName); }   // getName may touch the world (Block): game thread
    @Override public String typename() { return "userdata"; }

    // ------------------------------------------------------------ helpers
    @SuppressWarnings("unchecked")
    public static <T> T checkObj(LuaValue v, Class<T> cls) {
        if (cls.isInstance(v)) return (T) v;
        throw new LuaError("Expected " + cls.getSimpleName().replace("Obj", "") + ", got " + (v instanceof LObj o ? o.className : v.typename()));
    }

    public static LuaTable list(Collection<? extends LuaValue> c) {
        LuaTable t = new LuaTable();
        int i = 1;
        for (LuaValue v : c) t.set(i++, v);
        return t;
    }

    static {
        reg(LObj.class, "Destroy|destroy|Remove", (s, a) -> { s.destroy(); return NONE; });
        reg(LObj.class, "GetChildren|getChildren", (s, a) -> list(s.listChildren()));
        reg(LObj.class, "GetDescendants", (s, a) -> {
            List<LObj> out = new ArrayList<>();
            Deque<LObj> q = new ArrayDeque<>(s.listChildren());
            while (!q.isEmpty()) { LObj o = q.poll(); out.add(o); q.addAll(o.children); }
            return list(out);
        });
        reg(LObj.class, "FindFirstChild", (s, a) -> {
            String n = a.checkjstring(1);
            LObj c = s.findChild(n);
            if (c == null && a.optboolean(2, false)) {   // FindFirstChild(name, true) = recursive
                Deque<LObj> q = new ArrayDeque<>(s.listChildren());
                while (!q.isEmpty() && c == null) { LObj o = q.poll(); if (n.equals(o.getName())) c = o; else q.addAll(o.listChildren()); }
            }
            return c == null ? NIL : c; });
        reg(LObj.class, "WaitForChild", (s, a) -> { LObj c = s.findChild(a.checkjstring(1)); return c == null ? NIL : c; });
        reg(LObj.class, "FindFirstChildOfClass", (s, a) -> { String c = a.checkjstring(1); for (LObj o : s.listChildren()) if (o.className.equals(c)) return o; return NIL; });
        reg(LObj.class, "FindFirstChildWhichIsA", (s, a) -> { String c = a.checkjstring(1); for (LObj o : s.listChildren()) if (o.isA(c)) return o; return NIL; });
        reg(LObj.class, "FindFirstAncestor", (s, a) -> { String n = a.checkjstring(1); for (LObj p = s.parent; p != null; p = p.parent) if (n.equals(p.getName())) return p; return NIL; });
        reg(LObj.class, "FindFirstAncestorOfClass", (s, a) -> { String c = a.checkjstring(1); for (LObj p = s.parent; p != null; p = p.parent) if (p.className.equals(c)) return p; return NIL; });
        reg(LObj.class, "FindFirstAncestorWhichIsA", (s, a) -> { String c = a.checkjstring(1); for (LObj p = s.parent; p != null; p = p.parent) if (p.isA(c)) return p; return NIL; });
        reg(LObj.class, "IsDescendantOf", (s, a) -> valueOf(s.isDescendantOf(checkObj(a.arg1(), LObj.class))));
        reg(LObj.class, "IsAncestorOf", (s, a) -> valueOf(checkObj(a.arg1(), LObj.class).isDescendantOf(s)));
        reg(LObj.class, "GetFullName", (s, a) -> valueOf(s.fullName()));
        // GetAncestors(): parent, grand-parent, ... up to game
        reg(LObj.class, "GetAncestors", (s, a) -> { List<LObj> l = new ArrayList<>(); for (LObj p = s.parent; p != null; p = p.parent) l.add(p); return list(l); });
        reg(LObj.class, "IsA", (s, a) -> valueOf(s.isA(a.checkjstring(1))));
        reg(LObj.class, "ClearAllChildren", (s, a) -> { for (LObj c : new ArrayList<>(s.children)) c.destroy(); return NONE; });
        reg(LObj.class, "Clone", (s, a) -> s.cloneObj());
    }

    /** obj:WaitForChild(name, [timeout]) - yields (inside scripts / handlers) until the child exists */
    static final LuaValue WAIT_FOR_CHILD = new VarArgFunction() {
        @Override public Varargs invoke(Varargs a) {
            if (!(a.arg1() instanceof LObj o)) throw new LuaError("Expected ':' not '.' calling member function WaitForChild");
            String n = a.checkjstring(2);
            double timeout = a.optdouble(3, -1);
            FluwaRuntime r = o.rt != null ? o.rt : FluwaRuntime.current();
            long t0 = System.nanoTime();
            boolean warned = false;
            while (true) {
                LObj c = o.main(() -> o.destroyed ? null : o.findChild(n));
                if (c != null) return c;
                if (r == null || r.waitFn == null || !r.canWait() || o.destroyed) return NIL;
                double el = (System.nanoTime() - t0) / 1e9;
                if (timeout >= 0 && el >= timeout) return NIL;
                if (!warned && timeout < 0 && el > 5) { warned = true; r.output(1, "Infinite yield possible on " + o.fullName() + ":WaitForChild(\"" + n + "\")"); }
                r.waitFn.call(valueOf(0.05));
            }
        }
    };

    public String fullName() {
        StringBuilder b = new StringBuilder(getName());
        for (LObj p = parent; p != null && !"DataModel".equals(p.className); p = p.parent) b.insert(0, p.getName() + ".");
        return b.toString();
    }
    public boolean isDescendantOf(LObj a) { for (LObj p = parent; p != null; p = p.parent) if (p == a) return true; return false; }

    protected LuaValue cloneObj() { throw new LuaError(className + " can't be cloned"); }
}
