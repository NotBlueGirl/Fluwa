package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

/** UDim (scale + offset), used by UICorner.CornerRadius, UIListLayout.Padding. UDim.new(scale, offset) */
public final class UDimL extends LObj {
    public final double s, o;
    public UDimL(double s, double o) { super("UDim"); this.s = s; this.o = o; }

    public static UDimL check(LuaValue v) {
        if (v instanceof UDimL u) return u;
        if (v.isnumber()) return new UDimL(0, v.todouble());
        if (v instanceof UDim2L u) return new UDimL(u.xs, u.xo);
        if (v.istable()) return new UDimL(v.get(1).optdouble(0), v.get(2).optdouble(0));
        throw new LuaError("Expected UDim, got " + v.typename());
    }
    public double px(double size) { return s * size + o; }

    @Override protected boolean threadSafe() { return true; }
    @Override protected LuaValue getProp(String k) {
        switch (k) { case "Scale": return valueOf(s); case "Offset": return valueOf(o); }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) { throw new LuaError("UDim is immutable"); }
    @Override public String tojstring() { return s + ", " + o; }
    @Override public boolean eq_b(LuaValue v) { return v instanceof UDimL u && u.s == s && u.o == o; }
    @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }

    public static LuaTable lib() {
        LuaTable t = new LuaTable();
        t.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            int k = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            return new UDimL(a.optdouble(1 + k, 0), a.optdouble(2 + k, 0)); } });
        return t;
    }
}
