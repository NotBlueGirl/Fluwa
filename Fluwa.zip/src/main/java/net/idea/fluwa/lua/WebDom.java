package net.idea.fluwa.lua;

import java.util.*;
import java.util.regex.*;

/** Tiny tolerant HTML DOM for the lite Chromium engine: parser, CSS selectors, text/HTML serialization. */
public final class WebDom {
    private WebDom() {}

    public static final Set<String> VOID = Set.of("br", "img", "input", "hr", "meta", "link", "area", "base", "col", "embed", "source", "track", "wbr");
    public static final Set<String> RAW = Set.of("script", "style", "textarea", "title");
    public static final Set<String> BLOCK = Set.of("html", "body", "div", "p", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "br", "tr", "table",
            "section", "header", "footer", "article", "nav", "main", "form", "pre", "blockquote", "hr", "aside", "figure", "figcaption", "dl", "dt", "dd", "center", "details", "summary");
    static final Set<String> AUTO_CLOSE = Set.of("p", "li", "option", "tr", "td", "th", "dt", "dd");

    public static final class Node {
        public String tag;                       // "#text", "#root", "#comment" or lower-case tag
        public String text = "";                 // text nodes / raw elements
        public final LinkedHashMap<String, String> attrs = new LinkedHashMap<>();
        public final List<Node> kids = new ArrayList<>();
        public Node parent;
        public Node(String tag) { this.tag = tag; }
        public boolean isText() { return tag.equals("#text"); }
        public String attr(String k) { return attrs.getOrDefault(k, ""); }
        public void add(Node n) { n.parent = this; kids.add(n); }
        public void remove() { if (parent != null) parent.kids.remove(this); parent = null; }
        public String id() { return attr("id"); }
        public Set<String> classes() {
            Set<String> s = new LinkedHashSet<>();
            for (String c : attr("class").trim().split("\\s+")) if (!c.isEmpty()) s.add(c);
            return s;
        }
        public Map<String, String> style() {
            Map<String, String> m = new LinkedHashMap<>();
            for (String d : attr("style").split(";")) { int i = d.indexOf(':'); if (i > 0) m.put(d.substring(0, i).trim().toLowerCase(Locale.ROOT), d.substring(i + 1).trim()); }
            return m;
        }
        public Node find(String tagName) {
            if (tag.equals(tagName)) return this;
            for (Node k : kids) { Node f = k.find(tagName); if (f != null) return f; }
            return null;
        }
        public void walk(java.util.function.Consumer<Node> c) { c.accept(this); for (Node k : new ArrayList<>(kids)) k.walk(c); }
        public String innerText() { StringBuilder b = new StringBuilder(); text(this, b); return b.toString().replaceAll("[ \\t]+", " ").replaceAll(" *\\n *", "\n").replaceAll("\\n{3,}", "\n\n").trim(); }
        public String innerHTML() { StringBuilder b = new StringBuilder(); for (Node k : kids) html(k, b); return b.toString(); }
        public String outerHTML() { StringBuilder b = new StringBuilder(); html(this, b); return b.toString(); }
        public void setText(String t) { kids.clear(); if (RAW.contains(tag)) text = t; else { Node n = new Node("#text"); n.text = t; add(n); } }
        public void setHTML(String h) { kids.clear(); Node r = parse(h); for (Node k : new ArrayList<>(r.kids)) add(k); }
    }

    static void text(Node n, StringBuilder b) {
        if (n.isText()) { b.append(n.text.replaceAll("\\s+", " ")); return; }
        if (n.tag.equals("script") || n.tag.equals("style") || n.tag.equals("title") || n.tag.equals("head") || n.tag.equals("#comment")) return;
        if (n.tag.equals("textarea")) { b.append(n.text); return; }
        if (n.tag.equals("br")) { b.append('\n'); return; }
        boolean block = BLOCK.contains(n.tag);
        if (block && b.length() > 0 && b.charAt(b.length() - 1) != '\n') b.append('\n');
        if (n.tag.equals("li")) b.append("• ");
        for (Node k : n.kids) text(k, b);
        if (n.tag.equals("td") || n.tag.equals("th")) b.append('\t');
        if (block) b.append('\n');
    }

    static void html(Node n, StringBuilder b) {
        if (n.isText()) { b.append(esc(n.text)); return; }
        if (n.tag.equals("#comment")) { b.append("<!--").append(n.text).append("-->"); return; }
        if (n.tag.equals("#root")) { for (Node k : n.kids) html(k, b); return; }
        b.append('<').append(n.tag);
        n.attrs.forEach((k, v) -> b.append(' ').append(k).append("=\"").append(v.replace("\"", "&quot;")).append('"'));
        b.append('>');
        if (VOID.contains(n.tag)) return;
        if (RAW.contains(n.tag)) b.append(n.text);
        for (Node k : n.kids) html(k, b);
        b.append("</").append(n.tag).append('>');
    }

    static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    public static String decode(String s) {
        if (s.indexOf('&') < 0) return s;
        Matcher m = Pattern.compile("&(#x?[0-9a-fA-F]+|[a-zA-Z]+);").matcher(s);
        StringBuilder b = new StringBuilder();
        while (m.find()) {
            String e = m.group(1), r;
            if (e.startsWith("#x") || e.startsWith("#X")) r = new String(Character.toChars(Integer.parseInt(e.substring(2), 16)));
            else if (e.startsWith("#")) r = new String(Character.toChars(Integer.parseInt(e.substring(1))));
            else r = switch (e) { case "amp" -> "&"; case "lt" -> "<"; case "gt" -> ">"; case "quot" -> "\""; case "apos" -> "'"; case "nbsp" -> "\u00A0";
                case "copy" -> "©"; case "reg" -> "®"; case "mdash" -> "—"; case "ndash" -> "–"; case "hellip" -> "…"; default -> m.group(); };
            m.appendReplacement(b, Matcher.quoteReplacement(r));
        }
        m.appendTail(b);
        return b.toString();
    }

    static final Pattern TOKEN = Pattern.compile("<!--(.*?)-->|<!(?:[^>]*)>|<\\?[^>]*>|</\\s*([a-zA-Z][\\w:-]*)\\s*>|<([a-zA-Z][\\w:-]*)((?:\\s+[^\\s=>/]+(?:\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+))?)*)\\s*(/?)>", Pattern.DOTALL);
    static final Pattern ATTR = Pattern.compile("([^\\s=>/]+)(?:\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+)))?");

    public static Node parse(String html) {
        Node root = new Node("#root");
        Node cur = root;
        Matcher m = TOKEN.matcher(html);
        int pos = 0;
        while (pos < html.length()) {
            if (!m.find(pos)) { addText(cur, html.substring(pos)); break; }
            if (m.start() > pos) addText(cur, html.substring(pos, m.start()));
            pos = m.end();
            if (m.group(1) != null) { Node c = new Node("#comment"); c.text = m.group(1); cur.add(c); continue; }
            if (m.group(2) != null) {
                String t = m.group(2).toLowerCase(Locale.ROOT);
                for (Node n = cur; n != null && n != root; n = n.parent) if (n.tag.equals(t)) { cur = n.parent; break; }
                continue;
            }
            if (m.group(3) == null) continue; // doctype / processing instruction
            String t = m.group(3).toLowerCase(Locale.ROOT);
            if (AUTO_CLOSE.contains(t)) for (Node n = cur; n != null && n != root; n = n.parent) {
                if (n.tag.equals(t)) { cur = n.parent; break; }
                if (BLOCK.contains(n.tag) && !n.tag.equals("p") || n.tag.equals("table") || n.tag.equals("ul") || n.tag.equals("ol")) break;
            }
            Node e = new Node(t);
            Matcher am = ATTR.matcher(m.group(4) == null ? "" : m.group(4));
            while (am.find()) {
                String v = am.group(3) != null ? am.group(3) : am.group(4) != null ? am.group(4) : am.group(5) != null ? am.group(5) : "";
                e.attrs.put(am.group(1).toLowerCase(Locale.ROOT), decode(v));
            }
            cur.add(e);
            boolean selfClose = !m.group(5).isEmpty() || VOID.contains(t);
            if (selfClose) continue;
            if (RAW.contains(t)) {
                Matcher end = Pattern.compile("</\\s*" + t + "\\s*>", Pattern.CASE_INSENSITIVE).matcher(html);
                boolean found = end.find(pos);
                int stop = found ? end.start() : html.length();
                String raw = html.substring(pos, stop);
                e.text = t.equals("script") || t.equals("style") ? raw : decode(raw);
                pos = found ? end.end() : html.length();
                continue;
            }
            cur = e;
        }
        return root;
    }

    static void addText(Node cur, String s) {
        if (s.isEmpty()) return;
        Node t = new Node("#text"); t.text = decode(s); cur.add(t);
    }

    // ------------------------------------------------------------------ selectors
    record Simple(String tag, String id, List<String> cls, List<String[]> attrs) {}

    static final Pattern SIMPLE = Pattern.compile("([a-zA-Z*][\\w-]*)?((?:#[\\w-]+|\\.[\\w-]+|\\[[^\\]]+\\]|:[\\w-]+(?:\\([^)]*\\))?)*)");

    static Simple simple(String s) {
        Matcher m = SIMPLE.matcher(s);
        if (!m.matches()) return new Simple("\u0000", null, List.of(), List.of());
        String tag = m.group(1) == null || m.group(1).equals("*") ? null : m.group(1).toLowerCase(Locale.ROOT);
        String id = null; List<String> cls = new ArrayList<>(); List<String[]> at = new ArrayList<>();
        Matcher p = Pattern.compile("#([\\w-]+)|\\.([\\w-]+)|\\[\\s*([\\w-]+)\\s*(?:([~^$*|]?=)\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\]\\s]*)))?\\s*\\]").matcher(m.group(2));
        while (p.find()) {
            if (p.group(1) != null) id = p.group(1);
            else if (p.group(2) != null) cls.add(p.group(2));
            else if (p.group(3) != null) {
                String v = p.group(5) != null ? p.group(5) : p.group(6) != null ? p.group(6) : p.group(7);
                at.add(new String[]{p.group(3).toLowerCase(Locale.ROOT), p.group(4), v});
            }
        }
        return new Simple(tag, id, cls, at);
    }

    static boolean match(Node n, Simple s) {
        if (n.isText() || n.tag.startsWith("#")) return false;
        if (s.tag != null && !s.tag.equals(n.tag)) return false;
        if (s.id != null && !s.id.equals(n.id())) return false;
        if (!s.cls.isEmpty() && !n.classes().containsAll(s.cls)) return false;
        for (String[] a : s.attrs) {
            if (!n.attrs.containsKey(a[0])) return false;
            if (a[1] == null) continue;
            String v = n.attrs.get(a[0]), w = a[2] == null ? "" : a[2];
            boolean ok = switch (a[1]) {
                case "=" -> v.equals(w); case "^=" -> v.startsWith(w); case "$=" -> v.endsWith(w); case "*=" -> v.contains(w);
                case "~=" -> Arrays.asList(v.split("\\s+")).contains(w); case "|=" -> v.equals(w) || v.startsWith(w + "-"); default -> false;
            };
            if (!ok) return false;
        }
        return true;
    }

    /** matches "a b", "a > b", "a, b" */
    public static boolean matches(Node n, String selector) {
        for (String group : selector.split(",")) if (matchChain(n, group.trim())) return true;
        return false;
    }

    static boolean matchChain(Node n, String sel) {
        List<String> parts = new ArrayList<>(); List<Character> comb = new ArrayList<>();
        Matcher m = Pattern.compile("\\s*(>|\\+|~)\\s*|\\s+").matcher(sel.trim());
        int last = 0;
        while (m.find()) { parts.add(sel.trim().substring(last, m.start())); comb.add(m.group(1) == null ? ' ' : m.group(1).charAt(0)); last = m.end(); }
        parts.add(sel.trim().substring(last));
        return chain(n, parts, comb, parts.size() - 1);
    }

    static boolean chain(Node n, List<String> parts, List<Character> comb, int i) {
        if (!match(n, simple(parts.get(i)))) return false;
        if (i == 0) return true;
        char c = comb.get(i - 1);
        if (c == '>') return n.parent != null && chain(n.parent, parts, comb, i - 1);
        for (Node p = n.parent; p != null; p = p.parent) if (chain(p, parts, comb, i - 1)) return true;
        return false;
    }

    public static List<Node> select(Node root, String selector, int limit) {
        List<Node> out = new ArrayList<>();
        selectRec(root, selector, out, limit);
        return out;
    }
    static void selectRec(Node n, String sel, List<Node> out, int limit) {
        for (Node k : n.kids) {
            if (out.size() >= limit) return;
            if (!k.isText() && matches(k, sel)) out.add(k);
            selectRec(k, sel, out, limit);
        }
    }
}
