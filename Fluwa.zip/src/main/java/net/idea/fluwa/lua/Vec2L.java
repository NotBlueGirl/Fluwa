package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

/** Vector2 (UI AnchorPoint, offsets...). Vector2.new(x, y) */
public final class Vec2L extends LObj {
    public final double x, y;
    static final LuaTable MT = new LuaTable();

    public Vec2L(double x, double y) { super("Vector2"); this.x = x; this.y = y; setmetatable(MT); }

    public static Vec2L check(LuaValue v) {
        if (v instanceof Vec2L p) return p;
        if (v instanceof Vec3L p) return new Vec2L(p.x, p.y);
        if (v instanceof UDim2L u) return new Vec2L(u.xo, u.yo);
        if (v.istable()) {
            LuaValue X = v.get(1).isnil() ? v.get("X") : v.get(1), Y = v.get(2).isnil() ? v.get("Y") : v.get(2);
            return new Vec2L(X.checkdouble(), Y.checkdouble());
        }
        if (v.isnumber()) return new Vec2L(v.todouble(), v.todouble());
        throw new LuaError("Expected Vector2, got " + v.typename());
    }

    public double mag() { return Math.sqrt(x * x + y * y); }
    @Override protected boolean threadSafe() { return true; }
    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "X": case "x": return valueOf(x);
            case "Y": case "y": return valueOf(y);
            case "Magnitude": return valueOf(mag());
            case "Unit": { double m = mag(); return m == 0 ? new Vec2L(0, 0) : new Vec2L(x / m, y / m); }
        }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) { throw new LuaError("Vector2 is immutable"); }
    @Override public String tojstring() { return Vec3L.fmt(x) + ", " + Vec3L.fmt(y); }
    @Override public boolean eq_b(LuaValue v) { return v instanceof Vec2L o && o.x == x && o.y == y; }
    @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }
    @Override public LuaValue cloneObj() { return new Vec2L(x, y); }

    static LuaValue op(LuaValue a, LuaValue b, char o) {
        Vec2L p = check(a), q = check(b);
        return switch (o) {
            case '+' -> new Vec2L(p.x + q.x, p.y + q.y);
            case '-' -> new Vec2L(p.x - q.x, p.y - q.y);
            case '*' -> new Vec2L(p.x * q.x, p.y * q.y);
            default -> new Vec2L(p.x / q.x, p.y / q.y);
        };
    }

    static {
        MT.set("__add", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return op(a, b, '+'); } });
        MT.set("__sub", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return op(a, b, '-'); } });
        MT.set("__mul", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return op(a, b, '*'); } });
        MT.set("__div", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return op(a, b, '/'); } });
        MT.set("__unm", new OneArgFunction() { public LuaValue call(LuaValue a) { Vec2L p = check(a); return new Vec2L(-p.x, -p.y); } });
        MT.set("__eq", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return valueOf(a.eq_b(b)); } });
        MT.set("__tostring", new OneArgFunction() { public LuaValue call(LuaValue a) { return valueOf(a.tojstring()); } });
        reg(Vec2L.class, "Dot", (s, a) -> { Vec2L p = (Vec2L) s, q = check(a.arg1()); return valueOf(p.x * q.x + p.y * q.y); });
        reg(Vec2L.class, "Lerp", (s, a) -> { Vec2L p = (Vec2L) s, q = check(a.arg1()); double t = a.checkdouble(2); return new Vec2L(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t); });
    }

    public static LuaTable lib() {
        LuaTable t = new LuaTable();
        t.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            return new Vec2L(a.optdouble(1 + o, 0), a.optdouble(2 + o, 0)); } });
        t.set("zero", new Vec2L(0, 0));
        t.set("one", new Vec2L(1, 1));
        return t;
    }
}
