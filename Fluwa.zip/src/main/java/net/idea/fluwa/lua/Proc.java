package net.idea.fluwa.lua;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** External process helper for OS.Execute / LuaRT / FASM (only used when fullOsAccess=true). */
public final class Proc {
    private Proc() {}

    public static final String OS_NAME = System.getProperty("os.name", "unknown");
    public static final boolean WINDOWS = OS_NAME.toLowerCase(Locale.ROOT).startsWith("windows");
    public static final boolean MAC = OS_NAME.toLowerCase(Locale.ROOT).contains("mac");

    public record Result(int exit, String output) {}

    public static Result run(List<String> cmd, Path dir, int timeoutSec) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true);
        if (dir != null) pb.directory(dir.toFile());
        Process p = pb.start();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Thread reader = new Thread(() -> {
            try (InputStream in = p.getInputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) if (out.size() < 1 << 20) out.write(buf, 0, n);
            } catch (IOException ignored) {}
        }, "Fluwa-Proc-Reader");
        reader.setDaemon(true); reader.start();
        if (!p.waitFor(Math.max(1, timeoutSec), TimeUnit.SECONDS)) {
            p.destroyForcibly();
            throw new IOException("process timed out after " + timeoutSec + " s: " + cmd.get(0));
        }
        reader.join(2000);
        return new Result(p.exitValue(), out.toString(StandardCharsets.UTF_8));
    }

    /** Find an executable: explicit config path, else search PATH for the given names. */
    public static Path find(String configured, String... names) {
        if (configured != null && !configured.isBlank()) {
            Path p = Paths.get(configured);
            return Files.isRegularFile(p) ? p : null;
        }
        String path = System.getenv("PATH");
        if (path == null) return null;
        for (String dir : path.split(File.pathSeparator)) for (String n : names) {
            try { Path p = Paths.get(dir, n); if (Files.isRegularFile(p) && Files.isExecutable(p)) return p; }
            catch (InvalidPathException ignored) {}
        }
        return null;
    }

    public static List<String> shell(String command) {
        return WINDOWS ? List.of("cmd.exe", "/c", command) : List.of("/bin/sh", "-c", command);
    }
}
