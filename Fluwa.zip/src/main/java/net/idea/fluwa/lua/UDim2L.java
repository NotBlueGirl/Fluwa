package net.idea.fluwa.lua;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

/** UDim2 (scale + offset per axis), used by UI. UDim2.new(xScale, xOffset, yScale, yOffset), UDim2.fromOffset(x, y), UDim2.fromScale(x, y) */
public final class UDim2L extends LObj {
    public final double xs, xo, ys, yo;
    static final LuaTable MT = new LuaTable();

    public UDim2L(double xs, double xo, double ys, double yo) { super("UDim2"); this.xs = xs; this.xo = xo; this.ys = ys; this.yo = yo; setmetatable(MT); }

    public static UDim2L check(LuaValue v) {
        if (v instanceof UDim2L u) return u;
        if (v instanceof Vec3L p) return new UDim2L(0, p.x, 0, p.y);
        if (v.istable()) {
            if (v.length() >= 4) return new UDim2L(v.get(1).checkdouble(), v.get(2).checkdouble(), v.get(3).checkdouble(), v.get(4).checkdouble());
            return new UDim2L(0, v.get(1).checkdouble(), 0, v.get(2).checkdouble());
        }
        throw new LuaError("Expected UDim2, got " + v.typename());
    }

    @Override protected boolean threadSafe() { return true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "XScale": return valueOf(xs);
            case "XOffset": case "X": return valueOf(xo);
            case "YScale": return valueOf(ys);
            case "YOffset": case "Y": return valueOf(yo);
        }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) { throw new LuaError("UDim2 is immutable"); }
    @Override public String tojstring() { return "{" + xs + ", " + xo + "}, {" + ys + ", " + yo + "}"; }
    @Override public boolean eq_b(LuaValue v) { return v instanceof UDim2L o && o.xs == xs && o.xo == xo && o.ys == ys && o.yo == yo; }
    @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }

    static {
        MT.set("__add", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { UDim2L x = check(a), y = check(b); return new UDim2L(x.xs + y.xs, x.xo + y.xo, x.ys + y.ys, x.yo + y.yo); } });
        MT.set("__sub", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { UDim2L x = check(a), y = check(b); return new UDim2L(x.xs - y.xs, x.xo - y.xo, x.ys - y.ys, x.yo - y.yo); } });
        MT.set("__tostring", new OneArgFunction() { public LuaValue call(LuaValue a) { return valueOf(a.tojstring()); } });
    }

    public static LuaTable lib() {
        LuaTable t = new LuaTable();
        t.set("new", new VarArgFunction() { public Varargs invoke(Varargs a) {
            int o = a.arg1().istable() && !(a.arg1() instanceof LObj) ? 1 : 0;
            return new UDim2L(a.optdouble(1 + o, 0), a.optdouble(2 + o, 0), a.optdouble(3 + o, 0), a.optdouble(4 + o, 0)); } });
        t.set("fromOffset", new VarArgFunction() { public Varargs invoke(Varargs a) { return new UDim2L(0, a.optdouble(1, 0), 0, a.optdouble(2, 0)); } });
        t.set("fromScale", new VarArgFunction() { public Varargs invoke(Varargs a) { return new UDim2L(a.optdouble(1, 0), 0, a.optdouble(2, 0), 0); } });
        return t;
    }
}
