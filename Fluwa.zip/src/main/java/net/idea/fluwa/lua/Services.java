package net.idea.fluwa.lua;

import net.idea.fluwa.Config;
import org.luaj.vm2.*;
import org.luaj.vm2.lib.*;

import java.math.*;

/** getAccess(...) services shared by server and client. */
public final class Services {
    private Services() {}

    public static final String VERSION = "0.5.2";

    public static void registerCommon(FluwaRuntime rt) {
        rt.registerService("OS", () -> os(rt));
        rt.registerService("BigInt", () -> new BigNum.Lib(false));
        rt.registerService("BigDec", () -> new BigNum.Lib(true));
        rt.registerService("Runtime", () -> new RuntimeInfo(rt));
        rt.registerService("LuaRT", () -> {
            if (!Proc.WINDOWS) throw new LuaError("LuaRT is available only on Windows (this machine: " + Proc.OS_NAME + ")");
            return new LuaRT(rt);
        });
        rt.registerService("ShaderDT", () -> { throw new LuaError("ShaderDT is Client-Side only (OpenGL): use it in ClientScripts or UI"); });
        rt.registerService("UserInputService", () -> { throw new LuaError("UserInputService is Client-Side only: use it in ClientScripts or UI"); });
        rt.registerService("Chromium", () -> new Chromium(rt));
        rt.registerService("FASM", Fasm::new);
        rt.registerService("Projector", () -> new net.idea.fluwa.api.Projector(rt));
        rt.registerService("NET", () -> new NetService(rt));
        rt.registerService("Lighting", () -> rt instanceof net.idea.fluwa.api.GameRuntime g ? g.world.lighting : LuaValue.NIL);
        rt.registerService("Forge", () -> net.idea.fluwa.forge.ForgeService.get(rt));
    }

    /** strip the service itself when a function is called with ':' (OS:Execute(...)) */
    static Varargs args(Varargs a, LuaValue self) { return a.arg1() == self ? a.subargs(2) : a; }

    /** getAccess("OS"): safe os table + system information. Dangerous parts need fullOsAccess=true. */
    static LuaValue os(FluwaRuntime rt) {
        LuaTable t = new LuaTable();
        for (LuaValue k = rt.osLib.next(LuaValue.NIL).arg1(); !k.isnil(); k = rt.osLib.next(k).arg1()) t.set(k, rt.osLib.get(k));
        String fam = Proc.WINDOWS ? "Windows" : Proc.MAC ? "macOS" : Proc.OS_NAME.toLowerCase().contains("linux") ? "Linux" : Proc.OS_NAME;
        t.set("Name", Proc.OS_NAME);
        t.set("Family", fam);
        t.set("Version", System.getProperty("os.version", "?"));
        t.set("Arch", System.getProperty("os.arch", "?"));
        t.set("IsWindows", LuaValue.valueOf(Proc.WINDOWS));
        t.set("IsMac", LuaValue.valueOf(Proc.MAC));
        t.set("IsLinux", LuaValue.valueOf(fam.equals("Linux")));
        t.set("Cores", LuaValue.valueOf(Runtime.getRuntime().availableProcessors()));
        t.set("JavaVersion", System.getProperty("java.version", "?"));
        t.set("FullAccess", LuaValue.valueOf(Config.fullOsAccess));
        if (Config.fullOsAccess) {
            t.set("User", System.getProperty("user.name", "?"));
            t.set("Home", System.getProperty("user.home", "?"));
            // OS.Execute(command, [timeoutSec=10]) -> output, exitCode   (runs in background, script waits)
            t.set("Execute", new VarArgFunction() { public Varargs invoke(Varargs a0) {
                Varargs a = args(a0, t);
                String cmd = a.checkjstring(1); int to = a.optint(2, 10);
                LuaTable r = (LuaTable) AsyncTask.await("OS.Execute", () -> {
                    Proc.Result res = Proc.run(Proc.shell(cmd), null, to);
                    return LuaValue.listOf(new LuaValue[]{LuaValue.valueOf(res.output()), LuaValue.valueOf(res.exit())});
                });
                return LuaValue.varargsOf(r.get(1), r.get(2)); } });
        } else {
            VarArgFunction locked = new VarArgFunction() { public Varargs invoke(Varargs a) {
                throw new LuaError("This OS function needs fullOsAccess=true in config/fluwa-common.toml"); } };
            t.set("Execute", locked);
        }
        return t;
    }

    /** getAccess("Runtime"): information about the Fluwa Lua VM (was LuaRT in 0.1). */
    public static class RuntimeInfo extends LObj {
        final FluwaRuntime r; final long start = System.currentTimeMillis();
        RuntimeInfo(FluwaRuntime r) { super("Service"); this.r = r; name = "Runtime"; }
        @Override protected boolean threadSafe() { return true; }
        @Override protected LuaValue getProp(String k) {
            Runtime j = Runtime.getRuntime();
            switch (k) {
                case "Available": return TRUE;
                case "Version": return valueOf("Fluwa " + VERSION + " / " + Lua._VERSION + " (LuaJ 3.0.1)");
                case "Side": return valueOf(r.server ? "Server" : "Client");
                case "MemoryUsed": return valueOf((j.totalMemory() - j.freeMemory()) / 1048576.0);
                case "MemoryMax": return valueOf(j.maxMemory() / 1048576.0);
                case "Uptime": return valueOf((System.currentTimeMillis() - start) / 1000.0);
                case "Ticks": return valueOf(r.tick);
                case "Timeout": return valueOf(Config.scriptTimeoutMs);
            }
            return super.getProp(k);
        }
        static { reg(RuntimeInfo.class, "CollectGarbage", (s, a) -> { System.gc(); return NONE; }); }
    }

    /**
     * getAccess("LuaRT") - Windows only. Bridge to an installed LuaRT (https://www.luart.org, Lua 5.4 for Windows):
     * LuaRT:Run(code, [timeoutSec]) -> output, exitCode ; LuaRT:RunFile(path, [timeoutSec]).
     * Needs luart.exe (PATH or luartPath in config) and fullOsAccess=true.
     */
    public static final class LuaRT extends RuntimeInfo {
        LuaRT(FluwaRuntime r) { super(r); name = "LuaRT"; }
        static java.nio.file.Path exe() { return Proc.find(Config.luartPath, "luart.exe", "luart"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Installed": return valueOf(exe() != null);
                case "Available": return valueOf(exe() != null && Config.fullOsAccess);
                case "Path": { var p = exe(); return p == null ? NIL : valueOf(p.toString()); }
            }
            return super.getProp(k);
        }
        static Varargs run(java.nio.file.Path script, boolean temp, int timeout) {
            if (!Config.fullOsAccess) throw new LuaError("LuaRT needs fullOsAccess=true in config/fluwa-common.toml");
            var exe = exe();
            if (exe == null) throw new LuaError("LuaRT is not installed (luart.exe not found in PATH; set luartPath in config)");
            LuaTable r = (LuaTable) AsyncTask.await("LuaRT", () -> {
                try {
                    Proc.Result res = Proc.run(java.util.List.of(exe.toString(), script.toString()), script.getParent(), timeout);
                    return LuaValue.listOf(new LuaValue[]{LuaValue.valueOf(res.output()), LuaValue.valueOf(res.exit())});
                } finally { if (temp) java.nio.file.Files.deleteIfExists(script); }
            });
            return varargsOf(r.get(1), r.get(2));
        }
        static {
            reg(LuaRT.class, "Run", (s, a) -> {
                try {
                    var f = java.nio.file.Files.createTempFile("fluwa-luart", ".lua");
                    java.nio.file.Files.writeString(f, a.checkjstring(1));
                    return run(f, true, a.optint(2, 10));
                } catch (java.io.IOException e) { throw new LuaError("LuaRT: " + e.getMessage()); }
            });
            reg(LuaRT.class, "RunFile", (s, a) -> run(java.nio.file.Paths.get(a.checkjstring(1)).toAbsolutePath(), false, a.optint(2, 10)));
        }
    }

    /** BigInt / BigDec values */
    public static final class BigNum extends LObj {
        static final LuaTable MT = new LuaTable();
        static MathContext MC = MathContext.DECIMAL128;
        final BigDecimal d; final BigInteger i; final boolean dec;

        BigNum(BigInteger i) { super("BigInt"); this.i = i; this.d = null; dec = false; setmetatable(MT); }
        BigNum(BigDecimal d) { super("BigDec"); this.d = d; this.i = null; dec = true; setmetatable(MT); }

        static BigNum of(LuaValue v, boolean dec) {
            if (v instanceof BigNum b) {
                if (b.dec == dec) return b;
                return dec ? new BigNum(new BigDecimal(b.i)) : new BigNum(b.d.toBigInteger());
            }
            String s = v.type() == LuaValue.TNUMBER && !dec && v.todouble() == Math.rint(v.todouble()) ? String.valueOf((long) v.todouble()) : v.checkjstring();
            try { return dec ? new BigNum(new BigDecimal(s)) : new BigNum(new BigInteger(s)); }
            catch (NumberFormatException e) { throw new LuaError("Invalid number: " + s); }
        }
        static boolean anyDec(LuaValue a, LuaValue b) { return (a instanceof BigNum x && x.dec) || (b instanceof BigNum y && y.dec); }

        static LuaValue op(LuaValue a, LuaValue b, char op) {
            boolean dec = anyDec(a, b);
            BigNum x = of(a, dec), y = of(b, dec);
            if (dec) return new BigNum(switch (op) {
                case '+' -> x.d.add(y.d); case '-' -> x.d.subtract(y.d); case '*' -> x.d.multiply(y.d);
                case '/' -> x.d.divide(y.d, MC); case '%' -> x.d.remainder(y.d); default -> x.d.pow(y.d.intValueExact(), MC); });
            if ((op == '/' || op == '%') && y.i.signum() == 0) throw new LuaError("BigInt division by zero");
            return new BigNum(switch (op) {
                case '+' -> x.i.add(y.i); case '-' -> x.i.subtract(y.i); case '*' -> x.i.multiply(y.i);
                case '/' -> x.i.divide(y.i); case '%' -> x.i.mod(y.i.abs()); default -> x.i.pow(y.i.intValueExact()); });
        }
        static int cmp(LuaValue a, LuaValue b) { boolean dec = anyDec(a, b); BigNum x = of(a, dec), y = of(b, dec); return dec ? x.d.compareTo(y.d) : x.i.compareTo(y.i); }

        /** Machin formula: pi = 16 atan(1/5) - 4 atan(1/239) */
        static BigDecimal pi(MathContext mc) {
            MathContext m = new MathContext(mc.getPrecision() + 10);
            return atanInv(5, m).multiply(BigDecimal.valueOf(16)).subtract(atanInv(239, m).multiply(BigDecimal.valueOf(4))).round(mc);
        }
        static BigDecimal atanInv(int n, MathContext m) {
            BigDecimal x = BigDecimal.ONE.divide(BigDecimal.valueOf(n), m), x2 = x.multiply(x, m), term = x, sum = x;
            BigDecimal eps = BigDecimal.ONE.movePointLeft(m.getPrecision() + 2);
            for (int k = 1; term.abs().compareTo(eps) > 0; k++) {
                term = term.multiply(x2, m).negate();
                sum = sum.add(term.divide(BigDecimal.valueOf(2L * k + 1), m), m);
            }
            return sum;
        }

        static BigDecimal dec(LObj s) { return of((BigNum) s, true).d; }

        /** e^x by argument halving + Taylor series */
        static BigDecimal exp(BigDecimal x, MathContext mc) {
            MathContext m = new MathContext(mc.getPrecision() + 10);
            if (x.signum() == 0) return BigDecimal.ONE;
            if (x.abs().compareTo(BigDecimal.valueOf(1_000_000_000L)) > 0) throw new LuaError("BigDec:Exp argument too large");
            int halv = 0;
            while (x.abs().compareTo(BigDecimal.valueOf(0.5)) > 0) { x = x.divide(BigDecimal.valueOf(2), m); halv++; }
            BigDecimal sum = BigDecimal.ONE, term = BigDecimal.ONE, eps = BigDecimal.ONE.movePointLeft(m.getPrecision() + 2);
            for (int n = 1; n < 100000; n++) {
                term = term.multiply(x, m).divide(BigDecimal.valueOf(n), m);
                sum = sum.add(term, m);
                if (term.abs().compareTo(eps) < 0) break;
            }
            for (int k = 0; k < halv; k++) sum = sum.multiply(sum, m);
            return sum.round(mc);
        }

        /** natural log: x = m*10^e, Newton iterations on m in [1,10) */
        static BigDecimal ln(BigDecimal x, MathContext mc) {
            if (x.signum() <= 0) throw new LuaError("BigDec:Ln needs a positive number");
            MathContext m = new MathContext(mc.getPrecision() + 10);
            int e = x.precision() - x.scale() - 1;
            BigDecimal mant = x.movePointLeft(e);
            BigDecimal r = lnNewton(mant, m);
            if (e != 0) r = r.add(lnNewton(BigDecimal.TEN, m).multiply(BigDecimal.valueOf(e), m), m);
            return r.round(mc);
        }
        static BigDecimal lnNewton(BigDecimal x, MathContext m) {
            BigDecimal y = BigDecimal.valueOf(Math.log(x.doubleValue())), two = BigDecimal.valueOf(2);
            BigDecimal eps = BigDecimal.ONE.movePointLeft(m.getPrecision() - 2);
            for (int i = 0; i < 200; i++) {
                BigDecimal ey = exp(y, m);
                BigDecimal d = two.multiply(x.subtract(ey, m), m).divide(x.add(ey, m), m);
                y = y.add(d, m);
                if (d.abs().compareTo(eps) < 0) break;
            }
            return y;
        }

        @Override protected boolean threadSafe() { return true; }
        @Override public String tojstring() { return dec ? d.toPlainString() : i.toString(); }
        @Override public boolean eq_b(LuaValue v) { return v instanceof BigNum && cmp(this, v) == 0; }
        @Override public LuaValue eq(LuaValue v) { return valueOf(eq_b(v)); }
        @Override public LuaValue lt(LuaValue v) { return valueOf(cmp(this, v) < 0); }
        @Override public LuaValue lteq(LuaValue v) { return valueOf(cmp(this, v) <= 0); }
        @Override public boolean lt_b(LuaValue v) { return cmp(this, v) < 0; }
        @Override public boolean lteq_b(LuaValue v) { return cmp(this, v) <= 0; }

        static TwoArgFunction f(char op) { return new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return op(a, b, op); } }; }
        static {
            MT.set("__add", f('+')); MT.set("__sub", f('-')); MT.set("__mul", f('*'));
            MT.set("__div", f('/')); MT.set("__mod", f('%')); MT.set("__pow", f('^'));
            MT.set("__unm", new OneArgFunction() { public LuaValue call(LuaValue a) { BigNum b = (BigNum) a; return b.dec ? new BigNum(b.d.negate()) : new BigNum(b.i.negate()); } });
            MT.set("__eq", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return valueOf(cmp(a, b) == 0); } });
            MT.set("__lt", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return valueOf(cmp(a, b) < 0); } });
            MT.set("__le", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return valueOf(cmp(a, b) <= 0); } });
            MT.set("__tostring", new OneArgFunction() { public LuaValue call(LuaValue a) { return valueOf(a.tojstring()); } });
            MT.set("__concat", new TwoArgFunction() { public LuaValue call(LuaValue a, LuaValue b) { return valueOf(a.tojstring() + b.tojstring()); } });
            reg(BigNum.class, "ToString", (s, a) -> valueOf(s.tojstring()));
            reg(BigNum.class, "ToNumber", (s, a) -> { BigNum b = (BigNum) s; return valueOf(b.dec ? b.d.doubleValue() : b.i.doubleValue()); });
            reg(BigNum.class, "Abs", (s, a) -> { BigNum b = (BigNum) s; return b.dec ? new BigNum(b.d.abs()) : new BigNum(b.i.abs()); });
            reg(BigNum.class, "Pow", (s, a) -> op(s, a.arg1(), '^'));
            reg(BigNum.class, "Sqrt", (s, a) -> { BigNum b = (BigNum) s; return b.dec ? new BigNum(b.d.sqrt(MC)) : new BigNum(b.i.sqrt()); });
            reg(BigNum.class, "Gcd", (s, a) -> new BigNum(((BigNum) s).i.gcd(of(a.arg1(), false).i)));
            reg(BigNum.class, "ModPow", (s, a) -> new BigNum(((BigNum) s).i.modPow(of(a.arg1(), false).i, of(a.arg(2), false).i)));
            reg(BigNum.class, "IsPrime", (s, a) -> valueOf(((BigNum) s).i.isProbablePrime(a.optint(1, 30))));
            reg(BigNum.class, "Round", (s, a) -> { BigNum b = (BigNum) s; return new BigNum(b.d.setScale(a.optint(1, 0), RoundingMode.HALF_UP)); });
            reg(BigNum.class, "Digits", (s, a) -> valueOf(((BigNum) s).dec ? ((BigNum) s).d.precision() : ((BigNum) s).i.abs().toString().length()));
            // ---- 0.2: high precision math for very small / very precise numbers (BigDec)
            reg(BigNum.class, "Exp", (s, a) -> new BigNum(exp(dec(s), MC)));
            reg(BigNum.class, "Ln", (s, a) -> new BigNum(ln(dec(s), MC)));
            reg(BigNum.class, "Log10", (s, a) -> { MathContext m = new MathContext(MC.getPrecision() + 5);
                return new BigNum(ln(dec(s), m).divide(ln(BigDecimal.TEN, m), MC)); });
            reg(BigNum.class, "Scale", (s, a) -> valueOf(dec(s).scale()));
            reg(BigNum.class, "Exponent", (s, a) -> { BigDecimal d = dec(s); return valueOf(d.signum() == 0 ? 0 : d.precision() - d.scale() - 1); });
            reg(BigNum.class, "ToSci", (s, a) -> {
                BigDecimal d = dec(s).round(new MathContext(a.optint(1, Math.min(MC.getPrecision(), 20))));
                return valueOf(d.toString().contains("E") ? d.toString() : String.format(java.util.Locale.ROOT, "%." + Math.max(0, a.optint(1, 20) - 1) + "E", d)); });
            reg(BigNum.class, "Div", (s, a) -> new BigNum(dec(s).divide(of(a.arg1(), true).d, new MathContext(a.optint(2, MC.getPrecision())))));
            reg(BigNum.class, "Floor", (s, a) -> new BigNum(dec(s).setScale(0, RoundingMode.FLOOR)));
            reg(BigNum.class, "Ceil", (s, a) -> new BigNum(dec(s).setScale(0, RoundingMode.CEILING)));
            reg(BigNum.class, "Neg", (s, a) -> ((BigNum) s).dec ? new BigNum(((BigNum) s).d.negate()) : new BigNum(((BigNum) s).i.negate()));
            reg(BigNum.class, "Sign", (s, a) -> valueOf(((BigNum) s).dec ? ((BigNum) s).d.signum() : ((BigNum) s).i.signum()));
        }

        /** BigInt / BigDec service: Lib.new(value), Lib:new(value), Lib.Factorial(n) */
        public static final class Lib extends LObj {
            static LuaValue fn(Lib self, java.util.function.Function<Varargs, LuaValue> f) {
                return new VarArgFunction() { public Varargs invoke(Varargs a) { return f.apply(a.arg1() == self ? a.subargs(2) : a); } };
            }
            final boolean dec;
            Lib(boolean dec) { super("Service"); this.dec = dec; name = dec ? "BigDec" : "BigInt"; }
            @Override protected LuaValue getProp(String k) {
                if (k.equals("new")) return new VarArgFunction() { public Varargs invoke(Varargs a) {
                    return of(a.arg1() instanceof Lib ? a.arg(2) : a.arg1(), dec); } };
                if (k.equals("Available")) return TRUE;
                if (k.equals("Precision")) return valueOf(MC.getPrecision());
                final Lib self = this;
                // library functions work with both '.' and ':'
                switch (k) {
                    case "Factorial": return fn(self, a -> { BigInteger r = BigInteger.ONE; int n = a.checkint(1);
                        if (n > 100000) throw new LuaError("Factorial argument too large");
                        for (int i = 2; i <= n; i++) r = r.multiply(BigInteger.valueOf(i)); return new BigNum(r); });
                    case "Pi": return fn(self, a -> new BigNum(BigNum.pi(MC)));
                    case "E": return fn(self, a -> new BigNum(BigNum.exp(BigDecimal.ONE, MC)));
                    case "SetPrecision": return fn(self, a -> { int n = a.checkint(1);
                        if (n < 5 || n > 10000) throw new LuaError("Precision must be 5..10000");
                        MC = new MathContext(n, RoundingMode.HALF_EVEN); return NONE; });
                }
                return super.getProp(k);
            }
            static {
            }
        }
    }
}
