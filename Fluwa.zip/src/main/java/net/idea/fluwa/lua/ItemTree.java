package net.idea.fluwa.lua;

import net.idea.fluwa.api.GameRuntime;
import org.luaj.vm2.*;

import java.util.*;

/**
 * ZSpace items (Folder, StrValue, IntValue, NumValue, BoolValue, ObjValue) created in any section
 * (Workspace, UI, InitScripts, ServerScripts, ClientScripts). Builds / patches the live Lua objects.
 * Encoded value of an item: "Class\tValue".
 */
public final class ItemTree {
    private ItemTree() {}
    public static final String[] CLASSES = {"Folder", "StrValue", "IntValue", "NumValue", "BoolValue", "ObjValue"};
    public static boolean isItemClass(String c) { return Arrays.asList(CLASSES).contains(c); }

    /** the Lua container of a section (creates the global if missing) */
    public static LObj root(FluwaRuntime rt, String section) {
        if (section.equals("Workspace") && rt instanceof GameRuntime gr) return gr.world;
        if (section.equals("Player") && rt instanceof GameRuntime gr && gr.localPlayerObj() != null) return gr.localPlayerObj();
        LuaValue v = rt.g.get(section);
        if (v instanceof LObj o) return o;
        LObj o = new LObj("Folder");
        o.name = section;
        rt.g.set(section, o);
        // v0.5.2: sections hang below game, so script.Parent.Parent... ends at game
        if (rt.g.get("game") instanceof LObj game) try { o.setParent(game); } catch (LuaError ignored) {}
        return o;
    }

    public static LuaValue parse(String cls, String v) {
        v = v == null ? "" : v;
        try {
            return switch (cls) {
                case "IntValue" -> LuaValue.valueOf(v.isBlank() ? 0 : Math.round(Double.parseDouble(v.trim().replace(',', '.'))));
                case "NumValue", "NumberValue" -> LuaValue.valueOf(v.isBlank() ? 0 : Double.parseDouble(v.trim().replace(',', '.')));
                case "ObjValue" -> LuaValue.NIL;
                case "BoolValue" -> LuaValue.valueOf(isTrue(v));
                case "Vector3Value" -> {
                    String[] p = v.split("[,; ]+");
                    yield p.length >= 3 ? new Vec3L(Double.parseDouble(p[0]), Double.parseDouble(p[1]), Double.parseDouble(p[2])) : new Vec3L(0, 0, 0);
                }
                default -> LuaValue.valueOf(v);
            };
        } catch (NumberFormatException e) { return LuaValue.valueOf(0); }
    }

    public static boolean isTrue(String v) {
        v = v == null ? "" : v.trim().toLowerCase(java.util.Locale.ROOT);
        return v.equals("true") || v.equals("1") || v.equals("yes") || v.equals("on");
    }

    /** create or update the item at path ("Folder/Sub/Name") under root */
    public static LObj apply(LObj root, String path, String cls, String value) {
        String[] seg = path.split("/");
        LObj cur = root;
        for (int i = 0; i < seg.length - 1; i++) {
            LObj c = cur.findChild(seg[i]);
            if (c == null) { c = new LObj("Folder"); c.name = seg[i]; c.setParent(cur); }
            cur = c;
        }
        String n = seg[seg.length - 1];
        LObj ex = cur.findChild(n);
        if (cls.equals("Folder")) {
            if (ex != null && ex.className.equals("Folder")) return ex;
            if (ex instanceof ValueObj) ex.destroy();
            LObj f = new LObj("Folder"); f.name = n; f.setParent(cur); return f;
        }
        ValueObj vo;
        if (ex instanceof ValueObj v && v.className.equals(cls)) vo = v;
        else {
            if (ex instanceof ValueObj) ex.destroy();
            vo = new ValueObj(cls, parse(cls, cls.equals("ObjValue") ? "" : value));
            vo.name = n;
            vo.setParent(cur);
        }
        if (cls.equals("ObjValue")) vo.setRef(value);
        else vo.set(LuaValue.valueOf("Value"), parse(cls, value));
        return vo;
    }

    public static void remove(LObj root, String path) {
        LObj o = find(root, path);
        if (o != null && o != root) o.destroy();
    }

    public static LObj find(LObj root, String path) {
        LObj cur = root;
        for (String s : path.split("[/.]")) {
            if (s.isEmpty()) continue;
            cur = cur.findChild(s);
            if (cur == null) return null;
        }
        return cur;
    }

    /** "Workspace.Lighting", "ServerScripts/Config/MaxPlayers" -> object */
    public static LuaValue resolve(FluwaRuntime rt, String ref) {
        if (ref == null || ref.isBlank()) return LuaValue.NIL;
        String[] seg = ref.trim().split("[/.]");
        LuaValue v = rt.g.get(seg[0]);
        if (!(v instanceof LObj o)) return LuaValue.NIL;
        LObj cur = o;
        for (int i = 1; i < seg.length; i++) { cur = cur.findChild(seg[i]); if (cur == null) return LuaValue.NIL; }
        return cur;
    }

    /** build every item of the given sections from "#Section" -> path -> "Class\tValue" maps */
    public static void build(FluwaRuntime rt, Map<String, Map<String, String>> scripts) {
        for (var e : scripts.entrySet()) {
            if (!e.getKey().startsWith("#")) continue;
            LObj root = root(rt, e.getKey().substring(1));
            for (var it : e.getValue().entrySet()) {
                String[] cv = it.getValue().split("\t", 2);
                try { apply(root, it.getKey(), cv[0], cv.length > 1 ? cv[1] : ""); }
                catch (LuaError ex) { rt.output(1, "Item " + e.getKey().substring(1) + "/" + it.getKey() + ": " + ex.getMessage()); }
            }
        }
    }
}
