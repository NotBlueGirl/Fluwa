package net.idea.fluwa.lua;

import org.luaj.vm2.*;

import java.util.ArrayList;
import java.util.List;

/** Event object: Event:Connect(fn) -> Connection, Connection:Disconnect(), Event:Once(fn) */
public class Signal extends LObj {
    private final List<Handler> handlers = new ArrayList<>();

    static final class Handler { LuaValue fn; FluwaRuntime rt; boolean once; boolean dead; boolean sync; int fails; }

    public Signal(String name) { super("RBXScriptSignal"); this.name = name; }

    public boolean hasHandlers() { return !handlers.isEmpty(); }

    /** Event:Wait() is implemented in Lua (it has to yield the calling thread, see FluwaRuntime prelude) */
    @Override public LuaValue get(LuaValue key) {
        if (key.isstring() && key.tojstring().equals("Wait")) {
            FluwaRuntime r = FluwaRuntime.current();
            if (r != null && r.sigWaitFn != null) return r.sigWaitFn;
        }
        return super.get(key);
    }

    public void fire(LuaValue... args) { fire(LuaValue.varargsOf(args)); }

    public void fire(Varargs args) {
        if (handlers.isEmpty()) return;
        for (Handler h : new ArrayList<>(handlers)) {
            if (h.dead) continue;
            if (h.once) { h.dead = true; handlers.remove(h); }
            if (h.sync) h.rt.call(h.fn, args, "event " + name); else h.rt.callAsync(h.fn, args, "event " + name);
            if (!h.rt.lastCallFailed) { h.fails = 0; continue; }
            // a handler that fails 100 times in a row (e.g. every tick) is disconnected
            if (++h.fails >= 100) {
                h.dead = true; handlers.remove(h);
                h.rt.output(1, "Handler of " + name + " failed 100 times in a row and was disconnected");
            }
        }
    }

    public void clear() { handlers.clear(); }

    public static final class Connection extends LObj {
        final Signal sig; final Handler h;
        Connection(Signal s, Handler h) { super("RBXScriptConnection"); sig = s; this.h = h; }
        @Override protected LuaValue getProp(String k) {
            if (k.equals("Connected")) return valueOf(!h.dead);
            return super.getProp(k);
        }
    }

    private static Varargs connect(LObj s, Varargs a, boolean once) { return connect(s, a, once, false); }
    private static Varargs connect(LObj s, Varargs a, boolean once, boolean sync) {
        Signal sig = (Signal) s;
        Handler h = new Handler();
        h.fn = a.checkfunction(1);
        h.rt = FluwaRuntime.current();
        h.once = once;
        h.sync = sync;
        if (h.rt == null) throw new LuaError("No active Fluwa runtime");
        sig.handlers.add(h);
        h.rt.trackSignal(sig);
        return new Connection(sig, h);
    }

    static {
        reg(Signal.class, "Connect|connect", (s, a) -> connect(s, a, false));
        reg(Signal.class, "Once", (s, a) -> connect(s, a, true));
        // fastest: runs directly on the game thread, wait() is not allowed inside (for per-frame / per-tick handlers)
        reg(Signal.class, "ConnectSync|ConnectFast", (s, a) -> connect(s, a, false, true));

        reg(Signal.class, "DisconnectAll", (s, a) -> { ((Signal) s).handlers.clear(); return NONE; });
        reg(Connection.class, "Disconnect|disconnect", (s, a) -> {
            Connection c = (Connection) s; c.h.dead = true; c.sig.handlers.remove(c.h); return NONE;
        });
    }

    /** Remove all handlers owned by a runtime (used on script reload). */
    public void removeRuntime(FluwaRuntime r) { handlers.removeIf(h -> h.rt == r); }
}
