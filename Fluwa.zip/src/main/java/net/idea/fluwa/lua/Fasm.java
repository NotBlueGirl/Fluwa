package net.idea.fluwa.lua;

import net.idea.fluwa.Config;
import org.luaj.vm2.*;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * getAccess("FASM") - flat assembler bridge. Uses an installed fasm (https://flatassembler.net):
 *   local bin = FASM:Assemble(source)  -> Binary {Size, Hex, Bytes, Listing}
 *   bin:Save(name) -> path   (fluwa/bin/<name>)        bin:Run([args], [timeoutSec]) -> output, exitCode
 * Needs fasm/fasm.exe in PATH (or fasmPath in config) and fullOsAccess=true.
 */
public final class Fasm extends LObj {
    public Fasm() { super("Service"); name = "FASM"; }

    static Path exe() { return Proc.find(Config.fasmPath, "fasm.exe", "fasm", "fasm.x64"); }

    @Override protected boolean threadSafe() { return true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Installed": return valueOf(exe() != null);
            case "Available": return valueOf(exe() != null && Config.fullOsAccess);
            case "Path": { Path p = exe(); return p == null ? NIL : valueOf(p.toString()); }
        }
        return super.getProp(k);
    }

    static Path checkReady() {
        if (!Config.fullOsAccess) throw new LuaError("FASM needs fullOsAccess=true in config/fluwa-common.toml");
        Path p = exe();
        if (p == null) throw new LuaError("FASM is not installed (fasm not found in PATH; set fasmPath in config)");
        return p;
    }

    static AsyncTask assemble(String src) {
        Path fasm = checkReady();
        return AsyncTask.run("FASM", () -> {
            Path dir = Files.createTempDirectory("fluwa-fasm");
            try {
                Files.writeString(dir.resolve("main.asm"), src);
                Proc.Result r = Proc.run(List.of(fasm.toString(), "main.asm", "main.out"), dir, 20);
                Path out = dir.resolve("main.out");
                if (r.exit() != 0 || !Files.exists(out)) throw new LuaError("assembly failed:\n" + r.output().trim());
                return new Binary(Files.readAllBytes(out), r.output());
            } finally {
                try (var st = Files.walk(dir)) { st.sorted(Comparator.reverseOrder()).forEach(p -> { try { Files.delete(p); } catch (IOException ignored) {} }); }
            }
        });
    }

    /** Assembled output */
    public static final class Binary extends LObj {
        final byte[] bytes; final String listing; Path saved;
        Binary(byte[] b, String listing) { super("FasmBinary"); bytes = b; this.listing = listing; name = "Binary"; }
        @Override protected boolean threadSafe() { return true; }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Size": return valueOf(bytes.length);
                case "Listing": case "Output": return valueOf(listing);
                case "Data": return LuaString.valueOf(bytes);
                case "Hex": { StringBuilder sb = new StringBuilder(); for (byte x : bytes) sb.append(String.format("%02X", x & 255)); return valueOf(sb.toString()); }
                case "Bytes": { LuaTable t = new LuaTable(); for (int i = 0; i < bytes.length; i++) t.set(i + 1, valueOf(bytes[i] & 255)); return t; }
                case "Path": return saved == null ? NIL : valueOf(saved.toString());
            }
            return super.getProp(k);
        }
        static {
            reg(Binary.class, "Save", (s, a) -> {
                Binary b = (Binary) s; checkReady();
                String n = a.checkjstring(1);
                if (!n.matches("[A-Za-z0-9_.-]{1,64}") || n.startsWith(".")) throw new LuaError("Bad file name: " + n);
                try {
                    Path dir = Paths.get("fluwa", "bin").toAbsolutePath(); Files.createDirectories(dir);
                    b.saved = dir.resolve(n); Files.write(b.saved, b.bytes);
                    b.saved.toFile().setExecutable(true);
                    return valueOf(b.saved.toString());
                } catch (IOException e) { throw new LuaError("Save failed: " + e.getMessage()); }
            });
            reg(Binary.class, "Run", (s, a) -> {
                Binary b = (Binary) s; checkReady();
                if (b.saved == null) throw new LuaError("Call bin:Save(name) before bin:Run()");
                List<String> cmd = new ArrayList<>(); cmd.add(b.saved.toString());
                LuaValue args = a.arg1();
                if (args.istable()) for (int i = 1; i <= args.length(); i++) cmd.add(args.get(i).tojstring());
                int to = a.optint(2, 10);
                LuaTable r = (LuaTable) AsyncTask.await("FASM Run", () -> {
                    Proc.Result res = Proc.run(cmd, b.saved.getParent(), to);
                    return LuaValue.listOf(new LuaValue[]{valueOf(res.output()), valueOf(res.exit())});
                });
                return varargsOf(r.get(1), r.get(2));
            });
        }
    }

    static {
        reg(Fasm.class, "Assemble", (s, a) -> assemble(a.checkjstring(1)).await());
        reg(Fasm.class, "AssembleAsync", (s, a) -> assemble(a.checkjstring(1)));
    }
}
