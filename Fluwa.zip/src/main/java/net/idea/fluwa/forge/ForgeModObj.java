package net.idea.fluwa.forge;

import net.idea.fluwa.lua.*;
import net.minecraftforge.fml.ModContainer;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.forgespi.language.IModInfo;
import org.luaj.vm2.*;

import java.util.*;

/**
 * ForgeMod: an installed Forge mod (read-only information, its configs and mod event bus) or a script mod created with
 * Forge:RegisterMod{...} (Register* entries, configs, event handlers, commands; can be enabled/disabled).
 */
public class ForgeModObj extends LObj {
    /** Register&lt;Kind&gt; method -> registry type */
    static final LinkedHashMap<String, String> KINDS = new LinkedHashMap<>();
    static {
        String[][] k = {{"Block", "block"}, {"Item", "item"}, {"Entity", "entity_type"}, {"Biome", "worldgen/biome"}, {"Dimension", "dimension"},
                {"Sound", "sound_event"}, {"Particle", "particle_type"}, {"Menu", "menu"}, {"Screen", "fluwa:screen"}, {"Container", "menu"},
                {"TileEntity", "block_entity_type"}, {"BlockEntity", "block_entity_type"}, {"Fluid", "fluid"}, {"Effect", "mob_effect"},
                {"Enchantment", "enchantment"}, {"VillagerProfession", "villager_profession"}, {"PointOfInterest", "point_of_interest_type"},
                {"Structure", "worldgen/structure"}, {"Feature", "worldgen/feature"}, {"ChunkGenerator", "worldgen/chunk_generator"},
                {"BiomeSource", "worldgen/biome_source"}, {"DimensionType", "dimension_type"}, {"LevelStem", "dimension"},
                {"NoiseGeneratorSettings", "worldgen/noise_settings"}, {"Processor", "worldgen/structure_processor"},
                {"LootModifier", "forge:global_loot_modifier_serializers"}, {"DataProvider", "fluwa:data_provider"}, {"RecipeType", "recipe_type"},
                {"RecipeSerializer", "recipe_serializer"}, {"Ingredient", "forge:ingredient_serializer"}, {"CreativeTab", "creative_mode_tab"},
                {"Attribute", "attribute"}, {"MemoryModuleType", "memory_module_type"}, {"SensorType", "sensor_type"}, {"Activity", "activity"},
                {"Schedule", "schedule"}, {"EntityDataSerializer", "forge:entity_data_serializers"}, {"ParticleType", "particle_type"},
                {"SoundEvent", "sound_event"}, {"Stats", "stat_type"}, {"CommandArgumentType", "command_argument_type"},
                {"TreeDecorator", "worldgen/tree_decorator_type"}, {"FoliagePlacer", "worldgen/foliage_placer_type"},
                {"TrunkPlacer", "worldgen/trunk_placer_type"}, {"BlockStateProvider", "worldgen/block_state_provider_type"},
                {"ItemModelProvider", "fluwa:item_model_provider"}, {"BlockModelProvider", "fluwa:block_model_provider"},
                {"LanguageProvider", "fluwa:language_provider"}, {"RecipeProvider", "fluwa:recipe_provider"},
                {"LootTableProvider", "fluwa:loot_table_provider"}, {"TagsProvider", "fluwa:tags_provider"},
                {"DataPackProvider", "fluwa:data_pack_provider"}, {"ResourcePackProvider", "fluwa:resource_pack_provider"}};
        for (String[] x : k) KINDS.put(x[0], x[1]);
    }

    final ForgeService forge;
    final String id;
    final IModInfo info;     // real mod
    final LuaTable def;      // script mod definition
    boolean enabled = true, loaded = true;
    ForgeEventBusObj bus;
    ForgeConfigObj config;
    /** script registrations: "registry|id" -> object */
    final Map<String, LuaValue> regs = new LinkedHashMap<>();
    final Signal eLoad = new Signal("E_Load"), eUnload = new Signal("E_Unload"), eEnable = new Signal("E_Enable"), eDisable = new Signal("E_Disable"),
            eRegister = new Signal("E_Register"), eConfig = new Signal("E_ConfigChanged"), eReload = new Signal("E_Reload"), eError = new Signal("E_Error");

    ForgeModObj(ForgeService f, IModInfo info) { super("ForgeMod"); forge = f; this.info = info; def = null; id = info.getModId(); name = info.getDisplayName(); }

    ForgeModObj(ForgeService f, LuaTable t) {
        super("ForgeMod");
        forge = f; info = null; def = t;
        LuaValue i = t.get("Id").isnil() ? t.get("id") : t.get("Id");
        id = i.checkjstring().toLowerCase(Locale.ROOT);
        if (!id.matches("[a-z][a-z0-9_]{1,63}")) throw new LuaError("Mod id must match [a-z][a-z0-9_]{1,63}");
        name = s("Name", id);
    }

    boolean script() { return info == null; }
    String s(String k, String d) { if (def == null) return d; LuaValue v = def.get(k); if (v.isnil()) v = def.get(k.toLowerCase(Locale.ROOT)); return v.isnil() ? d : v.tojstring(); }

    String version() { return info != null ? info.getVersion().toString() : s("Version", "1.0.0"); }
    String description() { return info != null ? info.getDescription().trim() : s("Description", ""); }
    String cfg(String k) { if (info == null) return null; Optional<Object> o = info.getConfig().getConfigElement(k); return o.map(String::valueOf).orElse(null); }
    LuaValue authors() {
        if (info != null) { String a = cfg("authors"); return a == null ? new LuaTable() : ForgeRegistryObj.strList(Arrays.stream(a.split("\\s*,\\s*")).filter(x -> !x.isEmpty()).toList()); }
        LuaValue a = def.get("Authors").isnil() ? def.get("Author") : def.get("Authors");
        if (a.istable()) return a;
        return a.isnil() ? new LuaTable() : ForgeRegistryObj.strList(List.of(a.tojstring()));
    }
    String credits() { return info != null ? Objects.requireNonNullElse(cfg("credits"), "") : s("Credits", ""); }
    String license() { return info != null ? info.getOwningFile().getLicense() : s("License", "All Rights Reserved"); }
    String logo() { return info != null ? info.getLogoFile().orElse("") : s("Logo", ""); }
    Optional<? extends ModContainer> container() { return info == null ? Optional.empty() : ModList.get().getModContainerById(id); }

    List<String> deps() {
        List<String> l = new ArrayList<>();
        if (info != null) for (var d : info.getDependencies()) l.add(d.getModId());
        else { LuaValue d = def.get("Dependencies"); if (d.istable()) for (int i = 1; i <= d.length(); i++) l.add(d.get(i).tojstring()); }
        return l;
    }
    List<String> dependants() {
        List<String> l = new ArrayList<>();
        for (IModInfo m : ModList.get().getMods()) for (var d : m.getDependencies()) if (d.getModId().equals(id)) { l.add(m.getModId()); break; }
        for (ForgeModObj m : forge.scriptMods.values()) if (m != this && m.deps().contains(id)) l.add(m.id);
        return l;
    }

    String path() {
        if (info != null) try { return info.getOwningFile().getFile().getFilePath().toString(); } catch (RuntimeException e) { return ""; }
        return config != null ? config.file.getNioPath().toString() : "";
    }

    String state() {
        if (info != null) return container().map(c -> c.getCurrentState().name()).orElse("UNKNOWN");
        if (!loaded) return "UNLOADED";
        return enabled ? "ENABLED" : "DISABLED";
    }

    Info containerInfo() {
        Info i = new Info("ForgeModContainer", id);
        i.put("ModId", id).put("Namespace", id).put("Script", valueOf(script()));
        i.live("State", () -> valueOf(state()));
        container().ifPresent(c -> { Object m = c.getMod(); i.put("ModClass", m == null ? "" : m.getClass().getName()).put("ContainerClass", c.getClass().getName()); });
        return i;
    }
    Info metadata() {
        Info i = new Info("ForgeModMetadata", id);
        i.put("Id", id).put("Name", name).put("Version", version()).put("Description", description()).put("Authors", authors()).put("Credits", credits())
                .put("License", license()).put("Logo", logo()).put("Dependencies", ForgeRegistryObj.strList(deps()));
        if (info != null) { i.put("URL", info.getModURL().map(Object::toString).orElse("")).put("UpdateURL", info.getUpdateURL().map(Object::toString).orElse("")).put("Namespace", info.getNamespace()); }
        return i;
    }
    Info fileInfo() {
        Info i = new Info("ForgeModFile", id);
        if (info != null) {
            var f = info.getOwningFile();
            i.put("FileName", f.getFile().getFileName()).put("Path", path()).put("Type", f.getFile().getType().name()).put("License", f.getLicense());
            List<String> ms = new ArrayList<>(); for (IModInfo m : f.getMods()) ms.add(m.getModId());
            i.put("Mods", ForgeRegistryObj.strList(ms));
        } else i.put("FileName", id + ".toml").put("Path", path()).put("Type", "SCRIPT").put("Mods", ForgeRegistryObj.strList(List.of(id)));
        return i;
    }

    ForgeEventBusObj eventBus() {
        if (bus != null) return bus;
        if (info != null) {
            net.minecraftforge.eventbus.api.IEventBus b = null;
            var c = container();
            if (c.isPresent() && c.get() instanceof net.minecraftforge.fml.javafmlmod.FMLModContainer fc) b = fc.getEventBus();
            bus = new ForgeEventBusObj(forge, id, "ModBus", b, forge.forgeBus());
        } else {
            bus = new ForgeEventBusObj(forge, id, "ScriptMod", net.minecraftforge.common.MinecraftForge.EVENT_BUS, forge.forgeBus());
            bus.enabled = () -> enabled && loaded;
        }
        return bus;
    }

    void checkScript(String what) { if (!script()) throw new LuaError(what + ": " + id + " is an installed mod; only script mods (Forge:RegisterMod) can register at runtime"); }
    void checkActive() { if (!loaded) throw new LuaError("Mod " + id + " is unloaded"); }

    LuaValue register(String kind, String rid, LuaValue settings) {
        checkScript("Register" + kind);
        checkActive();
        String full = rid.contains(":") ? rid : id + ":" + rid;
        String regType = KINDS.get(kind);
        ForgeRegistryObj r = forge.registry(regType);
        LuaValue obj = forge.makeEntry(this, kind, r.type, full, settings);
        r.register(full, obj, true);
        regs.put(r.type + "|" + full, obj);
        eRegister.fire(valueOf(r.type), valueOf(full), obj);
        return obj;
    }

    void setEnabled(boolean b) {
        if (!script()) throw new LuaError("Installed mods can't be enabled/disabled at runtime");
        if (enabled == b) return;
        enabled = b;
        (b ? eEnable : eDisable).fire(this);
        forge.fire(b ? "E_ModEnabled" : "E_ModDisabled", this);
        hook(b ? "OnEnable" : "OnDisable");
    }

    void hook(String hook) {
        if (def == null) return;
        LuaValue f = def.get(hook);
        if (f.isfunction()) rt.callAsync(f, this, "ForgeMod " + id + "." + hook);
    }

    void unload() {
        if (!loaded) return;
        loaded = false;
        for (var e : new ArrayList<>(regs.entrySet())) {
            String[] p = e.getKey().split("\\|", 2);
            try { forge.registry(p[0]).unregister(p[1]); } catch (LuaError ignored) {}
        }
        regs.clear();
        forge.removeModCommands(id);
        if (bus != null) bus.clear();
        eUnload.fire(this);
        forge.fire("E_ModUnloaded", this);
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Id": return valueOf(id);
            case "Version": return valueOf(version());
            case "Description": return valueOf(description());
            case "Authors": return authors();
            case "Credits": return valueOf(credits());
            case "License": return valueOf(license());
            case "Logo": return valueOf(logo());
            case "Loaded": return valueOf(info != null ? ModList.get().isLoaded(id) : loaded);
            case "Enabled": return valueOf(info != null || enabled);
            case "Container": return containerInfo();
            case "Metadata": return metadata();
            case "EventBus": return eventBus();
            case "Config": { LuaValue c = forge.config(this); return c; }
            case "Registry": {
                LuaTable t = new LuaTable();
                for (var e : regs.entrySet()) { String[] p = e.getKey().split("\\|", 2); LuaValue sub = t.get(p[0]); if (sub.isnil()) { sub = new LuaTable(); t.set(p[0], sub); } sub.set(p[1], e.getValue()); }
                return t;
            }
            case "Side": return valueOf(rt.server ? "SERVER" : "CLIENT");
            case "Dist": return valueOf(net.minecraftforge.fml.loading.FMLEnvironment.dist.name());
            case "File": return fileInfo();
            case "Path": return valueOf(path());
            case "Dependencies": return ForgeRegistryObj.strList(deps());
            case "Dependants": return ForgeRegistryObj.strList(dependants());
            case "Script": return valueOf(script());
            case "State": return valueOf(state());
            case "E_Load": return eLoad;
            case "E_Unload": return eUnload;
            case "E_Enable": return eEnable;
            case "E_Disable": return eDisable;
            case "E_Register": return eRegister;
            case "E_ConfigChanged": return eConfig;
            case "E_Reload": return eReload;
            case "E_Error": return eError;
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (k.equals("Enabled")) { setEnabled(v.toboolean()); return true; }
        return super.setProp(k, v);
    }
    @Override public void setName(String n) { throw new LuaError("ForgeMod.Name is read-only"); }

    static ForgeModObj M(LObj s) { return (ForgeModObj) s; }
    static {
        Class<ForgeModObj> C = ForgeModObj.class;
        reg(C, "GetId", (s, a) -> valueOf(M(s).id));
        reg(C, "GetName", (s, a) -> valueOf(M(s).name));
        reg(C, "GetVersion", (s, a) -> valueOf(M(s).version()));
        reg(C, "GetDescription", (s, a) -> valueOf(M(s).description()));
        reg(C, "GetAuthors", (s, a) -> M(s).authors());
        reg(C, "GetCredits", (s, a) -> valueOf(M(s).credits()));
        reg(C, "GetLicense", (s, a) -> valueOf(M(s).license()));
        reg(C, "GetLogoFile", (s, a) -> valueOf(M(s).logo()));
        reg(C, "GetModFile", (s, a) -> M(s).fileInfo());
        reg(C, "GetMetadata", (s, a) -> M(s).metadata());
        reg(C, "IsLoaded", (s, a) -> M(s).getProp("Loaded"));
        reg(C, "IsEnabled", (s, a) -> M(s).getProp("Enabled"));
        reg(C, "GetContainer", (s, a) -> M(s).containerInfo());
        reg(C, "GetEventBus", (s, a) -> M(s).eventBus());
        reg(C, "GetConfig", (s, a) -> M(s).forge.config(M(s)));
        reg(C, "GetRegistry", (s, a) -> M(s).forge.registry(a.checkjstring(1)));
        for (String kind : KINDS.keySet())
            reg(C, "Register" + kind, (s, a) -> M(s).register(kind, a.checkjstring(1), a.arg(2)));
        reg(C, "RegisterRecipe", (s, a) -> { M(s).checkScript("RegisterRecipe"); return M(s).forge.registerRecipe(M(s).id, a.checkjstring(1), a.arg(2)); });
        reg(C, "RegisterCapability", (s, a) -> { M(s).checkScript("RegisterCapability"); return M(s).forge.registerCapability(M(s).id, a.checkjstring(1), a.arg(2)); });
        reg(C, "RegisterCommand", (s, a) -> { M(s).checkScript("RegisterCommand"); return M(s).forge.registerCommand(M(s).id, a.checktable(1)); });
        reg(C, "RegisterKeyBinding", (s, a) -> { M(s).checkScript("RegisterKeyBinding"); return M(s).forge.registerKey(M(s).id, a.checkjstring(1), a.arg(2)); });
        reg(C, "RegisterConfig", (s, a) -> { M(s).checkScript("RegisterConfig"); return M(s).forge.registerConfig(M(s), a.arg1()); });
        reg(C, "RegisterEventHandler", (s, a) -> { M(s).eventBus().subscribe(a.checkjstring(1), a.arg(2), a.arg(3), NIL); return a.arg(2); });
        reg(C, "Unregister", (s, a) -> {
            ForgeModObj m = M(s); m.checkScript("Unregister");
            String full = a.checkjstring(1).contains(":") ? a.checkjstring(1) : m.id + ":" + a.checkjstring(1);
            boolean any = false;
            for (String key : new ArrayList<>(m.regs.keySet())) if (key.endsWith("|" + full)) {
                String[] p = key.split("\\|", 2); m.forge.registry(p[0]).unregister(p[1]); m.regs.remove(key); any = true;
            }
            return valueOf(any); });
        reg(C, "Enable", (s, a) -> { M(s).setEnabled(true); return NONE; });
        reg(C, "Disable", (s, a) -> { M(s).setEnabled(false); return NONE; });
        reg(C, "Reload", (s, a) -> {
            ForgeModObj m = M(s);
            if (m.config != null) m.config.load(true);
            m.hook("OnReload");
            m.eReload.fire(m); return NONE; });
        reg(C, "Unload", (s, a) -> { M(s).checkScript("Unload"); M(s).unload(); return NONE; });
        reg(C, "GetState", (s, a) -> valueOf(M(s).state()));
    }
}
