package net.idea.fluwa.forge;

import com.electronwill.nightconfig.core.*;
import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.core.file.FileConfig;
import net.idea.fluwa.lua.*;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.config.ModConfig;
import org.luaj.vm2.*;

import java.nio.file.*;
import java.util.*;

/**
 * ForgeConfig: a mod configuration. Either a real Forge ModConfig (any installed mod — writing configs of other mods
 * needs fullOsAccess=true) or the TOML config of a script mod (config/fluwa-mods/&lt;modid&gt;.toml). Keys are dotted paths
 * ("general.maxPlayers"). A ForgeConfigSection (GetSection) is the same object restricted to a sub-path.
 */
public class ForgeConfigObj extends LObj {
    final ForgeService forge;
    final String modId;
    final ModConfig mod;            // real config or null
    final CommentedFileConfig file; // script config or null
    final LuaTable defaults;        // script config defaults
    final String prefix;            // section path ("" = root)
    final ForgeConfigObj root;
    boolean dirty, loaded;
    final Signal changed = new Signal("E_Changed"), saved = new Signal("E_Saved"), eLoaded = new Signal("E_Loaded"),
            reloaded = new Signal("E_Reloaded"), reset = new Signal("E_Reset"), error = new Signal("E_Error");

    ForgeConfigObj(ForgeService f, String modId, ModConfig m) {
        super("ForgeConfig");
        forge = f; this.modId = modId; mod = m; file = null; defaults = null; prefix = ""; root = this; loaded = m.getConfigData() != null;
        name = modId + "-" + m.getType().extension();
    }

    ForgeConfigObj(ForgeService f, String modId, Path p, LuaTable defs) {
        super("ForgeConfig");
        forge = f; this.modId = modId; mod = null; defaults = defs; prefix = ""; root = this;
        try { Files.createDirectories(p.getParent()); } catch (Exception e) { throw new LuaError("Can't create " + p.getParent() + ": " + e.getMessage()); }
        file = CommentedFileConfig.builder(p).sync().preserveInsertionOrder().build();
        try { file.load(); } catch (RuntimeException e) { /* new / broken file: defaults */ }
        boolean added = applyDefaults(file, defs, "");
        if (added) file.save();
        loaded = true;
        name = modId;
    }

    ForgeConfigObj(ForgeConfigObj parent, String section) {
        super("ForgeConfigSection");
        forge = parent.forge; modId = parent.modId; mod = parent.mod; file = parent.file; defaults = parent.defaults;
        root = parent.root; prefix = parent.prefix.isEmpty() ? section : parent.prefix + "." + section; loaded = true;
        name = section;
    }

    static boolean applyDefaults(Config c, LuaTable t, String pre) {
        if (t == null) return false;
        boolean any = false;
        for (LuaValue k = t.next(LuaValue.NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) {
            String key = pre.isEmpty() ? k.tojstring() : pre + "." + k.tojstring();
            LuaValue v = t.get(k);
            if (v.istable() && !isList(v)) { any |= applyDefaults(c, (LuaTable) v, key); continue; }
            if (!c.contains(key)) { c.set(key, toJava(v)); any = true; }
        }
        return any;
    }

    static boolean isList(LuaValue v) { return v.istable() && (v.length() > 0 || v.next(LuaValue.NIL).arg1().isnil()); }

    static Object toJava(LuaValue v) {
        if (v.isboolean()) return v.toboolean();
        if (v.isnumber() && v.isinttype()) return v.toint();
        if (v.isnumber()) { double d = v.todouble(); return d == Math.rint(d) && Math.abs(d) < 1e15 ? (Object) (long) d : d; }
        if (v.istable()) {
            if (isList(v)) { List<Object> l = new ArrayList<>(); for (int i = 1; i <= v.length(); i++) l.add(toJava(v.get(i))); return l; }
            Config c = Config.inMemory();
            LuaTable t = (LuaTable) v;
            for (LuaValue k = t.next(LuaValue.NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) c.set(k.tojstring(), toJava(t.get(k)));
            return c;
        }
        return v.tojstring();
    }

    static LuaValue toLua(Object o) {
        if (o instanceof UnmodifiableConfig c) {
            LuaTable t = new LuaTable();
            for (UnmodifiableConfig.Entry e : c.entrySet()) t.set(e.getKey(), toLua(e.getValue()));
            return t;
        }
        return J.lua(o);
    }

    CommentedConfig data() {
        CommentedConfig d = mod != null ? mod.getConfigData() : file;
        if (d == null) throw new LuaError("Config of " + modId + " is not loaded (server configs load with the world)");
        return d;
    }
    String path(String k) { return prefix.isEmpty() ? k : prefix + "." + k; }

    void checkWrite() {
        if (mod != null && !forge.isScriptMod(modId) && !modId.equals("fluwa") && !net.idea.fluwa.Config.fullOsAccess)
            throw new LuaError("Changing the config of mod '" + modId + "' requires fullOsAccess=true in config/fluwa-common.toml");
    }

    ForgeConfigSpec.ValueSpec spec(String path) {
        if (mod == null || !(mod.getSpec() instanceof ForgeConfigSpec fs)) return null;
        try { Object o = fs.getSpec().get(path); return o instanceof ForgeConfigSpec.ValueSpec v ? v : null; } catch (RuntimeException e) { return null; }
    }

    void afterChange() {
        if (mod != null && mod.getSpec() instanceof ForgeConfigSpec fs) { try { fs.afterReload(); } catch (RuntimeException ignored) {} }
    }

    LuaValue read(String k) { return toLua(data().get(path(k))); }

    void write(String k, LuaValue v) {
        checkWrite();
        String p = path(k);
        Object nv = toJava(v);
        ForgeConfigSpec.ValueSpec vs = spec(p);
        if (vs != null) {
            if (nv instanceof Long l && vs.getClazz() == Integer.class) nv = l.intValue();
            if (nv instanceof Integer i && (vs.getClazz() == Double.class || vs.getDefault() instanceof Double)) nv = i.doubleValue();
            if (nv instanceof Long l && vs.getDefault() instanceof Double) nv = l.doubleValue();
            if (vs.getDefault() instanceof Enum<?> en && nv instanceof String s) {
                Object match = null;
                for (Object c : en.getDeclaringClass().getEnumConstants()) if (((Enum<?>) c).name().equalsIgnoreCase(s)) match = c;
                if (match != null) nv = match;
            }
            if (!vs.test(nv)) throw new LuaError("Invalid value for " + p + ": " + v.tojstring() + (vs.getRange() != null ? " (range " + vs.getRange() + ")" : ""));
        }
        LuaValue old = read(k);
        CommentedConfig d = data();
        if (v.isnil()) d.remove(p); else d.set(p, nv);
        root.dirty = true;
        afterChange();
        LuaValue now = read(k);
        root.changed.fire(valueOf(p), old, now);
        if (root != this) changed.fire(valueOf(k), old, now);
        forge.configChanged(modId, root);
    }

    void save() {
        try {
            if (mod != null) { checkWrite(); mod.save(); }
            else file.save();
            root.dirty = false;
            root.saved.fire(root);
        } catch (LuaError e) { throw e; } catch (RuntimeException e) { fail(e); }
    }

    void load(boolean reloading) {
        try {
            CommentedConfig d = data();
            if (d instanceof FileConfig fc) fc.load();
            if (file != null) applyDefaults(file, defaults, "");
            afterChange();
            root.dirty = false; root.loaded = true;
            (reloading ? root.reloaded : root.eLoaded).fire(root);
        } catch (LuaError e) { throw e; } catch (RuntimeException e) { fail(e); }
    }

    void resetAll() {
        checkWrite();
        CommentedConfig d = data();
        if (mod != null && mod.getSpec() instanceof ForgeConfigSpec fs) resetSpec(d, fs.getSpec(), "");
        else if (file != null) { file.clear(); applyDefaults(file, defaults, ""); }
        root.dirty = true;
        afterChange();
        root.reset.fire(root);
        forge.configChanged(modId, root);
    }

    static void resetSpec(CommentedConfig d, UnmodifiableConfig spec, String pre) {
        for (UnmodifiableConfig.Entry e : spec.entrySet()) {
            String p = pre.isEmpty() ? e.getKey() : pre + "." + e.getKey();
            Object v = e.getValue();
            if (v instanceof ForgeConfigSpec.ValueSpec vs) d.set(p, vs.getDefault());
            else if (v instanceof UnmodifiableConfig sub) resetSpec(d, sub, p);
        }
    }

    void fail(Exception e) {
        String m = e.getMessage() == null ? e.toString() : e.getMessage();
        root.error.fire(valueOf(m));
        throw new LuaError("ForgeConfig " + modId + ": " + m);
    }

    UnmodifiableConfig here() {
        CommentedConfig d = data();
        if (prefix.isEmpty()) return d;
        Object o = d.get(prefix);
        if (!(o instanceof UnmodifiableConfig c)) throw new LuaError("Section " + prefix + " does not exist");
        return c;
    }

    List<String> sections() {
        List<String> l = new ArrayList<>();
        for (UnmodifiableConfig.Entry e : here().entrySet()) if (e.getValue() instanceof UnmodifiableConfig) l.add(e.getKey());
        return l;
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "ModId": return valueOf(modId);
            case "File": return valueOf(mod != null ? mod.getFileName() : file.getNioPath().getFileName().toString());
            case "Path": {
                if (file != null) return valueOf(file.getNioPath().toAbsolutePath().toString());
                try { return valueOf(mod.getFullPath().toString()); } catch (RuntimeException e) { return valueOf(mod.getFileName()); }
            }
            case "Sections": return ForgeRegistryObj.strList(sections());
            case "Values": return toLua(here());
            case "Dirty": return valueOf(root.dirty);
            case "Loaded": return valueOf(mod != null ? mod.getConfigData() != null : root.loaded);
            case "ConfigType": return valueOf(mod != null ? mod.getType().name() : "SCRIPT");
            case "Section": return valueOf(prefix);
            case "E_Changed": return root == this ? changed : changed;
            case "E_Saved": return root.saved;
            case "E_Loaded": return root.eLoaded;
            case "E_Reloaded": return root.reloaded;
            case "E_Reset": return root.reset;
            case "E_Error": return root.error;
        }
        return super.getProp(k);
    }
    @Override public void setName(String n) { throw new LuaError(className + ".Name is read-only"); }

    static ForgeConfigObj C(LObj s) { return (ForgeConfigObj) s; }
    static {
        Class<ForgeConfigObj> C = ForgeConfigObj.class;
        reg(C, "Get", (s, a) -> { LuaValue v = C(s).read(a.checkjstring(1)); return v.isnil() && !a.isnil(2) ? a.arg(2) : v; });
        reg(C, "Set", (s, a) -> { C(s).write(a.checkjstring(1), a.arg(2)); return NONE; });
        reg(C, "GetBool", (s, a) -> { LuaValue v = C(s).read(a.checkjstring(1)); return v.isnil() ? valueOf(a.optboolean(2, false)) : valueOf(v.toboolean()); });
        reg(C, "GetInt", (s, a) -> { LuaValue v = C(s).read(a.checkjstring(1)); return v.isnumber() ? valueOf((long) v.todouble()) : a.isnil(2) ? (v.isnil() ? NIL : valueOf(v.tojstring())) : a.arg(2); });
        reg(C, "GetFloat", (s, a) -> { LuaValue v = C(s).read(a.checkjstring(1)); return v.isnumber() ? valueOf(v.todouble()) : a.isnil(2) ? NIL : a.arg(2); });
        reg(C, "GetString", (s, a) -> { LuaValue v = C(s).read(a.checkjstring(1)); return v.isnil() ? (a.isnil(2) ? NIL : a.arg(2)) : valueOf(v.tojstring()); });
        reg(C, "GetList", (s, a) -> { LuaValue v = C(s).read(a.checkjstring(1)); if (v.istable()) return v; LuaTable t = new LuaTable(); if (!v.isnil()) t.set(1, v); return t; });
        reg(C, "GetEnum", (s, a) -> {
            LuaValue v = C(s).read(a.checkjstring(1));
            if (v.isnil()) return NIL;
            String sv = v.tojstring();
            if (a.arg(2).istable()) {
                LuaTable t = (LuaTable) a.arg(2);
                for (int i = 1; i <= t.length(); i++) if (t.get(i).tojstring().equalsIgnoreCase(sv)) return t.get(i);
                for (LuaValue k = t.next(NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) if (k.tojstring().equalsIgnoreCase(sv)) return t.get(k);
                throw new LuaError(sv + " is not a valid value of the enum");
            }
            return valueOf(sv); });
        reg(C, "Has", (s, a) -> valueOf(C(s).data().contains(C(s).path(a.checkjstring(1)))));
        reg(C, "Remove", (s, a) -> { C(s).write(a.checkjstring(1), NIL); return NONE; });
        reg(C, "Save", (s, a) -> { C(s).save(); return NONE; });
        reg(C, "Load", (s, a) -> { C(s).load(false); return NONE; });
        reg(C, "Reload", (s, a) -> { C(s).load(true); return NONE; });
        reg(C, "Reset", (s, a) -> { C(s).resetAll(); return NONE; });
        reg(C, "GetSections", (s, a) -> ForgeRegistryObj.strList(C(s).sections()));
        reg(C, "GetSection", (s, a) -> {
            ForgeConfigObj c = C(s); String n = a.checkjstring(1);
            if (!(c.data().get(c.path(n)) instanceof UnmodifiableConfig)) return NIL;
            return new ForgeConfigObj(c, n); });
        reg(C, "AddSection", (s, a) -> {
            ForgeConfigObj c = C(s); c.checkWrite(); String n = a.checkjstring(1);
            if (!(c.data().get(c.path(n)) instanceof UnmodifiableConfig)) { c.data().set(c.path(n), c.data().createSubConfig()); c.root.dirty = true; }
            return new ForgeConfigObj(c, n); });
        reg(C, "RemoveSection", (s, a) -> {
            ForgeConfigObj c = C(s); c.checkWrite(); String n = a.checkjstring(1);
            boolean had = c.data().get(c.path(n)) instanceof UnmodifiableConfig;
            if (had) { c.data().remove(c.path(n)); c.root.dirty = true; }
            return valueOf(had); });
        reg(C, "GetKeys", (s, a) -> { List<String> l = new ArrayList<>(); for (UnmodifiableConfig.Entry e : C(s).here().entrySet()) l.add(e.getKey()); return ForgeRegistryObj.strList(l); });
        reg(C, "GetComment", (s, a) -> { String c = C(s).data().getComment(C(s).path(a.checkjstring(1))); return c == null ? NIL : valueOf(c); });
        reg(C, "SetComment", (s, a) -> { C(s).checkWrite(); C(s).data().setComment(C(s).path(a.checkjstring(1)), a.checkjstring(2)); C(s).root.dirty = true; return NONE; });
    }
}
