package net.idea.fluwa.forge;

import net.idea.fluwa.lua.LObj;
import net.minecraftforge.eventbus.api.Event;
import org.luaj.vm2.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * A Forge event seen from Lua (ForgeEvent). Real events expose their getters reflectively: event.Entity == getEntity(),
 * event.Canceled, event:Cancel(), event:SetResult("DENY"), event:Get("Pos"), event:Set("NewSpeed", 3), event:Call("getX").
 * Custom script events (Bus:Post({Type = "MyEvent", ...})) carry the given fields.
 */
public class ForgeEventObj extends LObj {
    final Event ev;
    final LuaTable custom;
    final String type;
    boolean canceled;

    ForgeEventObj(Event e, LuaTable custom) {
        super("ForgeEvent");
        this.ev = e; this.custom = custom;
        if (e != null) type = typeName(e.getClass());
        else type = custom.get("Type").isnil() ? custom.get("Name").optjstring("CustomEvent") : custom.get("Type").tojstring();
        name = type;
    }

    static String typeName(Class<?> c) {
        String n = c.getName();
        int i = n.lastIndexOf('.');
        return (i >= 0 ? n.substring(i + 1) : n).replace('$', '.');
    }

    boolean canceled() { return ev != null ? ev.isCancelable() && ev.isCanceled() : canceled; }

    void cancel(boolean b) {
        if (ev == null) { canceled = b; return; }
        if (!ev.isCancelable()) throw new LuaError(type + " is not cancelable");
        ev.setCanceled(b);
    }

    static Method getter(Class<?> c, String k) {
        for (String p : new String[]{"get", "is", "has", "", "can"}) {
            String n = p.isEmpty() ? Character.toLowerCase(k.charAt(0)) + k.substring(1) : p + k;
            try { Method m = c.getMethod(n); if (m.getParameterCount() == 0 && m.getReturnType() != void.class) return m; } catch (NoSuchMethodException ignored) {}
        }
        return null;
    }

    LuaValue read(String k) {
        if (ev == null) return custom.get(k);
        Method m = getter(ev.getClass(), k);
        if (m == null) {
            try { Field f = ev.getClass().getField(Character.toLowerCase(k.charAt(0)) + k.substring(1)); return J.lua(f.get(ev)); } catch (ReflectiveOperationException ignored) {}
            if (net.idea.fluwa.Config.forgeUnlocked) {   // deep reflection: private / protected fields of the event
                Field f = JavaObj.field(ev.getClass(), k);
                if (f == null) f = JavaObj.field(ev.getClass(), Character.toLowerCase(k.charAt(0)) + k.substring(1));
                if (f != null && !Modifier.isStatic(f.getModifiers())) return J.lua(JavaObj.readField(f, ev));
            }
            return null;
        }
        try { return J.lua(m.invoke(ev)); }
        catch (InvocationTargetException e) { throw new LuaError(type + "." + k + ": " + e.getCause()); }
        catch (ReflectiveOperationException e) { throw new LuaError(type + "." + k + ": " + e); }
    }

    boolean write(String k, LuaValue v) {
        if (ev == null) { custom.set(k, v); return true; }
        for (Method m : ev.getClass().getMethods()) {
            if (!m.getName().equals("set" + k) || m.getParameterCount() != 1) continue;
            try { m.invoke(ev, J.java(v, m.getParameterTypes()[0])); return true; }
            catch (LuaError e) { continue; }
            catch (InvocationTargetException e) { throw new LuaError(type + "." + k + ": " + e.getCause()); }
            catch (ReflectiveOperationException e) { throw new LuaError(type + "." + k + ": " + e); }
        }
        if (net.idea.fluwa.Config.forgeUnlocked) {
            Field f = JavaObj.field(ev.getClass(), k);
            if (f == null) f = JavaObj.field(ev.getClass(), Character.toLowerCase(k.charAt(0)) + k.substring(1));
            if (f != null && !Modifier.isStatic(f.getModifiers())) { JavaObj.writeField(f, ev, v); return true; }
        }
        return false;
    }

    Varargs callJava(String n, Varargs a) {
        if (ev == null) throw new LuaError("Custom events have no Java methods");
        for (Method m : ev.getClass().getMethods()) {
            if (!m.getName().equals(n) || m.getParameterCount() != a.narg()) continue;
            try {
                Object[] args = new Object[m.getParameterCount()];
                for (int i = 0; i < args.length; i++) args[i] = J.java(a.arg(i + 1), m.getParameterTypes()[i]);
                return J.lua(m.invoke(ev, args));
            } catch (LuaError e) { continue; }
            catch (InvocationTargetException e) { throw new LuaError(type + ":" + n + ": " + e.getCause()); }
            catch (ReflectiveOperationException e) { throw new LuaError(type + ":" + n + ": " + e); }
        }
        if (net.idea.fluwa.Config.forgeUnlocked && JavaObj.hasMethod(ev.getClass(), n)) return J.lua(JavaObj.call(ev.getClass(), ev, n, a));
        throw new LuaError(type + " has no method " + n + " with " + a.narg() + " argument(s)");
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Type": case "EventType": return valueOf(type);
            case "Class": return valueOf(ev == null ? "custom" : ev.getClass().getName());
            case "Cancelable": return valueOf(ev == null || ev.isCancelable());
            case "Canceled": case "Cancelled": return valueOf(canceled());
            case "Result": return ev == null ? NIL : valueOf(ev.getResult() == null ? "DEFAULT" : ev.getResult().name());
            case "HasResult": return valueOf(ev != null && ev.hasResult());
            case "Phase": return ev == null || ev.getPhase() == null ? NIL : valueOf(ev.getPhase().name());
            case "Name": return valueOf(type);
            case "Parent": return NIL;
            case "Fields": {
                LuaTable t = new LuaTable();
                if (ev == null) return custom;
                for (Method m : ev.getClass().getMethods()) {
                    if (m.getParameterCount() != 0 || m.getDeclaringClass() == Object.class || m.getDeclaringClass() == Event.class) continue;
                    String n = m.getName();
                    String f = n.startsWith("get") ? n.substring(3) : n.startsWith("is") ? n.substring(2) : null;
                    if (f != null && !f.isEmpty()) t.set(t.length() + 1, valueOf(f));
                }
                return t;
            }
        }
        LuaValue v = read(k);
        if (v != null && !(ev == null && v.isnil())) return v;
        if (ev == null) return custom.get(k);
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "Canceled": case "Cancelled": cancel(v.toboolean()); return true;
            case "Result": setResult(v); return true;
        }
        if (write(k, v)) return true;
        return super.setProp(k, v);
    }

    void setResult(LuaValue v) {
        if (ev == null) throw new LuaError("Custom events have no Result");
        ev.setResult(Event.Result.valueOf(v.checkjstring().toUpperCase(Locale.ROOT)));
    }

    public Event raw() { return ev; }

    static {
        Class<ForgeEventObj> C = ForgeEventObj.class;
        reg(C, "Cancel", (s, a) -> { ((ForgeEventObj) s).cancel(true); return NONE; });
        reg(C, "SetCanceled|SetCancelled", (s, a) -> { ((ForgeEventObj) s).cancel(a.optboolean(1, true)); return NONE; });
        reg(C, "IsCanceled|IsCancelled", (s, a) -> valueOf(((ForgeEventObj) s).canceled()));
        reg(C, "IsCancelable", (s, a) -> { ForgeEventObj e = (ForgeEventObj) s; return valueOf(e.ev == null || e.ev.isCancelable()); });
        reg(C, "SetResult", (s, a) -> { ((ForgeEventObj) s).setResult(a.arg1()); return NONE; });
        reg(C, "GetResult", (s, a) -> ((ForgeEventObj) s).getProp("Result"));
        reg(C, "GetType", (s, a) -> valueOf(((ForgeEventObj) s).type));
        reg(C, "Get", (s, a) -> { LuaValue v = ((ForgeEventObj) s).read(a.checkjstring(1)); return v == null ? NIL : v; });
        reg(C, "Set", (s, a) -> { if (!((ForgeEventObj) s).write(a.checkjstring(1), a.arg(2))) throw new LuaError("No setter set" + a.checkjstring(1)); return NONE; });
        reg(C, "Call", (s, a) -> ((ForgeEventObj) s).callJava(a.checkjstring(1), a.subargs(2)));
        reg(C, "Java|GetJava", (s, a) -> { JavaObj.check(); ForgeEventObj e = (ForgeEventObj) s; if (e.ev == null) throw new LuaError("Custom events have no Java object"); return new JavaObj(e.ev); });
    }
}
