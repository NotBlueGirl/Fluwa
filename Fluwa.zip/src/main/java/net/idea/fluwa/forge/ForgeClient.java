package net.idea.fluwa.forge;

import com.mojang.blaze3d.platform.InputConstants;
import net.idea.fluwa.lua.*;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.luaj.vm2.*;

import java.nio.file.Path;
import java.util.*;

/** Client-only parts of the Forge service (only loaded on the client). */
final class ForgeClient {
    private ForgeClient() {}

    static Minecraft mc() { return Minecraft.getInstance(); }

    static int keyCode(LuaValue key) {
        if (key.isnumber()) return key.toint();
        String k = key.optjstring("").trim();
        if (k.isEmpty()) return InputConstants.UNKNOWN.getValue();
        String n = k.startsWith("key.") ? k : "key.keyboard." + k.toLowerCase(Locale.ROOT).replace(' ', '.');
        try { return InputConstants.getKey(n).getValue(); } catch (RuntimeException e) { throw new LuaError("Unknown key '" + k + "' (use e.g. \"G\", \"left.shift\", \"f6\" or a GLFW key code)"); }
    }

    static LuaValue registerKey(FluwaRuntime rt, String modId, String name, LuaValue key) {
        int code = keyCode(key);
        String id = "key." + modId + "." + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_.]", "_");
        KeyMapping km = new KeyMapping(id, InputConstants.Type.KEYSYM, code, "key.categories." + modId);
        var o = mc().options;
        KeyMapping[] arr = Arrays.copyOf(o.keyMappings, o.keyMappings.length + 1);
        arr[arr.length - 1] = km;
        o.keyMappings = arr;
        KeyMapping.resetMapping();
        Signal pressed = new Signal("E_Pressed"), released = new Signal("E_Released");
        Info i = new Info("ForgeKeyBinding", name);
        i.put("Name", name).put("Id", id).put("ModId", modId).put("Category", "key.categories." + modId)
                .put("E_Pressed", pressed).put("E_Released", released);
        i.live("Key", () -> LuaValue.valueOf(km.getKey().getName()));
        i.live("KeyCode", () -> LuaValue.valueOf(km.getKey().getValue()));
        i.live("IsDown", () -> LuaValue.valueOf(km.isDown()));
        i.method("WasPressed", a -> LuaValue.valueOf(km.consumeClick()));
        i.method("SetKey", a -> { km.setKey(InputConstants.Type.KEYSYM.getOrCreate(keyCode(a.arg1()))); KeyMapping.resetMapping(); o.save(); return LuaValue.NONE; });
        i.userKey = km;
        boolean[] down = {false};
        rt.tickers.add(() -> {
            boolean d = km.isDown();
            if (d && !down[0]) pressed.fire(i);
            if (!d && down[0]) released.fire(i);
            down[0] = d;
        });
        return i;
    }

    static void removeKeys(Collection<LuaValue> keys) {
        var o = mc().options;
        List<KeyMapping> l = new ArrayList<>(Arrays.asList(o.keyMappings));
        for (LuaValue v : keys) if (v instanceof Info i && i.userKey instanceof KeyMapping km) l.remove(km);
        o.keyMappings = l.toArray(new KeyMapping[0]);
        KeyMapping.resetMapping();
    }

    static LuaValue info() {
        Minecraft m = mc();
        Info i = new Info("ForgeClient", "Client");
        i.put("Version", m.getLaunchedVersion());
        i.live("FPS", () -> LuaValue.valueOf(m.getFps()))
                .live("Username", () -> LuaValue.valueOf(m.getUser().getName()))
                .live("Language", () -> LuaValue.valueOf(m.getLanguageManager().getSelected()))
                .live("WindowWidth", () -> LuaValue.valueOf(m.getWindow().getWidth()))
                .live("WindowHeight", () -> LuaValue.valueOf(m.getWindow().getHeight()))
                .live("Singleplayer", () -> LuaValue.valueOf(m.hasSingleplayerServer()))
                .live("Paused", () -> LuaValue.valueOf(m.isPaused()))
                .live("Server", () -> m.getCurrentServer() == null ? LuaValue.NIL : LuaValue.valueOf(m.getCurrentServer().ip));
        return i;
    }

    static LuaTable resourcePackIds() { return ForgeRegistryObj.strList(new ArrayList<>(mc().getResourcePackRepository().getSelectedIds())); }

    static LuaTable resourcePacks() {
        LuaTable t = new LuaTable(); int n = 0;
        var repo = mc().getResourcePackRepository();
        for (String id : repo.getAvailableIds()) {
            Info i = new Info("ForgeResourcePack", id);
            i.put("Id", id).live("Enabled", () -> LuaValue.valueOf(repo.getSelectedIds().contains(id)));
            t.set(++n, i);
        }
        return t;
    }

    static LuaValue registerResourcePack(ForgeService f, Path src) {
        Path dir = net.minecraftforge.fml.loading.FMLPaths.GAMEDIR.get().resolve("resourcepacks");
        Path dst = dir.resolve(src.getFileName().toString());
        if (!src.toAbsolutePath().normalize().equals(dst.toAbsolutePath().normalize())) ForgeService.copy(src, dst);
        String id = "file/" + dst.getFileName();
        var repo = mc().getResourcePackRepository();
        repo.reload();
        if (repo.getPack(id) == null) throw new LuaError("Not a valid resource pack (pack.mcmeta missing?): " + src);
        List<String> sel = new ArrayList<>(repo.getSelectedIds());
        if (!sel.contains(id)) { sel.add(id); repo.setSelected(sel); }
        var o = mc().options;
        o.resourcePacks.clear(); o.incompatibleResourcePacks.clear();
        for (var p : repo.getSelectedPacks()) if (!p.isFixedPosition()) o.resourcePacks.add(p.getId());
        o.save();
        Info pack = new Info("ForgeResourcePack", id);
        pack.put("Id", id).put("Name", dst.getFileName().toString()).put("Path", dst.toString()).live("Enabled", () -> LuaValue.valueOf(repo.getSelectedIds().contains(id)));
        mc().reloadResourcePacks().thenRun(() -> f.frt.post(() -> { f.fire("E_ResourcePackChanged", pack); f.fire("E_Reload"); }));
        return pack;
    }

    static void reloadResources(ForgeService f) { mc().reloadResourcePacks().thenRun(() -> f.frt.post(() -> f.fire("E_Reload"))); }
}
