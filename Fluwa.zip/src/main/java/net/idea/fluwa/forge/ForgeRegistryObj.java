package net.idea.fluwa.forge;

import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import org.luaj.vm2.*;

import java.util.*;

/**
 * ForgeRegistry: a real Minecraft/Forge registry (read access to every entry and tag) plus a script overlay.
 * Forge registries are frozen once the game has loaded, so Register/Unregister/AddTag/RemoveTag change the script
 * overlay: entries are visible through this registry (Get, GetAll, Contains, tags) and through Fluwa APIs that use them.
 */
public class ForgeRegistryObj extends LObj {
    static final Map<String, String> ALIASES = Map.ofEntries(
            Map.entry("entity", "entity_type"), Map.entry("entities", "entity_type"), Map.entry("items", "item"), Map.entry("blocks", "block"),
            Map.entry("biome", "worldgen/biome"), Map.entry("biomes", "worldgen/biome"), Map.entry("dimension", "dimension"),
            Map.entry("level_stem", "dimension"), Map.entry("effect", "mob_effect"), Map.entry("effects", "mob_effect"),
            Map.entry("sound", "sound_event"), Map.entry("sounds", "sound_event"), Map.entry("particle", "particle_type"),
            Map.entry("tile_entity", "block_entity_type"), Map.entry("block_entity", "block_entity_type"), Map.entry("blockentity", "block_entity_type"),
            Map.entry("container", "menu"), Map.entry("poi", "point_of_interest_type"), Map.entry("point_of_interest", "point_of_interest_type"),
            Map.entry("creative_tab", "creative_mode_tab"), Map.entry("structure", "worldgen/structure"), Map.entry("feature", "worldgen/feature"),
            Map.entry("enchantments", "enchantment"), Map.entry("fluids", "fluid"), Map.entry("stat", "stat_type"), Map.entry("stats", "stat_type"),
            Map.entry("dimensiontype", "dimension_type"), Map.entry("chunk_generator", "worldgen/chunk_generator"),
            Map.entry("biome_source", "worldgen/biome_source"), Map.entry("noise_settings", "worldgen/noise_settings"),
            Map.entry("noise_generator_settings", "worldgen/noise_settings"), Map.entry("processor", "worldgen/structure_processor"),
            Map.entry("tree_decorator", "worldgen/tree_decorator_type"), Map.entry("foliage_placer", "worldgen/foliage_placer_type"),
            Map.entry("trunk_placer", "worldgen/trunk_placer_type"), Map.entry("block_state_provider", "worldgen/block_state_provider_type"),
            Map.entry("villager_profession", "villager_profession"), Map.entry("profession", "villager_profession"),
            Map.entry("memory_module_type", "memory_module_type"), Map.entry("sensor_type", "sensor_type"),
            Map.entry("entity_data_serializer", "forge:entity_data_serializers"), Map.entry("loot_modifier", "forge:global_loot_modifier_serializers"),
            Map.entry("command_argument_type", "command_argument_type"), Map.entry("schedule", "schedule"), Map.entry("activity", "activity"),
            Map.entry("attribute", "attribute"), Map.entry("recipe_type", "recipe_type"), Map.entry("recipe_serializer", "recipe_serializer"),
            Map.entry("ingredient", "forge:ingredient_serializer"));

    final ForgeService forge;
    final String type;           // normalized registry id ("minecraft:item") or a virtual name
    final Registry<Object> real; // null for script-only registries
    final Map<String, LuaValue> overlay = new LinkedHashMap<>();
    final Map<String, LinkedHashSet<String>> tagAdd = new HashMap<>();
    final Map<String, Set<String>> tagRemove = new HashMap<>();
    final Map<String, ForgeTagObj> tagObjs = new HashMap<>();
    boolean frozen;
    final Signal eReg = new Signal("E_Register"), eUnreg = new Signal("E_Unregister"), eTagAdd = new Signal("E_TagAdded"),
            eTagRem = new Signal("E_TagRemoved"), eFreeze = new Signal("E_Freeze"), eClear = new Signal("E_Clear");

    static String normalize(String t) {
        String s = t.trim();
        String low = s.toLowerCase(Locale.ROOT);
        if (ALIASES.containsKey(low)) s = ALIASES.get(low);
        return s.contains(":") ? s : "minecraft:" + s;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static Registry<Object> lookup(String id) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return null;
        ResourceKey key = ResourceKey.createRegistryKey(rl);
        GameRuntime g = GameRuntime.cur();
        try {
            if (g != null && g.server() != null) { Optional<Registry<Object>> r = g.server().registryAccess().registry(key); if (r.isPresent()) return r.get(); }
            if (g != null && g.server() == null) {
                var mc = net.minecraft.client.Minecraft.getInstance();
                if (mc.level != null) { Optional<Registry<Object>> r = mc.level.registryAccess().registry(key); if (r.isPresent()) return r.get(); }
            }
        } catch (RuntimeException | LinkageError ignored) {}
        return (Registry<Object>) BuiltInRegistries.REGISTRY.get(rl);
    }

    ForgeRegistryObj(ForgeService f, String type) {
        super("ForgeRegistry");
        forge = f;
        String n = normalize(type);
        Registry<Object> r = lookup(n);
        this.type = r != null ? n : type;
        real = r;
        name = this.type;
    }

    String id(String s) { return s.contains(":") ? s : (real != null ? "minecraft:" : "fluwa:") + s; }

    // ------------------------------------------------------------ entries
    LuaValue wrapReal(ResourceLocation id, Object o) {
        if (o == null) return NIL;
        Info i = new Info("ForgeEntry", id.toString());
        i.put("Id", id.toString()).put("Namespace", id.getNamespace()).put("Path", id.getPath()).put("Registry", type)
                .put("Class", o.getClass().getName()).put("Builtin", TRUE);
        i.live("Tags", () -> tagsOf(id.toString()));
        if (o instanceof net.minecraft.world.item.Item it) {
            i.put("MaxStack", valueOf(it.getMaxStackSize())).put("MaxDamage", valueOf(it.getMaxDamage()));
            i.method("Create", a -> new ItemObj(new net.minecraft.world.item.ItemStack(it, Math.max(1, a.optint(1, 1)))));
        }
        if (o instanceof net.minecraft.world.level.block.Block b) i.put("Hardness", valueOf(b.defaultDestroyTime())).put("Item", BuiltInRegistries.ITEM.getKey(b.asItem()).toString());
        return i;
    }

    LuaValue entry(String raw) {
        String id = id(raw);
        LuaValue o = overlay.get(id);
        if (o != null) return o;
        if (real != null) {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl != null && real.containsKey(rl)) return wrapReal(rl, real.get(rl));
        }
        return NIL;
    }

    boolean contains(String raw) {
        String id = id(raw);
        if (overlay.containsKey(id)) return true;
        ResourceLocation rl = ResourceLocation.tryParse(id);
        return real != null && rl != null && real.containsKey(rl);
    }

    List<String> ids() {
        List<String> l = new ArrayList<>();
        if (real != null) for (ResourceLocation r : real.keySet()) l.add(r.toString());
        for (String k : overlay.keySet()) if (!l.contains(k)) l.add(k);
        return l;
    }

    String nameOf(LuaValue o) {
        for (var e : overlay.entrySet()) if (e.getValue().raweq(o)) return e.getKey();
        if (o instanceof Info i && i.props.containsKey("Id")) return i.props.get("Id").get().tojstring();
        if (real != null) {
            Object raw = null;
            if (o instanceof ItemObj it) raw = it.stack.getItem();
            else if (o instanceof EntityObj eo && eo.raw() != null) raw = eo.raw().getType();
            else if (o instanceof BlockObj b && b.rawLevel() != null) raw = b.rawLevel().getBlockState(b.blockPos()).getBlock();
            else if (o.isstring() && contains(o.tojstring())) return id(o.tojstring());
            if (raw != null) { ResourceLocation k = real.getKey(raw); if (k != null) return k.toString(); }
        }
        return null;
    }

    void register(String raw, LuaValue o, boolean fromMod) {
        if (frozen) throw new LuaError("Registry " + type + " is frozen");
        String id = id(raw);
        if (real != null) { ResourceLocation rl = ResourceLocation.tryParse(id); if (rl != null && real.containsKey(rl)) throw new LuaError(id + " is already registered in " + type); }
        if (overlay.containsKey(id)) throw new LuaError(id + " is already registered in " + type);
        overlay.put(id, o);
        eReg.fire(valueOf(id), o);
        forge.registered(type, id, o);
    }

    LuaValue unregister(String raw) {
        if (frozen) throw new LuaError("Registry " + type + " is frozen");
        String id = id(raw);
        LuaValue o = overlay.remove(id);
        if (o == null) {
            if (contains(id)) throw new LuaError(id + " is a built-in entry: Forge registries are frozen after loading, only script entries can be removed");
            return FALSE;
        }
        for (Set<String> s : tagAdd.values()) s.remove(id);
        eUnreg.fire(valueOf(id), o);
        return TRUE;
    }

    // ------------------------------------------------------------ tags
    @SuppressWarnings({"unchecked", "rawtypes"})
    Set<String> realTag(String tag) {
        Set<String> out = new LinkedHashSet<>();
        if (real == null) return out;
        ResourceLocation rl = ResourceLocation.tryParse(tag);
        if (rl == null) return out;
        TagKey k = TagKey.create(real.key(), rl);
        try { real.getTag(k).ifPresent(set -> ((Iterable<net.minecraft.core.Holder<Object>>) set).forEach(h -> h.unwrapKey().ifPresent(key -> out.add(key.location().toString())))); }
        catch (RuntimeException ignored) {}
        return out;
    }

    String tagId(String t) { String s = t.startsWith("#") ? t.substring(1) : t; return s.contains(":") ? s : "minecraft:" + s; }

    Set<String> tag(String raw) {
        String t = tagId(raw);
        Set<String> s = realTag(t);
        s.removeAll(tagRemove.getOrDefault(t, Set.of()));
        s.addAll(tagAdd.getOrDefault(t, new LinkedHashSet<>()));
        return s;
    }

    List<String> tagNames() {
        List<String> l = new ArrayList<>();
        if (real != null) real.getTagNames().forEach(k -> l.add(k.location().toString()));
        for (String k : tagAdd.keySet()) if (!l.contains(k)) l.add(k);
        Collections.sort(l);
        return l;
    }

    LuaTable tagsOf(String id) {
        LuaTable t = new LuaTable();
        for (String n : tagNames()) if (tag(n).contains(id)) t.set(t.length() + 1, valueOf(n));
        return t;
    }

    void addTag(String raw, String idRaw) {
        String t = tagId(raw), id = id(idRaw);
        tagAdd.computeIfAbsent(t, k -> new LinkedHashSet<>()).add(id);
        Set<String> r = tagRemove.get(t); if (r != null) r.remove(id);
        eTagAdd.fire(valueOf(t), valueOf(id));
        ForgeTagObj o = tagObjs.get(t); if (o != null) o.added.fire(valueOf(id));
    }

    void removeTag(String raw, String idRaw) {
        String t = tagId(raw), id = id(idRaw);
        Set<String> a = tagAdd.get(t); if (a != null) a.remove(id);
        if (realTag(t).contains(id)) tagRemove.computeIfAbsent(t, k -> new HashSet<>()).add(id);
        eTagRem.fire(valueOf(t), valueOf(id));
        ForgeTagObj o = tagObjs.get(t); if (o != null) o.removed.fire(valueOf(id));
    }

    ForgeTagObj tagObj(String raw) { String t = tagId(raw); return tagObjs.computeIfAbsent(t, k -> new ForgeTagObj(this, k)); }

    static LuaTable strList(Collection<String> c) { LuaTable t = new LuaTable(); int i = 0; for (String s : c) t.set(++i, valueOf(s)); return t; }

    LuaTable entries() { LuaTable t = new LuaTable(); for (String id : ids()) t.set(id, entry(id)); return t; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Type": return valueOf(real != null ? "Builtin" : "Script");
            case "Size": return valueOf((real == null ? 0 : real.size()) + overlay.size());
            case "Frozen": return valueOf(frozen);
            case "Entries": return entries();
            case "Tags": return strList(tagNames());
            case "Namespace": { int i = type.indexOf(':'); return valueOf(i < 0 ? "fluwa" : type.substring(0, i)); }
            case "Id": case "Key": return valueOf(type);
            case "E_Register": return eReg;
            case "E_Unregister": return eUnreg;
            case "E_TagAdded": return eTagAdd;
            case "E_TagRemoved": return eTagRem;
            case "E_Freeze": return eFreeze;
            case "E_Clear": return eClear;
        }
        return super.getProp(k);
    }
    @Override public void setName(String n) { throw new LuaError("ForgeRegistry.Name is read-only"); }

    static ForgeRegistryObj R(LObj s) { return (ForgeRegistryObj) s; }

    static {
        Class<ForgeRegistryObj> C = ForgeRegistryObj.class;
        reg(C, "Register", (s, a) -> { R(s).register(a.checkjstring(1), a.arg(2).isnil() ? TRUE : a.arg(2), false); return a.arg(2); });
        reg(C, "Unregister", (s, a) -> R(s).unregister(a.checkjstring(1)));
        reg(C, "Get", (s, a) -> R(s).entry(a.checkjstring(1)));
        reg(C, "GetAll", (s, a) -> { LuaTable t = new LuaTable(); int i = 0; for (String id : R(s).ids()) t.set(++i, R(s).entry(id)); return t; });
        reg(C, "GetIds|GetKeys", (s, a) -> strList(R(s).ids()));
        reg(C, "Contains", (s, a) -> valueOf(R(s).contains(a.checkjstring(1))));
        reg(C, "GetName|GetId", (s, a) -> { String n = R(s).nameOf(a.arg1()); return n == null ? NIL : valueOf(n); });
        reg(C, "GetKey", (s, a) -> { String n = R(s).nameOf(a.arg1()); return n == null ? NIL : valueOf(R(s).type + "/" + n); });
        reg(C, "GetValue", (s, a) -> { String k = a.checkjstring(1); int i = k.lastIndexOf('/'); return R(s).entry(i >= 0 && k.substring(0, i).equals(R(s).type) ? k.substring(i + 1) : k); });
        reg(C, "GetEntries", (s, a) -> R(s).entries());
        reg(C, "GetTags", (s, a) -> strList(R(s).tagNames()));
        reg(C, "GetTag", (s, a) -> strList(R(s).tag(a.checkjstring(1))));
        reg(C, "GetTagObject", (s, a) -> R(s).tagObj(a.checkjstring(1)));
        reg(C, "AddTag", (s, a) -> { R(s).addTag(a.checkjstring(1), a.checkjstring(2)); return NONE; });
        reg(C, "RemoveTag", (s, a) -> { R(s).removeTag(a.checkjstring(1), a.checkjstring(2)); return NONE; });
        reg(C, "HasTag", (s, a) -> valueOf(R(s).tag(a.checkjstring(1)).contains(R(s).id(a.checkjstring(2)))));
        reg(C, "Clear", (s, a) -> {
            ForgeRegistryObj r = R(s);
            if (r.frozen) throw new LuaError("Registry " + r.type + " is frozen");
            r.overlay.clear(); r.tagAdd.clear(); r.tagRemove.clear();
            r.eClear.fire(r); return NONE; });
        reg(C, "Freeze", (s, a) -> { ForgeRegistryObj r = R(s); if (!r.frozen) { r.frozen = true; r.eFreeze.fire(r); } return NONE; });
        reg(C, "IsFrozen", (s, a) -> valueOf(R(s).frozen));
        reg(C, "IsBuiltin", (s, a) -> valueOf(R(s).real != null));
        reg(C, "GetType", (s, a) -> valueOf(R(s).real != null ? "Builtin" : "Script"));
    }
}
