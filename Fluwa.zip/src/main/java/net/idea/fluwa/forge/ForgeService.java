package net.idea.fluwa.forge;

import com.google.gson.*;
import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundUpdateRecipesPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.config.ConfigTracker;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.fml.loading.FMLLoader;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.forgespi.language.IModInfo;
import org.luaj.vm2.*;

import java.nio.file.*;
import java.util.*;

/** v0.5 Forge service: getAccess("Forge") / global Forge. One instance per runtime. */
public class ForgeService extends LObj {
    final FluwaRuntime frt;
    final Map<String, ForgeModObj> scriptMods = new LinkedHashMap<>();
    final Map<String, ForgeModObj> realMods = new HashMap<>();
    final Map<String, ForgeRegistryObj> registries = new HashMap<>();
    final Map<String, ForgeConfigObj> configs = new HashMap<>();
    final Map<String, ForgeCapabilityObj> capabilities = new LinkedHashMap<>();
    final List<ForgeCommandObj> commands = new java.util.concurrent.CopyOnWriteArrayList<>();
    final Map<ResourceLocation, Recipe<?>> recipes = new LinkedHashMap<>();
    final Map<String, LuaValue> keyBindings = new LinkedHashMap<>();
    ForgeEventBusObj forgeBus;
    final Map<String, Signal> events = new HashMap<>();
    static final String[] EVENTS = {"E_ModLoaded", "E_ModUnloaded", "E_ModEnabled", "E_ModDisabled", "E_Register", "E_ConfigChanged", "E_Reload",
            "E_ResourcePackChanged", "E_DataPackChanged", "E_ServerStarted", "E_ServerStopping", "E_ClientStarted", "E_ClientStopping", "E_Error"};
    int recipeCounter;
    boolean hooks;

    ForgeService(FluwaRuntime r) {
        super("Forge");
        name = "Forge";
        frt = r;
        for (String e : EVENTS) events.put(e, new Signal(e));
        r.onClose(this::shutdown);
    }

    public static LuaValue get(FluwaRuntime r) {
        return (LuaValue) r.state.computeIfAbsent("fluwa.forge", k -> new ForgeService(r));
    }

    GameRuntime gr() { return (GameRuntime) frt; }
    MinecraftServer srv() { MinecraftServer s = frt instanceof GameRuntime g ? g.server() : null; if (s == null) throw new LuaError("Only Server-Side"); return s; }
    void fire(String e, LuaValue... a) { Signal s = events.get(e); if (s != null && s.hasHandlers()) s.fire(a); }

    // ================================================================ lifecycle hooks (real Forge events)
    void installHooks() {
        if (hooks) return;
        hooks = true;
        ForgeEventBusObj b = forgeBus();
        if (frt.server) {
            b.subscribe("net.minecraftforge.event.server.ServerStartedEvent", fn(a -> { fire("E_ServerStarted", info("ForgeServer")); return NONE; }), NIL, NIL);
            b.subscribe("net.minecraftforge.event.server.ServerStoppingEvent", fn(a -> { fire("E_ServerStopping", info("ForgeServer")); return NONE; }), NIL, NIL);
            b.subscribe("net.minecraftforge.event.RegisterCommandsEvent", fn(a -> {
                Object ev = ((ForgeEventObj) a.arg1()).raw();
                var d = ((net.minecraftforge.event.RegisterCommandsEvent) ev).getDispatcher();
                for (ForgeCommandObj c : commands) if (c.registered) for (String n : c.names()) if (d.getRoot().getChild(n) == null) c.addNode(d, n);
                return NONE; }), NIL, NIL);
            b.subscribe("net.minecraftforge.event.OnDatapackSyncEvent", fn(a -> {
                net.minecraftforge.event.OnDatapackSyncEvent ev = (net.minecraftforge.event.OnDatapackSyncEvent) ((ForgeEventObj) a.arg1()).raw();
                if (ev.getPlayer() == null && !recipes.isEmpty()) applyRecipes(false);
                if (ev.getPlayer() == null) fire("E_Reload");
                return NONE; }), NIL, NIL);
        }
    }
    static LuaValue fn(java.util.function.Function<Varargs, Varargs> f) { return new org.luaj.vm2.lib.VarArgFunction() { public Varargs invoke(Varargs a) { return f.apply(a); } }; }

    void shutdown() {
        for (ForgeCommandObj c : commands) c.unregister();
        commands.clear();
        if (!recipes.isEmpty()) { Set<ResourceLocation> ids = new HashSet<>(recipes.keySet()); recipes.clear(); try { removeRecipes(ids); } catch (RuntimeException ignored) {} }
        if (!frt.server && !keyBindings.isEmpty()) try { ForgeClient.removeKeys(keyBindings.values()); } catch (RuntimeException | LinkageError ignored) {}
    }

    // ================================================================ mods
    ForgeModObj mod(String id) {
        ForgeModObj s = scriptMods.get(id);
        if (s != null) return s;
        Optional<? extends net.minecraftforge.fml.ModContainer> c = ModList.get().getModContainerById(id);
        if (c.isEmpty()) return null;
        return realMods.computeIfAbsent(id, k -> new ForgeModObj(this, c.get().getModInfo()));
    }
    ForgeModObj checkMod(String id) { ForgeModObj m = mod(id); if (m == null) throw new LuaError("Mod '" + id + "' is not loaded (register script mods with Forge:RegisterMod{Id = ...})"); return m; }
    /** mod for Forge:RegisterX(modId, ...) — script mods are created on demand */
    ForgeModObj scriptMod(String id) {
        ForgeModObj m = scriptMods.get(id);
        if (m != null) return m;
        if (ModList.get().isLoaded(id)) throw new LuaError(id + " is an installed mod; only script mods can register at runtime");
        LuaTable t = new LuaTable(); t.set("Id", id);
        return registerMod(t);
    }
    boolean isScriptMod(String id) { return scriptMods.containsKey(id); }
    boolean modEnabled(String id) { ForgeModObj m = scriptMods.get(id); return m == null || (m.enabled && m.loaded); }

    ForgeModObj registerMod(LuaTable t) {
        ForgeModObj m = new ForgeModObj(this, t);
        if (scriptMods.containsKey(m.id)) throw new LuaError("Script mod '" + m.id + "' is already registered");
        if (ModList.get().isLoaded(m.id)) throw new LuaError("'" + m.id + "' is the id of an installed mod");
        scriptMods.put(m.id, m);
        if (t.get("Config").istable()) registerConfig(m, t.get("Config"));
        if (t.get("Enabled").isboolean()) m.enabled = t.get("Enabled").toboolean();
        LuaValue ev = t.get("Events");
        if (ev.istable()) for (LuaValue k = ev.next(NIL).arg1(); !k.isnil(); k = ev.next(k).arg1()) m.eventBus().subscribe(k.tojstring(), ev.get(k), NIL, ev);
        m.hook("OnLoad");
        m.eLoad.fire(m);
        fire("E_ModLoaded", m);
        return m;
    }

    List<LuaValue> allMods() {
        List<LuaValue> l = new ArrayList<>();
        for (IModInfo i : ModList.get().getMods()) l.add(mod(i.getModId()));
        l.addAll(scriptMods.values());
        return l;
    }

    // ================================================================ registries / tags
    ForgeRegistryObj registry(String type) {
        String n = ForgeRegistryObj.normalize(type);
        ForgeRegistryObj r = registries.get(n);
        if (r == null) { r = new ForgeRegistryObj(this, type); registries.put(n, r); registries.putIfAbsent(r.type, r); }
        return r;
    }
    void registered(String type, String id, LuaValue o) { fire("E_Register", valueOf(type), valueOf(id), o); }

    /** object returned by Mod:RegisterX(id, settings) */
    LuaValue makeEntry(ForgeModObj m, String kind, String regType, String full, LuaValue settings) {
        LuaTable st = settings.istable() ? (LuaTable) settings : new LuaTable();
        Info i = new Info("Forge" + kind, full);
        int c = full.indexOf(':');
        i.put("Id", full).put("ModId", m.id).put("Namespace", full.substring(0, c)).put("Path", full.substring(c + 1)).put("Registry", regType)
                .put("Kind", kind).put("Settings", st).put("Builtin", FALSE);
        switch (kind) {
            case "Item" -> {
                String base = st.get("Base").optjstring(st.get("base").optjstring("minecraft:paper"));
                i.put("Base", base);
                i.method("Create", a -> createItem(full, base, st, a.optint(1, 1)));
                i.method("Give", a -> {
                    PlayerObj p = checkObj(a.arg1(), PlayerObj.class);
                    ItemObj it = (ItemObj) createItem(full, base, st, a.optint(2, 1));
                    if (!p.p().getInventory().add(it.stack)) p.p().drop(it.stack, false);
                    return it; });
            }
            case "Block" -> {
                String base = st.get("Base").optjstring(st.get("base").optjstring("minecraft:stone"));
                i.put("Base", base);
                i.method("Place", a -> {
                    BlockObj b = new BlockObj();
                    b.set(valueOf("Id"), valueOf(base));
                    b.set(valueOf("Position"), a.arg(2));
                    b.setParent(checkObj(a.arg1(), DimensionObj.class));
                    apply(b, st, Set.of("Base", "base", "Id"));
                    return b; });
            }
            case "Entity" -> {
                String base = st.get("Base").optjstring(st.get("base").optjstring("minecraft:pig"));
                i.put("Base", base);
                i.method("Spawn", a -> {
                    EntityObj e = new EntityObj((net.minecraft.world.entity.Entity) null);
                    e.set(valueOf("Type"), valueOf(base));
                    e.set(valueOf("Position"), a.arg(2));
                    e.setParent(checkObj(a.arg1(), DimensionObj.class));
                    if (st.get("Name").isnil()) e.set(valueOf("Name"), valueOf(full.substring(c + 1)));
                    apply(e, st, Set.of("Base", "base", "Type", "Id"));
                    return e; });
            }
            default -> {}
        }
        return i;
    }

    LuaValue createItem(String full, String base, LuaTable st, int count) {
        var item = BuiltInRegistries.ITEM.getOptional(Conv.rl(base)).orElseThrow(() -> new LuaError("Unknown base item " + base));
        ItemObj o = new ItemObj(new ItemStack(item, Math.max(1, count)));
        o.set(valueOf("Id"), valueOf(full));
        apply(o, st, Set.of("Base", "base", "Id"));
        return o;
    }

    static void apply(LObj o, LuaTable st, Set<String> skip) {
        for (LuaValue k = st.next(NIL).arg1(); !k.isnil(); k = st.next(k).arg1()) {
            if (!k.isstring() || skip.contains(k.tojstring())) continue;
            o.set(k, st.get(k));
        }
    }

    // ================================================================ configs
    LuaValue config(ForgeModObj m) {
        if (m.script()) return m.config == null ? NIL : m.config;
        return realConfig(m.id, null);
    }
    LuaValue realConfig(String modId, String type) {
        String key = modId + "|" + (type == null ? "" : type.toUpperCase(Locale.ROOT));
        ForgeConfigObj c = configs.get(key);
        if (c != null) return c;
        ModConfig found = null;
        for (ModConfig.Type t : new ModConfig.Type[]{ModConfig.Type.COMMON, ModConfig.Type.CLIENT, ModConfig.Type.SERVER}) {
            if (type != null && !t.name().equalsIgnoreCase(type)) continue;
            for (ModConfig mc : ConfigTracker.INSTANCE.configSets().get(t)) if (mc.getModId().equals(modId)) { found = mc; break; }
            if (found != null) break;
        }
        if (found == null) return NIL;
        c = new ForgeConfigObj(this, modId, found);
        configs.put(key, c);
        return c;
    }
    LuaValue registerConfig(ForgeModObj m, LuaValue settings) {
        LuaTable st = settings.istable() ? (LuaTable) settings : new LuaTable();
        LuaValue defs = st.get("Values").istable() ? st.get("Values") : st.get("Defaults").istable() ? st.get("Defaults") : st;
        String file = st.get("File").optjstring(m.id + ".toml");
        if (!file.matches("[A-Za-z0-9_\\-.]+")) throw new LuaError("Config File must be a plain file name");
        Path p = FMLPaths.CONFIGDIR.get().resolve("fluwa-mods").resolve(file.endsWith(".toml") ? file : file + ".toml");
        m.config = new ForgeConfigObj(this, m.id, p, defs == st ? strip(st) : (LuaTable) defs);
        return m.config;
    }
    static LuaTable strip(LuaTable t) { LuaTable c = new LuaTable(); for (LuaValue k = t.next(NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) if (!k.tojstring().equals("File")) c.set(k, t.get(k)); return c; }
    void configChanged(String modId, ForgeConfigObj c) {
        fire("E_ConfigChanged", valueOf(modId), c);
        ForgeModObj m = scriptMods.get(modId);
        if (m == null) m = realMods.get(modId);
        if (m != null) m.eConfig.fire(c);
    }

    // ================================================================ recipes
    net.minecraft.world.item.crafting.RecipeManager recipeManager() {
        GameRuntime g = gr();
        if (g.server() != null) return g.server().getRecipeManager();
        var mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.getConnection() != null) return mc.getConnection().getRecipeManager();
        throw new LuaError("No recipe manager available");
    }

    LuaValue registerRecipe(String modId, String type, LuaValue recipe) {
        if (!frt.server) throw new LuaError("RegisterRecipe is Server-Side");
        installHooks();
        JsonObject json;
        if (recipe.isstring()) json = JsonParser.parseString(recipe.tojstring()).getAsJsonObject();
        else json = net.idea.fluwa.lua.Chromium.toJson(recipe.checktable(), 0).getAsJsonObject();
        String id = json.has("Id") ? json.remove("Id").getAsString() : json.has("id") ? json.remove("id").getAsString() : modId + ":recipe_" + (++recipeCounter);
        if (!id.contains(":")) id = modId + ":" + id;
        if (!json.has("type")) json.addProperty("type", type.contains(":") ? type : "minecraft:" + type);
        ResourceLocation rl = Conv.rl(id);
        Recipe<?> r;
        try { r = net.minecraft.world.item.crafting.RecipeManager.fromJson(rl, json, net.minecraftforge.common.crafting.conditions.ICondition.IContext.EMPTY); }
        catch (RuntimeException e) { fire("E_Error", valueOf("Recipe " + id + ": " + e.getMessage())); throw new LuaError("Invalid recipe " + id + ": " + e.getMessage()); }
        recipes.put(rl, r);
        applyRecipes(true);
        ForgeRecipeObj o = new ForgeRecipeObj(r, true);
        registry("recipe").overlay.put(id, o);
        fire("E_Register", valueOf("recipe"), valueOf(id), o);
        return o;
    }

    void applyRecipes(boolean sync) {
        var rm = srv().getRecipeManager();
        List<Recipe<?>> all = new ArrayList<>();
        for (Recipe<?> r : rm.getRecipes()) if (!recipes.containsKey(r.getId()) || recipes.get(r.getId()) == r) { if (!recipes.containsKey(r.getId())) all.add(r); }
        all.addAll(recipes.values());
        rm.replaceRecipes(all);
        if (sync) syncRecipes();
    }
    void removeRecipes(Set<ResourceLocation> ids) {
        MinecraftServer s = gr().server();
        if (s == null) return;
        List<Recipe<?>> all = new ArrayList<>();
        for (Recipe<?> r : s.getRecipeManager().getRecipes()) if (!ids.contains(r.getId())) all.add(r);
        s.getRecipeManager().replaceRecipes(all);
        syncRecipes();
    }
    void syncRecipes() {
        MinecraftServer s = srv();
        var pkt = new ClientboundUpdateRecipesPacket(s.getRecipeManager().getRecipes());
        for (var p : s.getPlayerList().getPlayers()) p.connection.send(pkt);
    }

    LuaValue recipeManagerObj() {
        Info i = new Info("RecipeManager", "RecipeManager");
        i.live("Count", () -> valueOf(recipeManager().getRecipes().size()));
        i.method("GetRecipes", a -> {
            LuaTable t = new LuaTable(); int n = 0;
            String type = a.isnil(1) ? null : (a.checkjstring(1).contains(":") ? a.checkjstring(1) : "minecraft:" + a.checkjstring(1));
            for (Recipe<?> r : recipeManager().getRecipes()) {
                if (type != null) { var k = BuiltInRegistries.RECIPE_TYPE.getKey(r.getType()); if (k == null || !k.toString().equals(type)) continue; }
                t.set(++n, new ForgeRecipeObj(r, recipes.containsKey(r.getId())));
            }
            return t; });
        i.method("GetRecipe", a -> recipeManager().byKey(Conv.rl(a.checkjstring(1))).map(r -> (LuaValue) new ForgeRecipeObj(r, recipes.containsKey(r.getId()))).orElse(NIL));
        i.method("GetRecipesFor", a -> {
            LuaTable t = new LuaTable(); int n = 0;
            String item = a.checkjstring(1).contains(":") ? a.checkjstring(1) : "minecraft:" + a.checkjstring(1);
            var acc = ForgeRecipeObj.access();
            for (Recipe<?> r : recipeManager().getRecipes()) {
                ItemStack out = r.getResultItem(acc);
                if (!out.isEmpty() && BuiltInRegistries.ITEM.getKey(out.getItem()).toString().equals(item)) t.set(++n, new ForgeRecipeObj(r, recipes.containsKey(r.getId())));
            }
            return t; });
        i.method("GetTypes", a -> { List<String> l = new ArrayList<>(); for (var k : BuiltInRegistries.RECIPE_TYPE.keySet()) l.add(k.toString()); return ForgeRegistryObj.strList(l); });
        i.method("Remove", a -> {
            ResourceLocation rl = Conv.rl(a.checkjstring(1));
            if (recipes.remove(rl) == null) throw new LuaError("Only script recipes can be removed");
            registry("recipe").overlay.remove(rl.toString());
            removeRecipes(Set.of(rl)); return TRUE; });
        return i;
    }

    LuaValue registryManagerObj() {
        Info i = new Info("RegistryManager", "RegistryManager");
        i.method("GetRegistry", a -> registry(a.checkjstring(1)));
        i.method("GetRegistries", a -> {
            List<String> l = new ArrayList<>();
            try {
                if (gr().server() != null) gr().server().registryAccess().registries().forEach(e -> l.add(e.key().location().toString()));
                else for (var k : BuiltInRegistries.REGISTRY.keySet()) l.add(k.toString());
            } catch (RuntimeException ignored) {}
            for (ForgeRegistryObj r : registries.values()) if (r.real == null && !l.contains(r.type)) l.add(r.type);
            Collections.sort(l);
            return ForgeRegistryObj.strList(l); });
        return i;
    }

    // ================================================================ capabilities / commands / keys
    LuaValue registerCapability(String modId, String type, LuaValue def) {
        String n = type.contains(":") ? type : modId + ":" + type;
        if (capabilities.containsKey(n)) return capabilities.get(n);
        LuaValue d = def;
        if (def.istable() && !def.get("Default").isnil()) d = def.get("Default");
        ForgeCapabilityObj c = new ForgeCapabilityObj(this, modId, type, null, d);
        capabilities.put(n, c);
        registry("fluwa:capability").overlay.put(n, c);
        fire("E_Register", valueOf("capability"), valueOf(n), c);
        return c;
    }
    LuaValue capability(String n) {
        ForgeCapabilityObj c = capabilities.get(n);
        if (c != null) return c;
        for (ForgeCapabilityObj x : capabilities.values()) if (x.capName.equals(n)) return x;
        var real = ForgeCapabilityObj.findReal(n);
        if (real == null) return NIL;
        c = new ForgeCapabilityObj(this, "forge", real.getName(), real, NIL);
        capabilities.put(n, c);
        return c;
    }

    LuaValue registerCommand(String modId, LuaTable t) {
        if (!frt.server) throw new LuaError("RegisterCommand is Server-Side");
        installHooks();
        ForgeCommandObj c = new ForgeCommandObj(this, modId, t);
        c.register();
        commands.add(c);
        registry("fluwa:command").overlay.put(modId + ":" + c.cmd, c);
        fire("E_Register", valueOf("command"), valueOf(c.cmd), c);
        return c;
    }
    void removeModCommands(String modId) {
        for (ForgeCommandObj c : commands) if (c.modId.equals(modId)) { c.unregister(); commands.remove(c); registry("fluwa:command").overlay.remove(modId + ":" + c.cmd); }
    }

    LuaValue registerKey(String modId, String n, LuaValue key) {
        if (frt.server) throw new LuaError("RegisterKeyBinding is Client-Side: use it in ClientScripts");
        String full = modId + ":" + n;
        if (keyBindings.containsKey(full)) return keyBindings.get(full);
        LuaValue k = ForgeClient.registerKey(frt, modId, n, key);
        keyBindings.put(full, k);
        registry("fluwa:keybinding").overlay.put(full, k);
        fire("E_Register", valueOf("keybinding"), valueOf(full), k);
        return k;
    }

    // ================================================================ packs
    Path checkedSource(String p) {
        Path game = FMLPaths.GAMEDIR.get().toAbsolutePath().normalize();
        Path src = Paths.get(p);
        if (!src.isAbsolute()) src = game.resolve(p);
        src = src.toAbsolutePath().normalize();
        if (!src.startsWith(game) && !net.idea.fluwa.Config.fullOsAccess) throw new LuaError("Packs outside the game directory need fullOsAccess=true");
        if (!Files.exists(src)) throw new LuaError("Pack not found: " + src);
        return src;
    }
    static void copy(Path src, Path dst) {
        try {
            if (Files.isDirectory(src)) {
                try (var st = Files.walk(src)) {
                    for (Path x : (Iterable<Path>) st::iterator) {
                        Path t = dst.resolve(src.relativize(x).toString());
                        if (Files.isDirectory(x)) Files.createDirectories(t); else { Files.createDirectories(t.getParent()); Files.copy(x, t, StandardCopyOption.REPLACE_EXISTING); }
                    }
                }
            } else { Files.createDirectories(dst.getParent()); Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING); }
        } catch (java.io.IOException e) { throw new LuaError("Copy failed: " + e.getMessage()); }
    }

    LuaValue registerDataPack(String path) {
        MinecraftServer s = srv();
        Path src = checkedSource(path);
        Path dir = s.getWorldPath(LevelResource.DATAPACK_DIR);
        Path dst = dir.resolve(src.getFileName().toString());
        if (!src.equals(dst)) copy(src, dst);
        String id = "file/" + dst.getFileName();
        var repo = s.getPackRepository();
        repo.reload();
        if (repo.getPack(id) == null) throw new LuaError("Not a valid data pack (pack.mcmeta missing?): " + src);
        List<String> sel = new ArrayList<>(repo.getSelectedIds());
        if (!sel.contains(id)) sel.add(id);
        Info pack = packInfo("ForgeDataPack", id, dst);
        s.reloadResources(sel).thenRun(() -> frt.post(() -> { fire("E_DataPackChanged", pack); fire("E_Reload"); }));
        return pack;
    }

    Info packInfo(String cls, String id, Path p) {
        Info i = new Info(cls, id);
        i.put("Id", id).put("Name", p == null ? id : p.getFileName().toString()).put("Path", p == null ? "" : p.toString());
        if (cls.equals("ForgeDataPack")) i.live("Enabled", () -> valueOf(gr().server() != null && gr().server().getPackRepository().getSelectedIds().contains(id)));
        return i;
    }

    LuaValue dataPacks() {
        LuaTable t = new LuaTable(); int n = 0;
        MinecraftServer s = gr().server();
        if (s == null) return t;
        for (String id : s.getPackRepository().getAvailableIds()) t.set(++n, packInfo("ForgeDataPack", id, null));
        return t;
    }

    LuaValue info(String cls) {
        if (cls.equals("ForgeServer")) {
            MinecraftServer s = gr().server();
            if (s == null) return NIL;
            Info i = new Info("ForgeServer", "Server");
            i.put("Dedicated", valueOf(s.isDedicatedServer())).put("Version", s.getServerVersion()).put("WorldName", s.getWorldData().getLevelName());
            i.live("Motd", () -> valueOf(s.getMotd())).live("MaxPlayers", () -> valueOf(s.getMaxPlayers())).live("PlayerCount", () -> valueOf(s.getPlayerCount()))
                    .live("Port", () -> valueOf(s.getPort())).live("TickTime", () -> valueOf(s.getAverageTickTime())).live("Running", () -> valueOf(s.isRunning()))
                    .live("Hardcore", () -> valueOf(s.isHardcore())).live("Difficulty", () -> valueOf(s.getWorldData().getDifficulty().getKey()));
            return i;
        }
        return ForgeClient.info();
    }

    // ================================================================ Lua surface
    String gameDir() { return FMLPaths.GAMEDIR.get().toAbsolutePath().normalize().toString(); }
    String worldDir() { MinecraftServer s = gr().server(); return s == null ? "" : s.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize().toString(); }
    /** FML is versioned together with Forge since 1.17 (fmlcore-1.20.1-47.x) */
    String fmlVersion() {
        try { return ModList.get().getModFileById("forge").getFile().getModInfos().get(0).getVersion().toString(); } catch (RuntimeException e) { return FMLLoader.versionInfo().forgeVersion(); }
    }

    ForgeEventBusObj forgeBus() {
        if (forgeBus == null) forgeBus = new ForgeEventBusObj(this, "MinecraftForge.EVENT_BUS", "Forge", MinecraftForge.EVENT_BUS, null);
        return forgeBus;
    }
    LuaValue modBus(String id) { ForgeModObj m = checkMod(id); return m.eventBus(); }

    LuaTable tags(String type) { return ForgeRegistryObj.strList(registry(type).tagNames()); }

    LuaValue reload() {
        if (frt.server) {
            MinecraftServer s = srv();
            s.reloadResources(s.getPackRepository().getSelectedIds()).thenRun(() -> frt.post(() -> fire("E_Reload")));
        } else ForgeClient.reloadResources(this);
        return NONE;
    }

    @Override protected LuaValue getProp(String k) {
        Signal sg = events.get(k);
        if (sg != null) { if (k.startsWith("E_Server") || k.equals("E_Reload")) installHooks(); return sg; }
        switch (k) {
            case "Loaded": return TRUE;
            case "Version": return valueOf(FMLLoader.versionInfo().mcAndForgeVersion());
            case "MinecraftVersion": return valueOf(FMLLoader.versionInfo().mcVersion());
            case "ForgeVersion": return valueOf(FMLLoader.versionInfo().forgeVersion());
            case "FMLVersion": return valueOf(fmlVersion());
            case "Side": return valueOf(frt.server ? "SERVER" : "CLIENT");
            case "Dist": return valueOf(FMLEnvironment.dist.name());
            case "GameDir": return valueOf(gameDir());
            case "ConfigDir": return valueOf(FMLPaths.CONFIGDIR.get().toAbsolutePath().normalize().toString());
            case "ModsDir": return valueOf(FMLPaths.MODSDIR.get().toAbsolutePath().normalize().toString());
            case "WorldDir": return valueOf(worldDir());
            case "LogDir": return valueOf(FMLPaths.GAMEDIR.get().resolve("logs").toAbsolutePath().normalize().toString());
            case "ResourcePackDir": return valueOf(FMLPaths.GAMEDIR.get().resolve("resourcepacks").toAbsolutePath().normalize().toString());
            case "Mods": return list(allMods());
            case "ModList": return modIds();
            case "EventBus": case "MinecraftEventBus": return forgeBus();
            case "RegistryManager": return registryManagerObj();
            case "RecipeManager": return recipeManagerObj();
            case "Server": return info("ForgeServer");
            case "Client": return frt.server ? NIL : info("ForgeClient");
            case "ResourcePacks": return frt.server ? new LuaTable() : ForgeClient.resourcePacks();
            case "DataPacks": return dataPacks();
            case "Tags": { LuaTable t = new LuaTable(); for (String r : new String[]{"item", "block", "entity_type", "fluid"}) t.set(r, tags(r)); return t; }
            case "ScriptMods": return list(scriptMods.values());
            case "Loader": return valueOf("Forge");
            case "Unlocked": return valueOf(net.idea.fluwa.Config.forgeUnlocked);
        }
        return super.getProp(k);
    }
    @Override public void setName(String n) { throw new LuaError("Forge.Name is read-only"); }

    LuaTable modIds() { List<String> l = new ArrayList<>(); for (IModInfo i : ModList.get().getMods()) l.add(i.getModId()); l.addAll(scriptMods.keySet()); return ForgeRegistryObj.strList(l); }

    static ForgeService F(LObj s) { return (ForgeService) s; }
    static {
        Class<ForgeService> C = ForgeService.class;
        reg(C, "GetMods", (s, a) -> list(F(s).allMods()));
        // v0.5.1 deep reflection
        reg(C, "GetClass|JavaClass", (s, a) -> { JavaObj.check(); return JavaObj.ofClass(JavaObj.forName(a.checkjstring(1))); });
        reg(C, "Java|Wrap", (s, a) -> {
            JavaObj.check();
            Object o = JavaObj.unwrap(a.arg1());
            if (o == null && a.arg1().isstring()) return JavaObj.ofClass(JavaObj.forName(a.tojstring(1)));
            if (o == null) throw new LuaError("Forge:Java - expected an Entity / Player / Dimension / Item / ForgeEvent / JavaObject or a class name");
            return o instanceof Class<?> c ? JavaObj.ofClass(c) : new JavaObj(o);
        });
        reg(C, "IsUnlocked", (s, a) -> valueOf(net.idea.fluwa.Config.forgeUnlocked));
        reg(C, "GetStatic", (s, a) -> { JavaObj.check(); return JavaObj.ofClass(JavaObj.forName(a.checkjstring(1))).get(a.arg(2)); });
        reg(C, "GetMinecraftServer|JavaServer", (s, a) -> { JavaObj.check(); return new JavaObj(F(s).srv()); });
        reg(C, "GetMinecraftClient|JavaClient", (s, a) -> {
            JavaObj.check();
            if (F(s).frt.server) throw new LuaError("Forge:GetMinecraftClient is client-only");
            return JavaObj.ofClass(JavaObj.forName("net.minecraft.client.Minecraft")).get("getInstance").call();
        });
        reg(C, "GetMod", (s, a) -> { ForgeModObj m = F(s).mod(a.checkjstring(1)); return m == null ? NIL : m; });
        reg(C, "IsModLoaded", (s, a) -> valueOf(ModList.get().isLoaded(a.checkjstring(1)) || F(s).scriptMods.containsKey(a.checkjstring(1)) && F(s).scriptMods.get(a.checkjstring(1)).loaded));
        reg(C, "GetModContainer", (s, a) -> F(s).checkMod(a.checkjstring(1)).containerInfo());
        reg(C, "GetModMetadata", (s, a) -> F(s).checkMod(a.checkjstring(1)).metadata());
        reg(C, "GetModFile", (s, a) -> F(s).checkMod(a.checkjstring(1)).fileInfo());
        reg(C, "GetEventBus|GetMinecraftEventBus", (s, a) -> F(s).forgeBus());
        reg(C, "GetModEventBus", (s, a) -> F(s).modBus(a.checkjstring(1)));
        reg(C, "GetRegistry", (s, a) -> F(s).registry(a.checkjstring(1)));
        reg(C, "GetConfig", (s, a) -> {
            String id = a.checkjstring(1);
            ForgeModObj m = F(s).scriptMods.get(id);
            if (m != null) return m.config == null ? NIL : m.config;
            return F(s).realConfig(id, a.isnil(2) ? null : a.checkjstring(2)); });
        reg(C, "RegisterMod", (s, a) -> F(s).registerMod(a.checktable(1)));
        for (String kind : new String[]{"Block", "Item", "Entity", "Biome", "Dimension"})
            reg(C, "Register" + kind, (s, a) -> F(s).scriptMod(a.checkjstring(1)).register(kind, a.checkjstring(2), a.arg(3)));
        reg(C, "RegisterRecipe", (s, a) -> { F(s).scriptMod(a.checkjstring(1)); return F(s).registerRecipe(a.checkjstring(1), a.checkjstring(2), a.arg(3)); });
        reg(C, "RegisterCapability", (s, a) -> { F(s).scriptMod(a.checkjstring(1)); return F(s).registerCapability(a.checkjstring(1), a.checkjstring(2), a.arg(3)); });
        reg(C, "GetCapability", (s, a) -> F(s).capability(a.checkjstring(1)));
        reg(C, "RegisterCommand", (s, a) -> { F(s).scriptMod(a.checkjstring(1)); return F(s).registerCommand(a.checkjstring(1), a.checktable(2)); });
        reg(C, "RegisterKeyBinding", (s, a) -> { F(s).scriptMod(a.checkjstring(1)); return F(s).registerKey(a.checkjstring(1), a.checkjstring(2), a.arg(3)); });
        reg(C, "RegisterResourcePack", (s, a) -> {
            if (F(s).frt.server) throw new LuaError("RegisterResourcePack is Client-Side: use it in ClientScripts");
            return ForgeClient.registerResourcePack(F(s), F(s).checkedSource(a.checkjstring(1))); });
        reg(C, "RegisterDataPack", (s, a) -> F(s).registerDataPack(a.checkjstring(1)));
        reg(C, "GetSide", (s, a) -> valueOf(F(s).frt.server ? "SERVER" : "CLIENT"));
        reg(C, "GetDist", (s, a) -> valueOf(FMLEnvironment.dist.name()));
        reg(C, "GetMinecraftVersion", (s, a) -> valueOf(FMLLoader.versionInfo().mcVersion()));
        reg(C, "GetForgeVersion", (s, a) -> valueOf(FMLLoader.versionInfo().forgeVersion()));
        reg(C, "GetFMLVersion", (s, a) -> valueOf(F(s).fmlVersion()));
        reg(C, "GetLoader", (s, a) -> valueOf("Forge"));
        reg(C, "GetGameDir", (s, a) -> F(s).getProp("GameDir"));
        reg(C, "GetConfigDir", (s, a) -> F(s).getProp("ConfigDir"));
        reg(C, "GetModsDir", (s, a) -> F(s).getProp("ModsDir"));
        reg(C, "GetWorldDir", (s, a) -> F(s).getProp("WorldDir"));
        reg(C, "GetLogDir", (s, a) -> F(s).getProp("LogDir"));
        reg(C, "GetResourcePackDir", (s, a) -> F(s).getProp("ResourcePackDir"));
        reg(C, "GetServer", (s, a) -> F(s).info("ForgeServer"));
        reg(C, "GetClient", (s, a) -> F(s).frt.server ? NIL : F(s).info("ForgeClient"));
        reg(C, "Reload", (s, a) -> F(s).reload());
        reg(C, "GetTags", (s, a) -> F(s).tags(a.checkjstring(1)));
        reg(C, "GetTag", (s, a) -> F(s).registry(a.checkjstring(1)).tagObj(a.checkjstring(2)));
        reg(C, "CreateTag", (s, a) -> {
            ForgeRegistryObj r = F(s).registry(a.checkjstring(1));
            ForgeTagObj t = r.tagObj(a.checkjstring(2));
            r.tagAdd.computeIfAbsent(t.id, k -> new LinkedHashSet<>());
            if (a.arg(3).istable()) for (int i = 1; i <= a.arg(3).length(); i++) r.addTag(t.id, a.arg(3).get(i).checkjstring());
            return t; });
        reg(C, "GetRecipeManager", (s, a) -> F(s).recipeManagerObj());
        reg(C, "GetRegistryManager", (s, a) -> F(s).registryManagerObj());
        reg(C, "GetDataPackList", (s, a) -> {
            MinecraftServer srv = F(s).gr().server();
            return srv == null ? new LuaTable() : ForgeRegistryObj.strList(new ArrayList<>(srv.getPackRepository().getSelectedIds())); });
        reg(C, "GetResourcePackList", (s, a) -> F(s).frt.server ? new LuaTable() : ForgeClient.resourcePackIds());
        reg(C, "GetModList|GetModIds", (s, a) -> F(s).modIds());
        reg(C, "GetLoadedMods", (s, a) -> {
            LuaTable t = new LuaTable(); int n = 0;
            for (LuaValue m : F(s).allMods()) if (m instanceof ForgeModObj fm && fm.getProp("Loaded").toboolean()) t.set(++n, m);
            return t; });
        reg(C, "GetModNames", (s, a) -> { LuaTable t = new LuaTable(); for (LuaValue m : F(s).allMods()) { ForgeModObj fm = (ForgeModObj) m; t.set(fm.id, valueOf(fm.name)); } return t; });
        reg(C, "GetModVersions", (s, a) -> { LuaTable t = new LuaTable(); for (LuaValue m : F(s).allMods()) { ForgeModObj fm = (ForgeModObj) m; t.set(fm.id, valueOf(fm.version())); } return t; });
    }
}
