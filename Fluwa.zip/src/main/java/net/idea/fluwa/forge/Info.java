package net.idea.fluwa.forge;

import net.idea.fluwa.lua.LObj;
import org.luaj.vm2.*;

import java.util.*;
import java.util.function.Supplier;

/** Read-only information object (ForgeModContainer, ForgeModMetadata, ForgeModFile, ForgeKeyBinding, ...). */
public class Info extends LObj {
    final Map<String, Supplier<LuaValue>> props = new LinkedHashMap<>();
    final Map<String, LuaValue> methods = new HashMap<>();
    /** attached Java object (key mapping...) */
    Object userKey;

    public Info(String cls, String name) { super(cls); this.name = name; }

    public Info put(String k, LuaValue v) { LuaValue x = v == null ? NIL : v; props.put(k, () -> x); return this; }
    public Info put(String k, String v) { return put(k, v == null ? NIL : valueOf(v)); }
    public Info live(String k, Supplier<LuaValue> s) { props.put(k, s); return this; }
    /** obj:Name(...) — fn receives the arguments without self */
    public Info method(String n, java.util.function.Function<Varargs, Varargs> fn) {
        methods.put(n, new org.luaj.vm2.lib.VarArgFunction() {
            public Varargs invoke(Varargs a) { return fn.apply(a.arg1() == Info.this ? a.subargs(2) : a); }
        });
        return this;
    }

    @Override protected LuaValue getProp(String k) {
        Supplier<LuaValue> s = props.get(k);
        if (s != null) return s.get();
        LuaValue m = methods.get(k);
        if (m != null) return m;
        if (k.startsWith("Get") && props.containsKey(k.substring(3))) { Supplier<LuaValue> g = props.get(k.substring(3)); return fn0(g); }
        if (k.startsWith("Is") && props.containsKey(k.substring(2))) { Supplier<LuaValue> g = props.get(k.substring(2)); return fn0(g); }
        return super.getProp(k);
    }
    static LuaValue fn0(Supplier<LuaValue> g) { return new org.luaj.vm2.lib.VarArgFunction() { public Varargs invoke(Varargs a) { return g.get(); } }; }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (props.containsKey(k)) throw new LuaError(className + "." + k + " is read-only");
        return super.setProp(k, v);
    }
    @Override public void setName(String n) { throw new LuaError(className + ".Name is read-only"); }

    public LuaTable toTable() { LuaTable t = new LuaTable(); for (var e : props.entrySet()) t.set(e.getKey(), e.getValue().get()); return t; }
    static { reg(Info.class, "ToTable", (s, a) -> ((Info) s).toTable()); }
}
