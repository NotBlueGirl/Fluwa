package net.idea.fluwa.forge;

import net.idea.fluwa.lua.*;
import org.luaj.vm2.*;

/** ForgeTag: a tag of a ForgeRegistry (real tag contents + script additions/removals). */
public class ForgeTagObj extends LObj {
    final ForgeRegistryObj reg;
    final String id;
    final Signal added = new Signal("E_Added"), removed = new Signal("E_Removed"), cleared = new Signal("E_Cleared");

    ForgeTagObj(ForgeRegistryObj r, String id) { super("ForgeTag"); reg = r; this.id = id; name = "#" + id; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Id": return valueOf(id);
            case "Entries": return ForgeRegistryObj.strList(reg.tag(id));
            case "Registry": return reg;
            case "Size": return valueOf(reg.tag(id).size());
            case "E_Added": return added;
            case "E_Removed": return removed;
            case "E_Cleared": return cleared;
        }
        return super.getProp(k);
    }
    @Override public void setName(String n) { throw new LuaError("ForgeTag.Name is read-only"); }

    static ForgeTagObj T(LObj s) { return (ForgeTagObj) s; }
    static {
        Class<ForgeTagObj> C = ForgeTagObj.class;
        reg(C, "GetId", (s, a) -> valueOf(T(s).id));
        reg(C, "GetEntries", (s, a) -> ForgeRegistryObj.strList(T(s).reg.tag(T(s).id)));
        reg(C, "Contains", (s, a) -> valueOf(T(s).reg.tag(T(s).id).contains(T(s).reg.id(a.checkjstring(1)))));
        reg(C, "Add", (s, a) -> { T(s).reg.addTag(T(s).id, a.checkjstring(1)); return NONE; });
        reg(C, "Remove", (s, a) -> { T(s).reg.removeTag(T(s).id, a.checkjstring(1)); return NONE; });
        reg(C, "Clear", (s, a) -> {
            ForgeTagObj t = T(s);
            for (String e : t.reg.tag(t.id)) t.reg.removeTag(t.id, e);
            t.cleared.fire(NIL); return NONE; });
    }
}
