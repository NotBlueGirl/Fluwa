package net.idea.fluwa.forge;

import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.luaj.vm2.*;

import java.util.*;

/** Java <-> Lua conversion for reflected Forge objects. */
final class J {
    private J() {}

    static LuaValue lua(Object o) { return lua(o, 0); }

    static LuaValue lua(Object o, int depth) {
        if (o == null) return LuaValue.NIL;
        if (o instanceof LuaValue v) return v;
        if (o instanceof Class<?> c && net.idea.fluwa.Config.forgeUnlocked) return JavaObj.ofClass(c);
        if (o instanceof Boolean b) return LuaValue.valueOf(b);
        if (o instanceof Integer || o instanceof Short || o instanceof Byte) return LuaValue.valueOf(((Number) o).intValue());
        if (o instanceof Number n) return LuaValue.valueOf(n.doubleValue());
        if (o instanceof CharSequence s) return LuaValue.valueOf(s.toString());
        if (o instanceof Character c) return LuaValue.valueOf(String.valueOf(c));
        if (o instanceof Enum<?> e) return LuaValue.valueOf(e.name());
        if (o instanceof Component c) return LuaValue.valueOf(c.getString());
        if (o instanceof ResourceLocation r) return LuaValue.valueOf(r.toString());
        if (o instanceof net.minecraft.resources.ResourceKey<?> k) return LuaValue.valueOf(k.location().toString());
        if (o instanceof Optional<?> op) return op.isPresent() ? lua(op.get(), depth) : LuaValue.NIL;
        GameRuntime g = GameRuntime.cur();
        if (g != null) {
            if (o instanceof Player p) return g.wrap(p);
            if (o instanceof Entity e) return g.wrapEntity(e);
            if (o instanceof Level l) return g.wrap(l);
        }
        if (o instanceof BlockPos p) return Vec3L.of(p);
        if (o instanceof Vec3 v) return Vec3L.of(v);
        if (o instanceof ItemStack s) return new ItemObj(s);
        if (o instanceof BlockState s) return LuaValue.valueOf(Conv.id(s));
        if (o instanceof Block b) return LuaValue.valueOf(BuiltInRegistries.BLOCK.getKey(b).toString());
        if (o instanceof Item i) return LuaValue.valueOf(BuiltInRegistries.ITEM.getKey(i).toString());
        if (o instanceof net.minecraftforge.eventbus.api.Event e) return new ForgeEventObj(e, null);
        if (o instanceof java.nio.file.Path p) return LuaValue.valueOf(p.toString());
        if (depth < 2 && o instanceof Collection<?> c) {
            LuaTable t = new LuaTable(); int i = 0;
            for (Object x : c) { if (++i > 2000) break; t.set(i, lua(x, depth + 1)); }
            return t;
        }
        if (depth < 2 && o instanceof Map<?, ?> m) {
            LuaTable t = new LuaTable(); int i = 0;
            for (var e : m.entrySet()) { if (++i > 2000) break; t.set(lua(e.getKey(), depth + 1), lua(e.getValue(), depth + 1)); }
            return t;
        }
        if (o.getClass().isArray() && depth < 2) {
            LuaTable t = new LuaTable(); int n = java.lang.reflect.Array.getLength(o);
            for (int i = 0; i < Math.min(n, 2000); i++) t.set(i + 1, lua(java.lang.reflect.Array.get(o, i), depth + 1));
            return t;
        }
        if (net.idea.fluwa.Config.forgeUnlocked) return new JavaObj(o);   // deep reflection: keep the real object
        return LuaValue.valueOf(String.valueOf(o));
    }

    /** a Lua function as a functional interface (Runnable, Consumer, Predicate, Supplier...) */
    static Object proxy(Class<?> t, LuaValue fn) {
        var rt = net.idea.fluwa.lua.FluwaRuntime.current();
        return java.lang.reflect.Proxy.newProxyInstance(t.getClassLoader(), new Class<?>[]{t}, (px, m, args) -> {
            if (m.getDeclaringClass() == Object.class) {
                return switch (m.getName()) { case "hashCode" -> System.identityHashCode(px); case "equals" -> px == args[0]; default -> "LuaFunction(" + t.getSimpleName() + ")"; };
            }
            if (m.isDefault()) return java.lang.reflect.InvocationHandler.invokeDefault(px, m, args);
            LuaValue[] la = new LuaValue[args == null ? 0 : args.length];
            for (int i = 0; i < la.length; i++) la[i] = lua(args[i]);
            java.util.function.Supplier<Object> call = () -> {
                Varargs r = fn.invoke(LuaValue.varargsOf(la));
                Class<?> rtp = m.getReturnType();
                if (rtp == void.class) return null;
                return java(r.arg1(), rtp);
            };
            return rt == null ? call.get() : rt.within(call::get);
        });
    }

    /** Lua value -> Java parameter of type t (null if impossible) */
    @SuppressWarnings({"unchecked", "rawtypes"})
    static Object java(LuaValue v, Class<?> t) {
        if (v.isnil() && !t.isPrimitive()) return null;
        if (LuaValue.class.isAssignableFrom(t) && t.isInstance(v) && !(v instanceof JavaObj)) return v;   // Lua values for Fluwa's own Java APIs
        Object raw = JavaObj.unwrap(v);
        if (raw != null && (t.isInstance(raw) || !t.isPrimitive() && t == Object.class)) return raw;
        if (raw != null && t.isPrimitive() && v instanceof JavaObj) {
            Class<?> box = java.lang.invoke.MethodType.methodType(t).wrap().returnType();
            if (box.isInstance(raw)) return raw;
        }
        if (t == short.class || t == Short.class) return (short) v.checkint();
        if (t == byte.class || t == Byte.class) return (byte) v.checkint();
        if (t == char.class || t == Character.class) { String s = v.checkjstring(); if (s.isEmpty()) throw new LuaError("empty char"); return s.charAt(0); }
        if (t == CharSequence.class) return v.checkjstring();
        if (t == int.class || t == Integer.class) return v.checkint();
        if (t == long.class || t == Long.class) return v.checklong();
        if (t == float.class || t == Float.class) return (float) v.checkdouble();
        if (t == double.class || t == Double.class) return v.checkdouble();
        if (t == boolean.class || t == Boolean.class) return v.toboolean();
        if (t == String.class) return v.checkjstring();
        if (Component.class.isAssignableFrom(t)) return Component.literal(v.checkjstring());
        if (t == ResourceLocation.class) return Conv.rl(v.checkjstring());
        if (t.isEnum()) { for (Object c : t.getEnumConstants()) if (((Enum) c).name().equalsIgnoreCase(v.checkjstring())) return c; throw new LuaError("Unknown " + t.getSimpleName() + " '" + v + "'"); }
        if (t == ItemStack.class) return v instanceof ItemObj i ? i.stack : new ItemStack(BuiltInRegistries.ITEM.get(Conv.rl(v.checkjstring())));
        if (t == BlockState.class) return Conv.block(v.checkjstring());
        if (t == Vec3.class) return Vec3L.check(v).mc();
        if (t == BlockPos.class) return Vec3L.check(v).pos();
        if (t == Object.class) {   // strings stay strings ("0.5"), whole numbers become Integer
            if (v.type() == LuaValue.TNUMBER) return v.isinttype() ? (Object) v.toint() : (Object) v.todouble();
            if (v.isboolean()) return v.toboolean();
            if (v.istable() && !(v instanceof LObj)) {
                LuaTable tb = (LuaTable) v;
                if (tb.length() > 0) { List<Object> l = new ArrayList<>(); for (int i = 1; i <= tb.length(); i++) l.add(java(tb.get(i), Object.class)); return l; }
                Map<Object, Object> m = new LinkedHashMap<>();
                for (LuaValue k = tb.next(LuaValue.NIL).arg1(); !k.isnil(); k = tb.next(k).arg1()) m.put(java(k, Object.class), java(tb.get(k), Object.class));
                return m;
            }
            return v.tojstring();
        }
        if (t == Class.class && v.isstring()) return JavaObj.forName(v.tojstring());
        if (t.isArray() && v.istable()) {
            Class<?> et = t.getComponentType(); int n = v.length();
            Object arr = java.lang.reflect.Array.newInstance(et, n);
            for (int i = 0; i < n; i++) java.lang.reflect.Array.set(arr, i, java(v.get(i + 1), et));
            return arr;
        }
        if (t.isInterface() && v.isfunction() && net.idea.fluwa.Config.forgeUnlocked) return proxy(t, v);
        if (raw != null) throw new LuaError("Can't convert " + raw.getClass().getSimpleName() + " to " + t.getSimpleName());
        throw new LuaError("Can't convert " + v.typename() + " to " + t.getSimpleName());
    }
}
