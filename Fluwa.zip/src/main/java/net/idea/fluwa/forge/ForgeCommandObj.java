package net.idea.fluwa.forge;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.CommandNode;
import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.luaj.vm2.*;

import java.util.*;

/**
 * ForgeCommand: a real Brigadier server command (/name [args...]) handled by a Lua function(sender, args, raw).
 * sender = Player (nil for the console / command blocks), args = table of words, raw = the whole argument string.
 * Permission: "all" (default), "op" (= level 2), "0".."4", "creator" (ZSpace creators). Removed when the scripts stop.
 */
public class ForgeCommandObj extends LObj {
    final ForgeService forge;
    final String modId;
    final String cmd;
    String permission;
    final List<String> aliases = new ArrayList<>();
    final LuaValue fn;
    final String description;
    boolean registered;
    final Signal eExec = new Signal("E_Execute"), eError = new Signal("E_Error");

    ForgeCommandObj(ForgeService f, String modId, LuaTable t) {
        super("ForgeCommand");
        forge = f; this.modId = modId;
        cmd = t.get("Name").isnil() ? t.get("name").checkjstring() : t.get("Name").checkjstring();
        if (!cmd.matches("[a-z0-9_\\-.]+")) throw new LuaError("Command name must be lowercase letters, digits, _ - .");
        permission = t.get("Permission").optjstring(t.get("permission").optjstring("all"));
        LuaValue al = t.get("Aliases").isnil() ? t.get("aliases") : t.get("Aliases");
        if (al.istable()) for (int i = 1; i <= al.length(); i++) aliases.add(al.get(i).checkjstring().toLowerCase(Locale.ROOT));
        LuaValue cb = NIL;
        for (String k : new String[]{"Callback", "Execute", "OnExecute", "callback", "execute", "Run", "run"}) if (t.get(k).isfunction()) { cb = t.get(k); break; }
        if (!cb.isfunction()) throw new LuaError("Command table needs a Callback function(sender, args, raw)");
        fn = cb;
        description = t.get("Description").optjstring("");
        name = cmd;
    }

    MinecraftServer srv() { MinecraftServer s = ((GameRuntime) rt).server(); if (s == null) throw new LuaError("Commands are Server-Side"); return s; }

    boolean allowed(CommandSourceStack src) {
        String p = permission.toLowerCase(Locale.ROOT);
        switch (p) {
            case "all": case "everyone": case "any": case "": return true;
            case "op": case "operator": return src.hasPermission(2);
            case "creator": return !(src.getEntity() instanceof ServerPlayer sp) || net.idea.fluwa.server.ScriptManager.isCreator(sp);
            case "console": return src.getEntity() == null;
        }
        try { return src.hasPermission(Integer.parseInt(p)); } catch (NumberFormatException e) { return src.hasPermission(2); }
    }

    int run(CommandContext<CommandSourceStack> ctx, String raw) {
        CommandSourceStack src = ctx.getSource();
        if (rt.closed) return 0;
        if (!forge.modEnabled(modId)) { src.sendFailure(Component.literal("Mod " + modId + " is disabled")); return 0; }
        LuaValue sender = src.getEntity() instanceof ServerPlayer sp ? ((GameRuntime) rt).wrap(sp) : NIL;
        Varargs r = invoke(sender, raw, src);
        LuaValue v = r.arg1();
        if (v.isstring() && !v.isnumber()) src.sendSuccess(() -> Component.literal(v.tojstring()), false);
        return v.isnumber() ? v.toint() : 1;
    }

    static LuaTable words(String raw) {
        LuaTable t = new LuaTable();
        int i = 0;
        for (String w : raw.trim().split("\\s+")) if (!w.isEmpty()) t.set(++i, valueOf(w));
        return t;
    }

    Varargs invoke(LuaValue sender, String raw, CommandSourceStack src) {
        return rt.<Varargs>within(() -> {
            LuaTable args = words(raw);
            eExec.fire(sender, args);
            try { return fn.invoke(LuaValue.varargsOf(sender, args, valueOf(raw))); }
            catch (LuaError e) {
                String m = e.getMessage();
                eError.fire(valueOf(m));
                rt.reportError("[command /" + cmd + "] " + m);
                if (src != null) src.sendFailure(Component.literal("/" + cmd + ": " + m));
                return (Varargs) NONE;
            }
        });
    }

    void register() {
        CommandDispatcher<CommandSourceStack> d = srv().getCommands().getDispatcher();
        for (String n : names()) {
            if (d.getRoot().getChild(n) != null) throw new LuaError("Command /" + n + " already exists");
        }
        for (String n : names()) addNode(d, n);
        registered = true;
        resend();
    }

    List<String> names() { List<String> l = new ArrayList<>(); l.add(cmd); l.addAll(aliases); return l; }

    void addNode(CommandDispatcher<CommandSourceStack> d, String n) {
        d.register(Commands.literal(n).requires(this::allowed).executes(c -> run(c, ""))
                .then(Commands.argument("args", StringArgumentType.greedyString()).executes(c -> run(c, StringArgumentType.getString(c, "args")))));
    }

    @SuppressWarnings("unchecked")
    static void removeNode(CommandNode<?> root, String n) {
        for (String f : new String[]{"children", "literals", "arguments"}) {
            try {
                java.lang.reflect.Field fl = CommandNode.class.getDeclaredField(f);
                fl.setAccessible(true);
                ((Map<String, ?>) fl.get(root)).remove(n);
            } catch (ReflectiveOperationException | RuntimeException ignored) {}
        }
    }

    void unregister() {
        if (!registered) return;
        registered = false;
        try {
            CommandDispatcher<CommandSourceStack> d = srv().getCommands().getDispatcher();
            for (String n : names()) removeNode(d.getRoot(), n);
            resend();
        } catch (RuntimeException ignored) {}
    }

    void resend() {
        MinecraftServer s = srv();
        for (ServerPlayer p : s.getPlayerList().getPlayers()) s.getCommands().sendCommands(p);
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Name": return valueOf(cmd);
            case "Permission": return valueOf(permission);
            case "Aliases": return ForgeRegistryObj.strList(aliases);
            case "ModId": return valueOf(modId);
            case "Description": return valueOf(description);
            case "Registered": return valueOf(registered);
            case "E_Execute": return eExec;
            case "E_Error": return eError;
        }
        return super.getProp(k);
    }
    @Override protected boolean setProp(String k, LuaValue v) {
        if (k.equals("Permission")) { permission = v.checkjstring(); resend(); return true; }
        return super.setProp(k, v);
    }
    @Override public void setName(String n) { throw new LuaError("ForgeCommand.Name is read-only"); }
    @Override protected void onDestroy() { unregister(); }

    static ForgeCommandObj K(LObj s) { return (ForgeCommandObj) s; }
    static {
        Class<ForgeCommandObj> C = ForgeCommandObj.class;
        reg(C, "Execute", (s, a) -> {
            LuaValue snd = a.arg1();
            String raw = a.arg(2).istable() ? joinWords((LuaTable) a.arg(2)) : a.optjstring(2, "");
            return K(s).invoke(snd, raw, null); });
        reg(C, "GetName", (s, a) -> valueOf(K(s).cmd));
        reg(C, "GetPermission", (s, a) -> valueOf(K(s).permission));
        reg(C, "SetPermission", (s, a) -> { K(s).setProp("Permission", a.arg1()); return NONE; });
        reg(C, "GetAliases", (s, a) -> ForgeRegistryObj.strList(K(s).aliases));
        reg(C, "AddAlias", (s, a) -> {
            ForgeCommandObj c = K(s); String n = a.checkjstring(1).toLowerCase(Locale.ROOT);
            if (c.aliases.contains(n)) return FALSE;
            if (c.registered) {
                var d = c.srv().getCommands().getDispatcher();
                if (d.getRoot().getChild(n) != null) throw new LuaError("Command /" + n + " already exists");
                c.addNode(d, n); c.resend();
            }
            c.aliases.add(n); return TRUE; });
        reg(C, "RemoveAlias", (s, a) -> {
            ForgeCommandObj c = K(s); String n = a.checkjstring(1).toLowerCase(Locale.ROOT);
            if (!c.aliases.remove(n)) return FALSE;
            if (c.registered) { removeNode(c.srv().getCommands().getDispatcher().getRoot(), n); c.resend(); }
            return TRUE; });
        reg(C, "Unregister", (s, a) -> { K(s).unregister(); return NONE; });
    }

    static String joinWords(LuaTable t) { StringBuilder b = new StringBuilder(); for (int i = 1; i <= t.length(); i++) { if (i > 1) b.append(' '); b.append(t.get(i).tojstring()); } return b.toString(); }
}
