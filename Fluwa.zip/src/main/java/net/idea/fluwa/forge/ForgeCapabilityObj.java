package net.idea.fluwa.forge;

import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import org.luaj.vm2.*;

import java.util.*;

/**
 * ForgeCapability. Builtin = a real Forge capability (ItemHandler, FluidHandler, FluidHandlerItem, Energy, or any registered
 * one by name): Get/Has query entities, block entities and items. Script = a named data slot that scripts Attach to
 * entities (saved in the entity data), items (saved in the item NBT) and blocks (kept while the scripts run).
 */
public class ForgeCapabilityObj extends LObj {
    final ForgeService forge;
    final String modId, capName;
    final Capability<?> real;
    final LuaValue def;
    final Map<String, LuaValue> mem = new LinkedHashMap<>();
    LuaValue lastProvider = NIL;

    ForgeCapabilityObj(ForgeService f, String modId, String n, Capability<?> real, LuaValue def) {
        super("ForgeCapability");
        forge = f; this.modId = modId; capName = n; this.real = real; this.def = def == null ? NIL : def; name = n;
    }

    static Capability<?> findReal(String n) {
        String k = n.toLowerCase(Locale.ROOT).replace("_", "").replace("forge:", "");
        switch (k) {
            case "itemhandler": case "iitemhandler": case "items": return net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER;
            case "fluidhandler": case "ifluidhandler": case "fluids": return net.minecraftforge.common.capabilities.ForgeCapabilities.FLUID_HANDLER;
            case "fluidhandleritem": case "ifluidhandleritem": return net.minecraftforge.common.capabilities.ForgeCapabilities.FLUID_HANDLER_ITEM;
            case "energy": case "energystorage": case "ienergystorage": return net.minecraftforge.common.capabilities.ForgeCapabilities.ENERGY;
        }
        try {
            var m = net.minecraftforge.common.capabilities.CapabilityManager.class.getDeclaredMethod("get", String.class, boolean.class);
            m.setAccessible(true);
            Capability<?> c = (Capability<?>) m.invoke(net.minecraftforge.common.capabilities.CapabilityManager.INSTANCE, n, false);
            if (c != null && c.isRegistered()) return c;
        } catch (ReflectiveOperationException | RuntimeException ignored) {}
        return null;
    }

    static ICapabilityProvider provider(LuaValue v) {
        if (v instanceof EntityObj e && e.raw() != null) return e.raw();
        if (v instanceof ItemObj i) return i.stack;
        if (v instanceof BlockObj b && b.rawLevel() != null) { var be = b.rawLevel().getBlockEntity(b.blockPos()); if (be != null) return be; }
        return null;
    }

    static String key(LuaValue v) {
        if (v instanceof EntityObj e && e.raw() != null) return "E:" + e.raw().getUUID();
        if (v instanceof BlockObj b && b.rawLevel() != null) return "B:" + b.rawLevel().dimension().location() + "@" + b.blockPos().toShortString();
        if (v instanceof LObj o) return "O:" + System.identityHashCode(o);
        return "V:" + v.tojstring();
    }

    CompoundTag nbt(LuaValue v, boolean create) {
        if (v instanceof EntityObj e && e.raw() != null && !e.raw().level().isClientSide()) {
            CompoundTag p = e.raw().getPersistentData();
            if (!p.contains("fluwaCaps") && !create) return null;
            if (!p.contains("fluwaCaps")) p.put("fluwaCaps", new CompoundTag());
            return p.getCompound("fluwaCaps");
        }
        if (v instanceof ItemObj i) {
            CompoundTag t = create ? i.stack.getOrCreateTagElement("fluwaCaps") : i.stack.getTagElement("fluwaCaps");
            return t;
        }
        return null;
    }

    String nbtKey() { return modId + ":" + capName; }

    LuaValue describe(Object inst) {
        Info i = new Info("ForgeCapabilityInstance", capName);
        i.put("Class", inst.getClass().getName());
        if (inst instanceof net.minecraftforge.items.IItemHandler h) {
            i.live("Slots", () -> valueOf(h.getSlots()));
            i.method("GetStackInSlot", a -> { var s = h.getStackInSlot(a.checkint(1) - 1); return s.isEmpty() ? NIL : new ItemObj(s.copy()); });
            i.method("GetItems", a -> { LuaTable t = new LuaTable(); for (int k = 0; k < h.getSlots(); k++) { var s = h.getStackInSlot(k); t.set(k + 1, s.isEmpty() ? NIL : new ItemObj(s.copy())); } return t; });
            i.method("Insert", a -> { var rem = h.insertItem(a.checkint(1) - 1, ((ItemObj) a.arg(2)).stack.copy(), a.optboolean(3, false)); return rem.isEmpty() ? NIL : new ItemObj(rem); });
            i.method("Extract", a -> { var s = h.extractItem(a.checkint(1) - 1, a.optint(2, 64), a.optboolean(3, false)); return s.isEmpty() ? NIL : new ItemObj(s); });
        }
        if (inst instanceof net.minecraftforge.energy.IEnergyStorage es) {
            i.live("Energy", () -> valueOf(es.getEnergyStored())).live("MaxEnergy", () -> valueOf(es.getMaxEnergyStored()));
            i.method("Receive", a -> valueOf(es.receiveEnergy(a.checkint(1), a.optboolean(2, false))));
            i.method("ExtractEnergy", a -> valueOf(es.extractEnergy(a.checkint(1), a.optboolean(2, false))));
        }
        if (inst instanceof net.minecraftforge.fluids.capability.IFluidHandler fh) {
            i.live("Tanks", () -> valueOf(fh.getTanks()));
            i.method("GetFluid", a -> { var f = fh.getFluidInTank(a.checkint(1) - 1); LuaTable t = new LuaTable();
                t.set("Fluid", String.valueOf(net.minecraft.core.registries.BuiltInRegistries.FLUID.getKey(f.getFluid()))); t.set("Amount", f.getAmount());
                t.set("Capacity", fh.getTankCapacity(a.checkint(1) - 1)); return t; });
        }
        return i;
    }

    LuaValue fetch(LuaValue p) {
        lastProvider = p;
        if (real != null) {
            ICapabilityProvider pr = provider(p);
            if (pr == null) return NIL;
            var o = pr.getCapability(real).resolve();
            return o.isPresent() ? describe(o.get()) : NIL;
        }
        LuaValue v = mem.get(key(p));
        if (v != null) return v;
        CompoundTag t = nbt(p, false);
        if (t != null && t.contains(nbtKey())) { LuaValue x = Conv.toLua(t.get(nbtKey())); mem.put(key(p), x); return x; }
        return NIL;
    }

    boolean has(LuaValue p) {
        if (real != null) { ICapabilityProvider pr = provider(p); return pr != null && pr.getCapability(real).isPresent(); }
        return !fetch(p).isnil();
    }

    void attach(LuaValue p, LuaValue v) {
        if (real != null) throw new LuaError(capName + " is a Forge capability: it is attached by the mod that provides it (AttachCapabilitiesEvent), not at runtime");
        LuaValue val = v.isnil() ? (def.istable() ? copy((LuaTable) def) : def.isnil() ? TRUE : def) : v;
        mem.put(key(p), val);
        lastProvider = p;
        try { CompoundTag t = nbt(p, true); if (t != null) t.put(nbtKey(), Conv.toTag(val)); } catch (RuntimeException ignored) {}
    }

    static LuaTable copy(LuaTable t) { LuaTable c = new LuaTable(); for (LuaValue k = t.next(NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) c.set(k, t.get(k).istable() ? copy((LuaTable) t.get(k)) : t.get(k)); return c; }

    void detach(LuaValue p) {
        if (real != null) throw new LuaError(capName + " is a Forge capability and can't be detached");
        mem.remove(key(p));
        CompoundTag t = nbt(p, false);
        if (t != null) t.remove(nbtKey());
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Type": return valueOf(real != null ? "Builtin" : "Script");
            case "Provider": return lastProvider;
            case "Holder": case "ModId": return valueOf(modId);
            case "Side": return valueOf(rt != null && rt.server ? "SERVER" : "CLIENT");
            case "Class": return real == null ? NIL : valueOf(real.getName());
        }
        return super.getProp(k);
    }
    @Override public void setName(String n) { throw new LuaError("ForgeCapability.Name is read-only"); }

    static ForgeCapabilityObj P(LObj s) { return (ForgeCapabilityObj) s; }
    static {
        Class<ForgeCapabilityObj> C = ForgeCapabilityObj.class;
        reg(C, "Get", (s, a) -> P(s).fetch(a.arg1()));
        reg(C, "Attach", (s, a) -> { P(s).attach(a.arg1(), a.arg(2)); return NONE; });
        reg(C, "Detach", (s, a) -> { P(s).detach(a.arg1()); return NONE; });
        reg(C, "Has", (s, a) -> valueOf(P(s).has(a.arg1())));
        reg(C, "GetType", (s, a) -> valueOf(P(s).real != null ? "Builtin" : "Script"));
        reg(C, "GetName", (s, a) -> valueOf(P(s).capName));
        reg(C, "Serialize", (s, a) -> { LuaTable t = new LuaTable(); for (var e : P(s).mem.entrySet()) t.set(e.getKey(), e.getValue()); return t; });
        reg(C, "Deserialize", (s, a) -> {
            LuaTable t = a.checktable(1);
            for (LuaValue k = t.next(NIL).arg1(); !k.isnil(); k = t.next(k).arg1()) P(s).mem.put(k.tojstring(), t.get(k));
            return NONE; });
    }
}
