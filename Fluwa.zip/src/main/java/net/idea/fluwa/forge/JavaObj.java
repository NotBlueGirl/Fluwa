package net.idea.fluwa.forge;

import net.idea.fluwa.Config;
import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.LObj;
import org.luaj.vm2.*;
import org.luaj.vm2.lib.VarArgFunction;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.*;
import java.util.*;

/**
 * v0.5.1 deep reflection ("unlocked" Forge module). A JavaObject wraps any Java object or class:
 * <pre>
 *   local Level = Forge:GetClass("net.minecraft.world.level.Level")
 *   local lvl   = Forge:Java(Dimension)            -- the real Level behind a Fluwa object
 *   print(lvl.isClientSide, lvl:getSeaLevel())     -- fields / methods of ANY visibility (private, protected, final)
 *   lvl:Set("thunderLevel", 1)                     -- also private / final fields
 *   local list = Forge:GetClass("java.util.ArrayList"):New()
 * </pre>
 * Access to non-public members uses setAccessible, falling back to the JVM's trusted lookup (sun.misc.Unsafe) for
 * module-locked JDK packages. Enabled with fluwa-common.toml forgeUnlocked = true (default in Mod Creator mode).
 */
public class JavaObj extends LObj {
    final Object target;      // null for a class (static access)
    final Class<?> cls;

    public JavaObj(Object target) { this(target, target.getClass()); }
    JavaObj(Object target, Class<?> cls) { super("JavaObject"); this.target = target; this.cls = cls; name = cls.getName(); }
    static JavaObj ofClass(Class<?> c) { return new JavaObj(null, c); }

    static void check() {
        if (!Config.forgeUnlocked) throw new LuaError("Deep reflection is disabled (fluwa-common.toml: forgeUnlocked = false)");
    }

    // ------------------------------------------------------------------ JVM access helpers
    private static sun.misc.Unsafe UNSAFE;
    private static MethodHandles.Lookup TRUSTED;

    static sun.misc.Unsafe unsafe() {
        if (UNSAFE == null) {
            try { Field f = sun.misc.Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); UNSAFE = (sun.misc.Unsafe) f.get(null); }
            catch (Exception e) { throw new LuaError("Unsafe is not available: " + e); }
        }
        return UNSAFE;
    }

    @SuppressWarnings("deprecation")
    static MethodHandles.Lookup trusted() {
        if (TRUSTED == null) {
            try {
                Field f = MethodHandles.Lookup.class.getDeclaredField("IMPL_LOOKUP");
                TRUSTED = (MethodHandles.Lookup) unsafe().getObject(unsafe().staticFieldBase(f), unsafe().staticFieldOffset(f));
            } catch (Exception e) { throw new LuaError("Trusted lookup is not available: " + e); }
        }
        return TRUSTED;
    }

    static boolean open(AccessibleObject o) {
        try { o.setAccessible(true); return true; } catch (RuntimeException e) { return false; }
    }

    public static Class<?> forName(String n) {
        n = n.trim();
        switch (n) {
            case "int": return int.class; case "long": return long.class; case "double": return double.class; case "float": return float.class;
            case "boolean": return boolean.class; case "byte": return byte.class; case "short": return short.class; case "char": return char.class; case "void": return void.class;
        }
        ClassLoader[] ls = {Thread.currentThread().getContextClassLoader(), JavaObj.class.getClassLoader(), net.minecraft.world.level.Level.class.getClassLoader(), ClassLoader.getSystemClassLoader()};
        for (ClassLoader l : ls) {
            if (l == null) continue;
            try { return Class.forName(n, false, l); } catch (ClassNotFoundException | LinkageError ignored) {}
        }
        throw new LuaError("Java class not found: " + n);
    }

    // ------------------------------------------------------------------ members
    static Field field(Class<?> c, String n) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            for (Field f : k.getDeclaredFields()) if (f.getName().equals(n)) return f;
        }
        for (Class<?> i : allInterfaces(c)) for (Field f : i.getDeclaredFields()) if (f.getName().equals(n)) return f;
        return null;
    }

    static Set<Class<?>> allInterfaces(Class<?> c) {
        Set<Class<?>> out = new LinkedHashSet<>();
        Deque<Class<?>> q = new ArrayDeque<>();
        for (Class<?> k = c; k != null; k = k.getSuperclass()) q.addAll(Arrays.asList(k.getInterfaces()));
        while (!q.isEmpty()) { Class<?> i = q.poll(); if (out.add(i)) q.addAll(Arrays.asList(i.getInterfaces())); }
        return out;
    }

    static List<Method> methods(Class<?> c, String n) {
        List<Method> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        List<Class<?>> order = new ArrayList<>();
        for (Class<?> k = c; k != null; k = k.getSuperclass()) order.add(k);
        order.addAll(allInterfaces(c));
        for (Class<?> k : order) for (Method m : k.getDeclaredMethods()) {
            if (!m.getName().equals(n) || m.isSynthetic() && m.isBridge()) continue;
            if (seen.add(Arrays.toString(m.getParameterTypes()))) out.add(m);
        }
        return out;
    }

    static boolean hasMethod(Class<?> c, String n) { return !methods(c, n).isEmpty(); }

    static Object readField(Field f, Object target) {
        boolean st = Modifier.isStatic(f.getModifiers());
        if (!st && target == null) throw new LuaError(f.getName() + " is an instance field (use an object, not the class)");
        try {
            if (open(f)) return f.get(st ? null : target);
            var h = trusted().unreflectGetter(f);
            return st ? h.invoke() : h.invoke(target);
        } catch (LuaError e) { throw e; }
        catch (Throwable e) { throw new LuaError("Can't read " + f.getName() + ": " + e); }
    }

    @SuppressWarnings("deprecation")
    static void writeField(Field f, Object target, LuaValue v) {
        boolean st = Modifier.isStatic(f.getModifiers()), fin = Modifier.isFinal(f.getModifiers());
        if (!st && target == null) throw new LuaError(f.getName() + " is an instance field (use an object, not the class)");
        Object val = J.java(v, f.getType());
        try {
            if (!(st && fin) && open(f)) {
                try { f.set(st ? null : target, val); return; } catch (IllegalAccessException ignored) {}
            }
            if (!fin) {
                var h = trusted().unreflectSetter(f);
                if (st) h.invoke(val); else h.invoke(target, val);
                return;
            }
            // final (static) field: write the memory directly
            sun.misc.Unsafe u = unsafe();
            Object base = st ? u.staticFieldBase(f) : target;
            long off = st ? u.staticFieldOffset(f) : u.objectFieldOffset(f);
            Class<?> t = f.getType();
            if (t == int.class) u.putIntVolatile(base, off, (Integer) val);
            else if (t == long.class) u.putLongVolatile(base, off, (Long) val);
            else if (t == double.class) u.putDoubleVolatile(base, off, (Double) val);
            else if (t == float.class) u.putFloatVolatile(base, off, (Float) val);
            else if (t == boolean.class) u.putBooleanVolatile(base, off, (Boolean) val);
            else if (t == byte.class) u.putByteVolatile(base, off, (Byte) val);
            else if (t == short.class) u.putShortVolatile(base, off, (Short) val);
            else if (t == char.class) u.putCharVolatile(base, off, (Character) val);
            else u.putObjectVolatile(base, off, val);
        } catch (LuaError e) { throw e; }
        catch (Throwable e) { throw new LuaError("Can't write " + f.getName() + ": " + e); }
    }

    static Object[] convert(Class<?>[] types, Varargs a) {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = J.java(a.arg(i + 1), types[i]);
        return args;
    }

    /** call method n on target (null = static) choosing the first overload whose parameters accept the arguments */
    static Object call(Class<?> c, Object target, String n, Varargs a) {
        List<Method> ms = methods(c, n);
        if (ms.isEmpty()) throw new LuaError(c.getName() + " has no method " + n);
        LuaError last = null;
        // exact arity first, then varargs methods
        for (Method m : ms) {
            if (m.getParameterCount() != a.narg() || m.isVarArgs()) continue;
            Object[] args;
            try { args = convert(m.getParameterTypes(), a); } catch (LuaError e) { last = e; continue; }
            return invoke(m, target, args);
        }
        for (Method m : ms) {
            if (!m.isVarArgs()) continue;
            Class<?>[] pt = m.getParameterTypes();
            if (a.narg() < pt.length - 1) continue;
            try {
                Object[] args = new Object[pt.length];
                for (int i = 0; i < pt.length - 1; i++) args[i] = J.java(a.arg(i + 1), pt[i]);
                Class<?> et = pt[pt.length - 1].getComponentType();
                Object arr = Array.newInstance(et, a.narg() - pt.length + 1);
                for (int i = 0; i < Array.getLength(arr); i++) Array.set(arr, i, J.java(a.arg(pt.length + i), et));
                args[pt.length - 1] = arr;
                return invoke(m, target, args);
            } catch (LuaError e) { last = e; }
        }
        throw new LuaError(c.getSimpleName() + ":" + n + " - no overload accepts " + a.narg() + " argument(s)" + (last != null ? " (" + last.getMessage() + ")" : ""));
    }

    static Object invoke(Method m, Object target, Object[] args) {
        boolean st = Modifier.isStatic(m.getModifiers());
        if (!st && target == null) throw new LuaError(m.getName() + " is an instance method (use an object, not the class)");
        try {
            if (open(m)) return m.invoke(st ? null : target, args);
            var h = trusted().unreflect(m);
            if (!st) h = h.bindTo(target);
            return h.invokeWithArguments(args);
        } catch (InvocationTargetException e) { throw new LuaError(m.getName() + ": " + e.getCause()); }
        catch (LuaError e) { throw e; }
        catch (Throwable e) { throw new LuaError(m.getName() + ": " + e); }
    }

    static Object construct(Class<?> c, Varargs a) {
        LuaError last = null;
        for (Constructor<?> k : c.getDeclaredConstructors()) {
            if (k.getParameterCount() != a.narg()) continue;
            Object[] args;
            try { args = convert(k.getParameterTypes(), a); } catch (LuaError e) { last = e; continue; }
            try {
                if (open(k)) return k.newInstance(args);
                return trusted().unreflectConstructor(k).invokeWithArguments(args);
            } catch (InvocationTargetException e) { throw new LuaError("new " + c.getSimpleName() + ": " + e.getCause()); }
            catch (Throwable e) { throw new LuaError("new " + c.getSimpleName() + ": " + e); }
        }
        throw new LuaError(c.getName() + " has no constructor for " + a.narg() + " argument(s)" + (last != null ? " (" + last.getMessage() + ")" : ""));
    }

    /** Java -> Lua: simple values converted, everything else wrapped */
    static LuaValue wrap(Object o) {
        if (o == null) return NIL;
        if (o instanceof LuaValue v && !(o instanceof JavaObj)) return v;
        if (o instanceof Boolean || o instanceof Number || o instanceof CharSequence || o instanceof Character) return J.lua(o);
        return new JavaObj(o);
    }

    /** the Java object behind a Fluwa value (Entity, Player, Level, ItemStack, Event, JavaObject) or null */
    public static Object unwrap(LuaValue v) {
        if (v instanceof JavaObj j) return j.target != null ? j.target : j.cls;
        if (v instanceof PlayerObj p) return p.raw();
        if (v instanceof EntityObj e) return e.raw();
        if (v instanceof DimensionObj d) return d.level();
        if (v instanceof ItemObj i) return i.stack;
        if (v instanceof ForgeEventObj f) return f.ev;
        return null;
    }

    // ------------------------------------------------------------------ Lua side
    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "ClassName": return valueOf("JavaObject");
            case "Class": return valueOf(cls.getName());
            case "IsClass": return valueOf(target == null);
            case "Name": return valueOf(cls.getSimpleName());
            case "Parent": return NIL;
        }
        // a method and a field with the same name (ArrayList.size / size()): the method wins, read the field with :Get("size")
        Field f = field(cls, k);
        boolean hasM = hasMethod(cls, k);
        if (f != null && !hasM && (target != null || Modifier.isStatic(f.getModifiers()))) return J.lua(readField(f, target));
        if (hasM) {
            final String mn = k;
            return new VarArgFunction() {
                @Override public Varargs invoke(Varargs a) {
                    Varargs args = a.arg1() == JavaObj.this ? a.subargs(2) : a;
                    return main(() -> J.lua(JavaObj.call(cls, target, mn, args)));
                }
            };
        }
        if (target == null) {   // nested class: Forge:GetClass("a.b.Outer").Inner
            for (Class<?> n : cls.getDeclaredClasses()) if (n.getSimpleName().equals(k)) return ofClass(n);
            if (cls.isEnum()) for (Object c : cls.getEnumConstants()) if (((Enum<?>) c).name().equals(k)) return new JavaObj(c);
        }
        return null;
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        Field f = field(cls, k);
        if (f == null) return false;
        writeField(f, target, v);
        return true;
    }

    @Override public String tojstring() { return target == null ? "class " + cls.getName() : String.valueOf(target); }
    @Override public String getName() { return cls.getSimpleName(); }

    static JavaObj J(LObj s) { return (JavaObj) s; }
    static {
        Class<JavaObj> C = JavaObj.class;
        reg(C, "Get", (s, a) -> {
            JavaObj j = J(s); Field f = field(j.cls, a.checkjstring(1));
            if (f == null) throw new LuaError(j.cls.getName() + " has no field " + a.checkjstring(1));
            return J.lua(readField(f, j.target));
        });
        reg(C, "GetRaw", (s, a) -> {
            JavaObj j = J(s); Field f = field(j.cls, a.checkjstring(1));
            if (f == null) throw new LuaError(j.cls.getName() + " has no field " + a.checkjstring(1));
            return wrap(readField(f, j.target));
        });
        reg(C, "Set", (s, a) -> {
            JavaObj j = J(s); Field f = field(j.cls, a.checkjstring(1));
            if (f == null) throw new LuaError(j.cls.getName() + " has no field " + a.checkjstring(1));
            writeField(f, j.target, a.arg(2)); return NONE;
        });
        reg(C, "Call", (s, a) -> J.lua(call(J(s).cls, J(s).target, a.checkjstring(1), a.subargs(2))));
        reg(C, "CallRaw", (s, a) -> wrap(call(J(s).cls, J(s).target, a.checkjstring(1), a.subargs(2))));
        reg(C, "New", (s, a) -> wrap(construct(J(s).cls, a)));
        reg(C, "Unwrap|ToLua", (s, a) -> J(s).target == null ? s : J.lua(J(s).target));
        reg(C, "GetClass", (s, a) -> ofClass(J(s).cls));
        reg(C, "Super", (s, a) -> { JavaObj j = J(s); Class<?> sc = j.cls.getSuperclass(); if (sc == null) return NIL; return j.target == null ? ofClass(sc) : new JavaObj(j.target, sc); });
        reg(C, "IsInstance|InstanceOf", (s, a) -> { Class<?> c = forName(a.checkjstring(1)); Object t = J(s).target; return valueOf(t != null && c.isInstance(t)); });
        reg(C, "Cast", (s, a) -> { JavaObj j = J(s); Class<?> c = forName(a.checkjstring(1)); if (j.target == null || !c.isInstance(j.target)) throw new LuaError("Can't cast to " + c.getName()); return new JavaObj(j.target, c); });
        reg(C, "GetFields", (s, a) -> {
            LuaTable t = new LuaTable(); JavaObj j = J(s);
            for (Class<?> k = j.cls; k != null; k = k.getSuperclass()) for (Field f : k.getDeclaredFields())
                t.set(t.length() + 1, valueOf(Modifier.toString(f.getModifiers()) + " " + f.getType().getSimpleName() + " " + f.getName() + "  (" + k.getSimpleName() + ")"));
            return t;
        });
        reg(C, "GetMethods", (s, a) -> {
            LuaTable t = new LuaTable(); JavaObj j = J(s); String filter = a.optjstring(1, "").toLowerCase(Locale.ROOT);
            for (Class<?> k = j.cls; k != null; k = k.getSuperclass()) for (Method m : k.getDeclaredMethods()) {
                if (m.isSynthetic() || !m.getName().toLowerCase(Locale.ROOT).contains(filter)) continue;
                StringBuilder sb = new StringBuilder(Modifier.toString(m.getModifiers())).append(' ').append(m.getReturnType().getSimpleName()).append(' ').append(m.getName()).append('(');
                Class<?>[] p = m.getParameterTypes();
                for (int i = 0; i < p.length; i++) sb.append(i > 0 ? ", " : "").append(p[i].getSimpleName());
                t.set(t.length() + 1, valueOf(sb.append(")  (").append(k.getSimpleName()).append(')').toString()));
            }
            return t;
        });
        reg(C, "GetConstructors", (s, a) -> {
            LuaTable t = new LuaTable();
            for (Constructor<?> k : J(s).cls.getDeclaredConstructors()) t.set(t.length() + 1, valueOf(k.toString()));
            return t;
        });
        reg(C, "IsNull", (s, a) -> valueOf(J(s).target == null && J(s).cls == null));
        reg(C, "Equals", (s, a) -> { Object o = unwrap(a.arg1()); return valueOf(Objects.equals(J(s).target, o)); });
        reg(C, "ToString", (s, a) -> valueOf(s.tojstring()));
        reg(C, "HashCode", (s, a) -> valueOf(System.identityHashCode(J(s).target)));
    }
}
