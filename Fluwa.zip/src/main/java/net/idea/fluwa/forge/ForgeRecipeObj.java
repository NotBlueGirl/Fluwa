package net.idea.fluwa.forge;

import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.Level;
import org.luaj.vm2.*;

/** ForgeRecipe: wraps a recipe of the RecipeManager (vanilla, datapack, mod or script registered). */
public class ForgeRecipeObj extends LObj {
    final Recipe<?> r;
    final boolean script;

    ForgeRecipeObj(Recipe<?> r, boolean script) { super("ForgeRecipe"); this.r = r; this.script = script; name = r.getId().toString(); }

    static RegistryAccess access() {
        GameRuntime g = GameRuntime.cur();
        if (g != null && g.server() != null) return g.server().registryAccess();
        for (Level l : g.levels()) return l.registryAccess();
        return RegistryAccess.EMPTY;
    }
    static Level level() { GameRuntime g = GameRuntime.cur(); for (Level l : g.levels()) return l; throw new LuaError("No level loaded"); }

    String rtype() { var k = BuiltInRegistries.RECIPE_TYPE.getKey(r.getType()); return k == null ? r.getType().toString() : k.toString(); }
    String serializer() { var k = BuiltInRegistries.RECIPE_SERIALIZER.getKey(r.getSerializer()); return k == null ? "?" : k.toString(); }
    String category() {
        if (r instanceof CraftingRecipe c) return c.category().getSerializedName();
        if (r instanceof AbstractCookingRecipe c) return c.category().getSerializedName();
        return "";
    }

    LuaTable inputs() {
        LuaTable t = new LuaTable();
        int i = 0;
        for (Ingredient ing : r.getIngredients()) {
            LuaTable opts = new LuaTable();
            int j = 0;
            for (ItemStack s : ing.getItems()) opts.set(++j, valueOf(BuiltInRegistries.ITEM.getKey(s.getItem()).toString()));
            t.set(++i, opts);
        }
        return t;
    }

    static ItemStack stack(LuaValue v) {
        if (v.isnil() || (v.isstring() && v.tojstring().isEmpty())) return ItemStack.EMPTY;
        if (v instanceof ItemObj o) return o.stack.copy();
        String s = v.checkjstring();
        if (s.equals("air") || s.equals("minecraft:air")) return ItemStack.EMPTY;
        var item = BuiltInRegistries.ITEM.getOptional(Conv.rl(s)).orElseThrow(() -> new LuaError("Unknown item " + s));
        return new ItemStack(item);
    }

    static final class Dummy extends AbstractContainerMenu {
        Dummy() { super(null, -1); }
        @Override public ItemStack quickMoveStack(Player p, int i) { return ItemStack.EMPTY; }
        @Override public boolean stillValid(Player p) { return true; }
    }

    /** input: list of items (crafting: row-major 3x3, nil/"" = empty) */
    Container container(LuaValue in) {
        LuaTable t = in.istable() ? (LuaTable) in : LuaValue.listOf(new LuaValue[]{in});
        int n = Math.max(t.length(), 1);
        if (r instanceof CraftingRecipe) {
            int w = n <= 4 && !(r instanceof ShapedRecipe sr && (sr.getWidth() > 2 || sr.getHeight() > 2)) ? 2 : 3;
            TransientCraftingContainer c = new TransientCraftingContainer(new Dummy(), w, w);
            for (int i = 0; i < Math.min(n, w * w); i++) c.setItem(i, stack(t.get(i + 1)));
            return c;
        }
        SimpleContainer c = new SimpleContainer(Math.max(n, 3));
        for (int i = 0; i < n; i++) c.setItem(i, stack(t.get(i + 1)));
        return c;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    boolean matches(LuaValue in) {
        try { return ((Recipe) r).matches(container(in), level()); } catch (ClassCastException e) { return false; }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    LuaValue craft(LuaValue in) {
        Container c = container(in);
        try {
            if (!((Recipe) r).matches(c, level())) return NIL;
            ItemStack s = ((Recipe) r).assemble(c, access());
            return s.isEmpty() ? NIL : new ItemObj(s);
        } catch (ClassCastException e) { return NIL; }
    }

    LuaValue output() { ItemStack s = r.getResultItem(access()); return s.isEmpty() ? NIL : new ItemObj(s.copy()); }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Type": return valueOf(rtype());
            case "Id": return valueOf(r.getId().toString());
            case "Output": return output();
            case "Input": return inputs();
            case "Serializer": return valueOf(serializer());
            case "Category": return valueOf(category());
            case "Group": return valueOf(r.getGroup());
            case "Script": return valueOf(script);
            case "Special": return valueOf(r.isSpecial());
        }
        return super.getProp(k);
    }
    @Override public void setName(String n) { throw new LuaError("ForgeRecipe.Name is read-only"); }

    static ForgeRecipeObj F(LObj s) { return (ForgeRecipeObj) s; }
    static {
        Class<ForgeRecipeObj> C = ForgeRecipeObj.class;
        reg(C, "GetType", (s, a) -> valueOf(F(s).rtype()));
        reg(C, "GetId", (s, a) -> valueOf(F(s).r.getId().toString()));
        reg(C, "GetOutput", (s, a) -> F(s).output());
        reg(C, "GetInput", (s, a) -> F(s).inputs());
        reg(C, "Matches", (s, a) -> valueOf(F(s).matches(a.arg1())));
        reg(C, "Craft", (s, a) -> F(s).craft(a.arg1()));
        reg(C, "GetSerializer", (s, a) -> valueOf(F(s).serializer()));
        reg(C, "GetCategory", (s, a) -> valueOf(F(s).category()));
        reg(C, "GetGroup", (s, a) -> valueOf(F(s).r.getGroup()));
    }
}
