package net.idea.fluwa.forge;

import net.idea.fluwa.lua.*;
import net.minecraftforge.eventbus.api.*;
import org.luaj.vm2.*;

import java.util.*;
import java.util.function.Consumer;

/**
 * ForgeEventBus. Wraps a real Forge IEventBus (MinecraftForge.EVENT_BUS, a mod bus) and/or carries custom script events.
 * Subscribe("LivingHurtEvent", fn) — event classes are resolved by simple name ("PlayerEvent.BreakSpeed", "BlockEvent.BreakEvent",
 * "TickEvent.ServerTickEvent") or fully-qualified name. Any other name is a custom event delivered by Bus:Post.
 */
public class ForgeEventBusObj extends LObj {
    static final String[] PACKAGES = {"net.minecraftforge.event", "net.minecraftforge.event.entity", "net.minecraftforge.event.entity.player",
            "net.minecraftforge.event.entity.living", "net.minecraftforge.event.entity.item", "net.minecraftforge.event.level",
            "net.minecraftforge.event.server", "net.minecraftforge.event.village", "net.minecraftforge.event.furnace",
            "net.minecraftforge.event.brewing", "net.minecraftforge.event.enchanting", "net.minecraftforge.event.network",
            "net.minecraftforge.client.event", "net.minecraftforge.client.event.sound", "net.minecraftforge.fml.event.lifecycle",
            "net.minecraftforge.fml.event.config", "net.minecraftforge.event.entity.living.LivingEvent", "net.minecraftforge.event.entity.player.PlayerEvent",
            "net.minecraftforge.event.level.BlockEvent", "net.minecraftforge.event.TickEvent", "net.minecraftforge.event.level.LevelEvent",
            "net.minecraftforge.event.level.ChunkEvent", "net.minecraftforge.event.entity.living.LivingEntityUseItemEvent",
            "net.minecraftforge.event.entity.player.PlayerInteractEvent"};
    static final String[] PRIORITY = {"HIGHEST", "HIGH", "NORMAL", "LOW", "LOWEST"};

    final IEventBus bus;
    final String type;
    final ForgeEventBusObj parentBus;
    final ForgeService forge;
    /** listener records */
    static final class Sub { String ev; Class<? extends Event> cls; LuaValue fn; Consumer<Event> real; LuaValue owner; EventPriority pr; }
    final List<Sub> subs = new java.util.concurrent.CopyOnWriteArrayList<>();
    final Map<String, EventPriority> priorities = new HashMap<>();
    final Signal posted = new Signal("E_EventPosted"), cancelled = new Signal("E_EventCancelled"),
            added = new Signal("E_ListenerAdded"), removed = new Signal("E_ListenerRemoved");
    /** custom events of a disabled script mod are not delivered */
    java.util.function.BooleanSupplier enabled = () -> true;

    ForgeEventBusObj(ForgeService f, String name, String type, IEventBus bus, ForgeEventBusObj parent) {
        super("ForgeEventBus");
        this.forge = f; this.name = name; this.type = type; this.bus = bus; this.parentBus = parent;
        if (rt != null) rt.onClose(this::clear);
    }

    @SuppressWarnings("unchecked")
    static Class<? extends Event> resolve(String n) {
        List<String> cands = new ArrayList<>();
        cands.add(n);
        if (n.contains(".")) { int i = n.indexOf('.'); cands.add(n.substring(0, i) + "$" + n.substring(i + 1).replace('.', '$')); }
        for (String p : PACKAGES) {
            String nn = n.replace('.', '$');
            if (p.substring(p.lastIndexOf('.') + 1).matches("[A-Z].*")) { cands.add(p.substring(0, p.lastIndexOf('.')) + "." + p.substring(p.lastIndexOf('.') + 1) + "$" + nn); }
            else { cands.add(p + "." + nn); if (!nn.endsWith("Event")) cands.add(p + "." + nn + "Event"); }
        }
        for (String c : cands) {
            try {
                Class<?> k = Class.forName(c, false, ForgeEventBusObj.class.getClassLoader());
                if (Event.class.isAssignableFrom(k)) return (Class<? extends Event>) k;
            } catch (ClassNotFoundException | LinkageError ignored) {}
        }
        return null;
    }

    EventPriority prio(String ev, LuaValue v) {
        if (!v.isnil()) return parsePrio(v);
        return priorities.getOrDefault(ev, EventPriority.NORMAL);
    }
    static EventPriority parsePrio(LuaValue v) {
        if (v.isnumber()) return EventPriority.values()[Math.max(0, Math.min(4, v.toint()))];
        try { return EventPriority.valueOf(v.checkjstring().toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException e) { throw new LuaError("Priority must be HIGHEST, HIGH, NORMAL, LOW, LOWEST or 0..4"); }
    }

    Sub subscribe(String ev, LuaValue fn, LuaValue prioArg, LuaValue owner) {
        if (!fn.isfunction()) throw new LuaError("Subscribe expects a function");
        Sub s = new Sub(); s.ev = ev; s.fn = fn; s.owner = owner; s.pr = prio(ev, prioArg);
        Class<? extends Event> cls = bus == null ? null : resolve(ev);
        if (cls != null) {
            if (java.lang.reflect.Modifier.isAbstract(cls.getModifiers()))
                throw new LuaError(ev + " is abstract: subscribe to one of its concrete sub-events");
            if (GenericEvent.class.isAssignableFrom(cls)) throw new LuaError(ev + " is a generic event and can't be subscribed from Lua");
            s.cls = cls;
            FluwaRuntime r = rt;
            s.real = e -> deliver(r, s, e);
            try { bus.addListener(s.pr, true, (Class<Event>) cls, s.real); }
            catch (RuntimeException ex) { throw new LuaError("Can't subscribe to " + ev + ": " + ex.getMessage()); }
        }
        subs.add(s);
        added.fire(valueOf(ev), fn);
        return s;
    }

    void deliver(FluwaRuntime r, Sub s, Event e) {
        if (r.closed || !enabled.getAsBoolean()) return;
        if (Thread.currentThread() == r.mainThread) {
            r.within(() -> { invoke(r, s, new ForgeEventObj(e, null)); return null; });
        } else {
            // event fired on another thread (e.g. the client thread for a server script): delivered next tick, read-only
            ForgeEventObj o = r.within(() -> new ForgeEventObj(e, null));
            r.post(() -> invoke(r, s, o));
        }
    }

    void invoke(FluwaRuntime r, Sub s, ForgeEventObj o) {
        boolean before = o.canceled();
        r.callAsync(s.fn, o, "ForgeEventBus " + s.ev);
        if (posted.hasHandlers()) posted.fire(o);
        if (!before && o.canceled() && cancelled.hasHandlers()) cancelled.fire(o);
    }

    void unsubscribe(Sub s) {
        subs.remove(s);
        if (s.real != null) try { bus.unregister(s.real); } catch (RuntimeException ignored) {}
        removed.fire(valueOf(s.ev), s.fn);
    }

    public void clear() { for (Sub s : new ArrayList<>(subs)) unsubscribe(s); }

    /** Post: a ForgeEvent (re-posted on the real bus) or a custom event (name or table with Type) */
    boolean post(LuaValue v, Varargs extra) {
        if (v instanceof ForgeEventObj fe && fe.ev != null) {
            if (bus == null) throw new LuaError("This bus only carries custom events");
            return bus.post(fe.ev);
        }
        LuaTable t;
        if (v.istable()) t = (LuaTable) v;
        else { t = new LuaTable(); t.set("Type", v.checkjstring()); if (extra.narg() > 0) t.set("Args", LuaValue.listOf(new LuaValue[0], extra)); }
        ForgeEventObj o = new ForgeEventObj(null, t);
        if (!enabled.getAsBoolean()) return false;
        for (EventPriority p : EventPriority.values())
            for (Sub s : subs) if (s.cls == null && s.pr == p && s.ev.equals(o.type)) {
                if (o.canceled() && !t.get("ReceiveCanceled").toboolean()) break;
                boolean before = o.canceled();
                rt.callAsync(s.fn, LuaValue.varargsOf(o, extra), "ForgeEventBus " + s.ev);
                if (!before && o.canceled()) cancelled.fire(o);
            }
        posted.fire(o);
        return o.canceled();
    }

    List<Sub> listeners(String ev) { List<Sub> l = new ArrayList<>(); for (Sub s : subs) if (ev == null || s.ev.equals(ev)) l.add(s); return l; }

    LuaTable listenerTable(String ev) {
        LuaTable t = new LuaTable();
        for (Sub s : listeners(ev)) {
            LuaTable e = new LuaTable();
            e.set("EventType", s.ev); e.set("Callback", s.fn); e.set("Priority", s.pr.name()); e.set("Real", valueOf(s.cls != null));
            t.set(t.length() + 1, e);
        }
        return t;
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Type": return valueOf(type);
            case "Listeners": return listenerTable(null);
            case "Parent": return parentBus == null ? NIL : parentBus;
            case "Priorities": { LuaTable t = new LuaTable(); for (var e : priorities.entrySet()) t.set(e.getKey(), e.getValue().ordinal()); return t; }
            case "E_EventPosted": return posted;
            case "E_EventCancelled": return cancelled;
            case "E_ListenerAdded": return added;
            case "E_ListenerRemoved": return removed;
        }
        return super.getProp(k);
    }
    @Override public void setName(String n) { throw new LuaError("ForgeEventBus.Name is read-only"); }

    static {
        Class<ForgeEventBusObj> C = ForgeEventBusObj.class;
        reg(C, "Subscribe|On|Connect", (s, a) -> { ((ForgeEventBusObj) s).subscribe(a.checkjstring(1), a.arg(2), a.arg(3), NIL); return a.arg(2); });
        reg(C, "Unsubscribe|Off", (s, a) -> {
            ForgeEventBusObj b = (ForgeEventBusObj) s;
            int n = 0;
            for (Sub x : b.listeners(a.checkjstring(1))) if (a.isnil(2) || x.fn.raweq(a.arg(2))) { b.unsubscribe(x); n++; }
            return valueOf(n); });
        reg(C, "Post|Fire", (s, a) -> valueOf(((ForgeEventBusObj) s).post(a.arg1(), a.subargs(2))));
        reg(C, "Register", (s, a) -> {
            ForgeEventBusObj b = (ForgeEventBusObj) s;
            LuaTable t = a.checktable(1);
            int n = 0;
            for (LuaValue k = t.next(NIL).arg1(); !k.isnil(); k = t.next(k).arg1())
                if (k.isstring() && t.get(k).isfunction()) { b.subscribe(k.tojstring(), t.get(k), NIL, t); n++; }
            return valueOf(n); });
        reg(C, "Unregister", (s, a) -> {
            ForgeEventBusObj b = (ForgeEventBusObj) s;
            int n = 0;
            for (Sub x : b.listeners(null)) if (x.owner.raweq(a.arg1()) || x.fn.raweq(a.arg1())) { b.unsubscribe(x); n++; }
            return valueOf(n); });
        reg(C, "GetListeners", (s, a) -> ((ForgeEventBusObj) s).listenerTable(a.isnil(1) ? null : a.checkjstring(1)));
        reg(C, "Clear", (s, a) -> { ((ForgeEventBusObj) s).clear(); return NONE; });
        reg(C, "HasListeners", (s, a) -> valueOf(!((ForgeEventBusObj) s).listeners(a.checkjstring(1)).isEmpty()));
        reg(C, "SetPriority", (s, a) -> { ((ForgeEventBusObj) s).priorities.put(a.checkjstring(1), parsePrio(a.arg(2))); return NONE; });
        reg(C, "GetPriority", (s, a) -> valueOf(((ForgeEventBusObj) s).priorities.getOrDefault(a.checkjstring(1), EventPriority.NORMAL).ordinal()));
        reg(C, "IsRealEvent", (s, a) -> valueOf(resolve(a.checkjstring(1)) != null));
    }
}
