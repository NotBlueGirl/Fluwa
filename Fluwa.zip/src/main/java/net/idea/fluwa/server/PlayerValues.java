package net.idea.fluwa.server;

import net.idea.fluwa.api.PlayerObj;
import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.server.level.ServerPlayer;
import org.luaj.vm2.LuaValue;

import java.util.*;

/**
 * Values / folders parented to a Player on the server (Instance.new("IntValue", player), ZSpace explorer "+")
 * are replicated to that player's client, so Players.LocalPlayer.Coins.Value works in ClientScripts / UI.
 * Uses the S_ZITEM packet with the special section "Player" (the local player on the client).
 */
public final class PlayerValues implements LObj.TreeHook {
    private PlayerValues() {}
    public static final PlayerValues INSTANCE = new PlayerValues();
    public static void install() { LObj.HOOK = INSTANCE; }

    static boolean item(LObj o) { return o instanceof ValueObj || (o.className.equals("Folder") && o.getClass() == LObj.class); }

    /** owning player + path below it ("leaderstats/Coins"), or null */
    static Object[] locate(LObj o) {
        if (o == null || !item(o)) return null;
        StringBuilder sb = new StringBuilder(o.getName());
        for (LObj p = o.parent; p != null; p = p.parent) {
            if (p instanceof PlayerObj pl) return new Object[]{pl, sb.toString()};
            if (!item(p)) return null;
            sb.insert(0, p.getName() + "/");
        }
        return null;
    }

    public static String encode(ValueObj v) {
        LuaValue x = v.raw();
        return switch (v.className) {
            case "ObjValue", "ObjectValue" -> v.getRef() != null ? v.getRef() : "";
            case "TableValue" -> "";
            case "Vector3Value" -> x instanceof Vec3L p ? p.x + "," + p.y + "," + p.z : "0,0,0";
            default -> x.isnil() ? "" : x.tojstring();
        };
    }

    static void send(PlayerObj p, boolean del, String path, LObj o) {
        if (!(p.raw() instanceof ServerPlayer sp)) return;
        String cls = o == null ? "" : o instanceof ValueObj ? o.className : "Folder";
        String val = o instanceof ValueObj v ? encode(v) : "";
        FluwaNet.toPlayer(sp, new Pkt(Pkt.S_ZITEM, List.of(del ? "delete" : "save", "Player", path, cls, val), null, null));
    }

    static void sendTree(PlayerObj p, String path, LObj o) {
        send(p, false, path, o);
        for (LObj c : o.children) if (item(c)) sendTree(p, path + "/" + c.getName(), c);
    }

    // ------------------------------------------------------------------ hooks (server runtime only)
    @Override public Object before(LObj o) { return o.rt != null && o.rt.server ? locate(o) : null; }

    @Override public void after(LObj o, Object before) {
        if (o.rt == null || !o.rt.server) return;
        Object[] old = (Object[]) before, now = o.destroyed || o.parent == null ? null : locate(o);
        if (old != null && (now == null || old[0] != now[0] || !old[1].equals(now[1]))) send((PlayerObj) old[0], true, (String) old[1], null);
        if (now != null) sendTree((PlayerObj) now[0], (String) now[1], o);
    }

    @Override public void valueChanged(ValueObj v) {
        if (v.rt == null || !v.rt.server) return;
        Object[] at = locate(v);
        if (at != null) send((PlayerObj) at[0], false, (String) at[1], v);
    }

    /** "path" -> "Class\tValue" of every value of a player (sent with the client scripts on join / reload) */
    public static Map<String, String> snapshot(ServerPlayer sp) {
        Map<String, String> out = new LinkedHashMap<>();
        ServerRuntime r = ScriptManager.rt;
        if (r == null || r.closed) return out;
        PlayerObj p = r.players.get(sp.getUUID());
        if (p != null) for (LObj c : p.children) if (item(c)) collect(out, c.getName(), c);
        return out;
    }
    static void collect(Map<String, String> out, String path, LObj o) {
        out.put(path, (o instanceof ValueObj v ? v.className + "\t" + encode(v) : "Folder\t"));
        for (LObj c : o.children) if (item(c)) collect(out, path + "/" + c.getName(), c);
    }
}
