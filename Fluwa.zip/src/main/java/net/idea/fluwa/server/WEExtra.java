package net.idea.fluwa.server;

import net.idea.fluwa.api.ModelSync;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.nio.file.Files;
import java.util.*;

/**
 * v0.5.2 World Editor → Entities / Structures modes (server side).
 * Data replies: S_WEDIT {"2", kind, ...}.
 */
final class WEExtra {
    private WEExtra() {}

    static final List<String> HUMANOID = List.of("Head", "Hat", "Body", "RightArm", "LeftArm", "RightLeg", "LeftLeg");

    static void data(ServerPlayer sp, String kind, List<String> rows) {
        List<String> l = new ArrayList<>(rows.size() + 2);
        l.add("2"); l.add(kind); l.addAll(rows);
        FluwaNet.toPlayerLarge(sp, new Pkt(Pkt.S_WEDIT, l, null, null));
    }

    static Entity find(ServerPlayer sp, String uuid) {
        UUID id;
        try { id = UUID.fromString(uuid); } catch (Exception e) { throw new IllegalStateException("No entity selected"); }
        for (ServerLevel l : sp.server.getAllLevels()) { Entity e = l.getEntity(id); if (e != null) return e; }
        throw new IllegalStateException("The entity no longer exists");
    }

    static boolean humanoid(Entity e) {
        return e instanceof Player || e instanceof net.minecraft.world.entity.monster.Zombie || e instanceof net.minecraft.world.entity.monster.AbstractSkeleton
                || e instanceof net.minecraft.world.entity.decoration.ArmorStand || e instanceof net.minecraft.world.entity.monster.piglin.AbstractPiglin
                || e instanceof net.minecraft.world.entity.monster.AbstractIllager || e instanceof net.minecraft.world.entity.monster.Giant;
    }

    static List<String> parts(Entity e) {
        List<String> l = new ArrayList<>(); l.add("Model"); l.addAll(ModelSync.partNames(e));
        return l;
    }

    static String num(double d) { return d == Math.rint(d) && Math.abs(d) < 1e9 ? String.valueOf((long) d) : String.format(Locale.ROOT, "%.2f", d); }

    static void info(ServerPlayer sp, Entity e) {
        List<String> r = new ArrayList<>();
        r.add(e.getUUID().toString());
        r.add(BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString());
        r.add(e.getName().getString());
        r.add("Position\t" + num(e.getX()) + " " + num(e.getY()) + " " + num(e.getZ()));
        r.add("Yaw\t" + num(e.getYRot()));
        boolean pl = e instanceof Player;
        if (!pl) r.add("Name\t" + (e.hasCustomName() ? e.getCustomName().getString() : ""));
        if (e instanceof LivingEntity le) { r.add("Health\t" + num(le.getHealth())); r.add("MaxHealth\t" + num(le.getMaxHealth())); }
        if (e instanceof Mob mob) { r.add("NoAI\t" + mob.isNoAi()); r.add("Persistent\t" + mob.isPersistenceRequired()); }
        r.add("Glowing\t" + e.hasGlowingTag());
        if (!pl) { r.add("Invulnerable\t" + e.isInvulnerable()); r.add("Silent\t" + e.isSilent()); r.add("NoGravity\t" + e.isNoGravity()); r.add("NameVisible\t" + e.isCustomNameVisible()); }
        String md = ModelSync.get(e.getUUID());
        r.add("Model\t" + (md == null ? "" : md));
        ModelSync.Model m = ModelSync.model(e.getUUID());
        r.add("ModelScale\t" + num(m == null ? 1 : m.scale()));
        r.add("Hitbox\t" + num(e.getBbWidth()) + " " + num(e.getBbHeight()));
        for (String p : parts(e))
            r.add("#part\t" + p + "\t" + (ModelSync.hidden(e.getUUID(), p) ? 1 : 0) + "\t" + ModelSync.xfString(ModelSync.transform(e.getUUID(), p)));
        try (var st = Files.list(ModelSync.modelsDir())) {
            st.filter(f -> net.idea.fluwa.mesh.MeshLoader.supported(f.getFileName().toString())).limit(200).forEach(f -> r.add("#file\t" + f.getFileName()));
        } catch (Exception ignored) {}
        data(sp, "einfo", r);
    }

    static boolean bool(String v) { return v.trim().equalsIgnoreCase("true") || v.trim().equals("1"); }
    static double dbl(String v) { return Double.parseDouble(v.trim().replace(',', '.')); }

    static void set(Entity e, String k, String v) {
        switch (k) {
            case "Name" -> { if (e instanceof Player) throw new IllegalStateException("Player names can't be changed"); e.setCustomName(v.isBlank() ? null : Component.literal(v)); }
            case "Health" -> { if (e instanceof LivingEntity le) le.setHealth((float) Math.max(0, dbl(v))); }
            case "MaxHealth" -> { if (e instanceof LivingEntity le && le.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH) != null) { le.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH).setBaseValue(Math.max(1, dbl(v))); } }
            case "NoAI" -> { if (e instanceof Mob m) m.setNoAi(bool(v)); }
            case "Persistent" -> { if (e instanceof Mob m && bool(v)) m.setPersistenceRequired(); }
            case "Glowing" -> e.setGlowingTag(bool(v));
            case "Invulnerable" -> e.setInvulnerable(bool(v));
            case "Silent" -> e.setSilent(bool(v));
            case "NoGravity" -> e.setNoGravity(bool(v));
            case "NameVisible" -> e.setCustomNameVisible(bool(v));
            case "Yaw" -> { float y = (float) dbl(v); e.setYRot(y); e.setYHeadRot(y); if (e instanceof LivingEntity le) le.yBodyRot = y; if (e instanceof ServerPlayer p) p.connection.teleport(p.getX(), p.getY(), p.getZ(), y, p.getXRot()); }
            case "Position" -> {
                String[] p = v.trim().split("[,; ]+");
                if (p.length < 3) throw new IllegalStateException("Position: x y z");
                tp(e, dbl(p[0]), dbl(p[1]), dbl(p[2]));
            }
            case "Model" -> {
                ModelSync.Model m = ModelSync.model(e.getUUID());
                ModelSync.set(e, v.isBlank() ? null : v.trim(), m == null ? 1 : m.scale());
            }
            case "ModelScale" -> {
                String md = ModelSync.get(e.getUUID());
                if (md == null) throw new IllegalStateException("Set a Model first (file or entity id) - ModelScale scales a custom model");
                ModelSync.set(e, md, (float) Math.max(0.01, dbl(v)));
            }
            case "Hitbox" -> { // "width height", one number = cube, blank / "reset" = normal hitbox
                String t = v.trim();
                if (t.isEmpty() || t.equalsIgnoreCase("reset") || t.equalsIgnoreCase("default")) net.idea.fluwa.api.Hitbox.set(e, 0, 0);
                else {
                    String[] p = t.split("[,; x]+");
                    double w = dbl(p[0]), h = p.length > 1 ? dbl(p[1]) : w;
                    if (w < 0.05 || h < 0.05 || w > 64 || h > 64) throw new IllegalStateException("Hitbox: width height (0.05 - 64), blank = reset");
                    net.idea.fluwa.api.Hitbox.set(e, (float) w, (float) h);
                }
            }
            default -> throw new IllegalStateException("Unknown property " + k);
        }
    }

    static void tp(Entity e, double x, double y, double z) {
        if (e instanceof ServerPlayer p) p.teleportTo(x, y, z);
        else { e.teleportTo(x, y, z); e.setDeltaMovement(Vec3.ZERO); }
    }

    // ------------------------------------------------------------------ structures
    static Rotation rot(String s) {
        return switch (s) { case "90" -> Rotation.CLOCKWISE_90; case "180" -> Rotation.CLOCKWISE_180; case "270" -> Rotation.COUNTERCLOCKWISE_90; default -> Rotation.NONE; };
    }
    static Mirror mirror(String s) { return switch (s) { case "x" -> Mirror.FRONT_BACK; case "z" -> Mirror.LEFT_RIGHT; default -> Mirror.NONE; }; }

    static StructureTemplate template(ServerPlayer sp, String name) {
        ResourceLocation id = ResourceLocation.tryParse(name.contains(":") ? name : "minecraft:" + name);
        if (id == null) throw new IllegalStateException("Bad structure name " + name);
        return sp.server.getStructureManager().get(id).orElseThrow(() -> new IllegalStateException("Structure " + id + " not found"));
    }

    /** places with undo; returns the bounding box {min, max} */
    static BlockPos[] place(ServerPlayer sp, WorldEditor.Session s, StructureTemplate t, BlockPos at, Rotation r, Mirror m, boolean ents) {
        ServerLevel l = sp.serverLevel();
        StructurePlaceSettings st = new StructurePlaceSettings().setRotation(r).setMirror(m).setIgnoreEntities(!ents);
        var bb = t.getBoundingBox(st, at);
        long vol = (long) bb.getXSpan() * bb.getYSpan() * bb.getZSpan();
        if (vol > net.idea.fluwa.Config.maxBlocksPerCall) throw new IllegalStateException("Structure is too big: " + vol + " blocks (maxBlocksPerCall)");
        LinkedHashMap<BlockPos, BlockState> before = new LinkedHashMap<>(), after = new LinkedHashMap<>();
        BlockPos mn = new BlockPos(bb.minX(), bb.minY(), bb.minZ()), mx = new BlockPos(bb.maxX(), bb.maxY(), bb.maxZ());
        for (BlockPos q : BlockPos.betweenClosed(mn, mx)) before.put(q.immutable(), l.getBlockState(q));
        t.placeInWorld(l, at, at, st, l.random, 2);
        for (BlockPos q : before.keySet()) after.put(q, l.getBlockState(q));
        before.entrySet().removeIf(en -> en.getValue() == after.get(en.getKey()));
        after.keySet().retainAll(before.keySet());
        if (!before.isEmpty()) {
            s.undo.addLast(new WorldEditor.Change(l, before, after));
            while (s.undo.size() > 40) s.undo.pollFirst();
            s.redo.clear();
        }
        return new BlockPos[]{mn, mx};
    }

    /** @return message, or null if op is not an Entities / Structures op */
    static String run(String op, Pkt p, ServerPlayer sp, WorldEditor.Session s) {
        ServerLevel l = sp.serverLevel();
        switch (op) {
            // ---------------------------------------------------------------- entities
            case "etypes" -> {
                List<String> r = new ArrayList<>();
                for (var t : BuiltInRegistries.ENTITY_TYPE) if (t.canSummon() && t != EntityType.PLAYER) r.add(BuiltInRegistries.ENTITY_TYPE.getKey(t).toString());
                Collections.sort(r);
                data(sp, "etypes", r);
                return "";
            }
            case "espawn" -> {
                String type = p.s(1).trim();
                EntityType<?> t = EntityType.byString(type.contains(":") ? type : "minecraft:" + type).orElseThrow(() -> new IllegalStateException("Unknown entity type " + type));
                Entity e = t.create(l);
                if (e == null) throw new IllegalStateException(type + " can't be spawned");
                e.moveTo(p.n(0) + 0.5, p.n(1), p.n(2) + 0.5, sp.getYRot() + 180, 0);
                if (e instanceof Mob m) m.finalizeSpawn(l, l.getCurrentDifficultyAt(e.blockPosition()), MobSpawnType.COMMAND, null, null);
                if (!l.tryAddFreshEntityWithPassengers(e)) throw new IllegalStateException("Can't add " + type + " (duplicate UUID?)");
                info(sp, e);
                return "Spawned " + type.replace("minecraft:", "");
            }
            case "einfo" -> { info(sp, find(sp, p.s(1))); return ""; }
            case "eset" -> {
                Entity e = find(sp, p.s(1));
                String[] kv = p.s(2).split("=", 2);
                set(e, kv[0], kv.length > 1 ? kv[1] : "");
                info(sp, e);
                return kv[0] + " = " + (kv.length > 1 ? kv[1] : "");
            }
            case "epart" -> { // s2 = part \t hidden \t xf
                Entity e = find(sp, p.s(1));
                String[] a = p.s(2).split("\t", -1);
                if (a.length >= 2 && !a[1].isEmpty()) ModelSync.setHidden(e.getUUID(), a[0], a[1].equals("1"));
                if (a.length >= 3) ModelSync.setTransform(e.getUUID(), a[0], ModelSync.parseXf(a[2]));
                info(sp, e);
                return "";
            }
            case "emove" -> {
                Entity e = find(sp, p.s(1));
                tp(e, p.n(0) + 0.5, p.n(1), p.n(2) + 0.5);
                info(sp, e);
                return "Moved " + e.getName().getString();
            }
            case "ehere" -> {
                Entity e = find(sp, p.s(1));
                tp(e, sp.getX(), sp.getY(), sp.getZ());
                info(sp, e);
                return "Moved to you";
            }
            case "edel" -> {
                Entity e = find(sp, p.s(1));
                if (e instanceof Player) throw new IllegalStateException("Players can't be removed");
                String n = e.getName().getString();
                e.discard();
                return "Removed " + n;
            }
            case "edup" -> {
                Entity e = find(sp, p.s(1));
                if (e instanceof Player) throw new IllegalStateException("Players can't be duplicated");
                CompoundTag tag = new CompoundTag();
                if (!e.save(tag)) throw new IllegalStateException("This entity can't be copied");
                tag.remove("UUID"); tag.remove("Passengers");
                Entity c = EntityType.loadEntityRecursive(tag, l, x -> x);
                if (c == null) throw new IllegalStateException("Copy failed");
                c.setUUID(UUID.randomUUID());
                c.moveTo(e.getX() + 1, e.getY(), e.getZ(), e.getYRot(), e.getXRot());
                l.addFreshEntity(c);
                String md = ModelSync.get(e.getUUID());
                if (md != null) ModelSync.set(c, md, ModelSync.model(e.getUUID()).scale());
                info(sp, c);
                return "Duplicated " + e.getName().getString();
            }
            case "enear" -> { // list of entities within radius (for the editor list)
                int r = Math.max(4, Math.min(128, p.n(0)));
                List<String> rows = new ArrayList<>();
                List<Entity> es = l.getEntities((Entity) null, new AABB(sp.blockPosition()).inflate(r), x -> x != sp);
                es.sort(Comparator.comparingDouble(x -> x.distanceToSqr(sp)));
                for (Entity e : es.subList(0, Math.min(80, es.size())))
                    rows.add(e.getUUID() + "\t" + BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath() + "\t" + e.getName().getString() + "\t" + num(Math.sqrt(e.distanceToSqr(sp))));
                data(sp, "enear", rows);
                return "";
            }
            // ---------------------------------------------------------------- structures
            case "slist" -> {
                List<String> r = new ArrayList<>();
                sp.server.getStructureManager().listTemplates().forEach(id -> r.add(id.toString()));
                Collections.sort(r, Comparator.comparing((String x) -> x.startsWith("minecraft:") ? 1 : 0).thenComparing(x -> x));
                data(sp, "slist", r);
                return "";
            }
            case "sinfo" -> {
                StructureTemplate t = template(sp, p.s(1));
                var sz = t.getSize();
                data(sp, "sinfo", List.of(p.s(1), sz.getX() + "", sz.getY() + "", sz.getZ() + ""));
                return "";
            }
            case "splace", "sload" -> {
                StructureTemplate t = template(sp, p.s(1));
                String[] o = (p.s(2) + "|||").split("\\|", -1);
                BlockPos at = new BlockPos(p.n(0), p.n(1), p.n(2));
                BlockPos[] bb = place(sp, s, t, at, rot(o[0]), mirror(o[1]), !o[2].equals("0"));
                data(sp, "sbox", List.of(bb[0].getX() + "", bb[0].getY() + "", bb[0].getZ() + "", bb[1].getX() + "", bb[1].getY() + "", bb[1].getZ() + "", op));
                return (op.equals("sload") ? "Loaded " : "Placed ") + p.s(1) + (op.equals("sload") ? " for editing - change it, then Save selection with the same name" : "");
            }
            case "ssave" -> {
                BlockPos[] b = WorldEditor.box(p, 0);
                ResourceLocation id = ResourceLocation.tryParse(p.s(1).contains(":") ? p.s(1).trim() : "fluwa:" + p.s(1).trim());
                if (id == null || p.s(1).isBlank()) throw new IllegalStateException("Enter a structure name (letters, digits, _ / -)");
                var mgr = sp.server.getStructureManager();
                StructureTemplate t = mgr.getOrCreate(id);
                net.minecraft.core.Vec3i size = new net.minecraft.core.Vec3i(b[1].getX() - b[0].getX() + 1, b[1].getY() - b[0].getY() + 1, b[1].getZ() - b[0].getZ() + 1);
                t.fillFromWorld(l, b[0], size, !p.s(2).equals("0"), Blocks.STRUCTURE_VOID);
                boolean ok = mgr.save(id);
                if (!ok) throw new IllegalStateException("Can't save " + id);
                return "Saved structure " + id + " (" + size.getX() + "×" + size.getY() + "×" + size.getZ() + ")";
            }
        }
        return null;
    }
}
