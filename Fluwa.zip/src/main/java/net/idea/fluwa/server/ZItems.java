package net.idea.fluwa.server;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.idea.fluwa.lua.ItemTree;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.server.level.ServerPlayer;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Storage of ZSpace items: folders are directories, values are "<name>.fval" JSON files
 * in <world>/fluwa/<Section>/ (Workspace items in <world>/fluwa/Workspace/).
 */
public final class ZItems {
    private ZItems() {}
    public static final String[] SECTIONS = {"Workspace", "UI", "InitScripts", "ServerScripts", "ClientScripts"};
    static final Set<String> SERVER = Set.of("Workspace", "InitScripts", "ServerScripts");
    static final Set<String> CLIENT = Set.of("Workspace", "InitScripts", "UI", "ClientScripts");

    static Path dir(String section) {
        if (!Arrays.asList(SECTIONS).contains(section)) throw new IllegalArgumentException("Unknown section " + section);
        return ScriptManager.root.resolve(section);
    }

    static Path path(String section, String p, boolean value) {
        String clean = p.replace('\\', '/');
        if (clean.isBlank() || clean.contains("..") || clean.startsWith("/") || !clean.matches("[\\w\\-./ ]+")) throw new IllegalArgumentException("Bad name: " + p);
        Path base = dir(section);
        Path r = base.resolve(value ? clean + ".fval" : clean).normalize();
        if (!r.startsWith(base) || r.equals(base)) throw new IllegalArgumentException("Bad name");
        return r;
    }

    /** path -> "Class\tValue" of every folder and value in a section */
    public static Map<String, String> read(String section) {
        Map<String, String> out = new TreeMap<>();
        if (ScriptManager.root == null) return out;
        Path base = dir(section);
        if (!Files.isDirectory(base)) return out;
        try (Stream<Path> st = Files.walk(base)) {
            st.sorted().forEach(p -> {
                if (p.equals(base)) return;
                String rel = base.relativize(p).toString().replace('\\', '/');
                if (Files.isDirectory(p)) out.put(rel, "Folder\t");
                else if (rel.endsWith(".fval")) {
                    try {
                        JsonObject o = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8)).getAsJsonObject();
                        out.put(rel.substring(0, rel.length() - 5), o.get("Class").getAsString() + "\t" + (o.has("Value") ? o.get("Value").getAsString() : ""));
                    } catch (Exception ignored) {}
                }
            });
        } catch (IOException ignored) {}
        return out;
    }

    /** "#Section", path, "Class\tValue" triplets (sent with scripts) */
    public static void append(List<String> s, Collection<String> sections) {
        for (String sec : sections) for (var e : read(sec).entrySet()) { s.add("#" + sec); s.add(e.getKey()); s.add(e.getValue()); }
    }

    public static void save(String section, String p, String cls, String value) throws IOException {
        if (!ItemTree.isItemClass(cls)) throw new IllegalArgumentException("Unknown item class " + cls);
        if (cls.equals("Folder")) { Files.createDirectories(path(section, p, false)); return; }
        Path f = path(section, p, true);
        Files.createDirectories(f.getParent());
        JsonObject o = new JsonObject();
        o.addProperty("Class", cls);
        o.addProperty("Value", value);
        Files.writeString(f, o.toString(), StandardCharsets.UTF_8);
    }

    /** @return true if a folder was removed (scripts inside may have been deleted) */
    public static boolean delete(String section, String p) throws IOException {
        Path v = path(section, p, true);
        if (Files.deleteIfExists(v)) return false;
        Path d = path(section, p, false);
        if (!Files.isDirectory(d)) return false;
        try (Stream<Path> st = Files.walk(d)) {
            for (Path x : st.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(x);
        }
        return true;
    }

    public static void rename(String section, String p, String np) throws IOException {
        Path v = path(section, p, true);
        if (Files.exists(v)) { Path nv = path(section, np, true); Files.createDirectories(nv.getParent()); Files.move(v, nv); return; }
        Path d = path(section, p, false), nd = path(section, np, false);
        if (!Files.isDirectory(d)) throw new IllegalArgumentException(p + " does not exist");
        if (Files.exists(nd)) throw new IllegalArgumentException(np + " already exists");
        Files.createDirectories(nd.getParent());
        Files.move(d, nd);
    }

    static void live(String section, String path, String cls, String value, boolean remove) {
        ServerRuntime rt = ScriptManager.rt;
        if (rt != null && !rt.closed && SERVER.contains(section)) rt.within(() -> {
            var root = ItemTree.root(rt, section);
            if (remove) ItemTree.remove(root, path); else ItemTree.apply(root, path, cls, value);
            return null;
        });
        if (CLIENT.contains(section)) FluwaNet.toAll(new Pkt(Pkt.S_ZITEM, List.of(remove ? "delete" : "save", section, path, cls, value), null, null));
    }

    /** C_ZITEM: save(section, path, class, value [, oldPath]) | delete(section, path) | rename(section, path, newPath) */
    public static void handle(Pkt p, ServerPlayer sp) {
        String op = p.s(0), sec = p.s(1), path = p.s(2).trim();
        String who = sp.getGameProfile().getName();
        try {
            String done;
            switch (op) {
                case "save" -> {
                    String old = p.s(5).trim();
                    if (!old.isEmpty() && !old.equals(path)) { delete(sec, old); live(sec, old, "", "", true); }
                    save(sec, path, p.s(3), p.s(4));
                    live(sec, path, p.s(3), p.s(4), false);
                    done = "Saved " + p.s(3) + " " + sec + "/" + path;
                }
                case "delete" -> {
                    boolean folder = delete(sec, path);
                    live(sec, path, "", "", true);
                    if (folder) ScriptManager.reload();
                    done = "Deleted " + sec + "/" + path;
                }
                case "rename" -> {
                    String np = p.s(3).trim();
                    rename(sec, path, np);
                    ScriptManager.reload();
                    done = "Renamed " + sec + "/" + path + " → " + np;
                }
                default -> throw new IllegalArgumentException("Unknown item operation " + op);
            }
            ScriptManager.log(0, who + ": " + done);
            FluwaNet.toPlayer(sp, new Pkt(Pkt.S_ZSTATUS, "1", done));
            if (!op.equals("save")) ScriptManager.openZSpace(sp);
        } catch (Exception e) {
            FluwaNet.toPlayer(sp, new Pkt(Pkt.S_ZSTATUS, "0", String.valueOf(e.getMessage())));
        }
    }
}
