package net.idea.fluwa.server;

import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.QuartPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.flat.FlatLevelGeneratorSettings;
import net.minecraft.world.level.storage.LevelResource;

import java.nio.file.*;
import java.util.*;

/**
 * Backend of ZSpace → Tools → Terrain DK (replaces the old TerrainGenerator service).
 * Edits / creates dimensions, biomes and world generation types (noise settings) in the world datapack
 * "fluwa_generated" and computes previews (biome + height maps) with the real Minecraft generators.
 * Kinds: D = dimension, B = biome, G = generation type (noise settings).
 */
public final class TerrainDK {
    private TerrainDK() {}
    static final String PACK = "fluwa_generated";
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // ------------------------------------------------------------------ fields helper
    record F(Map<String, String> m) {
        String s(String k, String d) { String v = m.get(k); return v == null || v.isBlank() ? d : v.trim(); }
        boolean b(String k, boolean d) { String v = m.get(k); return v == null || v.isBlank() ? d : v.trim().equalsIgnoreCase("true") || v.trim().equals("1"); }
        double n(String k, double d) { try { return Double.parseDouble(s(k, String.valueOf(d)).replace(',', '.')); } catch (NumberFormatException e) { return d; } }
        int i(String k, int d) { return (int) Math.round(n(k, d)); }
        boolean has(String k) { String v = m.get(k); return v != null && !v.isBlank(); }
    }

    static MinecraftServer srv() { return ScriptManager.server; }
    static Path pack() { return srv().getWorldPath(LevelResource.DATAPACK_DIR).resolve(PACK); }
    static RegistryOps<JsonElement> ops() { return RegistryOps.create(JsonOps.INSTANCE, srv().registryAccess()); }

    static String[] id(String n) {
        String id = n.toLowerCase(Locale.ROOT).trim();
        if (!id.contains(":")) id = "fluwa:" + id;
        if (!id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")) throw new IllegalArgumentException("Bad name '" + n + "' (use a-z 0-9 _ . - /)");
        return id.split(":", 2);
    }
    static String full(String n) { String[] i = id(n); return i[0] + ":" + i[1]; }
    static String mc(String s) { return s.contains(":") ? s : "minecraft:" + s; }

    static Path file(String kind, String n) {
        String[] i = id(n);
        String dir = switch (kind) { case "D" -> "dimension"; case "T" -> "dimension_type"; case "B" -> "worldgen/biome"; case "G" -> "worldgen/noise_settings"; case "P" -> "worldgen/world_preset"; default -> throw new IllegalArgumentException(kind); };
        return pack().resolve("data/" + i[0] + "/" + dir + "/" + i[1] + ".json");
    }

    static JsonObject readJson(Path p) {
        try { return Files.exists(p) ? JsonParser.parseString(Files.readString(p)).getAsJsonObject() : null; } catch (Exception e) { return null; }
    }
    static void writeJson(Path p, JsonElement e) throws java.io.IOException {
        Files.createDirectories(p.getParent());
        Files.writeString(p, GSON.toJson(e));
    }
    static void ensurePack() throws java.io.IOException {
        Path mc = pack().resolve("pack.mcmeta");
        if (Files.exists(mc)) return;
        JsonObject o = new JsonObject(), pk = new JsonObject();
        pk.addProperty("pack_format", 15);
        pk.addProperty("description", "Dimensions, biomes and generation types made with Fluwa Terrain DK");
        o.add("pack", pk);
        writeJson(mc, o);
    }

    // ------------------------------------------------------------------ list
    static List<String> list() {
        var ra = srv().registryAccess();
        List<String> out = new ArrayList<>();
        out.add("list");
        Set<String> loaded = new TreeSet<>();
        for (ServerLevel l : srv().getAllLevels()) loaded.add(l.dimension().location().toString());
        Set<String> gen = generated("dimension");
        Set<String> all = new TreeSet<>(loaded); all.addAll(gen);
        for (String d : all) out.add("D\t" + d + "\t" + (loaded.contains(d) ? gen.contains(d) ? "loaded · edited" : "loaded" : "after restart"));
        Set<String> gb = generated("worldgen/biome");
        Set<String> biomes = new TreeSet<>(); ra.registryOrThrow(Registries.BIOME).keySet().forEach(k -> biomes.add(k.toString())); biomes.addAll(gb);
        for (String b : biomes) out.add("B\t" + b + "\t" + (gb.contains(b) ? "custom" : ""));
        Set<String> gg = generated("worldgen/noise_settings");
        Set<String> gts = new TreeSet<>(); ra.registryOrThrow(Registries.NOISE_SETTINGS).keySet().forEach(k -> gts.add(k.toString())); gts.addAll(gg);
        for (String g : gts) out.add("G\t" + g + "\t" + (gg.contains(g) ? "custom" : ""));
        return out;
    }

    static Set<String> generated(String dir) {
        Set<String> out = new TreeSet<>();
        Path data = pack().resolve("data");
        if (!Files.isDirectory(data)) return out;
        try (var ns = Files.list(data)) {
            for (Path n : ns.toList()) {
                Path d = n.resolve(dir);
                if (!Files.isDirectory(d)) continue;
                try (var st = Files.walk(d)) {
                    st.filter(p -> p.toString().endsWith(".json")).forEach(p -> out.add(n.getFileName() + ":" + d.relativize(p).toString().replace('\\', '/').replaceAll("\\.json$", "")));
                }
            }
        } catch (java.io.IOException ignored) {}
        return out;
    }

    // ------------------------------------------------------------------ load fields
    static LinkedHashMap<String, String> load(String kind, String n) {
        return switch (kind) { case "D" -> loadDim(n); case "B" -> loadBiome(n); case "G" -> loadGen(n); default -> new LinkedHashMap<>(); };
    }

    /** IntProvider json -> "7" / "0-7" */
    static String intRange(JsonElement e) {
        if (e.isJsonPrimitive()) return e.getAsString();
        JsonObject o = e.getAsJsonObject();
        JsonObject v = o.has("value") && o.get("value").isJsonObject() ? o.getAsJsonObject("value") : o;
        if (v.has("min_inclusive") && v.has("max_inclusive")) {
            String a = v.get("min_inclusive").getAsString(), b = v.get("max_inclusive").getAsString();
            return a.equals(b) ? a : a + "-" + b;
        }
        if (o.has("value") && o.get("value").isJsonPrimitive()) return o.get("value").getAsString();
        return GSON.toJson(e).replaceAll("\\s+", "");
    }
    /** "7" / "0-7" -> IntProvider json (encoded with the real codec) */
    static JsonElement intProvider(String s, int lo, int hi) {
        s = s == null ? "" : s.trim();
        net.minecraft.util.valueproviders.IntProvider p;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(-?\\d+)\\s*(?:-|\\.\\.|to)\\s*(-?\\d+)").matcher(s);
        if (m.matches()) {
            int a = Math.max(lo, Math.min(hi, Integer.parseInt(m.group(1)))), b = Math.max(lo, Math.min(hi, Integer.parseInt(m.group(2))));
            p = net.minecraft.util.valueproviders.UniformInt.of(Math.min(a, b), Math.max(a, b));
        } else {
            int v; try { v = s.isEmpty() ? 0 : Integer.parseInt(s); } catch (NumberFormatException e) { throw new IllegalArgumentException("MonsterSpawnLight: use a number (7) or a range (0-7)"); }
            p = net.minecraft.util.valueproviders.ConstantInt.of(Math.max(lo, Math.min(hi, v)));
        }
        return net.minecraft.util.valueproviders.IntProvider.CODEC.encodeStart(JsonOps.INSTANCE, p).getOrThrow(false, e -> {});
    }

    static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }
    static int col(String s, int d) {
        try { s = s.trim().replace("#", "").replace("0x", ""); return s.isEmpty() ? d : Integer.parseInt(s, 16); } catch (Exception e) { return d; }
    }

    static LinkedHashMap<String, String> loadDim(String n) {
        String id = full(n);
        LinkedHashMap<String, String> f = new LinkedHashMap<>();
        JsonObject dim = readJson(file("D", id));
        ServerLevel lvl = null;
        for (ServerLevel l : srv().getAllLevels()) if (l.dimension().location().toString().equals(id)) lvl = l;
        JsonObject gen = null; JsonObject type = null;
        if (dim == null && lvl == null) lvl = srv().overworld(); // new dimension: start from the overworld settings
        if (dim != null) {
            gen = dim.getAsJsonObject("generator");
            if (dim.get("type").isJsonPrimitive()) { type = readJson(file("T", dim.get("type").getAsString())); f.put("DimensionType", dim.get("type").getAsString()); }
            else type = dim.getAsJsonObject("type");
        } else if (lvl != null) {
            gen = ChunkGenerator.CODEC.encodeStart(ops(), lvl.getChunkSource().getGenerator()).result().map(JsonElement::getAsJsonObject).orElse(null);
            type = DimensionType.DIRECT_CODEC.encodeStart(ops(), lvl.dimensionType()).result().map(JsonElement::getAsJsonObject).orElse(null);
            lvl.dimensionTypeRegistration().unwrapKey().ifPresent(k -> f.put("DimensionType", k.location().toString()));
        }
        // generator
        String gt = gen == null ? "minecraft:noise" : gen.get("type").getAsString();
        if (gt.endsWith("flat")) {
            JsonObject st = gen.getAsJsonObject("settings");
            String biome = st.has("biome") ? st.get("biome").getAsString() : "minecraft:plains";
            f.put("Type", biome.equals("minecraft:the_void") && (!st.has("layers") || st.getAsJsonArray("layers").isEmpty()) ? "void" : "flat");
            StringBuilder ls = new StringBuilder();
            if (st.has("layers")) for (JsonElement e : st.getAsJsonArray("layers")) {
                JsonObject o = e.getAsJsonObject();
                if (ls.length() > 0) ls.append(", ");
                ls.append(o.get("block").getAsString().replace("minecraft:", "")).append(':').append(o.get("height").getAsInt());
            }
            f.put("Layers", ls.toString());
            f.put("Biome", biome);
            f.put("Features", String.valueOf(st.has("features") && st.get("features").getAsBoolean()));
            f.put("Lakes", String.valueOf(st.has("lakes") && st.get("lakes").getAsBoolean()));
            List<String> so = new ArrayList<>();
            if (st.has("structure_overrides")) {
                JsonElement x = st.get("structure_overrides");
                if (x.isJsonArray()) for (JsonElement e : x.getAsJsonArray()) so.add(e.getAsString().replace("minecraft:", ""));
                else if (x.isJsonPrimitive()) so.add(x.getAsString());
            }
            f.put("Structures", String.join(", ", so));
        } else if (gt.endsWith("noise")) {
            f.put("Type", "noise");
            JsonElement s = gen.get("settings");
            f.put("Preset", s.isJsonPrimitive() ? s.getAsString() : "minecraft:overworld");
            JsonObject bs = gen.getAsJsonObject("biome_source");
            String bt = bs == null ? "minecraft:multi_noise" : bs.get("type").getAsString();
            f.put("BiomeSource", bt.replace("minecraft:", ""));
            if (bs != null && bs.has("biome")) f.put("Biome", bs.get("biome").getAsString());
            if (bs != null && bs.has("biomes") && bs.get("biomes").isJsonArray()) {
                List<String> l = new ArrayList<>(); for (JsonElement e : bs.getAsJsonArray("biomes")) l.add(e.getAsString()); f.put("Biome", String.join(", ", l));
            }
            if (bs != null && bs.has("scale")) f.put("CheckerboardScale", bs.get("scale").getAsString());
            if (bs != null && bs.has("preset")) f.put("BiomePreset", bs.get("preset").getAsString());
            else if (bt.endsWith("multi_noise")) f.put("BiomePreset", id.equals("minecraft:the_nether") ? "minecraft:nether" : "minecraft:overworld");
        } else f.put("Type", gt);
        if (!f.containsKey("Layers")) f.put("Layers", "");
        if (!f.containsKey("Biome")) f.put("Biome", "");
        for (String k : new String[]{"Lakes", "Structures", "CheckerboardScale"}) f.putIfAbsent(k, "");
        // dimension type
        if (type != null) {
            f.put("MinY", type.get("min_y").getAsString());
            f.put("Height", type.get("height").getAsString());
            f.put("LogicalHeight", type.get("logical_height").getAsString());
            f.put("HasSkylight", type.get("has_skylight").getAsString());
            f.put("HasCeiling", type.get("has_ceiling").getAsString());
            f.put("Ultrawarm", type.get("ultrawarm").getAsString());
            f.put("Natural", type.get("natural").getAsString());
            f.put("AmbientLight", type.get("ambient_light").getAsString());
            f.put("FixedTime", type.has("fixed_time") ? type.get("fixed_time").getAsString() : "");
            f.put("Effects", type.get("effects").getAsString());
            f.put("CoordinateScale", type.get("coordinate_scale").getAsString());
            f.put("BedWorks", type.get("bed_works").getAsString());
            f.put("RespawnAnchorWorks", type.get("respawn_anchor_works").getAsString());
            f.put("HasRaids", type.get("has_raids").getAsString());
            f.put("PiglinSafe", type.get("piglin_safe").getAsString());
            f.put("Infiniburn", type.has("infiniburn") ? type.get("infiniburn").getAsString() : "#minecraft:infiniburn_overworld");
            f.put("MonsterSpawnLight", type.has("monster_spawn_light_level") ? intRange(type.get("monster_spawn_light_level")) : "0");
            f.put("MonsterSpawnBlockLight", type.has("monster_spawn_block_light_limit") ? type.get("monster_spawn_block_light_limit").getAsString() : "0");
        }
        return f;
    }

    static JsonObject encodeBiome(String id) {
        var reg = srv().registryAccess().registryOrThrow(Registries.BIOME);
        Biome b = reg.get(new ResourceLocation(id));
        if (b == null) return null;
        return Biome.DIRECT_CODEC.encodeStart(ops(), b).result().map(JsonElement::getAsJsonObject).orElse(null);
    }

    static LinkedHashMap<String, String> loadBiome(String n) {
        String id = full(n);
        LinkedHashMap<String, String> f = new LinkedHashMap<>();
        JsonObject b = readJson(file("B", id));
        if (b == null) b = encodeBiome(id);
        if (b == null) b = encodeBiome("minecraft:plains");
        f.put("CopyFrom", "");
        f.put("Temperature", b.get("temperature").getAsString());
        f.put("Downfall", b.get("downfall").getAsString());
        f.put("HasPrecipitation", b.get("has_precipitation").getAsString());
        f.put("TemperatureModifier", b.has("temperature_modifier") ? b.get("temperature_modifier").getAsString() : "none");
        JsonObject e = b.getAsJsonObject("effects");
        for (String[] k : new String[][]{{"SkyColor", "sky_color"}, {"FogColor", "fog_color"}, {"WaterColor", "water_color"}, {"WaterFogColor", "water_fog_color"}, {"GrassColor", "grass_color"}, {"FoliageColor", "foliage_color"}})
            f.put(k[0], e.has(k[1]) ? hex(e.get(k[1]).getAsInt()) : "");
        f.put("GrassColorModifier", e.has("grass_color_modifier") ? e.get("grass_color_modifier").getAsString() : "none");
        JsonObject mu = e.has("music") ? e.getAsJsonObject("music") : null;
        f.put("Music", mu != null ? snd(mu.get("sound")) : "");
        f.put("MusicMinDelay", mu != null && mu.has("min_delay") ? mu.get("min_delay").getAsString() : "12000");
        f.put("MusicMaxDelay", mu != null && mu.has("max_delay") ? mu.get("max_delay").getAsString() : "24000");
        f.put("ReplaceMusic", String.valueOf(mu != null && mu.has("replace_current_music") && mu.get("replace_current_music").getAsBoolean()));
        f.put("AmbientSound", e.has("ambient_sound") ? snd(e.get("ambient_sound")) : "");
        f.put("MoodSound", e.has("mood_sound") ? snd(e.getAsJsonObject("mood_sound").get("sound")) : "");
        JsonObject ad = e.has("additions_sound") ? e.getAsJsonObject("additions_sound") : null;
        f.put("AdditionsSound", ad != null ? snd(ad.get("sound")) : "");
        f.put("AdditionsChance", ad != null && ad.has("tick_chance") ? ad.get("tick_chance").getAsString() : "0.0111");
        JsonObject pa = e.has("particle") ? e.getAsJsonObject("particle") : null;
        f.put("Particle", pa != null ? pa.getAsJsonObject("options").get("type").getAsString() : "");
        f.put("ParticleProbability", pa != null ? pa.get("probability").getAsString() : "0.01");
        f.put("CreatureSpawnProbability", b.has("creature_spawn_probability") ? b.get("creature_spawn_probability").getAsString() : "0.1");
        JsonObject sp = b.has("spawners") ? b.getAsJsonObject("spawners") : new JsonObject();
        for (String[] c : SPAWN_CATS) {
            List<String> l = new ArrayList<>();
            if (sp.has(c[1])) for (JsonElement x : sp.getAsJsonArray(c[1])) {
                JsonObject o = x.getAsJsonObject();
                l.add(o.get("type").getAsString().replace("minecraft:", "") + "*" + o.get("weight").getAsInt() + "(" + o.get("minCount").getAsInt() + "-" + o.get("maxCount").getAsInt() + ")");
            }
            f.put(c[0], String.join(", ", l));
        }
        f.put("Carvers", String.join(", ", carvers(b)));
        f.put("AddFeatures", "");
        f.put("RemoveFeatures", "");
        return f;
    }

    static final String[][] SPAWN_CATS = {{"SpawnMonster", "monster"}, {"SpawnCreature", "creature"}, {"SpawnAmbient", "ambient"}, {"SpawnWaterCreature", "water_creature"},
            {"SpawnWaterAmbient", "water_ambient"}, {"SpawnUndergroundWater", "underground_water_creature"}, {"SpawnAxolotls", "axolotls"}, {"SpawnMisc", "misc"}};
    static final String[] STEPS = {"raw_generation", "lakes", "local_modifications", "underground_structures", "surface_structures", "strongholds",
            "underground_ores", "underground_decoration", "fluid_springs", "vegetal_decoration", "top_layer_modification"};

    /** sound json (id string or {sound_id}) -> id */
    static String snd(JsonElement e) {
        if (e == null || e.isJsonNull()) return "";
        if (e.isJsonPrimitive()) return e.getAsString();
        JsonObject o = e.getAsJsonObject();
        return o.has("sound_id") ? o.get("sound_id").getAsString() : "";
    }

    static List<String> carvers(JsonObject b) {
        List<String> l = new ArrayList<>();
        if (!b.has("carvers")) return l;
        JsonElement c = b.get("carvers");
        if (c.isJsonObject()) { for (var en : c.getAsJsonObject().entrySet()) addIds(l, en.getValue()); }
        else addIds(l, c);
        return l;
    }
    static void addIds(List<String> l, JsonElement e) {
        if (e.isJsonArray()) for (JsonElement x : e.getAsJsonArray()) { if (x.isJsonPrimitive()) l.add(x.getAsString().replace("minecraft:", "")); }
        else if (e.isJsonPrimitive()) l.add(e.getAsString().replace("minecraft:", ""));
    }

    /** "zombie*95(4-4), skeleton*100(2-4), minecraft:creeper" -> spawner list */
    static JsonArray spawners(String cat, String s) {
        JsonArray a = new JsonArray();
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("([a-z0-9_.:/-]+)\\s*(?:\\*\\s*(\\d+))?\\s*(?:\\(\\s*(\\d+)\\s*(?:-\\s*(\\d+))?\\s*\\))?");
        for (String part : s.split(",")) {
            part = part.trim().toLowerCase(Locale.ROOT);
            if (part.isEmpty()) continue;
            var m = p.matcher(part);
            if (!m.matches()) throw new IllegalArgumentException(cat + ": bad entry '" + part + "' (use mob*weight(min-max), e.g. zombie*95(4-4))");
            String id = mc(m.group(1));
            if (!srv().registryAccess().registryOrThrow(Registries.ENTITY_TYPE).containsKey(new ResourceLocation(id))) throw new IllegalArgumentException(cat + ": unknown entity " + id);
            int w = m.group(2) == null ? 10 : Integer.parseInt(m.group(2));
            int mn = m.group(3) == null ? 1 : Integer.parseInt(m.group(3)), mx = m.group(4) == null ? mn : Integer.parseInt(m.group(4));
            JsonObject o = new JsonObject();
            o.addProperty("type", id); o.addProperty("weight", Math.max(1, w));
            o.addProperty("minCount", Math.max(1, Math.min(mn, mx))); o.addProperty("maxCount", Math.max(1, Math.max(mn, mx)));
            a.add(o);
        }
        return a;
    }

    static JsonObject soundObj(String key, String id) {
        JsonObject o = new JsonObject(); o.addProperty(key, mc(id)); return o;
    }

    static JsonObject encodeGen(String id) {
        var reg = srv().registryAccess().registryOrThrow(Registries.NOISE_SETTINGS);
        NoiseGeneratorSettings s = reg.get(new ResourceLocation(id));
        if (s == null) return null;
        return NoiseGeneratorSettings.DIRECT_CODEC.encodeStart(ops(), s).result().map(JsonElement::getAsJsonObject).orElse(null);
    }

    static LinkedHashMap<String, String> loadGen(String n) {
        String id = full(n);
        LinkedHashMap<String, String> f = new LinkedHashMap<>();
        JsonObject g = readJson(file("G", id));
        if (g == null) g = encodeGen(id);
        if (g == null) g = encodeGen("minecraft:overworld");
        f.put("CopyFrom", "");
        f.put("SeaLevel", g.get("sea_level").getAsString());
        f.put("DefaultBlock", g.getAsJsonObject("default_block").get("Name").getAsString());
        f.put("DefaultFluid", g.getAsJsonObject("default_fluid").get("Name").getAsString());
        JsonObject no = g.getAsJsonObject("noise");
        f.put("MinY", no.get("min_y").getAsString());
        f.put("Height", no.get("height").getAsString());
        f.put("SizeHorizontal", no.get("size_horizontal").getAsString());
        f.put("SizeVertical", no.get("size_vertical").getAsString());
        f.put("AquifersEnabled", g.get("aquifers_enabled").getAsString());
        f.put("OreVeinsEnabled", g.get("ore_veins_enabled").getAsString());
        f.put("DisableMobGeneration", g.get("disable_mob_generation").getAsString());
        f.put("LegacyRandomSource", g.get("legacy_random_source").getAsString());
        f.put("WorldPreset", String.valueOf(Files.exists(file("P", id))));
        JsonObject nr = g.getAsJsonObject("noise_router");
        JsonElement fd = nr == null ? null : nr.get("final_density");
        f.put("DensityOffset", fd != null && fd.isJsonObject() && isOffset(fd.getAsJsonObject()) ? fd.getAsJsonObject().get("argument2").getAsString() : "0");
        JsonArray seq = surfaceSeq(g);
        String sb = "", ub = "";
        int fi = seq == null ? -1 : surfaceIdx(seq);
        if (fi >= 0) {
            String[] v = seq.get(fi).getAsJsonObject().get("fluwa_surface").getAsString().split("\\|", -1);
            sb = v[0]; ub = v.length > 1 ? v[1] : "";
        }
        f.put("SurfaceBlock", sb); f.put("UnderSurfaceBlock", ub);
        f.put("BedrockFloor", String.valueOf(seq != null && findRule(seq, "minecraft:bedrock_floor") >= 0));
        f.put("BedrockRoof", String.valueOf(seq != null && findRule(seq, "minecraft:bedrock_roof") >= 0));
        return f;
    }

    static boolean isOffset(JsonObject o) {
        return o.has("type") && o.get("type").getAsString().endsWith("add") && o.has("argument2") && o.get("argument2").isJsonPrimitive() && o.get("argument2").getAsJsonPrimitive().isNumber();
    }

    /** top-level sequence of the surface rule (wrapping a single rule into a sequence) */
    static JsonArray surfaceSeq(JsonObject g) {
        JsonElement sr = g.get("surface_rule");
        if (sr == null || !sr.isJsonObject()) return null;
        JsonObject o = sr.getAsJsonObject();
        if (o.get("type").getAsString().endsWith("sequence")) return o.getAsJsonArray("sequence");
        JsonObject w = new JsonObject(); w.addProperty("type", "minecraft:sequence");
        JsonArray a = new JsonArray(); a.add(o); w.add("sequence", a);
        g.add("surface_rule", w);
        return a;
    }
    /** index of the rule added by SurfaceBlock / UnderSurfaceBlock (marked "fluwa_surface") or -1 */
    static int surfaceIdx(JsonArray seq) {
        for (int i = 0; i < seq.size(); i++) if (seq.get(i).isJsonObject() && seq.get(i).getAsJsonObject().has("fluwa_surface")) return i;
        return -1;
    }
    static int findRule(JsonArray seq, String randomName) {
        for (int i = 0; i < seq.size(); i++) if (seq.get(i).toString().contains("\"" + randomName + "\"")) return i;
        return -1;
    }
    static JsonObject blockRule(String block) {
        JsonObject r = new JsonObject(), st = new JsonObject();
        r.addProperty("type", "minecraft:block"); st.addProperty("Name", mc(block)); r.add("result_state", st);
        return r;
    }
    static JsonObject cond(JsonObject ifTrue, JsonObject then) {
        JsonObject c = new JsonObject(); c.addProperty("type", "minecraft:condition"); c.add("if_true", ifTrue); c.add("then_run", then); return c;
    }
    static JsonObject stoneDepth(boolean addSurfaceDepth) {
        JsonObject o = new JsonObject();
        o.addProperty("type", "minecraft:stone_depth"); o.addProperty("offset", 0); o.addProperty("surface_type", "floor");
        o.addProperty("add_surface_depth", addSurfaceDepth); o.addProperty("secondary_depth_range", 0);
        return o;
    }
    static JsonObject gradient(String name, boolean floor) {
        JsonObject v = new JsonObject(); v.addProperty("type", "minecraft:vertical_gradient"); v.addProperty("random_name", name);
        JsonObject a = new JsonObject(), b = new JsonObject();
        if (floor) { a.addProperty("above_bottom", 0); b.addProperty("above_bottom", 5); }
        else { a.addProperty("below_top", 5); b.addProperty("below_top", 0); }
        v.add("true_at_and_below", a); v.add("false_at_and_above", b);
        if (floor) return v;
        JsonObject not = new JsonObject(); not.addProperty("type", "minecraft:not"); not.add("invert", v);
        return not;
    }

    /** DensityOffset, SurfaceBlock / UnderSurfaceBlock, BedrockFloor / BedrockRoof */
    static void genExtras(JsonObject g, F f) {
        JsonObject nr = g.getAsJsonObject("noise_router");
        if (nr != null && nr.has("final_density")) {
            JsonElement fd = nr.get("final_density");
            if (fd.isJsonObject() && isOffset(fd.getAsJsonObject())) fd = fd.getAsJsonObject().get("argument1");
            double off = f.n("DensityOffset", 0);
            if (off != 0) {
                JsonObject add = new JsonObject(); add.addProperty("type", "minecraft:add"); add.add("argument1", fd); add.addProperty("argument2", off);
                fd = add;
            }
            nr.add("final_density", fd);
        }
        JsonArray seq = surfaceSeq(g);
        if (seq == null) return;
        for (int fi; (fi = surfaceIdx(seq)) >= 0; ) seq.remove(fi);
        if (f.has("SurfaceBlock") || f.has("UnderSurfaceBlock")) {
            JsonArray inner = new JsonArray();
            if (f.has("SurfaceBlock")) {
                JsonObject water = new JsonObject();
                water.addProperty("type", "minecraft:water"); water.addProperty("offset", -1); water.addProperty("surface_depth_multiplier", 0); water.addProperty("add_stone_depth", false);
                inner.add(cond(stoneDepth(false), cond(water, blockRule(f.s("SurfaceBlock", "grass_block")))));
            }
            if (f.has("UnderSurfaceBlock")) inner.add(cond(stoneDepth(true), blockRule(f.s("UnderSurfaceBlock", "dirt"))));
            JsonObject sq = new JsonObject(); sq.addProperty("type", "minecraft:sequence"); sq.add("sequence", inner);
            JsonObject above = new JsonObject(); above.addProperty("type", "minecraft:above_preliminary_surface");
            JsonObject rule = cond(above, sq);
            rule.addProperty("fluwa_surface", f.s("SurfaceBlock", "") + "|" + f.s("UnderSurfaceBlock", ""));
            for (String b : new String[]{f.s("SurfaceBlock", "grass_block"), f.s("UnderSurfaceBlock", "dirt")})
                if (!srv().registryAccess().registryOrThrow(Registries.BLOCK).containsKey(new ResourceLocation(mc(b)))) throw new IllegalArgumentException("Unknown block " + b);
            // keep bedrock rules first so they still win
            int at = 0;
            while (at < seq.size() && (seq.get(at).toString().contains("bedrock_floor") || seq.get(at).toString().contains("bedrock_roof"))) at++;
            JsonArray n = new JsonArray();
            for (int i = 0; i < seq.size(); i++) { if (i == at) n.add(rule); n.add(seq.get(i)); }
            if (at >= seq.size()) n.add(rule);
            while (seq.size() > 0) seq.remove(0);
            seq.addAll(n);
        }
        for (String[] bd : new String[][]{{"BedrockFloor", "minecraft:bedrock_floor"}, {"BedrockRoof", "minecraft:bedrock_roof"}}) {
            if (!f.m().containsKey(bd[0])) continue;
            boolean want = f.b(bd[0], false);
            int i = findRule(seq, bd[1]);
            if (!want) { while ((i = findRule(seq, bd[1])) >= 0) seq.remove(i); }
            else if (i < 0) {
                JsonArray n = new JsonArray();
                n.add(cond(gradient(bd[1], bd[0].equals("BedrockFloor")), blockRule("bedrock")));
                n.addAll(seq);
                while (seq.size() > 0) seq.remove(0);
                seq.addAll(n);
            }
        }
    }

    // ------------------------------------------------------------------ build JSON
    static JsonObject generator(F f) {
        String type = f.s("Type", "noise").toLowerCase(Locale.ROOT);
        JsonObject g = new JsonObject();
        switch (type) {
            case "flat", "void" -> {
                g.addProperty("type", "minecraft:flat");
                JsonObject st = new JsonObject();
                st.addProperty("biome", mc(f.s("Biome", type.equals("void") ? "the_void" : "plains")));
                st.addProperty("lakes", f.b("Lakes", false));
                st.addProperty("features", f.b("Features", false));
                JsonArray layers = new JsonArray();
                String ls = type.equals("void") ? "" : f.s("Layers", "bedrock:1, dirt:2, grass_block:1");
                for (String part : ls.split("[,;\\n]+")) {
                    part = part.trim();
                    if (part.isEmpty()) continue;
                    int c = part.lastIndexOf(':'), h = 1;
                    String blk = part;
                    if (c > 0 && part.substring(c + 1).matches("\\d+")) { h = Integer.parseInt(part.substring(c + 1)); blk = part.substring(0, c); }
                    else if (part.contains("*")) { String[] x = part.split("\\*"); blk = x[0].trim(); h = Integer.parseInt(x[1].trim()); }
                    JsonObject o = new JsonObject(); o.addProperty("block", mc(blk)); o.addProperty("height", h); layers.add(o);
                }
                st.add("layers", layers);
                JsonArray so = new JsonArray();
                for (String x : f.s("Structures", "").split("[,; ]+")) if (!x.isBlank()) so.add(mc(x.trim()));
                st.add("structure_overrides", so);
                g.add("settings", st);
            }
            case "noise" -> {
                g.addProperty("type", "minecraft:noise");
                g.addProperty("settings", mc(f.s("Preset", "overworld")));
                JsonObject bs = new JsonObject();
                String src = f.s("BiomeSource", f.has("Biome") ? "fixed" : "multi_noise").toLowerCase(Locale.ROOT).replace("minecraft:", "");
                switch (src) {
                    case "fixed" -> { bs.addProperty("type", "minecraft:fixed"); bs.addProperty("biome", mc(f.s("Biome", "plains"))); }
                    case "the_end", "end" -> bs.addProperty("type", "minecraft:the_end");
                    case "checkerboard" -> {
                        bs.addProperty("type", "minecraft:checkerboard");
                        JsonArray arr = new JsonArray();
                        for (String b : f.s("Biome", "plains, desert").split("[,; ]+")) if (!b.isBlank()) arr.add(mc(b));
                        bs.add("biomes", arr); bs.addProperty("scale", Math.max(0, Math.min(62, f.i("CheckerboardScale", 2))));
                    }
                    default -> { bs.addProperty("type", "minecraft:multi_noise"); bs.addProperty("preset", mc(f.s("BiomePreset", "overworld"))); }
                }
                g.add("biome_source", bs);
            }
            default -> throw new IllegalArgumentException("Unknown generation Type '" + type + "' (noise, flat, void)");
        }
        return g;
    }

    static JsonObject dimType(F f) {
        JsonObject t = new JsonObject();
        boolean nether = f.s("Preset", "").endsWith("nether");
        t.addProperty("ultrawarm", f.b("Ultrawarm", nether));
        t.addProperty("natural", f.b("Natural", !nether));
        t.addProperty("piglin_safe", f.b("PiglinSafe", nether));
        t.addProperty("respawn_anchor_works", f.b("RespawnAnchorWorks", nether));
        t.addProperty("bed_works", f.b("BedWorks", !nether));
        t.addProperty("has_raids", f.b("HasRaids", !nether));
        t.addProperty("has_skylight", f.b("HasSkylight", !nether));
        t.addProperty("has_ceiling", f.b("HasCeiling", nether));
        t.addProperty("coordinate_scale", f.n("CoordinateScale", nether ? 8 : 1));
        t.addProperty("ambient_light", f.n("AmbientLight", nether ? 0.1 : 0));
        if (f.has("FixedTime")) t.addProperty("fixed_time", (long) f.n("FixedTime", 6000));
        int minY = f.i("MinY", nether ? 0 : -64), height = f.i("Height", nether ? 256 : 384);
        if (minY % 16 != 0 || height % 16 != 0 || height < 16 || height > 4064) throw new IllegalArgumentException("MinY and Height must be multiples of 16 (Height 16..4064)");
        t.addProperty("min_y", minY);
        t.addProperty("height", height);
        t.addProperty("logical_height", Math.min(height, f.i("LogicalHeight", height)));
        t.addProperty("effects", mc(f.s("Effects", nether ? "the_nether" : "overworld")));
        String inf = f.s("Infiniburn", nether ? "#minecraft:infiniburn_nether" : "#minecraft:infiniburn_overworld");
        if (!inf.startsWith("#")) inf = "#" + inf;
        t.addProperty("infiniburn", inf.contains(":") ? inf : "#minecraft:" + inf.substring(1));
        t.add("monster_spawn_light_level", intProvider(f.s("MonsterSpawnLight", "0"), 0, 15));
        t.addProperty("monster_spawn_block_light_limit", Math.max(0, Math.min(15, f.i("MonsterSpawnBlockLight", 0))));
        return t;
    }

    static JsonObject biome(String id, F f) {
        JsonObject b = f.has("CopyFrom") ? encodeBiome(full(f.s("CopyFrom", "plains").contains(":") ? f.s("CopyFrom", "") : "minecraft:" + f.s("CopyFrom", ""))) : null;
        if (b == null) b = readJson(file("B", id));
        if (b == null) b = encodeBiome(id);
        if (b == null) b = encodeBiome("minecraft:plains");
        b.addProperty("temperature", (float) f.n("Temperature", 0.8));
        b.addProperty("downfall", (float) f.n("Downfall", 0.4));
        b.addProperty("has_precipitation", f.b("HasPrecipitation", true));
        String tm = f.s("TemperatureModifier", "none");
        if (tm.equals("none")) b.remove("temperature_modifier"); else b.addProperty("temperature_modifier", tm);
        JsonObject e = b.getAsJsonObject("effects");
        for (String[] k : new String[][]{{"SkyColor", "sky_color"}, {"FogColor", "fog_color"}, {"WaterColor", "water_color"}, {"WaterFogColor", "water_fog_color"}, {"GrassColor", "grass_color"}, {"FoliageColor", "foliage_color"}}) {
            if (f.has(k[0])) e.addProperty(k[1], col(f.s(k[0], ""), 0)); else if (!k[1].startsWith("grass") && !k[1].startsWith("foliage")) { if (!e.has(k[1])) e.addProperty(k[1], 0x7BA4FF); } else e.remove(k[1]);
        }
        if (f.has("Music")) {
            JsonObject m = new JsonObject();
            int a = Math.max(0, f.i("MusicMinDelay", 12000)), z = Math.max(a, f.i("MusicMaxDelay", 24000));
            m.addProperty("sound", mc(f.s("Music", ""))); m.addProperty("min_delay", a); m.addProperty("max_delay", z); m.addProperty("replace_current_music", f.b("ReplaceMusic", false));
            e.add("music", m);
        } else e.remove("music");
        String gm = f.s("GrassColorModifier", "none").toLowerCase(Locale.ROOT);
        if (gm.equals("none")) e.remove("grass_color_modifier"); else e.addProperty("grass_color_modifier", gm);
        if (f.has("AmbientSound")) e.addProperty("ambient_sound", mc(f.s("AmbientSound", ""))); else e.remove("ambient_sound");
        if (f.has("MoodSound")) {
            JsonObject m = new JsonObject(); m.addProperty("sound", mc(f.s("MoodSound", ""))); m.addProperty("tick_delay", 6000); m.addProperty("block_search_extent", 8); m.addProperty("offset", 2.0);
            e.add("mood_sound", m);
        } else e.remove("mood_sound");
        if (f.has("AdditionsSound")) {
            JsonObject m = new JsonObject(); m.addProperty("sound", mc(f.s("AdditionsSound", ""))); m.addProperty("tick_chance", Math.max(0, Math.min(1, f.n("AdditionsChance", 0.0111))));
            e.add("additions_sound", m);
        } else e.remove("additions_sound");
        if (f.has("Particle")) {
            JsonObject m = new JsonObject(), op = new JsonObject(); op.addProperty("type", mc(f.s("Particle", "")));
            m.add("options", op); m.addProperty("probability", (float) Math.max(0, Math.min(1, f.n("ParticleProbability", 0.01))));
            e.add("particle", m);
        } else e.remove("particle");
        b.addProperty("creature_spawn_probability", (float) Math.max(0, Math.min(0.9999, f.n("CreatureSpawnProbability", 0.1))));
        JsonObject sp = b.has("spawners") ? b.getAsJsonObject("spawners") : new JsonObject();
        for (String[] c : SPAWN_CATS) if (f.m().containsKey(c[0])) sp.add(c[1], spawners(c[0], f.s(c[0], "")));
        b.add("spawners", sp);
        if (!b.has("spawn_costs")) b.add("spawn_costs", new JsonObject());
        if (f.m().containsKey("Carvers")) {
            JsonArray air = new JsonArray();
            for (String x : f.s("Carvers", "").split("[,; ]+")) if (!x.isBlank()) air.add(mc(x.trim()));
            JsonObject cv = new JsonObject(); cv.add("air", air);
            b.add("carvers", cv);
        }
        // features: 11 generation steps of placed feature ids
        JsonArray steps = b.has("features") ? b.getAsJsonArray("features") : new JsonArray();
        while (steps.size() < STEPS.length) steps.add(new JsonArray());
        if (f.has("RemoveFeatures")) {
            Set<String> rm = new HashSet<>();
            for (String x : f.s("RemoveFeatures", "").split("[,; ]+")) if (!x.isBlank()) rm.add(mc(x.trim()));
            for (JsonElement st : steps) if (st.isJsonArray()) {
                JsonArray keep = new JsonArray();
                for (JsonElement x : st.getAsJsonArray()) if (!(x.isJsonPrimitive() && rm.contains(x.getAsString()))) keep.add(x);
                JsonArray arr = st.getAsJsonArray(); while (arr.size() > 0) arr.remove(0); arr.addAll(keep);
            }
        }
        if (f.has("AddFeatures")) {
            for (String x : f.s("AddFeatures", "").split("[,; ]+")) {
                x = x.trim(); if (x.isEmpty()) continue;
                int step = 9; String fid = x;
                int at = x.indexOf('@');
                if (at > 0) {
                    String st = x.substring(at + 1); fid = x.substring(0, at);
                    step = Arrays.asList(STEPS).indexOf(st);
                    if (step < 0) throw new IllegalArgumentException("AddFeatures: unknown step '" + st + "' (" + String.join(", ", STEPS) + ")");
                }
                fid = mc(fid);
                if (!srv().registryAccess().registryOrThrow(Registries.PLACED_FEATURE).containsKey(new ResourceLocation(fid))) throw new IllegalArgumentException("AddFeatures: unknown placed feature " + fid);
                if (!steps.get(step).isJsonArray()) throw new IllegalArgumentException("AddFeatures: step " + STEPS[step] + " uses a tag here and can't be edited");
                JsonArray arr = steps.get(step).getAsJsonArray();
                boolean dup = false; for (JsonElement y : arr) if (y.isJsonPrimitive() && y.getAsString().equals(fid)) dup = true;
                if (!dup) arr.add(fid);
            }
        }
        b.add("features", steps);
        return b;
    }

    static JsonObject gen(String id, F f) {
        JsonObject g = f.has("CopyFrom") ? encodeGen(mc(f.s("CopyFrom", "overworld"))) : null;
        if (g == null) g = readJson(file("G", id));
        if (g == null) g = encodeGen(id);
        if (g == null) g = encodeGen("minecraft:overworld");
        g.addProperty("sea_level", f.i("SeaLevel", 63));
        JsonObject db = new JsonObject(); db.addProperty("Name", mc(f.s("DefaultBlock", "stone"))); g.add("default_block", db);
        JsonObject df = new JsonObject(); df.addProperty("Name", mc(f.s("DefaultFluid", "water")));
        JsonObject pr = new JsonObject(); pr.addProperty("level", "0"); df.add("Properties", pr); g.add("default_fluid", df);
        JsonObject no = g.getAsJsonObject("noise");
        int minY = f.i("MinY", -64), h = f.i("Height", 384);
        if (minY % 16 != 0 || h % 16 != 0) throw new IllegalArgumentException("MinY and Height must be multiples of 16");
        no.addProperty("min_y", minY); no.addProperty("height", h);
        no.addProperty("size_horizontal", Math.max(1, Math.min(4, f.i("SizeHorizontal", 1))));
        no.addProperty("size_vertical", Math.max(1, Math.min(4, f.i("SizeVertical", 2))));
        g.addProperty("aquifers_enabled", f.b("AquifersEnabled", true));
        g.addProperty("ore_veins_enabled", f.b("OreVeinsEnabled", true));
        g.addProperty("disable_mob_generation", f.b("DisableMobGeneration", false));
        g.addProperty("legacy_random_source", f.b("LegacyRandomSource", false));
        genExtras(g, f);
        return g;
    }

    // ------------------------------------------------------------------ validation
    /** decode with the real Minecraft codec, so a bad field is reported here instead of breaking the world on restart */
    static <T> void validate(String what, com.mojang.serialization.Codec<T> codec, JsonElement json) {
        var r = codec.parse(ops(), json);
        r.error().ifPresent(e -> { throw new IllegalArgumentException("Invalid " + what + ": " + e.message()); });
    }

    /** generator json whose "settings" points at a custom, not yet loaded, generation type: inline it */
    static JsonObject inlineSettings(JsonObject genJson) {
        if (genJson.has("settings") && genJson.get("settings").isJsonPrimitive()) {
            String pid = genJson.get("settings").getAsString();
            if (!srv().registryAccess().registryOrThrow(Registries.NOISE_SETTINGS).containsKey(new ResourceLocation(pid))) {
                JsonObject inl = readJson(file("G", pid));
                if (inl == null) throw new IllegalArgumentException("Unknown generation type " + pid);
                genJson.add("settings", inl);
            }
        }
        return genJson;
    }

    // ------------------------------------------------------------------ save / delete
    static String save(String kind, String n, Map<String, String> m) throws Exception {
        String id = full(n); String[] ip = id(n);
        F f = new F(m);
        ensurePack();
        switch (kind) {
            case "D" -> {
                JsonObject dim = new JsonObject();
                String typeRef = f.s("DimensionType", "");
                boolean ownType = typeRef.isEmpty() || typeRef.equals(id) || !srv().registryAccess().registryOrThrow(Registries.DIMENSION_TYPE).containsKey(new ResourceLocation(mc(typeRef)));
                JsonObject gj = generator(f), tj = null;
                validate("generator", ChunkGenerator.CODEC, inlineSettings(gj.deepCopy()));
                if (ownType || f.has("MinY")) {
                    dim.addProperty("type", id);
                    tj = dimType(f);
                    validate("dimension type", DimensionType.DIRECT_CODEC, tj);
                } else dim.addProperty("type", mc(typeRef));
                if (tj != null) writeJson(file("T", id), tj);
                dim.add("generator", gj);
                writeJson(file("D", id), dim);
                return "Saved dimension " + id + " — restart the world/server to apply";
            }
            case "B" -> { JsonObject bj = biome(id, f); validate("biome", Biome.DIRECT_CODEC, bj); writeJson(file("B", id), bj); return "Saved biome " + id + " — restart the world/server to apply"; }
            case "G" -> {
                JsonObject gj = gen(id, f);
                validate("generation type", NoiseGeneratorSettings.DIRECT_CODEC, gj);
                writeJson(file("G", id), gj);
                Path wp = file("P", id);
                if (f.b("WorldPreset", false)) {
                    JsonObject p = new JsonObject(), dims = new JsonObject();
                    JsonObject ow = new JsonObject(); ow.addProperty("type", "minecraft:overworld");
                    JsonObject g = new JsonObject(); g.addProperty("type", "minecraft:noise"); g.addProperty("settings", id);
                    JsonObject bs = new JsonObject(); bs.addProperty("type", "minecraft:multi_noise"); bs.addProperty("preset", "minecraft:overworld");
                    g.add("biome_source", bs); ow.add("generator", g);
                    dims.add("minecraft:overworld", ow);
                    p.add("dimensions", dims);
                    writeJson(wp, p);
                    JsonObject tag = new JsonObject(); tag.addProperty("replace", false);
                    JsonArray vals = new JsonArray(); vals.add(id); tag.add("values", vals);
                    writeJson(pack().resolve("data/minecraft/tags/worldgen/world_preset/normal.json"), tag);
                } else Files.deleteIfExists(wp);
                return "Saved generation type " + id + " (" + ip[1] + ") — use it as Preset of a dimension; restart to apply";
            }
            default -> throw new IllegalArgumentException("Unknown kind " + kind);
        }
    }

    static String delete(String kind, String n) throws Exception {
        String id = full(n);
        boolean any = false;
        switch (kind) {
            case "D" -> { any |= Files.deleteIfExists(file("D", id)); any |= Files.deleteIfExists(file("T", id)); }
            case "B" -> any |= Files.deleteIfExists(file("B", id));
            case "G" -> { any |= Files.deleteIfExists(file("G", id)); any |= Files.deleteIfExists(file("P", id)); }
            default -> {}
        }
        return any ? "Deleted " + id + " from the datapack (restart to apply)" : id + " is not in the Fluwa datapack (built-in objects can't be deleted)";
    }

    // ------------------------------------------------------------------ preview
    /** biome + height map around the player, computed off-thread with a real generator built from the fields */
    static void preview(ServerPlayer sp, String kind, String n, Map<String, String> m, int zoom) throws Exception {
        F f = new F(m);
        JsonObject genJson;
        int minY, height;
        if (kind.equals("G")) {
            JsonObject g = gen(full(n), f);
            genJson = new JsonObject();
            genJson.addProperty("type", "minecraft:noise");
            genJson.add("settings", g);
            JsonObject bs = new JsonObject(); bs.addProperty("type", "minecraft:multi_noise"); bs.addProperty("preset", "minecraft:overworld");
            genJson.add("biome_source", bs);
            minY = f.i("MinY", -64); height = f.i("Height", 384);
        } else {
            // a custom generation type that is not loaded yet: inline it from the datapack
            genJson = inlineSettings(generator(f));
            minY = f.i("MinY", -64); height = f.i("Height", 384);
        }
        ChunkGenerator gen = ChunkGenerator.CODEC.parse(ops(), genJson).getOrThrow(false, e -> {});
        ServerLevel ow = srv().overworld();
        long seed = ow.getSeed();
        RandomState rs = gen instanceof NoiseBasedChunkGenerator nb
                ? RandomState.create(nb.generatorSettings().value(), srv().registryAccess().lookupOrThrow(Registries.NOISE), seed)
                : ow.getChunkSource().randomState();
        int sea = gen instanceof NoiseBasedChunkGenerator nb2 ? nb2.generatorSettings().value().seaLevel() : Integer.MIN_VALUE;
        LevelHeightAccessor ha = LevelHeightAccessor.create(minY, height);
        int N = 64, step = Math.max(1, Math.min(64, zoom));
        int cx = sp.blockPosition().getX(), cz = sp.blockPosition().getZ();
        Thread t = new Thread(() -> {
            List<String> pal = new ArrayList<>();
            Map<String, Integer> pi = new HashMap<>();
            byte[] out = new byte[N * N * 4];
            String err = null;
            try {
                for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
                    int x = cx + (i - N / 2) * step, z = cz + (j - N / 2) * step;
                    int h = gen.getBaseHeight(x, z, Heightmap.Types.OCEAN_FLOOR_WG, ha, rs);
                    var bh = gen.getBiomeSource().getNoiseBiome(QuartPos.fromBlock(x), QuartPos.fromBlock(Math.max(minY, Math.min(minY + height - 1, Math.max(h, sea)))), QuartPos.fromBlock(z), rs.sampler());
                    String bid = bh.unwrapKey().map(k -> k.location().toString()).orElse("?");
                    Integer idx = pi.get(bid);
                    if (idx == null) { idx = pal.size(); pi.put(bid, idx); pal.add(bid + "\t" + biomeColor(bid, bh.value())); }
                    int o = (j * N + i) * 4;
                    out[o] = (byte) (int) idx;
                    out[o + 1] = (byte) (h >> 8); out[o + 2] = (byte) h;
                    out[o + 3] = (byte) (sea != Integer.MIN_VALUE && h < sea ? 1 : 0);
                }
            } catch (Throwable e) { err = e.toString(); }
            String ferr = err;
            srv().execute(() -> {
                List<String> s = new ArrayList<>();
                s.add("preview"); s.add(ferr == null ? "" : ferr); s.add(String.valueOf(N)); s.add(String.valueOf(step));
                s.add(String.valueOf(minY)); s.add(String.valueOf(minY + height)); s.add(String.valueOf(sea == Integer.MIN_VALUE ? minY : sea));
                s.addAll(pal);
                FluwaNet.toPlayerLarge(sp, new Pkt(Pkt.S_TDK, s, null, out));
            });
        }, "Fluwa TerrainDK preview");
        t.setDaemon(true);
        t.start();
    }

    /** rough map colour of a biome (server side: the client colormaps are not available) */
    static int biomeColor(String id, Biome b) {
        var fx = b.getSpecialEffects();
        if (fx.getGrassColorOverride().isPresent()) return fx.getGrassColorOverride().get();
        String p = id.toLowerCase(Locale.ROOT);
        if (p.contains("ocean") || p.contains("river")) return fx.getWaterColor();
        if (p.contains("badlands") || p.contains("mesa")) return 0xC0662F;
        if (p.contains("desert") || p.contains("beach")) return 0xDBCF91;
        if (p.contains("nether") || p.contains("crimson") || p.contains("warped") || p.contains("basalt") || p.contains("soul")) return fx.getFogColor();
        if (p.contains("end")) return 0xDCDCA0;
        if (p.contains("void")) return 0x101018;
        float t = b.getBaseTemperature();
        if (t < 0.15f || p.contains("snow") || p.contains("frozen") || p.contains("ice")) return 0xEEF3F8;
        float d = Math.max(0, Math.min(1, b.getModifiedClimateSettings().downfall()));
        float tt = Math.max(0, Math.min(1, t / 2));
        int dry = 0xBDB25F, wet = 0x3E8F2A, cold = 0x6E9C6C;
        int base = lerp(dry, wet, d);
        return tt < 0.35f ? lerp(cold, base, tt / 0.35f) : base;
    }
    static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return r << 16 | g << 8 | bl;
    }

    // ------------------------------------------------------------------ network
    static Map<String, String> fields(Pkt p, int from) {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        for (int i = from; i + 1 < p.s.size(); i += 2) m.put(p.s.get(i), p.s.get(i + 1));
        return m;
    }

    static void reply(ServerPlayer sp, List<String> s) { FluwaNet.toPlayerLarge(sp, new Pkt(Pkt.S_TDK, s, null, null)); }
    static void msg(ServerPlayer sp, boolean ok, String m) { reply(sp, List.of("msg", ok ? "1" : "0", m)); }

    public static void handle(Pkt p, ServerPlayer sp) {
        if (srv() == null) return;
        try {
            switch (p.s(0)) {
                case "list" -> reply(sp, list());
                case "load" -> {
                    List<String> s = new ArrayList<>(List.of("fields", p.s(1), full(p.s(2))));
                    load(p.s(1), p.s(2)).forEach((k, v) -> { s.add(k); s.add(v); });
                    reply(sp, s);
                }
                case "save" -> { msg(sp, true, save(p.s(1), p.s(2), fields(p, 3))); ScriptManager.log(0, sp.getGameProfile().getName() + " (Terrain DK) saved " + p.s(1) + " " + full(p.s(2))); reply(sp, list()); }
                case "delete" -> { msg(sp, true, delete(p.s(1), p.s(2))); reply(sp, list()); }
                case "preview" -> preview(sp, p.s(1), p.s(2), fields(p, 3), p.n(0) <= 0 ? 4 : p.n(0));
                case "biome" -> { // paint biome in the current world (runtime, like /fillbiome)
                    var src = srv().createCommandSourceStack().withLevel(sp.serverLevel()).withSuppressedOutput().withPermission(4);
                    int r = Math.max(1, Math.min(128, p.n(0)));
                    var b = sp.blockPosition();
                    int ok = srv().getCommands().performPrefixedCommand(src, String.format("fillbiome %d %d %d %d %d %d %s",
                            b.getX() - r, sp.serverLevel().getMinBuildHeight(), b.getZ() - r, b.getX() + r, sp.serverLevel().getMaxBuildHeight() - 1, b.getZ() + r, full(p.s(1))));
                    msg(sp, ok > 0, ok > 0 ? "Biome " + full(p.s(1)) + " painted around you (radius " + r + ")" : "Biome paint failed (volume too large or unknown biome)");
                }
                default -> msg(sp, false, "Unknown Terrain DK action " + p.s(0));
            }
        } catch (Exception e) { msg(sp, false, "Error: " + e.getMessage()); }
    }

    @SuppressWarnings("unused") static FlatLevelGeneratorSettings unusedFlat() { return null; }
}
