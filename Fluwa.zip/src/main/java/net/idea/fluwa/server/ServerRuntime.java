package net.idea.fluwa.server;

import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.luaj.vm2.*;

import java.util.*;

public class ServerRuntime extends GameRuntime {
    public final MinecraftServer srv;
    private final NetBridge bridge = new NetBridge() {
        public void fireServer(String e, LuaValue a) { throw new LuaError("Event:FireServer is only Client-Side"); }
        public void firePlayer(LObj p, String e, int kind, LuaValue a) {
            ServerPlayer sp = (ServerPlayer) LObj.checkObj(p, PlayerObj.class).p();
            FluwaNet.toPlayer(sp, new Pkt(Pkt.S_REMOTE, List.of(e), new int[]{kind}, LuaSer.encode(a)));
        }
        public void fireAllPlayers(String e, LuaValue a) { FluwaNet.toAll(new Pkt(Pkt.S_REMOTE, List.of(e), new int[]{0}, LuaSer.encode(a))); }
        public void fireRadius(String e, LuaValue a, double r, Vec3L c, LObj dim) {
            byte[] data = LuaSer.encode(a);
            for (ServerPlayer p : srv.getPlayerList().getPlayers()) {
                if (dim instanceof DimensionObj d && p.level().dimension() != d.key) continue;
                if (p.position().distanceTo(c.mc()) <= r) FluwaNet.toPlayer(p, new Pkt(Pkt.S_REMOTE, List.of(e), new int[]{1}, data));
            }
        }
    };

    public ServerRuntime(MinecraftServer s) { super(true); srv = s; }

    @Override protected void setupGlobals() {
        world = new WorldObj();
        LObj game = new GameObj(this);
        g.set("game", game);
        g.set("World", world);
        g.set("Workspace", world);
        g.set("workspace", world);
        g.set("Players", world.players);
        g.set("Lighting", world.lighting);
        g.set("Terrain", world.terrain);
        g.set("Dimension", wrap(srv.overworld()));
        g.set("IsServer", LuaValue.TRUE);
        ItemTree.root(this, "InitScripts"); ItemTree.root(this, "ServerScripts");
        g.set("IsClient", LuaValue.FALSE);
        factory.put("Entity", () -> new EntityObj((net.minecraft.world.entity.Entity) null));
        factory.put("Block", BlockObj::new);
        factory.put("Item", () -> new ItemObj(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.STONE)));
        factory.put("Structure", StructureObj::new);
        for (String ui : new String[]{"ScreenGUI", "ScreenGui", "Overlay", "Frame", "Button", "TextButton", "ImageButton", "Image", "ImageLabel", "AnimImage", "TextLabel", "TextBox",
                "ScrollingFrame", "UIListLayout", "UIGridLayout", "UIPadding", "UICorner", "UIStroke", "UIGradient", "ViewportFrame", "VideoFrame", "CanvasGroup"})
            factory.put(ui, () -> { throw new LuaError(ui + " is a client object: create it in ClientScripts or UI (this code runs on the server"
                    + " - InitScripts run on both sides, so guard client code with 'if IsClient then ... end')"); });
        factory.put("Dimension", () -> { throw new LuaError("Dimensions are created in ZSpace → ☰ → Tools → Terrain DK"); });
        factory.put("Player", () -> { throw new LuaError("Players can't be created"); });
    }

    @Override public void output(int level, String msg) {
        if (level == 2) LOG.error("[Fluwa] {}", msg); else if (level == 1) LOG.warn("[Fluwa] {}", msg); else LOG.info("[Fluwa] {}", msg);
        ScriptManager.log(level, msg);
    }

    @Override protected String findModule(String name) { return ScriptManager.findModule(name); }
    @Override public Player resolvePlayer(UUID id) { return srv.getPlayerList().getPlayer(id); }
    @Override public Level resolveLevel(ResourceKey<Level> key) { return srv.getLevel(key); }
    @Override public Collection<? extends Player> allPlayers() { return srv.getPlayerList().getPlayers(); }
    @Override public Collection<? extends Level> levels() {
        List<Level> l = new ArrayList<>();
        l.add(srv.overworld());
        for (ServerLevel s : srv.getAllLevels()) if (s != srv.overworld()) l.add(s);
        return l;
    }
    @Override public MinecraftServer server() { return srv; }
    @Override public NetBridge bridge() { return bridge; }

    @Override public void sendPlayerState(PlayerObj p) {
        if (p.raw() instanceof ServerPlayer sp)
            FluwaNet.toPlayer(sp, new Pkt(Pkt.S_STATE, List.of(), new int[]{p.asynced ? 1 : 0, p.asyncTick, p.freezeUntil >= 0 ? 1 : 0, p.freezeCam ? 1 : 0}, null));
    }

    @Override public void playLocalSound(PlayerObj p, String id, float vol, float pitch) {
        FluwaNet.toPlayer((ServerPlayer) p.p(), new Pkt(Pkt.S_SOUND, List.of(id), new int[]{Math.round(vol * 1000), Math.round(pitch * 1000)}, null));
    }

    @Override public void skybox(String target, DimensionObj d, String file) {
        Pkt pk = new Pkt(Pkt.S_SKYBOX, d.key.location().toString(), file);
        for (ServerPlayer p : srv.getPlayerList().getPlayers()) {
            boolean send = target == null || (target.isEmpty() ? ScriptManager.isCreator(p) : p.getGameProfile().getName().equalsIgnoreCase(target));
            if (send) FluwaNet.toPlayer(p, pk);
        }
    }

    /** game: DataModel with GetService */
    public static class GameObj extends LObj {
        public GameObj(GameRuntime r) { super("DataModel"); name = "Game"; r.world.setParent(this); }
        static {
            reg(GameObj.class, "GetService", (s, a) -> {
                String n = a.checkjstring(1);
                GameRuntime r = (GameRuntime) s.rt;
                return switch (n) {
                    case "Workspace", "World" -> r.world;
                    case "Players" -> r.world.players;
                    case "Lighting" -> r.world.lighting;
                    default -> r.getService(n);
                };
            });
        }
    }
}
