package net.idea.fluwa.server;

import net.idea.fluwa.Config;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/** Stores scripts in <world>/fluwa/<Folder>/*.lua and owns the server runtime. */
public final class ScriptManager {
    public static final String[] FOLDERS = {"InitScripts", "ServerScripts", "ClientScripts", "UI"};
    public static ServerRuntime rt;
    public static MinecraftServer server;
    public static Path root;
    public static final Deque<String> CONSOLE = new ArrayDeque<>();

    private ScriptManager() {}

    public static void start(MinecraftServer s) {
        server = s;
        root = s.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize().resolve("fluwa");
        try {
            boolean fresh = !Files.exists(root);
            for (String f : FOLDERS) Files.createDirectories(root.resolve(f));
            Files.createDirectories(root.resolve("Workspace"));
            if (fresh && Config.createExampleScripts) Examples.write(root);
        } catch (IOException e) { ServerRuntime.LOG.error("Fluwa: can't create script folders", e); }
        boot();
    }

    static void boot() {
        PlayerValues.install();
        rt = (ServerRuntime) new ServerRuntime(server).init();
        Map<String, Map<String, String>> items = new LinkedHashMap<>();
        for (String sec : new String[]{"Workspace", "InitScripts", "ServerScripts"}) items.put("#" + sec, ZItems.read(sec));
        rt.within(() -> { net.idea.fluwa.lua.ItemTree.build(rt, items); return null; });
        for (var e : read("InitScripts").entrySet()) rt.runScript("InitScripts/" + e.getKey(), e.getValue());
        for (var e : read("ServerScripts").entrySet()) rt.runScript("ServerScripts/" + e.getKey(), e.getValue());
    }

    public static void stop() {
        if (rt != null) rt.close();
        rt = null; server = null;
    }

    public static void reload() {
        if (server == null) return;
        if (rt != null) rt.close();
        CONSOLE.clear();
        boot();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) sendClientScripts(p);
        log(0, "Scripts reloaded");
    }

    public static boolean isCreator(ServerPlayer p) {
        return p.hasPermissions(Config.creatorPermissionLevel) || Config.coCreators.contains(p.getGameProfile().getName())
                || (p.server.isSingleplayerOwner(p.getGameProfile()));
    }

    // ------------------------------------------------------------ files
    public static Map<String, String> read(String folder) {
        Map<String, String> out = new TreeMap<>();
        if (root == null) return out;
        Path dir = root.resolve(folder);
        if (!Files.isDirectory(dir)) return out;
        try (Stream<Path> st = Files.walk(dir)) {
            st.filter(p -> p.toString().endsWith(".lua")).sorted().forEach(p -> {
                try { out.put(dir.relativize(p).toString().replace('\\', '/').replaceAll("\\.lua$", ""), Files.readString(p, StandardCharsets.UTF_8)); }
                catch (IOException ignored) {}
            });
        } catch (IOException ignored) {}
        return out;
    }

    static Path file(String folder, String name) {
        if (!Arrays.asList(FOLDERS).contains(folder)) throw new IllegalArgumentException("Unknown folder " + folder);
        String clean = name.replace('\\', '/').replaceAll("\\.lua$", "");
        if (clean.isBlank() || clean.contains("..") || clean.startsWith("/") || !clean.matches("[\\w\\-./ ]+")) throw new IllegalArgumentException("Bad script name: " + name);
        Path p = root.resolve(folder).resolve(clean + ".lua").normalize();
        if (!p.startsWith(root.resolve(folder))) throw new IllegalArgumentException("Bad script name");
        return p;
    }

    public static void save(String folder, String name, String src) throws IOException {
        Path p = file(folder, name);
        Files.createDirectories(p.getParent());
        Files.writeString(p, src, StandardCharsets.UTF_8);
    }

    public static void delete(String folder, String name) throws IOException { Files.deleteIfExists(file(folder, name)); }

    public static String findModule(String name) {
        for (String f : new String[]{"InitScripts", "ServerScripts"}) {
            try { Path p = file(f, name); if (Files.exists(p)) return Files.readString(p, StandardCharsets.UTF_8); } catch (Exception ignored) {}
        }
        if (Config.fullOsAccess) {
            try { Path p = Paths.get(name.endsWith(".lua") ? name : name + ".lua"); if (Files.exists(p)) return Files.readString(p, StandardCharsets.UTF_8); } catch (Exception ignored) {}
        }
        return null;
    }

    // ------------------------------------------------------------ network
    /** InitScripts + UI + ClientScripts are sent to every client (they run there). */
    public static void sendClientScripts(ServerPlayer p) {
        List<String> s = new ArrayList<>();
        for (String f : new String[]{"InitScripts", "UI", "ClientScripts"})
            for (var e : read(f).entrySet()) { s.add(f); s.add(e.getKey()); s.add(e.getValue()); }
        ZItems.append(s, List.of("Workspace", "InitScripts", "UI", "ClientScripts"));
        for (var e : PlayerValues.snapshot(p).entrySet()) { s.add("#Player"); s.add(e.getKey()); s.add(e.getValue()); }
        FluwaNet.toPlayerLarge(p, new Pkt(Pkt.S_SCRIPTS, s, null, null));
    }

    public static void openZSpace(ServerPlayer p) {
        if (!isCreator(p)) { p.sendSystemMessage(net.minecraft.network.chat.Component.literal("§cOnly Creator / Co-Creators can open ZSpace")); return; }
        List<String> s = new ArrayList<>();
        s.add(String.join("\n", workspaceInfo()));
        s.add(String.join("\n", CONSOLE));
        for (String f : FOLDERS) for (var e : read(f).entrySet()) { s.add(f); s.add(e.getKey()); s.add(e.getValue()); }
        ZItems.append(s, List.of(ZItems.SECTIONS));
        FluwaNet.toPlayerLarge(p, new Pkt(Pkt.S_ZSPACE, s, null, null));
    }

    static List<String> workspaceInfo() {
        List<String> l = new ArrayList<>();
        var ow = server.overworld();
        l.add("Lighting: day time " + (ow.getDayTime() % 24000) + ", weather " + (ow.isThundering() ? "thunder" : ow.isRaining() ? "rain" : "clear"));
        l.add("Terrain: seed " + ow.getSeed());
        int ents = 0;
        for (var lv : server.getAllLevels()) for (var e : lv.getAllEntities()) ents++;
        l.add("Entities: " + ents + " loaded");
        l.add("Players:");
        for (ServerPlayer p : server.getPlayerList().getPlayers())
            l.add("  " + p.getGameProfile().getName() + "  " + p.level().dimension().location() + "  " + p.blockPosition().toShortString());
        l.add("Dimensions:");
        for (var lv : server.getAllLevels()) l.add("  " + lv.dimension().location());
        return l;
    }

    public static void log(int level, String msg) {
        String line = (level == 2 ? "[ERROR] " : level == 1 ? "[WARN] " : "") + msg;
        CONSOLE.addLast(line);
        while (CONSOLE.size() > 300) CONSOLE.removeFirst();
        if (server == null) return;
        String col = level == 2 ? "§c" : level == 1 ? "§e" : "§7";
        for (ServerPlayer p : server.getPlayerList().getPlayers()) if (isCreator(p)) {
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(col + "[Fluwa] " + msg));
            FluwaNet.toPlayer(p, new Pkt(Pkt.S_CONSOLE, line));
        }
    }
}
