package net.idea.fluwa.server;

import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.luaj.vm2.*;

import java.util.*;

/**
 * ZSpace explorer backend: Workspace tree (Lighting, Terrain, Entities, Players, Dimensions, Models),
 * property get/set, insert and actions. Node ids: "Workspace", "Lighting", ..., "E:<entityId>", "P:<uuid>",
 * "D:<dimension>", "M:<projectorId>".
 */
public final class Explorer {
    private Explorer() {}
    static final int LIMIT = 300;

    static final Map<String, String[]> PROPS = Map.of(
            "Entity", new String[]{"Name", "Type", "Position", "Velocity", "Health", "MaxHealth", "OnGround", "Alive", "UUID", "Frozen", "Model"},
            "Player", new String[]{"Name", "UserName", "Position", "Health", "MaxHealth", "Hunger", "Saturation", "XP", "GameMode", "Ping", "Frozen", "IsCreator", "Model"},
            "Dimension", new String[]{"Name", "Id", "Weather", "DayTime", "MinY", "MaxY"},
            "Lighting", new String[]{"TimeOfDay", "ClockTime", "Brightness", "Ambient", "OutdoorAmbient", "FogEnabled", "FogColor", "FogStart", "FogEnd", "ExposureCompensation", "GlobalShadows", "Technology", "Skybox", "StarCount", "SunSize", "MoonSize", "GeographicLatitude", "MoonPhase", "SkyDarken"},
            "Workspace", new String[]{"DayTime", "FullTime", "GameTime", "Seed"},
            "ProjectorObject", new String[]{"Name", "Position", "Scale", "Visible", "Transparency", "Material", "Texture", "CanCollide", "Source"});

    static ServerLevel[] levels(ServerRuntime r) {
        List<ServerLevel> l = new ArrayList<>(); r.srv.getAllLevels().forEach(l::add); return l.toArray(new ServerLevel[0]);
    }

    static String row(String id, String name, String cls, boolean kids) { return id + "\t" + name.replace('\t', ' ') + "\t" + cls + "\t" + (kids ? 1 : 0); }

    static Entity entity(ServerRuntime r, int id) {
        for (ServerLevel l : levels(r)) { Entity e = l.getEntity(id); if (e != null) return e; }
        return null;
    }

    /** Lua object for a node id (or null) */
    static LuaValue obj(ServerRuntime r, String id) {
        if (id.equals("Workspace")) return r.world;
        if (id.equals("Lighting")) return r.world.lighting;
        if (id.equals("Terrain")) return r.world.terrain;
        if (id.equals("Players")) return r.world.players;
        if (id.equals("Dimensions")) return r.world.dimensions;
        if (id.startsWith("E:")) { Entity e = entity(r, Integer.parseInt(id.substring(2))); return e == null ? null : r.wrapEntity(e); }
        if (id.startsWith("P:")) { Player p = r.resolvePlayer(UUID.fromString(id.substring(2))); return p == null ? null : r.wrap(p); }
        if (id.startsWith("D:")) return r.dimByName(id.substring(2));
        if (id.startsWith("M:")) return Projector.reg(r).objs.get(Integer.parseInt(id.substring(2)));
        if (id.startsWith("W:")) return ItemTree.find(r.world, id.substring(2));
        if (id.startsWith("PV:")) {
            String rest = id.substring(3); int k = rest.indexOf('/');
            if (k < 0) return null;
            LuaValue p = obj(r, "P:" + rest.substring(0, k));
            return p instanceof LObj pl ? ItemTree.find(pl, rest.substring(k + 1)) : null;
        }
        return null;
    }

    static String cls(LuaValue o) {
        if (o instanceof PlayerObj) return "Player";
        if (o instanceof EntityObj) return "Entity";
        if (o instanceof DimensionObj) return "Dimension";
        if (o instanceof WorldObj) return "Workspace";
        if (o instanceof ProjectorObj) return "ProjectorObject";
        if (o instanceof LObj l) return l.className;
        return "?";
    }

    static List<String> children(ServerRuntime r, String id, ServerPlayer sp) {
        List<String> out = new ArrayList<>();
        switch (id) {
            case "Workspace" -> {
                out.add(row("Lighting", "Lighting", "Lighting", false));
                out.add(row("Terrain", "Terrain", "Terrain", false));
                out.add(row("Entities", "Entities", "Entities", true));
                out.add(row("Players", "Players", "Players", true));
                out.add(row("Dimensions", "Dimensions", "Dimensions", true));
                out.add(row("Models", "Models", "Models", true));
                items(out, r.world, "W:");
            }
            case "Players" -> { for (ServerPlayer p : r.srv.getPlayerList().getPlayers()) out.add(row("P:" + p.getStringUUID(), p.getGameProfile().getName(), "Player", true)); }
            case "Dimensions" -> { for (ServerLevel l : levels(r)) out.add(row("D:" + l.dimension().location(), l.dimension().location().toString(), "Dimension", true)); }
            case "Entities" -> entities(out, List.of(levels(r)), sp);
            case "Models" -> { for (ProjectorObj o : Projector.reg(r).objs.values()) out.add(row("M:" + o.id, o.getName(), "ProjectorObject", false)); }
            default -> {
                if (id.startsWith("W:")) { LObj f = ItemTree.find(r.world, id.substring(2)); if (f != null) items(out, f, id + "/"); }
                if (id.startsWith("P:") && obj(r, id) instanceof LObj pl) items(out, pl, "PV:" + id.substring(2) + "/");
                if (id.startsWith("PV:") && obj(r, id) instanceof LObj f) items(out, f, id + "/");
                if (id.startsWith("D:")) {
                    for (ServerLevel l : levels(r)) if (("D:" + l.dimension().location()).equals(id)) entities(out, List.of(l), sp);
                }
            }
        }
        return out;
    }

    /** ZSpace items (Folder / values) stored in <world>/fluwa/Workspace */
    static void items(List<String> out, LObj parent, String idPrefix) {
        List<LObj> l = new ArrayList<>();
        for (LObj c : parent.children) if (c instanceof ValueObj || (c.className.equals("Folder") && c.getClass() == LObj.class)) l.add(c);
        l.sort(Comparator.comparing((LObj c) -> !c.className.equals("Folder")).thenComparing(c -> c.getName().toLowerCase(Locale.ROOT)));
        for (LObj c : l) out.add(row(idPrefix + c.getName(), c.getName(), c.className, c.className.equals("Folder")));
    }

    static void entities(List<String> out, List<ServerLevel> ls, ServerPlayer sp) {
        List<Entity> all = new ArrayList<>();
        for (ServerLevel l : ls) for (Entity e : l.getAllEntities()) if (!(e instanceof Player)) all.add(e);
        all.sort(Comparator.comparingDouble(e -> e.level() == sp.level() ? e.distanceToSqr(sp) : 1e18));
        for (int i = 0; i < Math.min(LIMIT, all.size()); i++) {
            Entity e = all.get(i);
            out.add(row("E:" + e.getId(), e.getName().getString() + " (" + EntityType.getKey(e.getType()).getPath() + ")", "Entity", false));
        }
        if (all.size() > LIMIT) out.add(row("#more", "… " + (all.size() - LIMIT) + " more (nearest shown)", "Info", false));
    }

    static String typeOf(LuaValue v) {
        if (v instanceof Vec3L) return "vec3";
        if (v instanceof CFrameL) return "cframe";
        if (v.isboolean()) return "bool";
        if (v.isnumber()) return "number";
        if (v.isstring()) return "string";
        if (v.isnil()) return "nil";
        return "object";
    }
    static String str(LuaValue v) {
        if (v instanceof Vec3L p) return fmt(p.x) + ", " + fmt(p.y) + ", " + fmt(p.z);
        if (v instanceof CFrameL c) return fmt(c.x) + ", " + fmt(c.y) + ", " + fmt(c.z);
        if (v.isnumber() && !v.isinttype()) return fmt(v.todouble());
        return v.tojstring();
    }
    static String fmt(double d) { return d == Math.rint(d) && Math.abs(d) < 1e9 ? String.valueOf((long) d) : String.format(Locale.ROOT, "%.2f", d); }

    static LuaValue parse(String type, String s) {
        s = s.trim();
        switch (type) {
            case "vec3": case "cframe": {
                String[] p = s.split("[,; ]+");
                if (p.length < 3) throw new LuaError("Expected x, y, z");
                return new Vec3L(Double.parseDouble(p[0]), Double.parseDouble(p[1]), Double.parseDouble(p[2]));
            }
            case "bool": return LuaValue.valueOf(s.equalsIgnoreCase("true") || s.equals("1") || s.equalsIgnoreCase("yes"));
            case "number": return LuaValue.valueOf(Double.parseDouble(s.replace(',', '.')));
            default: return LuaValue.valueOf(s);
        }
    }

    static List<String> props(ServerRuntime r, String id) {
        List<String> out = new ArrayList<>();
        out.add(id);
        LuaValue o = obj(r, id);
        if (o == null) { out.add("Info\tstring\tObject no longer exists\t0"); return out; }
        String c = cls(o);
        out.add("ClassName\tstring\t" + c + "\t0");
        if (o instanceof ValueObj vo) {
            String v = vo.className.equals("ObjValue") ? (vo.getRef() != null ? vo.getRef() : vo.raw().isnil() ? "" : vo.raw().tojstring()) : str(vo.raw());
            out.add("Name\tstring\t" + vo.getName() + "\t0");
            String vt = switch (vo.className) {
                case "BoolValue" -> "bool";
                case "IntValue", "NumValue", "NumberValue" -> "number";
                case "Vector3Value" -> "vec3";
                default -> "string";
            };
            out.add("Value\t" + vt + "\t" + v.replace('\t', ' ').replace('\n', ' ') + "\t" + (vo.className.equals("TableValue") ? 0 : 1));
            out.add("Saved\tstring\t" + (id.startsWith("W:") ? "<world>/fluwa/Workspace/" + id.substring(2) + ".fval" : id.startsWith("PV:") ? "runtime only (replicated to the player's client)" : "runtime only") + "\t0");
            return out;
        }
        String[] names = PROPS.getOrDefault(c, new String[]{"Name"});
        for (String n : names) {
            String t, v; boolean rw;
            try {
                LuaValue val = o.get(n);
                t = typeOf(val); v = str(val);
                rw = isWritable(c, n) && !t.equals("object");
            } catch (Exception e) { t = "string"; v = "<" + e.getMessage() + ">"; rw = false; }
            out.add(n + "\t" + t + "\t" + v.replace('\t', ' ').replace('\n', ' ') + "\t" + (rw ? 1 : 0));
        }
        return out;
    }

    static boolean isWritable(String cls, String n) {
        return switch (n) {
            case "Type", "OnGround", "Alive", "UUID", "Frozen", "UserName", "Ping", "IsCreator", "Id", "MinY", "MaxY", "MoonPhase", "SkyDarken",
                    "FullTime", "GameTime", "Seed", "Source" -> false;
            case "Name" -> !cls.equals("Dimension") && !cls.equals("Workspace");
            default -> true;
        };
    }

    static void reply(ServerPlayer sp, int type, List<String> s) { FluwaNet.toPlayerLarge(sp, new Pkt(type, s, null, null)); }
    static void msg(ServerPlayer sp, String m) { reply(sp, Pkt.S_ZPROPS, List.of("#msg", m)); }

    public static void handle(Pkt p, ServerPlayer sp) {
        ServerRuntime r = ScriptManager.rt;
        if (r == null || r.closed) { msg(sp, "Scripts are not running"); return; }
        try {
            r.within(() -> { run(r, p, sp); return null; });
        } catch (Exception e) { msg(sp, "Error: " + e.getMessage()); }
    }

    static void run(ServerRuntime r, Pkt p, ServerPlayer sp) {
        String id = p.s(0);
        switch (p.type) {
            case Pkt.C_ZTREE -> { List<String> s = new ArrayList<>(); s.add(id); s.addAll(children(r, id, sp)); reply(sp, Pkt.S_ZTREE, s); }
            case Pkt.C_ZPROPS -> reply(sp, Pkt.S_ZPROPS, props(r, id));
            case Pkt.C_ZSET -> {
                LuaValue o = obj(r, id);
                if (o == null) { msg(sp, "Object no longer exists"); return; }
                String prop = p.s(1);
                if (id.startsWith("W:") && o instanceof LObj lo) {
                    if (!prop.equals("Value")) { msg(sp, "Only Value can be edited here (rename in the ZSpace sidebar)"); return; }
                    try { ZItems.save("Workspace", id.substring(2), lo.className, p.s(2)); } catch (java.io.IOException e) { throw new LuaError(e.getMessage()); }
                    ZItems.live("Workspace", id.substring(2), lo.className, p.s(2), false);
                    reply(sp, Pkt.S_ZPROPS, props(r, id));
                    return;
                }
                if (o instanceof ValueObj vo && prop.equals("Value")) {
                    if (vo.className.equals("ObjValue") || vo.className.equals("ObjectValue")) vo.setRef(p.s(2));
                    else if (vo.className.equals("TableValue")) { msg(sp, "TableValue can't be edited here"); return; }
                    else vo.set(LuaValue.valueOf("Value"), ItemTree.parse(vo.className, p.s(2)));
                    reply(sp, Pkt.S_ZPROPS, props(r, id));
                    return;
                }
                LuaValue cur = o.get(prop);
                LuaValue v = parse(typeOf(cur), p.s(2));
                if (prop.equals("Name") && o instanceof LObj l) l.setName(v.tojstring()); else o.set(prop, v);
                reply(sp, Pkt.S_ZPROPS, props(r, id));
            }
            case Pkt.C_ZINSERT -> {
                String cls = p.s(1), arg = p.s(2).trim();
                if (id.startsWith("P:") || id.startsWith("PV:")) {
                    LuaValue t = obj(r, id);
                    if (t instanceof ValueObj vo) { t = vo.parent; id = id.substring(0, id.lastIndexOf('/')); if (id.indexOf('/') < 0) id = "P:" + id.substring(3); }
                    if (!(t instanceof LObj pl)) { msg(sp, "Player is not online"); return; }
                    String n = arg.isEmpty() ? cls : arg;
                    LObj made = ItemTree.apply(pl, n, cls, p.s.size() > 3 ? p.s(3) : "");
                    msg(sp, "Inserted " + cls + " " + made.getName() + " into " + (pl instanceof PlayerObj po ? po.profileName : pl.getName()));
                    List<String> s = new ArrayList<>(); s.add(id); s.addAll(children(r, id, sp));
                    reply(sp, Pkt.S_ZTREE, s);
                    return;
                }
                insert(r, sp, id, cls, arg);
                List<String> s = new ArrayList<>();
                String parent = cls.equals("Model") ? "Models" : id.startsWith("D:") ? id : "Entities";
                s.add(parent); s.addAll(children(r, parent, sp));
                reply(sp, Pkt.S_ZTREE, s);
            }
            case Pkt.C_ZACTION -> action(r, sp, id, p.s(1));
            default -> {}
        }
    }

    static Vec3 front(ServerPlayer sp) { return sp.getEyePosition().add(sp.getLookAngle().scale(3)); }

    static void insert(ServerRuntime r, ServerPlayer sp, String parent, String cls, String arg) {
        ServerLevel l = sp.serverLevel();
        if (parent.startsWith("D:")) { DimensionObj d = r.dimByName(parent.substring(2)); if (d != null) l = EntityObj.sl(d.level()); }
        Vec3 pos = front(sp);
        switch (cls) {
            case "Entity" -> { Entity e = DimensionObj.spawn(l, arg.isEmpty() ? "minecraft:pig" : arg, pos); msg(sp, "Inserted " + e.getName().getString()); }
            case "Item" -> {
                ItemEntity ie = new ItemEntity(l, pos.x, pos.y, pos.z, ItemObj.create(arg.isEmpty() ? "minecraft:diamond" : arg, 1));
                ie.setDefaultPickUpDelay(); l.addFreshEntity(ie); msg(sp, "Inserted item " + arg);
            }
            case "Block" -> {
                var b = BuiltInRegistries.BLOCK.get(Conv.rl(arg.isEmpty() ? "minecraft:stone" : arg));
                l.setBlockAndUpdate(BlockPos.containing(pos), b.defaultBlockState()); msg(sp, "Placed " + arg);
            }
            case "Model" -> {
                LuaTable t = new LuaTable(); t.set("Position", Vec3L.of(pos));
                ProjectorObj o = Projector.imp(r, arg, t, true);
                o.dim = l.dimension().location().toString();
                msg(sp, "Imported model " + o.getName());
            }
            default -> throw new LuaError("Can't insert " + cls);
        }
    }

    static void action(ServerRuntime r, ServerPlayer sp, String id, String act) {
        LuaValue o = obj(r, id);
        if (o == null) { msg(sp, "Object no longer exists"); return; }
        switch (act) {
            case "delete" -> {
                if (id.startsWith("W:")) {
                    try { ZItems.delete("Workspace", id.substring(2)); } catch (java.io.IOException e) { throw new LuaError(e.getMessage()); }
                    ZItems.live("Workspace", id.substring(2), "", "", true);
                    msg(sp, "Deleted " + id.substring(2));
                    List<String> s = new ArrayList<>(); s.add("Workspace"); s.addAll(children(r, "Workspace", sp)); reply(sp, Pkt.S_ZTREE, s);
                    return;
                }
                if (o instanceof PlayerObj) { msg(sp, "Players can't be deleted"); return; }
                if (id.startsWith("PV:") && o instanceof LObj l) {
                    l.destroy(); msg(sp, "Deleted " + l.getName());
                    String par = id.substring(0, id.lastIndexOf('/')); if (par.indexOf('/') < 0) par = "P:" + par.substring(3);
                    List<String> s = new ArrayList<>(); s.add(par); s.addAll(children(r, par, sp)); reply(sp, Pkt.S_ZTREE, s);
                    return;
                }
                if (o instanceof LObj l && (o instanceof EntityObj || o instanceof ProjectorObj)) { l.destroy(); msg(sp, "Deleted " + id); }
                else msg(sp, "This object can't be deleted");
            }
            case "goto" -> {
                LuaValue pos = o.get("Position");
                if (pos instanceof Vec3L v) { sp.teleportTo(v.x, v.y, v.z); msg(sp, "Teleported"); } else msg(sp, "No position");
            }
            case "bring" -> {
                if (o instanceof EntityObj eo) { Vec3 f = front(sp); eo.teleport(f.x, f.y, f.z, sp.getYRot() + 180, 0); msg(sp, "Brought"); }
                else if (o instanceof ProjectorObj po) { po.set("Position", Vec3L.of(front(sp))); msg(sp, "Brought"); }
                else msg(sp, "Can't bring this object");
            }
            case "lua" -> reply(sp, Pkt.S_ZPROPS, List.of("#lua", lua(r, id, o)));
            default -> msg(sp, "Unknown action " + act);
        }
        reply(sp, Pkt.S_ZPROPS, props(r, id));
    }

    /** "export to Lua": a snippet that finds this object from a script */
    static String lua(ServerRuntime r, String id, LuaValue o) {
        if (id.startsWith("P:") && o instanceof PlayerObj p) return "local player = Players:FindFirstChild(\"" + p.profileName + "\")";
        if (id.startsWith("E:") && o instanceof EntityObj e) {
            Vec3L v = Vec3L.of(e.e().position());
            return "-- " + e.getName() + "\nlocal ent = Instance:new(\"Entity\")\nent.Type = \"" + EntityType.getKey(e.e().getType()) + "\"\nent.Position = Vec3.new("
                    + fmt(v.x) + ", " + fmt(v.y) + ", " + fmt(v.z) + ")\nent.Parent = Dimension";
        }
        if (id.startsWith("D:")) return "local dim = Workspace.Dimensions:FindFirstChild(\"" + id.substring(2) + "\")";
        if (id.startsWith("M:") && o instanceof ProjectorObj m) return "local Projector = getAccess(\"Projector\")\nlocal model = Projector:Import(\"" + m.source + "\")";
        if (id.startsWith("PV:") && o instanceof LObj l) {
            String rest = id.substring(3); Player pl = r.resolvePlayer(UUID.fromString(rest.substring(0, rest.indexOf('/'))));
            String path = rest.substring(rest.indexOf('/') + 1).replace("/", ".");
            return "-- server\nlocal player = Players:FindFirstChild(\"" + (pl == null ? "?" : pl.getGameProfile().getName()) + "\")\nlocal v = player." + path
                    + "\n-- client (ClientScripts / UI)\nlocal v = Players.LocalPlayer." + path;
        }
        if (id.startsWith("W:")) return "local obj = Workspace." + id.substring(2).replace("/", ".");
        return "local obj = Workspace." + id;
    }
}
