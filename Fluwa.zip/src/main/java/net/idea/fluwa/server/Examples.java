package net.idea.fluwa.server;

import java.io.IOException;
import java.nio.file.*;

/** Example scripts written into new worlds. */
final class Examples {
    private Examples() {}

    static void write(Path root) throws IOException {
        Files.writeString(root.resolve("InitScripts/Shared.lua"), """
            -- InitScripts run first, on the server AND on every client.
            -- Create network events here so both sides know them by Name.
            local hello = Instance:new("Event")
            hello.Name = "Hello"

            -- a module for CAR("Utils")
            """);
        Files.writeString(root.resolve("InitScripts/Utils.lua"), """
            -- Module: load with  local Utils = CAR("Utils")
            local Utils = {}
            function Utils.round(x) return math.floor(x + 0.5) end
            function Utils.vecToString(v) return ("%d %d %d"):format(Utils.round(v.X), Utils.round(v.Y), Utils.round(v.Z)) end
            return Utils
            """);
        Files.writeString(root.resolve("ServerScripts/Welcome.lua"), """
            local Utils = CAR("Utils")
            print("Fluwa server scripts started. Players online: " .. Players.Count)

            Players.E_Join:Connect(function(player)
              player:SendMessage("§aWelcome to a Fluwa world, " .. player.Name .. "! Press F8 to open ZSpace (Creators).")
              player:GetEffect({"speed", 5, 1})

              player.E_Death:Connect(function(reason)
                print(player.Name .. " died: " .. tostring(reason))
              end)

              player.E_Chatted:Connect(function(msg)
                if msg == "!pos" then player:SendMessage("You are at " .. Utils.vecToString(player.Position)) end
                if msg == "!day" then World.Time:Set(1000) end
              end)
            end)
            """);
        Files.writeString(root.resolve("ServerScripts/HelloServer.lua"), """
            -- Event "Hello" is created in InitScripts/Shared.lua (both sides)
            local hello = Events:FindFirstChild("Hello")
            hello.OnServerFire:Connect(function(player, arg)
              print(player.Name .. " says hello: " .. tostring(arg))
              hello:FirePlayer(player, "Hi " .. player.Name .. ", the server heard you!")
            end)
            """);
        Files.writeString(root.resolve("ClientScripts/Hello.lua"), """
            local hello = Events:FindFirstChild("Hello")
            hello.OnPlayerFire:Connect(function(msg)
              print("Server answered: " .. tostring(msg))
            end)
            wait(3)
            hello:FireServer("hello from " .. Players.LocalPlayer.Name)
            """);
        Files.writeString(root.resolve("UI/Hud.lua"), """
            -- Simple overlay (HUD) that shows the player's coordinates
            local hud = Instance:new("Overlay", UI)
            hud.Name = "CoordsHud"
            local label = Instance:new("TextLabel", hud)
            label.Position = UDim2.new(0, 6, 0, 6)
            label.Size = UDim2.new(0, 160, 0, 14)
            label.BackgroundTransparency = 0.6
            label.TextColor = Color.new(255, 255, 160)

            label.Text = "XYZ: ..."

            local me = Players.LocalPlayer
            me.E_Tick:Connect(function()
              local p = me.Position
              if p then label.Text = ("XYZ: %.1f %.1f %.1f"):format(p.X, p.Y, p.Z) end
            end)
            """);
    }
}
