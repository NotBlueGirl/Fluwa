package net.idea.fluwa.server;

import net.idea.fluwa.Fluwa;
import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.luaj.vm2.LuaValue;

import java.util.*;
import java.util.function.Supplier;

/** Bridges Forge events to Fluwa Lua events, for the server runtime and (on the client) the client runtime. */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ServerEvents {
    public static int noDropExplosions;

    private ServerEvents() {}

    static GameRuntime rt(Level l) {
        if (l == null) return null;
        GameRuntime r = l.isClientSide ? GameRuntime.CLIENT : ScriptManager.rt;
        return r == null || r.closed ? null : r;
    }

    static void player(Entity e, String ev, Supplier<LuaValue[]> args) {
        if (e instanceof Player) ent(e, ev, args);
    }

    /** wrapped Lua object of an entity (only if a script already references it) */
    static EntityObj obj(GameRuntime r, Entity e) {
        if (r == null || e == null) return null;
        if (e instanceof Player p) return r.players.get(p.getUUID());
        EntityObj o = r.entities.get(e.getId());
        return o != null && o.raw() == e ? o : null;
    }

    static void ent(Entity e, String ev, Supplier<LuaValue[]> args) {
        if (e == null) return;
        GameRuntime r = rt(e.level());
        EntityObj o = obj(r, e);
        if (o == null || !o.listens(ev)) return;
        r.within(() -> { o.fire(ev, args.get()); return null; });
    }

    public static void tickEntity(GameRuntime r, EntityObj o) {
        Entity en = o.raw();
        if (en == null || en.isRemoved()) return;
        if (o.freezeUntil >= 0) {
            if (r.tick > o.freezeUntil) o.unfreezeEntity();
            else {
                en.setPos(o.fx, o.fy, o.fz);
                if (o.freezeCam) { en.setYRot(o.fyaw); en.setXRot(o.fpitch); en.setYHeadRot(o.fyaw); }
                en.setDeltaMovement(Vec3.ZERO);
                en.hurtMarked = true;
            }
        }
        if (o.drownMode == 1) {
            o.drownAir--;
            if (o.drownAir <= -20) { o.drownAir = 0; en.hurt(en.damageSources().drown(), 2f); }
            en.setAirSupply(o.drownAir);
        } else if (o.drownMode == 2) en.setAirSupply(o.drownAir);
        if (o.listens("E_Move")) {
            Vec3L p = Vec3L.of(en.position());
            if (o.lastPos == null || o.lastPos.sub(p).mag() > 1e-3) { if (o.lastPos != null) o.fire("E_Move", p); o.lastPos = p; }
        }
        if (o.listens("E_Interact")) {
            Set<Integer> now = new HashSet<>();
            for (Entity t : en.level().getEntities(en, en.getBoundingBox().inflate(0.05))) {
                now.add(t.getId());
                if (!o.touching.contains(t.getId())) o.fire("E_Interact", r.wrapEntity(t));
            }
            o.touching = now;
        }
        if (o.listens("E_Tick")) o.fire("E_Tick");
    }

    static void dim(Level l, String ev, Supplier<LuaValue[]> args) {
        GameRuntime r = rt(l);
        if (r == null) return;
        DimensionObj d = r.dims.get(l.dimension());
        if (d == null || !d.listens(ev)) return;
        r.within(() -> { d.fire(ev, args.get()); return null; });
    }

    static LuaValue[] a(LuaValue... v) { return v; }

    // ================================================================ lifecycle
    @SubscribeEvent public static void started(ServerStartedEvent e) { ScriptManager.start(e.getServer()); }
    @SubscribeEvent public static void stopping(ServerStoppingEvent e) { ScriptManager.stop(); net.idea.fluwa.api.NoCollide.clearServer(); net.idea.fluwa.api.ModelSync.clear(); net.idea.fluwa.api.EntityFlags.clear(); }

    @SubscribeEvent public static void levelLoad(net.minecraftforge.event.level.LevelEvent.Load e) {
        if (e.getLevel() instanceof net.minecraft.server.level.ServerLevel sl) net.idea.fluwa.api.NoCollide.onLevelLoad(sl);
    }
    @SubscribeEvent public static void commands(RegisterCommandsEvent e) { FluwaCommand.register(e.getDispatcher()); }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        ServerRuntime r = ScriptManager.rt;
        if (r == null || r.closed) return;
        r.within(() -> {
            r.onTick();
            r.world.tickTime();
            for (PlayerObj o : new ArrayList<>(r.players.values())) tickPlayer(r, o);
            for (EntityObj o : new ArrayList<>(r.entities.values())) if (o != null && !(o instanceof PlayerObj)) tickEntity(r, o);
            for (DimensionObj d : new ArrayList<>(r.dims.values())) {
                if (!d.listens("E_WeatherChanged")) continue;
                String w = d.weather();
                if (d.lastWeather != null && !d.lastWeather.equals(w)) d.fire("E_WeatherChanged", LuaValue.valueOf(w));
                d.lastWeather = w;
            }
            return null;
        });
        for (ServerLevel l : r.srv.getAllLevels()) tickGravity(l);
    }

    static void tickPlayer(ServerRuntime r, PlayerObj o) {
        if (!(o.raw() instanceof ServerPlayer sp)) return;
        if (o.freezeUntil >= 0) {
            if (r.tick > o.freezeUntil) { o.freezeUntil = -1; r.sendPlayerState(o); }
            else {
                boolean moved = sp.distanceToSqr(o.fx, o.fy, o.fz) > 1e-4;
                boolean turned = o.freezeCam && (Math.abs(sp.getYRot() - o.fyaw) > 0.5 || Math.abs(sp.getXRot() - o.fpitch) > 0.5);
                if (moved || turned) sp.connection.teleport(o.fx, o.fy, o.fz, o.freezeCam ? o.fyaw : sp.getYRot(), o.freezeCam ? o.fpitch : sp.getXRot());
                sp.setDeltaMovement(Vec3.ZERO);
            }
        }
        if (o.drownMode == 1) {
            o.drownAir--;
            if (o.drownAir <= -20) { o.drownAir = 0; sp.hurt(sp.damageSources().drown(), 2f); }
            sp.setAirSupply(o.drownAir);
        } else if (o.drownMode == 2) sp.setAirSupply(o.drownAir);
        if (o.listens("E_Move")) {
            Vec3L p = Vec3L.of(sp.position());
            if (o.lastPos == null || o.lastPos.sub(p).mag() > 1e-3) { if (o.lastPos != null) o.fire("E_Move", p); o.lastPos = p; }
        }
        if (o.listens("E_Tick")) o.fire("E_Tick");
    }

    static void tickGravity(ServerLevel l) {
        BlockData d = BlockData.get(l);
        if (d.gravity.isEmpty()) return;
        for (Long key : new ArrayList<>(d.gravity)) {
            BlockPos p = BlockPos.of(key);
            if (!l.isLoaded(p)) continue;
            BlockState st = l.getBlockState(p);
            if (st.isAir()) { d.gravity.remove(key); d.setDirty(); continue; }
            if (p.getY() > l.getMinBuildHeight() && FallingBlock.isFree(l.getBlockState(p.below()))) {
                d.gravity.remove(key); d.setDirty();
                FallingBlockEntity.fall(l, p, st);
            }
        }
    }

    @SubscribeEvent
    public static void levelTick(TickEvent.LevelTickEvent e) {
        if (e.phase == TickEvent.Phase.END) dim(e.level, "E_Tick", () -> a());
    }

    // ================================================================ players
    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        ScriptManager.sendClientScripts(sp);
        net.idea.fluwa.api.NoCollide.sendAll(sp);
        net.idea.fluwa.api.ModelSync.sendAll(sp);
        net.idea.fluwa.api.Projector.sendAll(sp);
        net.idea.fluwa.api.EntityFlags.sendAll(sp);
        net.idea.fluwa.api.WorldTween.sendAll(sp);
        net.idea.fluwa.api.Hitbox.sendAll(sp);
        byte[] light = net.idea.fluwa.lighting.LightingObj.SERVER_STATE;
        if (light != null) FluwaNet.toPlayerLarge(sp, new Pkt(Pkt.S_LIGHTING, null, null, light));
        ServerRuntime r = ScriptManager.rt;
        if (r == null) return;
        r.within(() -> { PlayerObj o = r.wrap(sp); r.world.players.join.fire(o); o.fire("E_Join", o); return null; });
    }

    @SubscribeEvent
    public static void logout(PlayerEvent.PlayerLoggedOutEvent e) {
        ServerRuntime r = ScriptManager.rt;
        if (r == null || !(e.getEntity() instanceof ServerPlayer sp)) return;
        r.within(() -> { PlayerObj o = r.wrap(sp); o.fire("E_Leave", o); r.world.players.leave.fire(o); return null; });
        r.players.remove(sp.getUUID());
        PlayerObj.NAME_OVERRIDES.remove(sp.getUUID());
    }

    @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent e) { player(e.getEntity(), "E_Respawn", () -> a()); }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        var old = e.getOriginal().getPersistentData();
        if (old.contains("fluwa")) e.getEntity().getPersistentData().put("fluwa", old.getCompound("fluwa").copy());
        if (!e.isWasDeath() && old.contains("fluwa_tmp")) e.getEntity().getPersistentData().put("fluwa_tmp", old.getCompound("fluwa_tmp").copy());
    }

    @SubscribeEvent
    public static void chat(ServerChatEvent e) {
        String msg = e.getRawText();
        player(e.getPlayer(), "E_Chatted", () -> a(LuaValue.valueOf(msg)));
    }

    @SubscribeEvent
    public static void death(LivingDeathEvent e) {
        ent(e.getEntity(), "E_Death", () -> a(LuaValue.valueOf(e.getSource().getMsgId())));
    }

    @SubscribeEvent
    public static void hurt(LivingHurtEvent e) {
        ent(e.getEntity(), "E_Damaged", () -> a(LuaValue.valueOf(e.getSource().getMsgId()), LuaValue.valueOf(e.getAmount())));
    }

    @SubscribeEvent public static void sleep(PlayerSleepInBedEvent e) { player(e.getEntity(), "E_Sleep", () -> a(Vec3L.of(e.getPos()))); }

    @SubscribeEvent
    public static void wake(PlayerWakeUpEvent e) {
        GameRuntime r = rt(e.getEntity().level());
        if (r != null) { PlayerObj o = r.players.get(e.getEntity().getUUID()); if (o != null) o.forcedSleep = false; }
        player(e.getEntity(), "E_Wake", () -> a());
    }

    @SubscribeEvent
    public static void sleepCheck(SleepingLocationCheckEvent e) {
        GameRuntime r = rt(e.getEntity().level());
        if (r == null) return;
        PlayerObj o = r.players.get(e.getEntity().getUUID());
        if (o != null && o.forcedSleep) e.setResult(Event.Result.ALLOW);
    }

    @SubscribeEvent public static void effAdd(MobEffectEvent.Added e) { ent(e.getEntity(), "E_EffAdd", () -> a(Conv.effectTable(e.getEffectInstance()))); }
    @SubscribeEvent public static void effRemove(MobEffectEvent.Remove e) {
        if (e.getEffectInstance() != null) ent(e.getEntity(), "E_EffDel", () -> a(Conv.effectTable(e.getEffectInstance())));
    }
    @SubscribeEvent public static void effExpire(MobEffectEvent.Expired e) {
        if (e.getEffectInstance() != null) ent(e.getEntity(), "E_EffDel", () -> a(Conv.effectTable(e.getEffectInstance())));
    }

    @SubscribeEvent
    public static void equip(LivingEquipmentChangeEvent e) {
        if (e.getSlot().getType() != EquipmentSlot.Type.ARMOR) return;
        ent(e.getEntity(), "E_ArmorChanged", () -> a(LuaValue.valueOf(e.getSlot().getIndex() + 1), new ItemObj(e.getTo())));
    }

    @SubscribeEvent public static void pick(EntityItemPickupEvent e) { player(e.getEntity(), "E_PickItem", () -> a(new ItemObj(e.getItem().getItem()))); }
    @SubscribeEvent public static void toss(ItemTossEvent e) { player(e.getPlayer(), "E_DropItem", () -> a(new ItemObj(e.getEntity().getItem()))); }

    @SubscribeEvent
    public static void changeDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer tsp) net.idea.fluwa.api.WorldTween.sendAll(tsp);
        GameRuntime r = rt(e.getEntity().level());
        if (r == null) return;
        player(e.getEntity(), "E_DimensionChanged", () -> a(r.wrap(e.getEntity().level())));
    }

    @SubscribeEvent
    public static void section(EntityEvent.EnteringSection e) {
        if (!e.didChunkChange()) return;
        Entity en = e.getEntity();
        player(en, "E_ChunkChange", () -> a(new ChunkObj(en.level(), new ChunkPos(e.getNewPos().x(), e.getNewPos().z()))));
    }

    @SubscribeEvent
    public static void interact(PlayerInteractEvent.RightClickBlock e) {
        Level l = e.getLevel();
        player(e.getEntity(), "E_Interact", () -> a(new BlockObj(l, e.getPos())));
        if (l instanceof ServerLevel sl && e.getEntity() instanceof ServerPlayer sp && e.getHand() == net.minecraft.world.InteractionHand.MAIN_HAND) {
            String screen = BlockData.get(sl).screens.get(e.getPos().asLong());
            if (screen != null && !sp.isShiftKeyDown()) {
                FluwaNet.toPlayer(sp, new Pkt(Pkt.S_SCREEN, screen));
                e.setCanceled(true);
            }
        }
    }

    @SubscribeEvent public static void jump(LivingEvent.LivingJumpEvent e) { ent(e.getEntity(), "E_Jump", () -> a()); }

    @SubscribeEvent
    public static void interactEntity(PlayerInteractEvent.EntityInteract e) {
        if (e.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        GameRuntime r = rt(e.getLevel());
        if (r == null) return;
        Entity t = e.getTarget();
        player(e.getEntity(), "E_Interact", () -> a(r.wrapEntity(t)));
        ent(t, "E_Interact", () -> a(r.wrap(e.getEntity())));
    }

    @SubscribeEvent
    public static void baby(BabyEntitySpawnEvent e) {
        GameRuntime r = rt(e.getParentA().level());
        if (r == null) return;
        Supplier<LuaValue[]> args = () -> a(e.getChild() == null ? LuaValue.NIL : r.wrapEntity(e.getChild()),
                r.wrapEntity(e.getParentA()), r.wrapEntity(e.getParentB()));
        ent(e.getParentA(), "E_Multiply", args);
        ent(e.getParentB(), "E_Multiply", args);
    }

    @SubscribeEvent
    public static void attack(AttackEntityEvent e) {
        GameRuntime r = rt(e.getEntity().level());
        if (r != null) player(e.getEntity(), "E_Attack", () -> a(r.wrapEntity(e.getTarget())));
    }

    @SubscribeEvent
    public static void eat(LivingEntityUseItemEvent.Finish e) {
        if (e.getItem().isEdible()) player(e.getEntity(), "E_Feed", () -> a(new ItemObj(e.getItem())));
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void nameFormat(PlayerEvent.NameFormat e) {
        String n = PlayerObj.NAME_OVERRIDES.get(e.getEntity().getUUID());
        if (n != null) e.setDisplayname(Component.literal(n));
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void tabFormat(PlayerEvent.TabListNameFormat e) {
        String n = PlayerObj.NAME_OVERRIDES.get(e.getEntity().getUUID());
        if (n != null) e.setDisplayName(Component.literal(n));
    }

    // ================================================================ world
    @SubscribeEvent
    public static void place(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getLevel() instanceof Level l)) return;
        GameRuntime r = rt(l);
        dim(l, "E_BlockPlaced", () -> a(LuaValue.valueOf(Conv.id(e.getPlacedBlock())), Vec3L.of(e.getPos()),
                e.getEntity() == null ? LuaValue.NIL : r.wrapEntity(e.getEntity())));
    }

    @SubscribeEvent
    public static void breakBlock(BlockEvent.BreakEvent e) {
        if (!(e.getLevel() instanceof Level l)) return;
        GameRuntime r = rt(l);
        dim(l, "E_BlockDestroyed", () -> a(LuaValue.valueOf(Conv.id(e.getState())), Vec3L.of(e.getPos()),
                e.getPlayer() == null ? LuaValue.NIL : r.wrap(e.getPlayer())));
        if (l instanceof ServerLevel sl) {
            BlockData d = BlockData.get(sl);
            if (d.tags.containsKey(e.getPos().asLong()) || d.screens.containsKey(e.getPos().asLong()) || d.gravity.contains(e.getPos().asLong())) d.clear(e.getPos());
        }
    }

    @SubscribeEvent
    public static void entityJoin(EntityJoinLevelEvent e) {
        Level l = e.getLevel();
        if (!l.isClientSide) net.idea.fluwa.api.Hitbox.joined(e.getEntity());
        GameRuntime r = rt(l);
        if (r == null) return;
        Entity en = e.getEntity();
        dim(l, "E_EntityAdded", () -> a(LuaValue.valueOf(net.minecraft.world.entity.EntityType.getKey(en.getType()).toString()),
                CFrameL.fromYawPitch(Vec3L.of(en.position()), en.getYRot(), en.getXRot()), r.wrapEntity(en)));
    }

    @SubscribeEvent
    public static void entityLeave(EntityLeaveLevelEvent e) {
        Entity en = e.getEntity();
        if (!e.getLevel().isClientSide) net.idea.fluwa.api.Hitbox.left(en);
        if (en.getRemovalReason() == Entity.RemovalReason.KILLED) return; // dead, not "destroyed"
        GameRuntime r = rt(e.getLevel());
        if (r == null) return;
        dim(e.getLevel(), "E_EntityDestroyed", () -> a(LuaValue.valueOf(net.minecraft.world.entity.EntityType.getKey(en.getType()).toString()),
                CFrameL.fromYawPitch(Vec3L.of(en.position()), en.getYRot(), en.getXRot()), r.wrapEntity(en)));
    }

    @SubscribeEvent
    public static void chunkLoad(ChunkEvent.Load e) {
        if (!(e.getLevel() instanceof Level l)) return;
        ChunkPos cp = e.getChunk().getPos();
        dim(l, "E_ChunkLoaded", () -> a(new ChunkObj(l, cp)));
        if (l.isClientSide) {
            GameRuntime r = rt(l);
            Signal s = ChunkObj.CLIENT_LOADED.get(cp.toLong());
            if (r != null && s != null) r.within(() -> { s.fire(); return null; });
        }
    }

    @SubscribeEvent
    public static void chunkUnload(ChunkEvent.Unload e) {
        if (e.getLevel() instanceof Level l) { ChunkPos cp = e.getChunk().getPos(); dim(l, "E_ChunkUnloaded", () -> a(new ChunkObj(l, cp))); }
    }

    @SubscribeEvent
    public static void explode(ExplosionEvent.Detonate e) {
        Level l = e.getLevel();
        if (noDropExplosions > 0 && !l.isClientSide) {
            var air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
            for (BlockPos p : e.getAffectedBlocks()) if (!l.getBlockState(p).isAir()) l.setBlock(p, air, 3);
            e.getAffectedBlocks().clear();
        }
        Vec3 c = e.getExplosion().getPosition();
        dim(l, "E_Explosion", () -> a(new Vec3L(c.x, c.y, c.z)));
    }
}
