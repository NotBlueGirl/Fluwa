package net.idea.fluwa.server;

import net.idea.fluwa.Config;
import net.idea.fluwa.api.Conv;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

import java.util.*;

/**
 * Backend of ZSpace → Tools → World Editor (Axiom-like in-world editing).
 * Every operation is recorded per player for Undo / Redo. Volume per operation is limited by maxBlocksPerCall.
 */
public final class WorldEditor {
    private WorldEditor() {}

    record Change(ServerLevel level, LinkedHashMap<BlockPos, BlockState> before, LinkedHashMap<BlockPos, BlockState> after) {}
    static final class Session {
        final Deque<Change> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
        Map<BlockPos, BlockState> clip; // relative to the copy origin (min corner)
    }
    static final Map<UUID, Session> SESSIONS = new HashMap<>();
    static Session ses(ServerPlayer p) { return SESSIONS.computeIfAbsent(p.getUUID(), k -> new Session()); }

    static final class Edit {
        final ServerLevel l; final LinkedHashMap<BlockPos, BlockState> before = new LinkedHashMap<>(), after = new LinkedHashMap<>();
        Edit(ServerLevel l) { this.l = l; }
        void set(BlockPos p, BlockState s) {
            if (before.size() >= Config.maxBlocksPerCall) throw new IllegalStateException("Too many blocks in one operation (maxBlocksPerCall = " + Config.maxBlocksPerCall + ")");
            if (!l.isInWorldBounds(p)) return;
            BlockState old = l.getBlockState(p);
            if (old == s) return;
            BlockPos ip = p.immutable();
            before.putIfAbsent(ip, old);
            after.put(ip, s);
            l.setBlock(ip, s, 2);
        }
    }

    static BlockPos[] box(Pkt p, int o) {
        BlockPos a = new BlockPos(p.n(o), p.n(o + 1), p.n(o + 2)), b = new BlockPos(p.n(o + 3), p.n(o + 4), p.n(o + 5));
        BlockPos mn = new BlockPos(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()));
        BlockPos mx = new BlockPos(Math.max(a.getX(), b.getX()), Math.max(a.getY(), b.getY()), Math.max(a.getZ(), b.getZ()));
        long vol = (long) (mx.getX() - mn.getX() + 1) * (mx.getY() - mn.getY() + 1) * (mx.getZ() - mn.getZ() + 1);
        if (vol > Config.maxBlocksPerCall) throw new IllegalStateException("Selection is too big: " + vol + " blocks (maxBlocksPerCall = " + Config.maxBlocksPerCall + ")");
        return new BlockPos[]{mn, mx};
    }

    static Iterable<BlockPos> sphere(BlockPos c, int r, boolean cube) { return sphere(c, r, cube, false); }
    /** sphere / cube of radius r; hollow = only the 1-block shell */
    static Iterable<BlockPos> sphere(BlockPos c, int r, boolean cube, boolean hollow) {
        List<BlockPos> l = new ArrayList<>();
        int in = (r - 1) * (r - 1) + (r - 1);
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            int d = x * x + y * y + z * z;
            boolean inside = cube || d <= r * r + r;
            if (!inside) continue;
            if (hollow && r > 0) {
                boolean shell = cube ? (Math.abs(x) == r || Math.abs(y) == r || Math.abs(z) == r) : d > in;
                if (!shell) continue;
            }
            l.add(c.offset(x, y, z));
        }
        return l;
    }

    /** "stone" or a mix "stone, andesite, cobblestone" */
    static Conv.Picker picker(String s) {
        String[] parts = s.split("[,;]+");
        org.luaj.vm2.LuaTable st = new org.luaj.vm2.LuaTable(), add = new org.luaj.vm2.LuaTable();
        for (int i = 1; i < parts.length; i++) if (!parts[i].isBlank()) add.insert(0, org.luaj.vm2.LuaValue.valueOf(parts[i].trim()));
        st.set("add", add);
        return new Conv.Picker(parts[0].trim(), st);
    }

    static void msg(ServerPlayer sp, boolean ok, String m) { FluwaNet.toPlayer(sp, new Pkt(Pkt.S_WEDIT, ok ? "1" : "0", m)); }

    public static void handle(Pkt p, ServerPlayer sp) {
        try { String m = run(p, sp); if (!m.isEmpty()) msg(sp, true, m); }
        catch (Exception e) { msg(sp, false, String.valueOf(e.getMessage())); }
    }

    static String run(Pkt p, ServerPlayer sp) {
        Session s = ses(sp);
        ServerLevel l = sp.serverLevel();
        String op = p.s(0);
        String ex = WEExtra.run(op, p, sp, s);
        if (ex != null) return ex;
        switch (op) {
            case "undo" -> {
                Change c = s.undo.pollLast();
                if (c == null) return "Nothing to undo";
                c.before().forEach((pos, st) -> c.level().setBlock(pos, st, 2));
                s.redo.addLast(c);
                return "Undo: " + c.before().size() + " blocks";
            }
            case "redo" -> {
                Change c = s.redo.pollLast();
                if (c == null) return "Nothing to redo";
                c.after().forEach((pos, st) -> c.level().setBlock(pos, st, 2));
                s.undo.addLast(c);
                return "Redo: " + c.after().size() + " blocks";
            }
            case "copy" -> {
                BlockPos[] b = box(p, 0);
                Map<BlockPos, BlockState> clip = new LinkedHashMap<>();
                for (BlockPos q : BlockPos.betweenClosed(b[0], b[1])) clip.put(q.subtract(b[0]).immutable(), l.getBlockState(q));
                s.clip = clip;
                return "Copied " + clip.size() + " blocks";
            }
            case "rotate" -> {
                if (s.clip == null) return "Clipboard is empty";
                Map<BlockPos, BlockState> r = new LinkedHashMap<>();
                int maxX = 0; for (BlockPos q : s.clip.keySet()) maxX = Math.max(maxX, q.getX());
                for (var e : s.clip.entrySet()) { BlockPos q = e.getKey(); r.put(new BlockPos(-q.getZ() + 0, q.getY(), q.getX()), e.getValue().rotate(Rotation.CLOCKWISE_90)); }
                int minX = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
                for (BlockPos q : r.keySet()) { minX = Math.min(minX, q.getX()); minZ = Math.min(minZ, q.getZ()); }
                Map<BlockPos, BlockState> n = new LinkedHashMap<>();
                for (var e : r.entrySet()) n.put(e.getKey().offset(-minX, 0, -minZ), e.getValue());
                s.clip = n;
                return "Clipboard rotated 90°";
            }
            case "flip" -> {
                if (s.clip == null) return "Clipboard is empty";
                int axis = Math.max(0, Math.min(2, p.n(0)));
                int max = 0;
                for (BlockPos q : s.clip.keySet()) max = Math.max(max, axis == 0 ? q.getX() : axis == 1 ? q.getY() : q.getZ());
                Map<BlockPos, BlockState> n = new LinkedHashMap<>();
                for (var en : s.clip.entrySet()) {
                    BlockPos q = en.getKey();
                    BlockPos nq = axis == 0 ? new BlockPos(max - q.getX(), q.getY(), q.getZ()) : axis == 1 ? new BlockPos(q.getX(), max - q.getY(), q.getZ()) : new BlockPos(q.getX(), q.getY(), max - q.getZ());
                    BlockState st = en.getValue();
                    if (axis == 0) st = st.mirror(net.minecraft.world.level.block.Mirror.FRONT_BACK);
                    else if (axis == 2) st = st.mirror(net.minecraft.world.level.block.Mirror.LEFT_RIGHT);
                    n.put(nq, st);
                }
                s.clip = n;
                return "Clipboard flipped along " + "XYZ".charAt(axis);
            }
            case "count" -> {
                BlockPos[] b = box(p, 0);
                Map<String, Integer> cnt = new HashMap<>();
                int solid = 0, total = 0;
                for (BlockPos q : BlockPos.betweenClosed(b[0], b[1])) {
                    total++;
                    BlockState st = l.getBlockState(q);
                    if (st.isAir()) continue;
                    solid++;
                    cnt.merge(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath(), 1, Integer::sum);
                }
                StringBuilder sb = new StringBuilder(solid + " / " + total + " blocks");
                cnt.entrySet().stream().sorted((x, y) -> y.getValue() - x.getValue()).limit(6).forEach(en -> sb.append(" · ").append(en.getKey()).append(' ').append(en.getValue()));
                return sb.toString();
            }
            case "tp" -> {
                double x = p.n(0) + 0.5, y = p.n(1), z = p.n(2) + 0.5;
                if (!l.isInWorldBounds(BlockPos.containing(x, y, z))) return "Out of the world";
                sp.teleportTo(x, y, z);
                return "Teleported to " + p.n(0) + " " + p.n(1) + " " + p.n(2);
            }
            case "fly" -> {
                var ab = sp.getAbilities();
                if (!sp.isSpectator()) { ab.mayfly = true; ab.flying = !ab.flying; }
                sp.onUpdateAbilities();
                return ab.flying ? "Flying (double-tap Space or press F again to land)" : "Flying off";
            }
        }
        Edit e = new Edit(l);
        String block = p.s(1).isBlank() ? "minecraft:stone" : p.s(1);
        String done;
        switch (op) {
            case "set" -> { e.set(new BlockPos(p.n(0), p.n(1), p.n(2)), picker(block).next()); done = "Placed " + block; }
            case "fill", "walls", "outline", "clear", "replace" -> {
                BlockPos[] b = box(p, 0);
                BlockState st = op.equals("clear") ? Blocks.AIR.defaultBlockState() : null;
                Conv.Picker pk = st == null ? picker(block) : null;
                BlockState from = op.equals("replace") ? (p.s(2).isBlank() ? null : Conv.block(p.s(2))) : null;
                for (BlockPos q : BlockPos.betweenClosed(b[0], b[1])) {
                    boolean edge = q.getX() == b[0].getX() || q.getX() == b[1].getX() || q.getZ() == b[0].getZ() || q.getZ() == b[1].getZ();
                    if (op.equals("walls") && !edge) continue;
                    if (op.equals("outline") && !edge && q.getY() != b[0].getY() && q.getY() != b[1].getY()) continue;
                    if (op.equals("replace")) {
                        BlockState cur = l.getBlockState(q);
                        if (from == null ? cur.isAir() : cur.getBlock() != from.getBlock()) continue;
                    }
                    e.set(q, st != null ? st : pk.next());
                }
                done = switch (op) { case "clear" -> "Cleared"; case "replace" -> "Replaced"; case "walls" -> "Walls"; case "outline" -> "Outline"; default -> "Filled"; } + " " + e.before.size() + " blocks";
            }
            case "brush", "erase", "paint", "smooth", "cube" -> {
                BlockPos c = new BlockPos(p.n(0), p.n(1), p.n(2));
                int r = Math.max(0, Math.min(32, p.n(3)));
                boolean hollow = p.n(4) == 1 && (op.equals("brush") || op.equals("cube"));
                Conv.Picker pk = picker(block);
                BlockState air = Blocks.AIR.defaultBlockState();
                if (op.equals("smooth")) {
                    // simple 3D majority filter: solid if most neighbours are solid
                    Map<BlockPos, Boolean> want = new HashMap<>();
                    for (BlockPos q : sphere(c, r, false)) {
                        int solid = 0, tot = 0;
                        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) { tot++; if (!l.getBlockState(q.offset(dx, dy, dz)).isAir()) solid++; }
                        want.put(q, solid * 2 > tot);
                    }
                    BlockState fill = Conv.block(block.split(",")[0].trim());
                    want.forEach((q, sol) -> { boolean has = !l.getBlockState(q).isAir(); if (sol && !has) e.set(q, fill); else if (!sol && has) e.set(q, air); });
                } else for (BlockPos q : sphere(c, r, op.equals("cube"), hollow)) {
                    BlockState cur = l.getBlockState(q);
                    switch (op) {
                        case "erase" -> { if (!cur.isAir()) e.set(q, air); }
                        case "paint" -> { if (!cur.isAir() && l.getBlockState(q.above()).isAir()) e.set(q, pk.next()); }
                        default -> e.set(q, pk.next());
                    }
                }
                done = op.substring(0, 1).toUpperCase(Locale.ROOT) + op.substring(1) + ": " + e.before.size() + " blocks";
            }
            case "hollow" -> {
                BlockPos[] b = box(p, 0);
                BlockState air = Blocks.AIR.defaultBlockState();
                for (BlockPos q : BlockPos.betweenClosed(b[0], b[1])) {
                    boolean face = q.getX() == b[0].getX() || q.getX() == b[1].getX() || q.getY() == b[0].getY() || q.getY() == b[1].getY() || q.getZ() == b[0].getZ() || q.getZ() == b[1].getZ();
                    if (!face) e.set(q, air);
                }
                done = "Hollowed: " + e.before.size() + " blocks removed";
            }
            case "naturalize" -> {
                BlockPos[] b = box(p, 0);
                BlockState grass = Blocks.GRASS_BLOCK.defaultBlockState(), dirt = Blocks.DIRT.defaultBlockState(), stone = Blocks.STONE.defaultBlockState();
                for (int x = b[0].getX(); x <= b[1].getX(); x++) for (int z = b[0].getZ(); z <= b[1].getZ(); z++) {
                    int depth = -1;
                    for (int y = b[1].getY(); y >= b[0].getY(); y--) {
                        BlockPos q = new BlockPos(x, y, z);
                        BlockState cur = l.getBlockState(q);
                        if (cur.isAir() || !cur.getFluidState().isEmpty() || !cur.isSolid()) { depth = -1; continue; }
                        depth++;
                        if (depth == 0 && y == b[1].getY() && !l.getBlockState(q.above()).isAir()) depth = 1;
                        e.set(q, depth == 0 ? grass : depth <= 3 ? dirt : stone);
                    }
                }
                done = "Naturalized " + e.before.size() + " blocks";
            }
            case "line" -> {
                BlockPos a = new BlockPos(p.n(0), p.n(1), p.n(2)), z = new BlockPos(p.n(3), p.n(4), p.n(5));
                int r = Math.max(0, Math.min(8, p.n(6)));
                Conv.Picker pk = picker(block);
                int steps = Math.max(1, Math.max(Math.abs(z.getX() - a.getX()), Math.max(Math.abs(z.getY() - a.getY()), Math.abs(z.getZ() - a.getZ()))));
                Set<BlockPos> pts = new LinkedHashSet<>();
                for (int i = 0; i <= steps; i++) {
                    double t = i / (double) steps;
                    BlockPos c = BlockPos.containing(a.getX() + (z.getX() - a.getX()) * t + 0.5, a.getY() + (z.getY() - a.getY()) * t + 0.5, a.getZ() + (z.getZ() - a.getZ()) * t + 0.5);
                    for (BlockPos q : sphere(c, r, false)) pts.add(q.immutable());
                }
                for (BlockPos q : pts) e.set(q, pk.next());
                done = "Line: " + e.before.size() + " blocks";
            }
            case "move" -> {
                BlockPos[] b = box(p, 0);
                int dx = p.n(6), dy = p.n(7), dz = p.n(8), dist = Math.max(1, Math.min(256, p.n(9)));
                List<Map.Entry<BlockPos, BlockState>> src = new ArrayList<>();
                for (BlockPos q : BlockPos.betweenClosed(b[0], b[1])) src.add(Map.entry(q.immutable(), l.getBlockState(q)));
                BlockState air = Blocks.AIR.defaultBlockState();
                for (var en : src) e.set(en.getKey(), air);
                for (var en : src) e.set(en.getKey().offset(dx * dist, dy * dist, dz * dist), en.getValue());
                done = "Moved " + src.size() + " blocks by " + dist;
            }
            case "paste" -> {
                if (s.clip == null) return "Clipboard is empty — select a region and Copy first";
                BlockPos o = new BlockPos(p.n(0), p.n(1), p.n(2));
                boolean skipAir = p.n(3) == 1;
                for (var en : s.clip.entrySet()) if (!skipAir || !en.getValue().isAir()) e.set(o.offset(en.getKey()), en.getValue());
                done = "Pasted " + e.before.size() + " blocks";
            }
            case "stack" -> {
                BlockPos[] b = box(p, 0);
                int dx = p.n(6), dy = p.n(7), dz = p.n(8), times = Math.max(1, Math.min(64, p.n(9)));
                int sx = b[1].getX() - b[0].getX() + 1, sy = b[1].getY() - b[0].getY() + 1, sz = b[1].getZ() - b[0].getZ() + 1;
                List<Map.Entry<BlockPos, BlockState>> src = new ArrayList<>();
                for (BlockPos q : BlockPos.betweenClosed(b[0], b[1])) src.add(Map.entry(q.immutable(), l.getBlockState(q)));
                for (int t = 1; t <= times; t++) for (var en : src) e.set(en.getKey().offset(dx * sx * t, dy * sy * t, dz * sz * t), en.getValue());
                done = "Stacked " + times + "x (" + e.before.size() + " blocks)";
            }
            default -> { return "Unknown World Editor operation " + op; }
        }
        if (!e.before.isEmpty()) {
            s.undo.addLast(new Change(l, e.before, e.after));
            while (s.undo.size() > 40) s.undo.pollFirst();
            s.redo.clear();
        }
        return done;
    }

    public static void forget(UUID id) { SESSIONS.remove(id); }
}
