package net.idea.fluwa.server;

import net.idea.fluwa.api.PlayerObj;
import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.Pkt;
import net.idea.fluwa.net.FluwaNet;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import org.luaj.vm2.LuaValue;

public final class ServerNet {
    private ServerNet() {}

    public static void handle(Pkt p, ServerPlayer sender) {
        ServerRuntime rt = ScriptManager.rt;
        switch (p.type) {
            case Pkt.C_REMOTE -> {
                if (rt == null) return;
                RemoteEvent ev = rt.remote(p.s(0));
                if (ev == null) { rt.output(1, "Event '" + p.s(0) + "' fired by " + sender.getGameProfile().getName() + " does not exist on the server"); return; }
                rt.within(() -> {
                    PlayerObj po = rt.wrap(sender);
                    LuaValue arg = LuaSer.decode(p.data, rt);
                    ev.onServerFire.fire(po, arg);
                    return null;
                });
            }
            case Pkt.C_ZREQUEST -> ScriptManager.openZSpace(sender);
            case Pkt.C_MODELPARTS -> net.idea.fluwa.api.ModelSync.clientParts(p.s);
            case Pkt.C_PROJ -> net.idea.fluwa.api.Projector.clicked(sender, p.n(0), p.n(1));
            case Pkt.C_TDK, Pkt.C_WEDIT, Pkt.C_ZITEM -> {
                if (!ScriptManager.isCreator(sender)) { sender.sendSystemMessage(Component.literal("§cYou are not a Creator")); return; }
                if (p.type == Pkt.C_TDK) TerrainDK.handle(p, sender);
                else if (p.type == Pkt.C_WEDIT) WorldEditor.handle(p, sender);
                else ZItems.handle(p, sender);
            }
            case Pkt.C_ZTREE, Pkt.C_ZPROPS, Pkt.C_ZSET, Pkt.C_ZINSERT, Pkt.C_ZACTION -> {
                if (!ScriptManager.isCreator(sender)) { sender.sendSystemMessage(Component.literal("§cYou are not a Creator")); return; }
                Explorer.handle(p, sender);
            }
            case Pkt.C_ZSAVE, Pkt.C_ZDELETE, Pkt.C_ZRELOAD, Pkt.C_ZRUN -> {
                if (!ScriptManager.isCreator(sender)) { sender.sendSystemMessage(Component.literal("§cYou are not a Creator")); return; }
                try {
                    if (p.type == Pkt.C_ZSAVE) { ScriptManager.save(p.s(0), p.s(1), p.s(2)); ScriptManager.log(0, sender.getGameProfile().getName() + " saved " + p.s(0) + "/" + p.s(1)); }
                    if (p.type == Pkt.C_ZDELETE) { ScriptManager.delete(p.s(0), p.s(1)); ScriptManager.log(0, sender.getGameProfile().getName() + " deleted " + p.s(0) + "/" + p.s(1)); }
                    if (p.type == Pkt.C_ZRUN) { if (rt != null) rt.runScript("ZSpace/console", p.s(0)); }
                    boolean reloaded = p.type == Pkt.C_ZRELOAD || p.n(0) == 1;
                    if (reloaded) ScriptManager.reload();
                    String done = switch (p.type) {
                        case Pkt.C_ZSAVE -> "Saved " + p.s(0) + "/" + p.s(1) + (reloaded ? " (scripts reloaded)" : " (press Reload to apply)");
                        case Pkt.C_ZDELETE -> "Deleted " + p.s(0) + "/" + p.s(1) + (reloaded ? " (scripts reloaded)" : "");
                        case Pkt.C_ZRUN -> "Executed on server";
                        default -> "Scripts reloaded";
                    };
                    FluwaNet.toPlayer(sender, new Pkt(Pkt.S_ZSTATUS, "1", done));
                } catch (Exception e) {
                    FluwaNet.toPlayer(sender, new Pkt(Pkt.S_ZSTATUS, "0", String.valueOf(e.getMessage())));
                    sender.sendSystemMessage(Component.literal("§c[Fluwa] " + e.getMessage()));
                }
            }
        }
    }
}
