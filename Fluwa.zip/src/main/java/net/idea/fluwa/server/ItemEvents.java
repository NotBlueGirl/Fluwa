package net.idea.fluwa.server;

import net.idea.fluwa.Fluwa;
import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.Vec3L;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.enchanting.EnchantmentLevelSetEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.luaj.vm2.LuaValue;

import java.util.function.Supplier;

/** Item.E_* events and Item.Can* restrictions. */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ItemEvents {
    private ItemEvents() {}

    static void fire(Level l, ItemStack st, String ev, Supplier<LuaValue[]> args) {
        GameRuntime r = ServerEvents.rt(l);
        if (r == null) return;
        ItemObj o = ItemObj.find(st, !l.isClientSide);
        if (o == null || !o.listens(ev)) return;
        o.stack = st;
        r.within(() -> { o.fire(ev, args.get()); return null; });
    }

    static LuaValue pl(Player p) { GameRuntime r = ServerEvents.rt(p.level()); return r == null ? LuaValue.NIL : r.wrap(p); }

    @SubscribeEvent
    public static void use(PlayerInteractEvent.RightClickItem e) {
        ItemStack st = e.getItemStack();
        if (ItemObj.data(st) == null) return;
        if (!ItemObj.flag(st, "CanUse")) { e.setCanceled(true); return; }
        String gui = ItemObj.guiName(st);
        if (gui != null && e.getEntity() instanceof ServerPlayer sp) { FluwaNet.toPlayer(sp, new Pkt(Pkt.S_SCREEN, gui)); e.setCanceled(true); }
        fire(e.getLevel(), st, "E_Used", () -> new LuaValue[]{pl(e.getEntity())});
    }

    @SubscribeEvent
    public static void attack(AttackEntityEvent e) {
        ItemStack st = e.getEntity().getMainHandItem();
        if (ItemObj.data(st) == null) return;
        if (!ItemObj.flag(st, "CanAttack")) { e.setCanceled(true); return; }
        GameRuntime r = ServerEvents.rt(e.getEntity().level());
        if (r == null) return;
        fire(e.getEntity().level(), st, "E_Attacked", () -> new LuaValue[]{pl(e.getEntity()), r.wrapEntity(e.getTarget())});
    }

    @SubscribeEvent
    public static void toss(ItemTossEvent e) {
        ItemStack st = e.getEntity().getItem();
        if (ItemObj.data(st) == null) return;
        if (!ItemObj.flag(st, "CanDrop")) {
            e.setCanceled(true);
            if (!e.getPlayer().getInventory().add(st.copy())) e.getPlayer().getInventory().placeItemBackInInventory(st.copy());
            return;
        }
        fire(e.getPlayer().level(), st, "E_Dropped", () -> new LuaValue[]{pl(e.getPlayer()), Vec3L.of(e.getEntity().position())});
    }

    @SubscribeEvent
    public static void pick(EntityItemPickupEvent e) {
        ItemStack st = e.getItem().getItem();
        if (ItemObj.data(st) == null) return;
        fire(e.getEntity().level(), st, "E_Picked", () -> new LuaValue[]{pl(e.getEntity())});
    }

    @SubscribeEvent
    public static void anvil(AnvilUpdateEvent e) {
        ItemStack l = e.getLeft(), rgt = e.getRight();
        if (ItemObj.data(l) == null || rgt.isEmpty()) return;
        boolean ench = !net.minecraft.world.item.enchantment.EnchantmentHelper.getEnchantments(rgt).isEmpty();
        if (ench && !ItemObj.flag(l, "CanEnchant")) e.setCanceled(true);
        else if (!ench && !ItemObj.flag(l, "CanRepair")) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void anvilDone(AnvilRepairEvent e) {
        ItemStack out = e.getOutput(), in = e.getLeft();
        if (ItemObj.data(out) == null) return;
        int gained = in.getDamageValue() - out.getDamageValue();
        if (gained > 0) fire(e.getEntity().level(), out, "E_Repaired",
                () -> new LuaValue[]{LuaValue.valueOf(gained), LuaValue.valueOf(out.getMaxDamage() - out.getDamageValue())});
    }

    @SubscribeEvent
    public static void enchantTable(EnchantmentLevelSetEvent e) {
        if (ItemObj.data(e.getItem()) != null && !ItemObj.flag(e.getItem(), "CanEnchant")) e.setEnchantLevel(0);
    }

    /** from ItemStackMixin.hurt (server thread, before the damage is applied) */
    public static void damaged(ItemStack st, int amount) {
        if (ItemObj.data(st) == null) return;
        ServerRuntime r = ScriptManager.rt;
        if (r == null || r.closed) return;
        ItemObj o = ItemObj.find(st, true);
        if (o == null || !o.listens("E_Damaged")) return;
        r.post(() -> { o.stack = st; o.fire("E_Damaged", LuaValue.valueOf(amount), LuaValue.valueOf(st.getMaxDamage() - st.getDamageValue())); });
    }
}
