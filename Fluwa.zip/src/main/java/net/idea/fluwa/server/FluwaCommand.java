package net.idea.fluwa.server;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.idea.fluwa.Config;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

/** /fluwa reload | run <lua> | scripts | zspace */
public final class FluwaCommand {
    private FluwaCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("fluwa")
            .then(Commands.literal("reload").requires(s -> s.hasPermission(Config.creatorPermissionLevel)).executes(c -> {
                ScriptManager.reload(); c.getSource().sendSuccess(() -> Component.literal("Fluwa scripts reloaded"), true); return 1; }))
            .then(Commands.literal("run").requires(s -> s.hasPermission(Config.creatorPermissionLevel))
                .then(Commands.argument("code", StringArgumentType.greedyString()).executes(c -> {
                    if (ScriptManager.rt == null) return 0;
                    ScriptManager.rt.runScript("command", StringArgumentType.getString(c, "code")); return 1; })))
            .then(Commands.literal("scripts").requires(s -> s.hasPermission(Config.creatorPermissionLevel)).executes(c -> {
                for (String f : ScriptManager.FOLDERS) {
                    var m = ScriptManager.read(f);
                    c.getSource().sendSuccess(() -> Component.literal("§b" + f + "§r: " + String.join(", ", m.keySet())), false);
                }
                return 1; }))
            .then(Commands.literal("zspace").executes(c -> {
                ScriptManager.openZSpace(c.getSource().getPlayerOrException()); return 1; })));
    }
}
