package net.idea.fluwa.client;

import com.mojang.blaze3d.audio.OggAudioStream;
import com.mojang.blaze3d.audio.SoundBuffer;
import net.idea.fluwa.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import org.luaj.vm2.LuaError;
import org.lwjgl.openal.AL10;

import javax.sound.sampled.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.*;
import java.util.*;

/**
 * Player:PlayLocalSound(path) - plays an .ogg / .wav file from the player's own device.
 * Paths are relative to <game folder>/fluwa/sounds/ (absolute paths only with fullOsAccess=true in the client config).
 */
public final class LocalAudio {
    private LocalAudio() {}
    private record Playing(int source) {}
    private static final List<Playing> PLAYING = new ArrayList<>();
    private static final Map<Path, Integer> CACHE = new HashMap<>();

    public static boolean isFile(String id) {
        String l = id.toLowerCase(Locale.ROOT);
        return l.endsWith(".ogg") || l.endsWith(".wav") || id.contains("/") && !id.contains(":") || id.contains("\\");
    }

    public static Path resolve(String path) {
        Path base = Minecraft.getInstance().gameDirectory.toPath().resolve("fluwa").resolve("sounds").toAbsolutePath().normalize();
        Path p = Paths.get(path);
        if (p.isAbsolute()) {
            if (!Config.fullOsAccess) throw new LuaError("Absolute sound paths need fullOsAccess=true (client config). Put files into " + base);
            return p.normalize();
        }
        Path r = base.resolve(path).normalize();
        if (!r.startsWith(base)) throw new LuaError("Sound path escapes the fluwa/sounds folder: " + path);
        return r;
    }

    static int load(Path f) throws IOException, UnsupportedAudioFileException {
        Integer cached = CACHE.get(f);
        if (cached != null) return cached;
        String n = f.getFileName().toString().toLowerCase(Locale.ROOT);
        ByteBuffer data; AudioFormat fmt;
        if (n.endsWith(".ogg")) {
            try (InputStream in = new BufferedInputStream(Files.newInputStream(f)); OggAudioStream ogg = new OggAudioStream(in)) {
                data = ogg.readAll(); fmt = ogg.getFormat();
            }
        } else {
            try (AudioInputStream src = AudioSystem.getAudioInputStream(new BufferedInputStream(Files.newInputStream(f)))) {
                AudioFormat base = src.getFormat();
                AudioFormat pcm = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, base.getSampleRate(), 16, Math.min(2, base.getChannels()),
                        Math.min(2, base.getChannels()) * 2, base.getSampleRate(), false);
                try (AudioInputStream conv = AudioSystem.getAudioInputStream(pcm, src)) {
                    byte[] all = conv.readAllBytes();
                    data = org.lwjgl.BufferUtils.createByteBuffer(all.length); data.put(all).flip(); fmt = pcm;
                }
            }
        }
        OptionalInt id = new SoundBuffer(data, fmt).releaseAlBuffer();
        if (id.isEmpty()) throw new IOException("can't decode");
        if (CACHE.size() > 64 && PLAYING.isEmpty()) freeBuffers();
        CACHE.put(f, id.getAsInt());
        return id.getAsInt();
    }

    public static void play(String path, float volume, float pitch) {
        Path f = resolve(path);
        if (!Files.isRegularFile(f)) throw new LuaError("Sound file not found: " + f);
        try {
            int buf = load(f);
            float master = Minecraft.getInstance().options.getSoundSourceVolume(SoundSource.MASTER);
            int src = AL10.alGenSources();
            AL10.alSourcei(src, AL10.AL_BUFFER, buf);
            AL10.alSourcei(src, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
            AL10.alSource3f(src, AL10.AL_POSITION, 0, 0, 0);
            AL10.alSourcef(src, AL10.AL_GAIN, Math.max(0, volume) * master);
            AL10.alSourcef(src, AL10.AL_PITCH, Math.max(0.05f, Math.min(4f, pitch)));
            AL10.alSourcePlay(src);
            PLAYING.add(new Playing(src));
        } catch (IOException | UnsupportedAudioFileException e) {
            throw new LuaError("Can't play " + f.getFileName() + ": " + e.getMessage() + " (supported: .ogg, .wav)");
        }
    }

    /** client tick: free finished sources */
    public static void tick() {
        if (PLAYING.isEmpty()) return;
        PLAYING.removeIf(p -> {
            if (AL10.alGetSourcei(p.source, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING) return false;
            AL10.alDeleteSources(p.source); return true;
        });
    }

    public static void stopAll() {
        for (Playing p : PLAYING) { AL10.alSourceStop(p.source); AL10.alDeleteSources(p.source); }
        PLAYING.clear();
        freeBuffers();
    }

    private static void freeBuffers() { CACHE.values().forEach(AL10::alDeleteBuffers); CACHE.clear(); }
}
