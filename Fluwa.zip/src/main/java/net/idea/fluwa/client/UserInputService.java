package net.idea.fluwa.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.idea.fluwa.client.ui.FluwaUiScreen;
import net.idea.fluwa.client.ui.TextBoxObj;
import net.idea.fluwa.client.ui.UiInput;
import net.idea.fluwa.lua.EvObj;
import net.idea.fluwa.lua.LObj;
import net.idea.fluwa.lua.Vec2L;
import net.minecraft.client.Minecraft;
import org.luaj.vm2.*;
import org.lwjgl.BufferUtils;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;
import org.lwjgl.glfw.GLFWImage;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * getAccess("UserInputService") - client-side keyboard / mouse / gamepad / window input.
 * Key codes are Roblox-style names ("W", "Space", "LeftShift"; Enum.KeyCode.Space == "Space").
 */
public final class UserInputService extends EvObj {
    static final Map<Integer, String> KEY_NAMES = new LinkedHashMap<>();
    static final Map<String, Integer> KEY_CODES = new HashMap<>();
    static void key(int code, String name) { KEY_NAMES.put(code, name); KEY_CODES.put(name.toLowerCase(Locale.ROOT), code); }
    static {
        for (char c = 'A'; c <= 'Z'; c++) key(GLFW.GLFW_KEY_A + (c - 'A'), String.valueOf(c));
        String[] digits = {"Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
        for (int i = 0; i < 10; i++) { key(GLFW.GLFW_KEY_0 + i, digits[i]); key(GLFW.GLFW_KEY_KP_0 + i, "Keypad" + digits[i]); }
        for (int i = 1; i <= 25; i++) key(GLFW.GLFW_KEY_F1 + i - 1, "F" + i);
        key(GLFW.GLFW_KEY_SPACE, "Space"); key(GLFW.GLFW_KEY_ENTER, "Return"); key(GLFW.GLFW_KEY_ESCAPE, "Escape");
        key(GLFW.GLFW_KEY_TAB, "Tab"); key(GLFW.GLFW_KEY_BACKSPACE, "Backspace"); key(GLFW.GLFW_KEY_DELETE, "Delete");
        key(GLFW.GLFW_KEY_INSERT, "Insert"); key(GLFW.GLFW_KEY_HOME, "Home"); key(GLFW.GLFW_KEY_END, "End");
        key(GLFW.GLFW_KEY_PAGE_UP, "PageUp"); key(GLFW.GLFW_KEY_PAGE_DOWN, "PageDown");
        key(GLFW.GLFW_KEY_UP, "Up"); key(GLFW.GLFW_KEY_DOWN, "Down"); key(GLFW.GLFW_KEY_LEFT, "Left"); key(GLFW.GLFW_KEY_RIGHT, "Right");
        key(GLFW.GLFW_KEY_LEFT_SHIFT, "LeftShift"); key(GLFW.GLFW_KEY_RIGHT_SHIFT, "RightShift");
        key(GLFW.GLFW_KEY_LEFT_CONTROL, "LeftControl"); key(GLFW.GLFW_KEY_RIGHT_CONTROL, "RightControl");
        key(GLFW.GLFW_KEY_LEFT_ALT, "LeftAlt"); key(GLFW.GLFW_KEY_RIGHT_ALT, "RightAlt");
        key(GLFW.GLFW_KEY_LEFT_SUPER, "LeftSuper"); key(GLFW.GLFW_KEY_RIGHT_SUPER, "RightSuper");
        key(GLFW.GLFW_KEY_CAPS_LOCK, "CapsLock"); key(GLFW.GLFW_KEY_NUM_LOCK, "NumLock"); key(GLFW.GLFW_KEY_SCROLL_LOCK, "ScrollLock");
        key(GLFW.GLFW_KEY_PRINT_SCREEN, "Print"); key(GLFW.GLFW_KEY_PAUSE, "Pause"); key(GLFW.GLFW_KEY_MENU, "Menu");
        key(GLFW.GLFW_KEY_MINUS, "Minus"); key(GLFW.GLFW_KEY_EQUAL, "Equals"); key(GLFW.GLFW_KEY_LEFT_BRACKET, "LeftBracket");
        key(GLFW.GLFW_KEY_RIGHT_BRACKET, "RightBracket"); key(GLFW.GLFW_KEY_BACKSLASH, "BackSlash"); key(GLFW.GLFW_KEY_SEMICOLON, "Semicolon");
        key(GLFW.GLFW_KEY_APOSTROPHE, "Quote"); key(GLFW.GLFW_KEY_GRAVE_ACCENT, "Backquote"); key(GLFW.GLFW_KEY_COMMA, "Comma");
        key(GLFW.GLFW_KEY_PERIOD, "Period"); key(GLFW.GLFW_KEY_SLASH, "Slash");
        key(GLFW.GLFW_KEY_KP_DECIMAL, "KeypadPeriod"); key(GLFW.GLFW_KEY_KP_DIVIDE, "KeypadDivide"); key(GLFW.GLFW_KEY_KP_MULTIPLY, "KeypadMultiply");
        key(GLFW.GLFW_KEY_KP_SUBTRACT, "KeypadMinus"); key(GLFW.GLFW_KEY_KP_ADD, "KeypadPlus"); key(GLFW.GLFW_KEY_KP_ENTER, "KeypadEnter");
        key(GLFW.GLFW_KEY_KP_EQUAL, "KeypadEquals");
        KEY_CODES.put("enter", GLFW.GLFW_KEY_ENTER); KEY_CODES.put("leftctrl", GLFW.GLFW_KEY_LEFT_CONTROL); KEY_CODES.put("rightctrl", GLFW.GLFW_KEY_RIGHT_CONTROL);
    }
    static final String[] PAD_BUTTONS = {"ButtonA", "ButtonB", "ButtonX", "ButtonY", "ButtonL1", "ButtonR1", "ButtonSelect", "ButtonStart",
            "ButtonHome", "ButtonL3", "ButtonR3", "DPadUp", "DPadRight", "DPadDown", "DPadLeft"};
    static final String[] PAD_AXES = {"Thumbstick1X", "Thumbstick1Y", "Thumbstick2X", "Thumbstick2Y", "TriggerL", "TriggerR"};

    static String last(String s) { return s.contains(".") ? s.substring(s.lastIndexOf('.') + 1) : s; }
    public static String keyName(int code) { return KEY_NAMES.getOrDefault(code, "Unknown"); }
    public static int keyCode(LuaValue v) {
        if (v.isnumber()) return v.toint();
        return KEY_CODES.getOrDefault(last(v.tojstring()).toLowerCase(Locale.ROOT), -1);
    }
    static int mouseCode(LuaValue v) {
        if (v.isnumber()) return Math.max(0, v.toint() - 1);
        String s = last(v.tojstring()).toLowerCase(Locale.ROOT);
        switch (s) { case "left": case "mousebutton1": return 0; case "right": case "mousebutton2": return 1; case "middle": case "mousebutton3": return 2; }
        try { return s.startsWith("mousebutton") ? Math.max(0, Integer.parseInt(s.substring(11)) - 1) : -1; } catch (NumberFormatException e) { return -1; }
    }
    static int padButton(LuaValue v) {
        if (v.isnumber()) return v.toint();
        String s = last(v.tojstring());
        for (int i = 0; i < PAD_BUTTONS.length; i++) if (PAD_BUTTONS[i].equalsIgnoreCase(s)) return i;
        if (s.equalsIgnoreCase("ButtonL2")) return 100;
        if (s.equalsIgnoreCase("ButtonR2")) return 101;
        return -1;
    }
    static int padAxis(LuaValue v) {
        if (v.isnumber()) return v.toint();
        String s = last(v.tojstring());
        for (int i = 0; i < PAD_AXES.length; i++) if (PAD_AXES[i].equalsIgnoreCase(s)) return i;
        return -1;
    }
    static int padNum(LuaValue v) {
        if (v.isnil()) return 1;
        if (v.isnumber()) return v.toint();
        String s = v.tojstring().replaceAll("[^0-9]", "");
        return s.isEmpty() ? 1 : Integer.parseInt(s);
    }

    // ------------------------------------------------------------------ InputObject
    public static final class InputObject extends LObj {
        final String keyCode, button, type, state;
        final Vec2L pos, delta, velocity;
        final int gamepad;
        InputObject(String keyCode, String button, String type, String state, Vec2L pos, Vec2L delta, int gamepad) {
            super("InputObject");
            this.keyCode = keyCode; this.button = button; this.type = type; this.state = state;
            this.pos = pos; this.delta = delta; this.gamepad = gamepad;
            this.velocity = new Vec2L(delta.x * 20, delta.y * 20);
        }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "KeyCode": return valueOf(keyCode);
                case "Button": return valueOf(button);
                case "Position": return pos;
                case "Delta": return delta;
                case "UserInputType": return valueOf(type);
                case "UserInputState": return valueOf(state);
                case "GamepadNum": return valueOf(gamepad);
                case "TouchCount": return valueOf(0);
                case "Velocity": return velocity;
            }
            return super.getProp(k);
        }
        @Override public String tojstring() { return "InputObject(" + type + ", " + (keyCode.equals("Unknown") ? button : keyCode) + ", " + state + ")"; }
        static {
            reg(InputObject.class, "GetKeyCode", (s, a) -> valueOf(((InputObject) s).keyCode));
            reg(InputObject.class, "GetButton", (s, a) -> valueOf(((InputObject) s).button));
            reg(InputObject.class, "GetPosition", (s, a) -> ((InputObject) s).pos);
            reg(InputObject.class, "GetDelta", (s, a) -> ((InputObject) s).delta);
            reg(InputObject.class, "GetUserInputType", (s, a) -> valueOf(((InputObject) s).type));
            reg(InputObject.class, "GetUserInputState", (s, a) -> valueOf(((InputObject) s).state));
            reg(InputObject.class, "GetGamepadNum", (s, a) -> valueOf(((InputObject) s).gamepad));
            reg(InputObject.class, "IsGamepadButtonDown", (s, a) -> valueOf(padDown(Math.max(1, ((InputObject) s).gamepad), padButton(a.arg1()))));
            reg(InputObject.class, "IsKeyDown", (s, a) -> valueOf(keyDown(keyCode(a.arg1()))));
            reg(InputObject.class, "IsMouseButtonDown", (s, a) -> valueOf(mouseDown(mouseCode(a.arg1()))));
        }
    }

    // ------------------------------------------------------------------ state
    final ClientRuntime crt;
    String mouseBehavior = "Default", mouseIcon = "", inputType = "Keyboard";
    boolean iconEnabled = true, overrideIcon, touchEnabled, keyboardEnabled = true, gamepadEnabled = true, mouseEnabled = true;
    double deltaSensitivity = 1, wheelDelta;
    double lastX = Double.NaN, lastY, dX, dY, lockX = -1, lockY = -1;
    boolean hovered = true, focused = true, minimized, fullscreen;
    int winW, winH, wheelFrame;
    TextBoxObj lastBox;
    final boolean[] padPresent = new boolean[16];
    final boolean[][] padButtons = new boolean[16][17];
    final float[][] padAxes = new float[16][6];
    static long customCursor, appliedCursor;
    static boolean cursorHidden;

    public UserInputService(ClientRuntime r) { super("UserInputService"); this.crt = r; }

    static final Set<String> EVENTS = new HashSet<>(Arrays.asList(
            "E_InputBegan", "E_InputEnded", "E_InputChanged", "E_InputFocused", "E_InputBlurred", "E_MouseEnter", "E_MouseLeave", "E_MouseMoved",
            "E_MouseWheel", "E_MouseButton1Down", "E_MouseButton1Up", "E_MouseButton2Down", "E_MouseButton2Up", "E_MouseButton3Down", "E_MouseButton3Up",
            "E_TouchStarted", "E_TouchEnded", "E_TouchMoved", "E_TouchTap", "E_TouchLongPress", "E_TouchPan", "E_TouchPinch", "E_TouchRotate", "E_TouchSwipe",
            "E_GamepadConnected", "E_GamepadDisconnected", "E_GamepadButtonDown", "E_GamepadButtonUp", "E_GamepadAxisChanged",
            "E_KeyboardKeyDown", "E_KeyboardKeyUp", "E_KeyboardKeyRepeat", "E_WindowFocused", "E_WindowFocusReleased", "E_WindowResized",
            "E_WindowMinimized", "E_WindowRestored", "E_WindowFullscreenChanged", "E_DeviceMotion", "E_AccelerometerChanged", "E_GyroscopeChanged",
            "E_VREnabled", "E_VRDisabled", "E_LastInputTypeChanged", "E_TextBoxFocused", "E_TextBoxFocusReleased",
            "E_ChildAdded", "E_ChildRemoved", "E_AttributeChanged"));
    @Override protected Collection<String> eventNames() { return EVENTS; }

    static Minecraft mc() { return Minecraft.getInstance(); }
    static long win() { return mc().getWindow().getWindow(); }
    static UserInputService cur() { ClientRuntime r = ClientEvents.rt(); return r == null ? null : r.uis; }

    static boolean keyDown(int code) { return code >= 0 && GLFW.glfwGetKey(win(), code) == GLFW.GLFW_PRESS; }
    static boolean mouseDown(int b) { return b >= 0 && b < 8 && GLFW.glfwGetMouseButton(win(), b) == GLFW.GLFW_PRESS; }
    static boolean padDown(int num, int b) {
        int j = num - 1;
        if (j < 0 || j > 15 || b < 0 || !GLFW.glfwJoystickIsGamepad(j)) return false;
        try (GLFWGamepadState st = GLFWGamepadState.malloc()) {
            if (!GLFW.glfwGetGamepadState(j, st)) return false;
            if (b == 100) return st.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_TRIGGER) > 0.5f;
            if (b == 101) return st.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_TRIGGER) > 0.5f;
            return b < 15 && st.buttons(b) == GLFW.GLFW_PRESS;
        }
    }
    static float padAxisValue(int num, int a) {
        int j = num - 1;
        if (j < 0 || j > 15 || a < 0 || a > 5 || !GLFW.glfwJoystickIsGamepad(j)) return 0;
        try (GLFWGamepadState st = GLFWGamepadState.malloc()) { return GLFW.glfwGetGamepadState(j, st) ? st.axes(a) : 0; }
    }

    /** mouse position in GUI-scaled units (same space as ScreenGUI / Overlay objects) */
    static Vec2L mousePos() {
        var w = mc().getWindow();
        double s = w.getGuiScaledWidth() / (double) Math.max(1, w.getScreenWidth());
        return new Vec2L(mc().mouseHandler.xpos() * s, mc().mouseHandler.ypos() * s);
    }
    static boolean gameProcessed() { return (mc().screen != null && !(mc().screen instanceof FluwaUiScreen)) || UiInput.focus != null; }
    static Vec2L zero() { return new Vec2L(0, 0); }

    void emit(String ev, LuaValue... a) {
        if (crt.closed || !listens(ev)) return;
        crt.within(() -> { fire(ev, a); return null; });
    }
    void setInputType(String t) {
        if (t.equals(inputType)) return;
        inputType = t;
        emit("E_LastInputTypeChanged", valueOf(t));
    }

    // ------------------------------------------------------------------ hooks (ClientEvents)
    public static void onKey(int key, int action) {
        UserInputService u = cur();
        if (u == null || !u.keyboardEnabled) return;
        String n = keyName(key);
        u.setInputType("Keyboard");
        if (action == GLFW.GLFW_REPEAT) { u.emit("E_KeyboardKeyRepeat", valueOf(n)); return; }
        boolean down = action == GLFW.GLFW_PRESS;
        InputObject io = new InputObject(n, "", "Keyboard", down ? "Begin" : "End", mousePos(), zero(), 0);
        u.emit(down ? "E_InputBegan" : "E_InputEnded", io, valueOf(gameProcessed()));
        u.emit(down ? "E_KeyboardKeyDown" : "E_KeyboardKeyUp", valueOf(n));
    }

    public static void onMouse(int button, int action) {
        UserInputService u = cur();
        if (u == null || !u.mouseEnabled) return;
        boolean down = action == GLFW.GLFW_PRESS;
        String b = "MouseButton" + (button + 1);
        InputObject io = new InputObject("Unknown", b, b, down ? "Begin" : "End", mousePos(), zero(), 0);
        u.setInputType("Keyboard");
        u.emit(down ? "E_InputBegan" : "E_InputEnded", io, valueOf(gameProcessed()));
        if (button <= 2) u.emit("E_" + b + (down ? "Down" : "Up"), io);
    }

    public static void onScroll(double d) {
        UserInputService u = cur();
        if (u == null || !u.mouseEnabled) return;
        u.wheelDelta = d; u.wheelFrame = 0;
        InputObject io = new InputObject("Unknown", "", "MouseWheel", "Change", mousePos(), new Vec2L(0, d), 0);
        u.emit("E_InputChanged", io, valueOf(gameProcessed()));
        u.emit("E_MouseWheel", io);
    }

    /** every frame: mouse movement, window state, text box focus, cursor behaviour */
    public static void frame() {
        UserInputService u = cur();
        if (u == null || u.crt.closed) return;
        Minecraft mc = mc();
        long w = win();
        double x = mc.mouseHandler.xpos(), y = mc.mouseHandler.ypos();
        if (Double.isNaN(u.lastX)) { u.lastX = x; u.lastY = y; }
        u.dX = (x - u.lastX) * u.deltaSensitivity; u.dY = (y - u.lastY) * u.deltaSensitivity;
        u.lastX = x; u.lastY = y;
        if (u.wheelFrame++ > 1) u.wheelDelta = 0;
        if ((u.dX != 0 || u.dY != 0) && u.mouseEnabled) {
            InputObject io = new InputObject("Unknown", "", "MouseMovement", "Change", mousePos(), new Vec2L(u.dX, u.dY), 0);
            u.emit("E_MouseMoved", io);
            u.emit("E_InputChanged", io, valueOf(gameProcessed()));
        }
        boolean hov = GLFW.glfwGetWindowAttrib(w, GLFW.GLFW_HOVERED) == 1;
        if (hov != u.hovered) { u.hovered = hov; u.emit(hov ? "E_MouseEnter" : "E_MouseLeave"); }
        boolean foc = GLFW.glfwGetWindowAttrib(w, GLFW.GLFW_FOCUSED) == 1;
        if (foc != u.focused) {
            u.focused = foc;
            u.emit(foc ? "E_WindowFocused" : "E_WindowFocusReleased");
            u.emit(foc ? "E_InputFocused" : "E_InputBlurred", new InputObject("Unknown", "", "Focus", foc ? "Begin" : "End", mousePos(), zero(), 0));
        }
        boolean min = GLFW.glfwGetWindowAttrib(w, GLFW.GLFW_ICONIFIED) == 1;
        if (min != u.minimized) { u.minimized = min; u.emit(min ? "E_WindowMinimized" : "E_WindowRestored"); }
        boolean fs = mc.getWindow().isFullscreen();
        if (fs != u.fullscreen) { u.fullscreen = fs; u.emit("E_WindowFullscreenChanged", valueOf(fs)); }
        int ww = mc.getWindow().getWidth(), wh = mc.getWindow().getHeight();
        if (u.winW != 0 && (ww != u.winW || wh != u.winH)) u.emit("E_WindowResized", new Vec2L(ww, wh));
        u.winW = ww; u.winH = wh;
        TextBoxObj tb = UiInput.focus;
        if (tb != u.lastBox) {
            if (u.lastBox != null) u.emit("E_TextBoxFocusReleased", u.lastBox);
            if (tb != null) u.emit("E_TextBoxFocused", tb);
            u.lastBox = tb;
        }
        boolean grabbed = mc.mouseHandler.isMouseGrabbed();
        if (!grabbed) {
            if (u.mouseBehavior.equals("LockCenter")) GLFW.glfwSetCursorPos(w, ww / 2.0, wh / 2.0);
            else if (u.mouseBehavior.equals("LockCurrentPosition")) {
                if (u.lockX < 0) { u.lockX = x; u.lockY = y; }
                GLFW.glfwSetCursorPos(w, u.lockX, u.lockY);
            }
            boolean hide = !u.iconEnabled;
            if (hide != cursorHidden) { cursorHidden = hide; GLFW.glfwSetInputMode(w, GLFW.GLFW_CURSOR, hide ? GLFW.GLFW_CURSOR_HIDDEN : GLFW.GLFW_CURSOR_NORMAL); }
            boolean vanillaScreen = mc.screen != null && !(mc.screen instanceof FluwaUiScreen);
            long want = customCursor != 0 && (u.overrideIcon || !vanillaScreen) ? customCursor : 0;
            if (want != appliedCursor) { GLFW.glfwSetCursor(w, want); appliedCursor = want; }
        } else cursorHidden = false;
        if (!u.mouseBehavior.equals("LockCurrentPosition")) u.lockX = -1;
    }

    /** every client tick: gamepads */
    public static void tick() {
        UserInputService u = cur();
        if (u == null || u.crt.closed || !u.gamepadEnabled) return;
        try (GLFWGamepadState st = GLFWGamepadState.malloc()) {
            for (int j = 0; j < 16; j++) {
                boolean present = GLFW.glfwJoystickPresent(j) && GLFW.glfwJoystickIsGamepad(j);
                int num = j + 1;
                if (present != u.padPresent[j]) {
                    u.padPresent[j] = present;
                    u.emit(present ? "E_GamepadConnected" : "E_GamepadDisconnected", valueOf(num));
                    if (!present) { Arrays.fill(u.padButtons[j], false); Arrays.fill(u.padAxes[j], 0); }
                }
                if (!present || !GLFW.glfwGetGamepadState(j, st)) continue;
                String type = "Gamepad" + num;
                for (int b = 0; b < 17; b++) {
                    boolean down = b < 15 ? st.buttons(b) == GLFW.GLFW_PRESS : st.axes(b == 15 ? GLFW.GLFW_GAMEPAD_AXIS_LEFT_TRIGGER : GLFW.GLFW_GAMEPAD_AXIS_RIGHT_TRIGGER) > 0.5f;
                    if (down == u.padButtons[j][b]) continue;
                    u.padButtons[j][b] = down;
                    String n = b < 15 ? PAD_BUTTONS[b] : b == 15 ? "ButtonL2" : "ButtonR2";
                    u.setInputType("Gamepad");
                    u.emit(down ? "E_GamepadButtonDown" : "E_GamepadButtonUp", valueOf(num), valueOf(n));
                    u.emit(down ? "E_InputBegan" : "E_InputEnded", new InputObject(n, n, type, down ? "Begin" : "End", mousePos(), zero(), num), valueOf(gameProcessed()));
                }
                for (int a = 0; a < 6; a++) {
                    float v = st.axes(a);
                    if (Math.abs(v - u.padAxes[j][a]) < 0.02f) continue;
                    u.padAxes[j][a] = v;
                    u.setInputType("Gamepad");
                    u.emit("E_GamepadAxisChanged", valueOf(num), valueOf(PAD_AXES[a]), valueOf(v));
                    Vec2L d = a <= 1 ? new Vec2L(st.axes(0), st.axes(1)) : a <= 3 ? new Vec2L(st.axes(2), st.axes(3)) : new Vec2L(v, 0);
                    u.emit("E_InputChanged", new InputObject(PAD_AXES[a], PAD_AXES[a], type, "Change", d, d, num), valueOf(gameProcessed()));
                }
            }
        }
    }

    /** keyboard disabled by a script -> the player does not move */
    public static boolean blockMovement() { UserInputService u = cur(); return u != null && !u.keyboardEnabled; }

    /** restores the system cursor (runtime stopped / logout) */
    public static void restore() {
        try {
            long w = win();
            if (appliedCursor != 0) GLFW.glfwSetCursor(w, 0);
            if (customCursor != 0) GLFW.glfwDestroyCursor(customCursor);
            if (cursorHidden && !mc().mouseHandler.isMouseGrabbed()) GLFW.glfwSetInputMode(w, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL);
        } catch (Throwable ignored) {}
        customCursor = appliedCursor = 0; cursorHidden = false;
    }

    // ------------------------------------------------------------------ cursor icon
    void setIcon(String id) {
        mouseIcon = id == null ? "" : id;
        long old = customCursor;
        customCursor = 0;
        if (!mouseIcon.isEmpty()) {
            int std = switch (mouseIcon.toLowerCase(Locale.ROOT)) {
                case "arrow" -> GLFW.GLFW_ARROW_CURSOR; case "ibeam", "text" -> GLFW.GLFW_IBEAM_CURSOR; case "crosshair" -> GLFW.GLFW_CROSSHAIR_CURSOR;
                case "hand", "pointer" -> GLFW.GLFW_HAND_CURSOR; case "hresize" -> GLFW.GLFW_HRESIZE_CURSOR; case "vresize" -> GLFW.GLFW_VRESIZE_CURSOR;
                default -> 0;
            };
            customCursor = std != 0 ? GLFW.glfwCreateStandardCursor(std) : loadCursor(mouseIcon);
        }
        if (old != 0) {
            if (appliedCursor == old) { GLFW.glfwSetCursor(win(), 0); appliedCursor = 0; }
            GLFW.glfwDestroyCursor(old);
        }
        if (!mouseIcon.isEmpty() && customCursor == 0)
            throw new LuaError("Can't load mouse icon " + mouseIcon + " (file in .minecraft/fluwa/images, a resource id or Arrow/IBeam/Crosshair/Hand/HResize/VResize)");
    }

    static long loadCursor(String img) {
        NativeImage ni = null;
        try {
            if (img.contains(":") && !img.matches("^[A-Za-z]:[\\\\/].*")) {
                var rl = net.minecraft.resources.ResourceLocation.tryParse(img);
                if (rl == null) return 0;
                var res = mc().getResourceManager().getResource(rl);
                if (res.isEmpty()) return 0;
                try (InputStream in = res.get().open()) { ni = NativeImage.read(in); }
            } else {
                Path p = mc().gameDirectory.toPath().resolve("fluwa").resolve("images").resolve(img).normalize();
                try (InputStream in = Files.newInputStream(p)) { ni = NativeImage.read(in); }
            }
            int w = ni.getWidth(), h = ni.getHeight();
            ByteBuffer buf = BufferUtils.createByteBuffer(w * h * 4);
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int c = ni.getPixelRGBA(x, y); // ABGR
                buf.put((byte) (c & 255)).put((byte) (c >> 8 & 255)).put((byte) (c >> 16 & 255)).put((byte) (c >>> 24));
            }
            buf.flip();
            try (GLFWImage gi = GLFWImage.malloc()) {
                gi.set(w, h, buf);
                return GLFW.glfwCreateCursor(gi, 0, 0);
            }
        } catch (Exception e) {
            return 0;
        } finally { if (ni != null) ni.close(); }
    }

    // ------------------------------------------------------------------ Lua API
    static String platform() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        return os.contains("win") ? "Windows" : os.contains("mac") ? "Mac" : "Linux";
    }
    LuaTable keysPressed() {
        LuaTable t = new LuaTable();
        for (var e : KEY_NAMES.entrySet()) if (keyDown(e.getKey())) t.insert(0, new InputObject(e.getValue(), "", "Keyboard", "Begin", mousePos(), zero(), 0));
        return t;
    }
    LuaTable buttonsPressed() {
        LuaTable t = new LuaTable();
        for (int b = 0; b < 8; b++) if (mouseDown(b)) t.insert(0, new InputObject("Unknown", "MouseButton" + (b + 1), "MouseButton" + (b + 1), "Begin", mousePos(), zero(), 0));
        return t;
    }
    static boolean padOk(int j) { return GLFW.glfwJoystickPresent(j) && GLFW.glfwJoystickIsGamepad(j); }
    static LuaTable connected() {
        LuaTable t = new LuaTable();
        for (int j = 0; j < 16; j++) if (padOk(j)) t.insert(0, valueOf(j + 1));
        return t;
    }
    static LuaTable connectedFlags() {
        LuaTable t = new LuaTable();
        for (int j = 0; j < 8; j++) t.set(j + 1, valueOf(padOk(j)));
        return t;
    }
    static LuaTable padState(int num) {
        LuaTable t = new LuaTable();
        for (int b = 0; b < PAD_BUTTONS.length; b++) t.set(PAD_BUTTONS[b], valueOf(padDown(num, b)));
        t.set("ButtonL2", valueOf(padDown(num, 100))); t.set("ButtonR2", valueOf(padDown(num, 101)));
        for (int a = 0; a < PAD_AXES.length; a++) t.set(PAD_AXES[a], valueOf(padAxisValue(num, a)));
        t.set("Connected", valueOf(num >= 1 && num <= 16 && padOk(num - 1)));
        return t;
    }
    static Vec2L cursorPx() { return new Vec2L(mc().mouseHandler.xpos(), mc().mouseHandler.ypos()); }
    static void setCursorPx(LuaValue v) { Vec2L p = Vec2L.check(v); GLFW.glfwSetCursorPos(win(), p.x, p.y); }
    void setBehavior(String b) {
        b = last(b);
        if (!Set.of("Default", "LockCenter", "LockCurrentPosition").contains(b)) throw new LuaError("MouseBehavior must be Default, LockCenter or LockCurrentPosition");
        mouseBehavior = b; lockX = -1;
    }
    static void setFullscreen(boolean f) {
        if (mc().getWindow().isFullscreen() != f) { mc().getWindow().toggleFullScreen(); mc().options.fullscreen().set(mc().getWindow().isFullscreen()); }
    }
    static double sensitivity() { return mc().options.sensitivity().get(); }
    static void setSensitivity(double v) { mc().options.sensitivity().set(Math.max(0, Math.min(1, v))); }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "MouseBehavior": return valueOf(mouseBehavior);
            case "MouseIconEnabled": return valueOf(iconEnabled);
            case "MouseIcon": return valueOf(mouseIcon);
            case "MouseDeltaSensitivity": return valueOf(deltaSensitivity);
            case "TouchEnabled": return valueOf(touchEnabled);
            case "KeyboardEnabled": return valueOf(keyboardEnabled);
            case "MouseEnabled": return valueOf(mouseEnabled);
            case "GamepadEnabled": return valueOf(gamepadEnabled && connected().length() > 0);
            case "AccelerometerEnabled": case "GyroscopeEnabled": case "VREnabled": return FALSE;
            case "Platform": return valueOf(platform());
            case "DeviceType": return valueOf("Desktop");
            case "InputType": return valueOf(inputType);
            case "FocusedTextBox": return UiInput.focus == null ? NIL : UiInput.focus;
            case "WindowFocused": return valueOf(GLFW.glfwGetWindowAttrib(win(), GLFW.GLFW_FOCUSED) == 1);
            case "WindowSize": return new Vec2L(mc().getWindow().getWidth(), mc().getWindow().getHeight());
            case "WindowPosition": return new Vec2L(mc().getWindow().getX(), mc().getWindow().getY());
            case "WindowMinimized": return valueOf(GLFW.glfwGetWindowAttrib(win(), GLFW.GLFW_ICONIFIED) == 1);
            case "WindowFullscreen": return valueOf(mc().getWindow().isFullscreen());
            case "CursorPosition": return cursorPx();
            case "MouseSensitivity": return valueOf(sensitivity());
            case "GamepadConnected": return connectedFlags();
            case "ConnectedGamepads": return connected();
            case "OverrideMouseIcon": return valueOf(overrideIcon);
            case "MouseWheelDelta": return valueOf(wheelDelta);
        }
        return super.getProp(k);
    }

    static final Set<String> READ_ONLY = Set.of("TouchEnabled", "KeyboardEnabled", "MouseEnabled", "GamepadEnabled", "AccelerometerEnabled", "GyroscopeEnabled",
            "VREnabled", "Platform", "DeviceType", "InputType", "FocusedTextBox", "WindowFocused", "WindowSize", "WindowPosition", "WindowMinimized",
            "GamepadConnected", "ConnectedGamepads", "MouseWheelDelta");

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "MouseBehavior": setBehavior(v.checkjstring()); return true;
            case "MouseIconEnabled": iconEnabled = v.toboolean(); return true;
            case "MouseIcon": setIcon(v.isnil() ? "" : v.tojstring()); return true;
            case "MouseDeltaSensitivity": deltaSensitivity = v.checkdouble(); return true;
            case "WindowFullscreen": setFullscreen(v.toboolean()); return true;
            case "CursorPosition": setCursorPx(v); return true;
            case "MouseSensitivity": setSensitivity(v.checkdouble()); return true;
            case "OverrideMouseIcon": overrideIcon = v.toboolean(); return true;
        }
        if (READ_ONLY.contains(k)) throw new LuaError(k + " of UserInputService is read-only" + (k.endsWith("Enabled") ? " (use Set" + k + ")" : ""));
        return super.setProp(k, v);
    }

    static UserInputService u(LObj s) { return (UserInputService) s; }
    static {
        Class<?> C = UserInputService.class;
        reg(C, "IsKeyDown", (s, a) -> valueOf(keyDown(keyCode(a.arg1()))));
        reg(C, "IsMouseButtonPressed|IsMouseButtonDown", (s, a) -> valueOf(mouseDown(mouseCode(a.arg1()))));
        reg(C, "IsGamepadButtonDown", (s, a) -> a.narg() >= 2 ? valueOf(padDown(padNum(a.arg1()), padButton(a.arg(2)))) : valueOf(padDown(1, padButton(a.arg1()))));
        reg(C, "IsGamepadEnabled", (s, a) -> valueOf(u(s).gamepadEnabled && connected().length() > 0));
        reg(C, "IsTouchEnabled", (s, a) -> valueOf(u(s).touchEnabled));
        reg(C, "IsKeyboardEnabled", (s, a) -> valueOf(u(s).keyboardEnabled));
        reg(C, "IsMouseEnabled", (s, a) -> valueOf(u(s).mouseEnabled));
        reg(C, "GetMouseLocation", (s, a) -> mousePos());
        reg(C, "GetMouseDelta", (s, a) -> new Vec2L(u(s).dX, u(s).dY));
        reg(C, "GetKeysPressed", (s, a) -> u(s).keysPressed());
        reg(C, "GetMouseButtonsPressed", (s, a) -> u(s).buttonsPressed());
        reg(C, "GetGamepadState", (s, a) -> padState(padNum(a.arg1())));
        reg(C, "GetConnectedGamepads", (s, a) -> connected());
        reg(C, "GetFocusedTextBox", (s, a) -> UiInput.focus == null ? NIL : UiInput.focus);
        reg(C, "SetMouseBehavior", (s, a) -> { u(s).setBehavior(a.checkjstring(1)); return NONE; });
        reg(C, "GetMouseBehavior", (s, a) -> valueOf(u(s).mouseBehavior));
        reg(C, "SetMouseIconEnabled", (s, a) -> { u(s).iconEnabled = a.arg1().toboolean(); return NONE; });
        reg(C, "IsMouseIconEnabled", (s, a) -> valueOf(u(s).iconEnabled));
        reg(C, "SetMouseIcon", (s, a) -> { u(s).setIcon(a.isnil(1) ? "" : a.tojstring(1)); return NONE; });
        reg(C, "GetMouseIcon", (s, a) -> valueOf(u(s).mouseIcon));
        reg(C, "SetTouchEnabled", (s, a) -> { u(s).touchEnabled = a.arg1().toboolean(); return NONE; });
        reg(C, "SetKeyboardEnabled", (s, a) -> { u(s).keyboardEnabled = a.arg1().toboolean(); return NONE; });
        reg(C, "SetGamepadEnabled", (s, a) -> { u(s).gamepadEnabled = a.arg1().toboolean(); return NONE; });
        reg(C, "SetMouseEnabled", (s, a) -> { u(s).mouseEnabled = a.arg1().toboolean(); return NONE; });
        reg(C, "SetOverrideMouseIcon", (s, a) -> { u(s).overrideIcon = a.arg1().toboolean(); return NONE; });
        reg(C, "GetPlatform", (s, a) -> valueOf(platform()));
        reg(C, "GetDeviceType", (s, a) -> valueOf("Desktop"));
        reg(C, "GetInputType|GetLastInputType", (s, a) -> valueOf(u(s).inputType));
        reg(C, "VibrateGamepad", (s, a) -> FALSE);  // GLFW has no rumble API: accepted, no effect
        reg(C, "VibratePhone", (s, a) -> FALSE);
        reg(C, "GetGamepadConnected", (s, a) -> { int n = padNum(a.arg1()); return valueOf(n >= 1 && n <= 16 && padOk(n - 1)); });
        reg(C, "GetGamepadName", (s, a) -> { int n = padNum(a.arg1()); String nm = n >= 1 && n <= 16 ? GLFW.glfwGetGamepadName(n - 1) : null; return nm == null ? NIL : valueOf(nm); });
        reg(C, "GetGamepadButtonState", (s, a) -> valueOf(padDown(padNum(a.arg1()), padButton(a.arg(2)))));
        reg(C, "GetGamepadAxis", (s, a) -> valueOf(padAxisValue(padNum(a.arg1()), padAxis(a.arg(2)))));
        reg(C, "GetMouseWheelDelta", (s, a) -> valueOf(u(s).wheelDelta));
        reg(C, "GetMouseSensitivity", (s, a) -> valueOf(sensitivity()));
        reg(C, "SetMouseSensitivity", (s, a) -> { setSensitivity(a.checkdouble(1)); return NONE; });
        reg(C, "GetCursorPosition", (s, a) -> cursorPx());
        reg(C, "SetCursorPosition", (s, a) -> { setCursorPx(a.arg1()); return NONE; });
        reg(C, "GetKeyCodeFromName", (s, a) -> { int c = keyCode(a.arg1()); return c < 0 ? NIL : valueOf(c); });
        reg(C, "GetKeyNameFromCode", (s, a) -> valueOf(a.arg1().isnumber() ? keyName(a.toint(1)) : keyName(keyCode(a.arg1()))));
        reg(C, "GetButtonNameFromCode", (s, a) -> valueOf("MouseButton" + (a.checkint(1) + 1)));
        reg(C, "GetButtonCodeFromName", (s, a) -> { int c = mouseCode(a.arg1()); return c < 0 ? NIL : valueOf(c); });
    }
}
