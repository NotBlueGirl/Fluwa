package net.idea.fluwa.client.zspace;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static net.idea.fluwa.client.zspace.ZUi.*;

/**
 * Lua code editor: highlighting, line numbers, indent guides, selection, undo/redo, auto-indent,
 * auto "end", auto-closing brackets, comment toggle, line move/duplicate, find & replace,
 * autocomplete and live syntax check.
 */
public class CodeEditor {
    public static final int LH = 10, IND = 4, FIND_H = 18;
    final Font font;
    public int x, y, w, h;
    public boolean focused;

    final List<String> lines = new ArrayList<>(List.of(""));
    int cl, cc, al, ac;               // cursor line/col, anchor line/col
    int wantX = -1;                   // preferred x when moving vertically
    float scrollY, targetY;
    int scrollX;
    int[] states = new int[0];
    boolean statesDirty = true;
    String saved = "";
    long blink = System.currentTimeMillis();

    record Snap(String text, int l, int c) {}
    final ArrayDeque<Snap> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    long lastTypeAt;

    // find / replace
    boolean findOpen, replaceOpen;
    int findField;                    // 0 = find box, 1 = replace box
    String query = "", replacement = "";
    final List<int[]> matches = new ArrayList<>();
    int matchIdx = -1;

    // completion
    final List<Completer.Item> comp = new ArrayList<>();
    int compSel, compScroll;
    String compPrefix = "";

    // syntax check
    public int errLine = -1;
    public String errMsg;
    long checkAt;
    boolean checkPending = true;

    // mouse
    boolean dragging, dragBar;
    long lastClick;
    int clicks;

    public CodeEditor(Font font) { this.font = font; }

    // ------------------------------------------------------------------ text model
    public void setText(String s) {
        lines.clear();
        lines.addAll(Arrays.asList(norm(s).split("\n", -1)));
        cl = cc = al = ac = 0;
        statesDirty = true; checkPending = true;
        saved = getText();
        undo.clear(); redo.clear();
    }

    static String norm(String s) { return s == null ? "" : s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    "); }

    public String getText() { return String.join("\n", lines); }
    public boolean modified() { return !getText().equals(saved); }
    public void markSaved() { saved = getText(); }
    public void markUnsaved() { saved = "\u0000"; }
    /** refresh from server copy, keeping the cursor */
    public void reload(String src) {
        String n = norm(src);
        if (n.equals(getText())) { saved = n; return; }
        int l = cl, c = cc;
        lines.clear(); lines.addAll(Arrays.asList(n.split("\n", -1)));
        cl = al = Math.min(l, lines.size() - 1); cc = ac = Math.min(c, lines.get(cl).length());
        saved = n; statesDirty = true; checkPending = true; undo.clear(); redo.clear();
    }
    public int line() { return cl + 1; }
    public int col() { return cc + 1; }
    public int lineCount() { return lines.size(); }

    boolean hasSel() { return cl != al || cc != ac; }
    boolean before(int l1, int c1, int l2, int c2) { return l1 < l2 || (l1 == l2 && c1 < c2); }
    int[] selA() { return before(al, ac, cl, cc) ? new int[]{al, ac} : new int[]{cl, cc}; }
    int[] selB() { return before(al, ac, cl, cc) ? new int[]{cl, cc} : new int[]{al, ac}; }

    String selected() {
        if (!hasSel()) return "";
        int[] a = selA(), b = selB();
        if (a[0] == b[0]) return lines.get(a[0]).substring(a[1], b[1]);
        StringBuilder sb = new StringBuilder(lines.get(a[0]).substring(a[1]));
        for (int i = a[0] + 1; i < b[0]; i++) sb.append('\n').append(lines.get(i));
        sb.append('\n').append(lines.get(b[0]), 0, b[1]);
        return sb.toString();
    }

    void changed() { statesDirty = true; checkPending = true; checkAt = System.currentTimeMillis() + 350; blink = System.currentTimeMillis(); redo.clear(); }

    void snap(boolean typing) {
        long now = System.currentTimeMillis();
        if (typing && now - lastTypeAt < 900 && !undo.isEmpty()) { lastTypeAt = now; return; }
        lastTypeAt = typing ? now : 0;
        undo.push(new Snap(getText(), cl, cc));
        while (undo.size() > 300) undo.removeLast();
    }

    void restore(Snap s) {
        lines.clear(); lines.addAll(Arrays.asList(s.text.split("\n", -1)));
        cl = Math.min(s.l, lines.size() - 1); cc = Math.min(s.c, lines.get(cl).length()); al = cl; ac = cc;
        statesDirty = true; checkPending = true; checkAt = 0;
        ensureVisible();
    }

    void doUndo() { if (undo.isEmpty()) return; redo.push(new Snap(getText(), cl, cc)); var r = redo; Snap s = undo.pop(); restoreKeepRedo(s, r); }
    void doRedo() { if (redo.isEmpty()) return; undo.push(new Snap(getText(), cl, cc)); restoreKeepRedo(redo.pop(), redo); }
    private void restoreKeepRedo(Snap s, ArrayDeque<Snap> r) { restore(s); lastTypeAt = 0; }

    void deleteSel() {
        if (!hasSel()) return;
        int[] a = selA(), b = selB();
        String head = lines.get(a[0]).substring(0, a[1]), tail = lines.get(b[0]).substring(b[1]);
        for (int i = b[0]; i > a[0]; i--) lines.remove(i);
        lines.set(a[0], head + tail);
        cl = al = a[0]; cc = ac = a[1];
    }

    void insert(String t) {
        deleteSel();
        String[] parts = norm(t).split("\n", -1);
        String line = lines.get(cl), head = line.substring(0, cc), tail = line.substring(cc);
        if (parts.length == 1) { lines.set(cl, head + parts[0] + tail); cc += parts[0].length(); }
        else {
            lines.set(cl, head + parts[0]);
            for (int i = 1; i < parts.length; i++) lines.add(cl + i, parts[i]);
            cl += parts.length - 1;
            cc = parts[parts.length - 1].length();
            lines.set(cl, lines.get(cl) + tail);
        }
        al = cl; ac = cc;
        changed();
    }

    static int indentOf(String s) { int i = 0; while (i < s.length() && s.charAt(i) == ' ') i++; return i; }

    // ------------------------------------------------------------------ highlighting state
    void ensureStates() {
        if (!statesDirty && states.length == lines.size()) return;
        states = new int[lines.size()];
        int st = 0;
        List<LuaLexer.Tok> tmp = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) { states[i] = st; tmp.clear(); st = LuaLexer.lex(lines.get(i), st, tmp); }
        statesDirty = false;
    }

    List<LuaLexer.Tok> toks(int i) { ensureStates(); List<LuaLexer.Tok> t = new ArrayList<>(); LuaLexer.lex(lines.get(i), states[i], t); return t; }

    int typeAt(int l, int c) {
        for (var t : toks(l)) if (c > t.s() && c <= t.e()) return t.type();
        return LuaLexer.DEF;
    }

    /** openers minus closers over the whole document (function/if/do/repeat vs end/until) */
    int blockBalance() {
        int bal = 0;
        for (int i = 0; i < lines.size(); i++) for (var t : toks(i)) if (t.type() == LuaLexer.KW) {
            switch (lines.get(i).substring(t.s(), t.e())) {
                case "function", "if", "do", "repeat" -> bal++;
                case "end", "until" -> bal--;
                default -> {}
            }
        }
        return bal;
    }

    static boolean opensBlock(String trimmed) {
        String t = stripComment(trimmed).trim();
        if (t.isEmpty()) return false;
        if (t.endsWith(" then") || t.equals("then") || t.endsWith(" do") || t.equals("do") || t.equals("else") || t.equals("repeat")) return true;
        if (t.endsWith("{") || t.endsWith("(")) return true;
        return t.matches(".*\\bfunction\\b[^)]*\\)\\s*$") && !t.matches(".*\\bend\\b.*");
    }

    static String stripComment(String s) { int k = s.indexOf("--"); return k >= 0 ? s.substring(0, k) : s; }

    // ------------------------------------------------------------------ geometry
    int gutterW() { return font.width(String.valueOf(lines.size())) + 16; }
    int top() { return y + (findOpen ? FIND_H + (replaceOpen ? FIND_H - 4 : 0) : 0) + 3; }
    int textX() { return x + gutterW() + 4 - scrollX; }
    int viewLines() { return Math.max(1, (y + h - top()) / LH); }
    int colX(int l, int c) { String s = lines.get(l); return font.width(s.substring(0, Math.min(c, s.length()))); }

    int colAt(int l, double px) {
        String s = lines.get(l);
        int acc = 0;
        for (int i = 0; i < s.length(); i++) {
            int cw = font.width(String.valueOf(s.charAt(i)));
            if (px < acc + cw / 2.0) return i;
            acc += cw;
        }
        return s.length();
    }

    int lineAt(double my) { return Math.max(0, Math.min(lines.size() - 1, (int) Math.floor((my - top()) / LH + scrollY))); }

    void clampScroll() { targetY = Math.max(0, Math.min(targetY, Math.max(0, lines.size() - viewLines() + 3))); }

    public void ensureVisible() {
        int vl = viewLines();
        if (cl < targetY) targetY = cl;
        if (cl >= targetY + vl - 1) targetY = cl - vl + 2;
        clampScroll();
        int cx = colX(cl, cc), vw = w - gutterW() - 14;
        if (cx - scrollX < 0) scrollX = Math.max(0, cx - 30);
        if (cx - scrollX > vw) scrollX = cx - vw + 30;
    }

    // ------------------------------------------------------------------ syntax check
    static final Pattern ERR_RX = Pattern.compile("^(?:script)?:?(\\d+):\\s*(.*)$", Pattern.DOTALL);

    /** false for non-Lua code (Shader DK: GLSL) */
    public boolean luaCheck = true;

    public void tick() {
        if (!luaCheck) { checkPending = false; return; }
        if (checkPending && System.currentTimeMillis() >= checkAt) {
            checkPending = false;
            errLine = -1; errMsg = null;
            try {
                org.luaj.vm2.compiler.LuaC.instance.compile(new ByteArrayInputStream(getText().getBytes(StandardCharsets.UTF_8)), "=script");
            } catch (Throwable e) {
                String m = String.valueOf(e.getMessage());
                if (m.startsWith("script")) m = m.substring(6);
                Matcher mt = ERR_RX.matcher(m);
                if (mt.find()) { errLine = Integer.parseInt(mt.group(1)) - 1; errMsg = pretty(mt.group(2)); }
                else errMsg = m;
            }
        }
    }

    static final String[] TOKENS = {"and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in",
            "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while", "..", "...", "==", ">=", "<=", "~=",
            "::", "<eof>", "<number>", "<name>", "<string>"};

    static String pretty(String m) {
        Matcher mt = Pattern.compile("symbol (\\d+)(?: \\(.\\))?",Pattern.DOTALL).matcher(m);
        StringBuilder sb = new StringBuilder();
        while (mt.find()) {
            int t = Integer.parseInt(mt.group(1)) - 257;
            String n = t >= 0 && t < TOKENS.length ? "'" + TOKENS[t] + "'" : t < 0 && t + 257 >= 32 ? "'" + (char) (t + 257) + "'" : mt.group(1);
            mt.appendReplacement(sb, Matcher.quoteReplacement("symbol " + n));
        }
        mt.appendTail(sb);
        return sb.toString().replace(" (?)", "").replace(" near '<eof>'", " at end of script").trim();
    }

    // ------------------------------------------------------------------ render
    public void render(GuiGraphics g, int mx, int my, float time) {
        scrollY += (targetY - scrollY) * 0.4f;
        if (Math.abs(targetY - scrollY) < 0.01f) scrollY = targetY;
        ensureStates();
        int gw = gutterW(), tp = top();
        g.fill(x, y, x + w, y + h, EDITOR);
        g.fill(x, y, x + gw, y + h, GUTTER);
        g.fill(x + gw, y, x + gw + 1, y + h, LINE);
        int first = Math.max(0, (int) Math.floor(scrollY));
        int off = Math.round((scrollY - first) * LH);
        int[] sa = selA(), sb = selB();
        boolean sel = hasSel();
        int tx = textX(), spaceW = font.width(" ");
        int[] br = bracketPair();

        // gutter
        ZUi.scissor(g, x, tp, x + gw, y + h);
        for (int i = first; i < lines.size(); i++) {
            int ly = tp + (i - first) * LH - off;
            if (ly > y + h) break;
            String num = String.valueOf(i + 1);
            int col = i == cl ? 0xFFC8C8DA : FAINT;
            if (i == errLine) { g.fill(x, ly - 1, x + 2, ly + LH - 1, ERR); col = ERR; }
            text(g, font, num, x + gw - 6 - font.width(num), ly, col);
        }
        g.disableScissor();

        // text
        ZUi.scissor(g, x + gw + 1, tp - 2, x + w, y + h);
        String ql = query.toLowerCase(Locale.ROOT);
        for (int i = first; i < lines.size(); i++) {
            int ly = tp + (i - first) * LH - off;
            if (ly > y + h) break;
            String s = lines.get(i);
            if (i == cl && !sel && focused) g.fill(x + gw + 1, ly - 1, x + w, ly + LH - 1, 0x0EFFFFFF);
            if (i == errLine) g.fill(x + gw + 1, ly - 1, x + w, ly + LH - 1, 0x22FF4060);
            // indent guides
            int ind = s.isBlank() ? nearestIndent(i) : indentOf(s);
            for (int k = IND; k <= ind; k += IND) {
                int gx = tx + (k - IND) * spaceW;
                g.fill(gx, ly - 1, gx + 1, ly + LH - 1, k <= indentOf(lines.get(cl)) && Math.abs(i - cl) < 200 ? 0x22FFFFFF : 0x12FFFFFF);
            }
            // selection
            if (sel && i >= sa[0] && i <= sb[0]) {
                int c1 = i == sa[0] ? sa[1] : 0, c2 = i == sb[0] ? sb[1] : s.length();
                int x1 = tx + colX(i, c1), x2 = tx + colX(i, c2) + (i < sb[0] ? spaceW : 0);
                g.fill(x1, ly - 1, Math.max(x2, x1 + 1), ly + LH - 1, focused ? 0x558B7CFF : 0x33808090);
            }
            // find matches
            if (findOpen && !ql.isEmpty()) {
                String sl = s.toLowerCase(Locale.ROOT);
                for (int k = sl.indexOf(ql); k >= 0; k = sl.indexOf(ql, k + Math.max(1, ql.length()))) {
                    boolean cur = matchIdx >= 0 && matchIdx < matches.size() && matches.get(matchIdx)[0] == i && matches.get(matchIdx)[1] == k;
                    int x1 = tx + colX(i, k), x2 = tx + colX(i, k + ql.length());
                    g.fill(x1, ly - 1, x2, ly + LH - 1, cur ? 0x77FFC66B : 0x33FFC66B);
                }
            }
            // bracket match
            if (br != null) for (int b = 0; b < 2; b++) if (br[b * 2] == i) {
                int x1 = tx + colX(i, br[b * 2 + 1]), x2 = tx + colX(i, br[b * 2 + 1] + 1);
                outline(g, x1 - 1, ly - 1, x2 + 1, ly + LH - 1, 0x99FFFFFF);
            }
            // tokens
            int px = tx;
            for (var t : toks(i)) {
                String part = s.substring(t.s(), t.e());
                int pw = font.width(part);
                if (t.type() != LuaLexer.SPACE && px + pw > x + gw && px < x + w)
                    g.drawString(font, FormattedCharSequence.forward(part, t.type() == LuaLexer.COM ? Style.EMPTY.withItalic(true) : Style.EMPTY),
                            px, ly, 0xFF000000 | LuaLexer.COLORS[t.type()], false);
                px += pw;
            }
            if (i == errLine && errMsg != null) {
                int ex = tx + font.width(s) + 12;
                text(g, font, "● " + errMsg, ex, ly, 0xAAFF6B7A);
            }
        }
        // caret
        if (focused && ((System.currentTimeMillis() - blink) / 530) % 2 == 0 && cl >= first) {
            int ly = tp + (cl - first) * LH - off;
            int cx = tx + colX(cl, cc);
            g.fill(cx, ly - 1, cx + 1, ly + LH - 1, 0xFFE8E4FF);
        }
        g.disableScissor();

        // scrollbar
        int total = lines.size() + viewLines() - 3;
        if (lines.size() > viewLines()) {
            int trackH = y + h - tp - 2;
            int th = Math.max(16, trackH * viewLines() / Math.max(1, total));
            int ty = tp + (int) ((trackH - th) * (scrollY / Math.max(1, total - viewLines())));
            boolean hov = in(mx, my, x + w - 6, tp, x + w, y + h) || dragBar;
            round(g, x + w - (hov ? 5 : 4), ty, x + w - 1, ty + th, hov ? 0x66FFFFFF : 0x30FFFFFF);
            if (errLine >= 0) { int ey = tp + trackH * errLine / Math.max(1, lines.size()); g.fill(x + w - 6, ey, x + w - 1, ey + 2, ERR); }
            for (int[] m : matches) { int my2 = tp + trackH * m[0] / Math.max(1, lines.size()); g.fill(x + w - 3, my2, x + w - 1, my2 + 1, WARN); }
        }
        if (findOpen) renderFind(g, mx, my);
    }

    int nearestIndent(int i) {
        int a = 0, b = 0;
        for (int k = i - 1; k >= 0; k--) if (!lines.get(k).isBlank()) { a = indentOf(lines.get(k)); break; }
        for (int k = i + 1; k < lines.size(); k++) if (!lines.get(k).isBlank()) { b = indentOf(lines.get(k)); break; }
        return Math.min(a, b);
    }

    void renderFind(GuiGraphics g, int mx, int my) {
        int fx = x + w - 230, fy = y + 2, fw = 222;
        int fh = FIND_H - 2 + (replaceOpen ? FIND_H - 4 : 0);
        shadow(g, fx, fy, fx + fw, fy + fh);
        round(g, fx, fy, fx + fw, fy + fh, 0xFA1E1E28);
        outline(g, fx, fy, fx + fw, fy + fh, LINE);
        drawField(g, fx + 4, fy + 3, 140, query, "Find", findField == 0);
        String cnt = query.isEmpty() ? "" : matches.isEmpty() ? "no results" : (matchIdx + 1) + " of " + matches.size();
        small(g, font, cnt, fx + 148, fy + 6, matches.isEmpty() && !query.isEmpty() ? ERR : DIM);
        text(g, font, "×", fx + fw - 9, fy + 4, in(mx, my, fx + fw - 12, fy, fx + fw, fy + 14) ? TEXT : DIM);
        if (replaceOpen) {
            drawField(g, fx + 4, fy + FIND_H - 1, 140, replacement, "Replace", findField == 1);
            boolean h1 = in(mx, my, fx + 148, fy + FIND_H - 1, fx + 178, fy + FIND_H + 11), h2 = in(mx, my, fx + 182, fy + FIND_H - 1, fx + 216, fy + FIND_H + 11);
            round(g, fx + 148, fy + FIND_H - 1, fx + 178, fy + FIND_H + 11, h1 ? 0x44FFFFFF : 0x22FFFFFF);
            round(g, fx + 182, fy + FIND_H - 1, fx + 216, fy + FIND_H + 11, h2 ? 0x44FFFFFF : 0x22FFFFFF);
            small(g, font, "One", fx + 156, fy + FIND_H + 2, TEXT);
            small(g, font, "All", fx + 194, fy + FIND_H + 2, TEXT);
        }
    }

    void drawField(GuiGraphics g, int fx, int fy, int fw, String val, String hint, boolean active) {
        round(g, fx, fy, fx + fw, fy + 12, 0xFF121218);
        if (active) outline(g, fx, fy, fx + fw, fy + 12, ACCENT);
        String shown = ellipsizeLeft(val, fw - 8);
        if (val.isEmpty()) text(g, font, hint, fx + 3, fy + 2, FAINT);
        else text(g, font, shown, fx + 3, fy + 2, TEXT);
        if (active && ((System.currentTimeMillis() - blink) / 530) % 2 == 0) {
            int cx = fx + 3 + font.width(shown);
            g.fill(cx, fy + 2, cx + 1, fy + 11, TEXT);
        }
    }

    String ellipsizeLeft(String s, int wpx) { while (s.length() > 0 && font.width(s) > wpx) s = s.substring(1); return s; }

    /** completion popup, drawn last (above everything) */
    static final int COMP_ROWS = 10;
    static int kindColor(char k) {
        return switch (k) {
            case 'm' -> 0xFFFFCB6B; case 'p' -> 0xFF7AA2F7; case 'e' -> 0xFFF2A2B8; case 'k' -> 0xFFC792EA; case 'l' -> 0xFFA5E075;
            case 'g' -> 0xFF89DDFF; case 'c' -> 0xFFFF9E64; case 's' -> 0xFF5CD6C8; default -> 0xFF8A8A9A;
        };
    }
    static String kindLetter(char k) {
        return switch (k) { case 'm' -> "ƒ"; case 'p' -> "P"; case 'e' -> "⚡"; case 'k' -> "K"; case 'l' -> "L"; case 'g' -> "G"; case 'c' -> "C"; case 's' -> "S"; default -> "·"; };
    }

    public void renderOverlay(GuiGraphics g, int mx, int my) {
        if (comp.isEmpty() || !focused) return;
        int first = Math.max(0, (int) Math.floor(scrollY));
        int ly = top() + (cl - first) * LH - Math.round((scrollY - first) * LH) + LH + 1;
        int px = textX() + colX(cl, cc - compPrefix.length()) - 4;
        compSel = Math.max(0, Math.min(compSel, comp.size() - 1));
        if (compSel < compScroll) compScroll = compSel;
        if (compSel >= compScroll + COMP_ROWS) compScroll = compSel - COMP_ROWS + 1;
        int rows = Math.min(COMP_ROWS, comp.size());
        int pw = 60, dw = 0;
        for (int i = compScroll; i < compScroll + rows; i++) {
            pw = Math.max(pw, font.width(comp.get(i).text()) + 26);
            dw = Math.max(dw, (int) (font.width(comp.get(i).detail()) * 0.75f) + 10);
        }
        pw += Math.min(dw, 90);
        int ph = rows * 11 + 4 + (comp.size() > COMP_ROWS ? 0 : 0);
        if (ly + ph > y + h) ly -= ph + LH + 2;
        if (px + pw > x + w) px = Math.max(x, x + w - pw);
        shadow(g, px, ly, px + pw, ly + ph);
        round(g, px, ly, px + pw, ly + ph, 0xFC1C1C26);
        outline(g, px, ly, px + pw, ly + ph, LINE);
        for (int r = 0; r < rows; r++) {
            int i = compScroll + r;
            Completer.Item it = comp.get(i);
            String s = it.text();
            int ry = ly + 2 + r * 11;
            if (i == compSel) round(g, px + 2, ry, px + pw - 2, ry + 11, 0x558B7CFF);
            int kc = kindColor(it.kind());
            small(g, font, kindLetter(it.kind()), px + 5, ry + 3, kc);
            int pl = compPrefix.length();
            if (pl > 0 && s.regionMatches(true, 0, compPrefix, 0, pl)) {
                text(g, font, s.substring(0, pl), px + 14, ry + 2, ACCENT2);
                text(g, font, s.substring(pl), px + 14 + font.width(s.substring(0, pl)), ry + 2, TEXT);
            } else text(g, font, s, px + 14, ry + 2, TEXT);
            if (!it.detail().isEmpty()) {
                String d = it.detail();
                small(g, font, d, px + pw - 5 - (int) (font.width(d) * 0.75f), ry + 3, FAINT);
            }
        }
        if (comp.size() > COMP_ROWS) {
            int th = Math.max(6, ph * COMP_ROWS / comp.size()), ty = ly + (ph - th) * compScroll / Math.max(1, comp.size() - COMP_ROWS);
            round(g, px + pw - 3, ty, px + pw - 1, ty + th, 0x50FFFFFF);
        }
    }

    // ------------------------------------------------------------------ brackets
    int[] bracketPair() {
        if (!focused) return null;
        String s = lines.get(cl);
        int c = -1;
        if (cc < s.length() && "()[]{}".indexOf(s.charAt(cc)) >= 0) c = cc;
        else if (cc > 0 && "()[]{}".indexOf(s.charAt(cc - 1)) >= 0) c = cc - 1;
        if (c < 0) return null;
        char ch = s.charAt(c);
        int k = "()[]{}".indexOf(ch);
        char open = "([{".charAt(k / 2), close = ")]}".charAt(k / 2);
        int dir = k % 2 == 0 ? 1 : -1, depth = 0, l = cl, i = c, steps = 0;
        while (steps++ < 20000) {
            String ln = lines.get(l);
            if (i >= 0 && i < ln.length()) {
                char d = ln.charAt(i);
                if (d == open) depth += dir;
                else if (d == close) depth -= dir;
                if (depth == 0) return new int[]{cl, c, l, i};
            }
            i += dir;
            while (i < 0 || i >= lines.get(l).length()) {
                l += dir;
                if (l < 0 || l >= lines.size()) return null;
                i = dir > 0 ? 0 : lines.get(l).length() - 1;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ completion
    void updateCompletion() { updateCompletion(false); }
    void updateCompletion(boolean explicit) {
        comp.clear(); compSel = 0; compScroll = 0;
        if (!ZOptions.autocomplete) return;
        int tp = typeAt(cl, cc);
        if (tp == LuaLexer.COM) return;
        boolean inStr = tp == LuaLexer.STR || (cc > 0 && "\"'".indexOf(lines.get(cl).charAt(cc - 1)) >= 0 && cc < lines.get(cl).length() && lines.get(cl).charAt(cc) == lines.get(cl).charAt(cc - 1));
        Completer.Result r;
        try { r = Completer.complete(lines, cl, cc, inStr, explicit); } catch (RuntimeException e) { r = null; }
        if (r == null) return;
        compPrefix = r.prefix();
        comp.addAll(r.items());
    }

    void acceptCompletion() {
        if (comp.isEmpty()) return;
        Completer.Item it = comp.get(Math.max(0, Math.min(compSel, comp.size() - 1)));
        String c = it.text();
        Completer.used(c);
        snap(false);
        String line = lines.get(cl);
        int st = cc - compPrefix.length();
        // replace the whole identifier under the cursor (also the part after it)
        int en = cc;
        while (en < line.length() && LuaLexer.id(line.charAt(en))) en++;
        String tail = line.substring(en);
        String ins = c;
        int back = 0;
        if (it.kind() == 'm' && !tail.startsWith("(")) { ins = c + "()"; back = 1; }
        lines.set(cl, line.substring(0, st) + ins + tail);
        cc = st + ins.length() - back; al = cl; ac = cc;
        changed();
        comp.clear();
        ensureVisible();
    }

    // ------------------------------------------------------------------ find
    public void openFind(boolean replace) {
        findOpen = true; replaceOpen = replace; findField = 0;
        if (hasSel() && selA()[0] == selB()[0]) query = selected();
        refreshMatches(); clampScroll();
    }

    void refreshMatches() {
        matches.clear(); matchIdx = -1;
        if (query.isEmpty()) return;
        String q = query.toLowerCase(Locale.ROOT);
        for (int i = 0; i < lines.size(); i++) {
            String sl = lines.get(i).toLowerCase(Locale.ROOT);
            for (int k = sl.indexOf(q); k >= 0; k = sl.indexOf(q, k + q.length())) matches.add(new int[]{i, k});
        }
        for (int i = 0; i < matches.size(); i++) if (!before(matches.get(i)[0], matches.get(i)[1], cl, cc - (hasSel() ? query.length() : 0))) { matchIdx = i; break; }
        if (matchIdx < 0 && !matches.isEmpty()) matchIdx = 0;
    }

    void gotoMatch(int dir) {
        if (matches.isEmpty()) return;
        if (matchIdx < 0) matchIdx = 0; else matchIdx = Math.floorMod(matchIdx + dir, matches.size());
        selectMatch();
    }

    void selectMatch() {
        int[] m = matches.get(matchIdx);
        al = m[0]; ac = m[1]; cl = m[0]; cc = m[1] + query.length();
        ensureVisible();
    }

    void replaceOne() {
        if (matches.isEmpty()) return;
        if (matchIdx < 0) matchIdx = 0;
        int[] m = matches.get(matchIdx);
        snap(false);
        String s = lines.get(m[0]);
        lines.set(m[0], s.substring(0, m[1]) + replacement + s.substring(m[1] + query.length()));
        cl = al = m[0]; cc = ac = m[1] + replacement.length();
        changed();
        int keep = matchIdx;
        refreshMatches();
        if (!matches.isEmpty()) { matchIdx = Math.min(keep, matches.size() - 1); selectMatch(); }
    }

    int replaceAll() {
        if (query.isEmpty()) return 0;
        snap(false);
        int n = matches.size();
        Pattern p = Pattern.compile(Pattern.quote(query), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        for (int i = 0; i < lines.size(); i++) lines.set(i, p.matcher(lines.get(i)).replaceAll(Matcher.quoteReplacement(replacement)));
        cc = Math.min(cc, lines.get(cl).length()); al = cl; ac = cc;
        changed(); refreshMatches();
        return n;
    }

    // ------------------------------------------------------------------ input
    public boolean charTyped(char ch) {
        if (ch < 32 || ch == 127) return false;
        if (findOpen && findField >= 0 && findFocus) {
            if (findField == 0) { query += ch; refreshMatches(); if (matchIdx >= 0) selectMatch(); }
            else replacement += ch;
            blink = System.currentTimeMillis();
            return true;
        }
        String pairs = "()[]{}\"\"''";
        int pi = pairs.indexOf(ch);
        String s = lines.get(cl);
        char next = cc < s.length() ? s.charAt(cc) : 0;
        // overtype closer
        if ((ch == ')' || ch == ']' || ch == '}' || ch == '"' || ch == '\'') && next == ch && !hasSel()) {
            cc++; al = cl; ac = cc; blink = System.currentTimeMillis(); comp.clear(); return true;
        }
        snap(true);
        if (pi >= 0 && pi % 2 == 0) {
            char close = pairs.charAt(pi + 1);
            if (hasSel()) { String inner = selected(); insert(ch + inner + close); cc--; ac = cc; ensureVisible(); return true; }
            boolean quote = ch == '"' || ch == '\'';
            char prev = cc > 0 ? s.charAt(cc - 1) : 0;
            boolean ok = next == 0 || next == ' ' || ")]},".indexOf(next) >= 0;
            if (quote && (LuaLexer.id(prev) || typeAt(cl, cc) == LuaLexer.STR)) ok = false;
            if (ok && typeAt(cl, cc) != LuaLexer.COM) { insert("" + ch + close); cc--; ac = cc; ensureVisible(); comp.clear(); if (quote) updateCompletion(); return true; }
        }
        insert(String.valueOf(ch));
        // auto-dedent for end/else/elseif/until
        String now = lines.get(cl), tr = now.trim();
        if (cc == now.length() && (tr.equals("end") || tr.equals("else") || tr.equals("until") || tr.equals("}") || tr.equals(")"))) {
            int ind = indentOf(now);
            int pl = cl - 1;
            while (pl >= 0 && lines.get(pl).isBlank()) pl--;
            if (ind >= IND && pl >= 0 && (indentOf(lines.get(pl)) == ind && !opensBlock(lines.get(pl).trim()))) {
                lines.set(cl, now.substring(IND)); cc -= IND; ac = cc; changed();
            } else if (ind >= IND && pl >= 0 && opensBlock(lines.get(pl).trim()) && indentOf(lines.get(pl)) < ind) {
                int to = indentOf(lines.get(pl));
                lines.set(cl, " ".repeat(to) + tr); cc = to + tr.length(); ac = cc; changed();
            }
        }
        if (LuaLexer.id(ch) || ch == ':' || (ch == '.' && !(cc >= 2 && lines.get(cl).charAt(cc - 2) == '.'))) updateCompletion(); else comp.clear();
        ensureVisible();
        return true;
    }

    boolean findFocus;

    public boolean keyPressed(int key, int mods) {
        boolean ctrl = Screen.hasControlDown(), shift = Screen.hasShiftDown(), alt = Screen.hasAltDown();
        blink = System.currentTimeMillis();
        // completion navigation
        if (!comp.isEmpty()) {
            switch (key) {
                case GLFW.GLFW_KEY_DOWN -> { compSel = (compSel + 1) % comp.size(); return true; }
                case GLFW.GLFW_KEY_UP -> { compSel = Math.floorMod(compSel - 1, comp.size()); return true; }
                case GLFW.GLFW_KEY_TAB, GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> { acceptCompletion(); return true; }
                case GLFW.GLFW_KEY_ESCAPE -> { comp.clear(); return true; }
                case GLFW.GLFW_KEY_PAGE_DOWN -> { compSel = Math.min(comp.size() - 1, compSel + COMP_ROWS); return true; }
                case GLFW.GLFW_KEY_PAGE_UP -> { compSel = Math.max(0, compSel - COMP_ROWS); return true; }
                default -> {}
            }
        }
        // find bar input
        if (findOpen && findFocus) {
            switch (key) {
                case GLFW.GLFW_KEY_ESCAPE -> { findOpen = false; findFocus = false; return true; }
                case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
                    if (findField == 1) { if (ctrl || alt) replaceAll(); else replaceOne(); } else gotoMatch(shift ? -1 : 1);
                    return true;
                }
                case GLFW.GLFW_KEY_TAB -> { if (replaceOpen) findField = 1 - findField; return true; }
                case GLFW.GLFW_KEY_BACKSPACE -> {
                    if (findField == 0) { if (!query.isEmpty()) query = ctrl ? "" : query.substring(0, query.length() - 1); refreshMatches(); }
                    else if (!replacement.isEmpty()) replacement = ctrl ? "" : replacement.substring(0, replacement.length() - 1);
                    return true;
                }
                case GLFW.GLFW_KEY_V -> {
                    if (ctrl) { String c = Minecraft.getInstance().keyboardHandler.getClipboard().replace("\n", " ");
                        if (findField == 0) { query += c; refreshMatches(); } else replacement += c; return true; }
                }
                case GLFW.GLFW_KEY_F -> { if (ctrl) { findField = 0; return true; } }
                case GLFW.GLFW_KEY_H -> { if (ctrl) { replaceOpen = true; findField = 1; return true; } }
                default -> {}
            }
            if (!ctrl) return key != GLFW.GLFW_KEY_F8 && key != GLFW.GLFW_KEY_F5;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (findOpen) { findOpen = false; findFocus = false; return true; }
            if (hasSel()) { al = cl; ac = cc; return true; }
            return false;
        }
        if (ctrl) {
            switch (key) {
                case GLFW.GLFW_KEY_A -> { al = 0; ac = 0; cl = lines.size() - 1; cc = lines.get(cl).length(); return true; }
                case GLFW.GLFW_KEY_C -> { Minecraft.getInstance().keyboardHandler.setClipboard(hasSel() ? selected() : lines.get(cl) + "\n"); return true; }
                case GLFW.GLFW_KEY_X -> {
                    snap(false);
                    if (hasSel()) { Minecraft.getInstance().keyboardHandler.setClipboard(selected()); deleteSel(); }
                    else { Minecraft.getInstance().keyboardHandler.setClipboard(lines.get(cl) + "\n"); deleteLines(cl, cl); }
                    changed(); ensureVisible(); return true;
                }
                case GLFW.GLFW_KEY_V -> { snap(false); insert(Minecraft.getInstance().keyboardHandler.getClipboard()); ensureVisible(); return true; }
                case GLFW.GLFW_KEY_Z -> { if (shift) doRedo(); else doUndo(); return true; }
                case GLFW.GLFW_KEY_Y -> { doRedo(); return true; }
                case GLFW.GLFW_KEY_D -> { duplicate(); return true; }
                case GLFW.GLFW_KEY_SLASH, GLFW.GLFW_KEY_KP_DIVIDE -> { toggleComment(); return true; }
                case GLFW.GLFW_KEY_F -> { openFind(false); findFocus = true; return true; }
                case GLFW.GLFW_KEY_H -> { openFind(true); findFocus = true; findField = 1; return true; }
                case GLFW.GLFW_KEY_L -> { al = cl; ac = 0; if (cl + 1 < lines.size()) { cl++; cc = 0; } else cc = lines.get(cl).length(); return true; }
                case GLFW.GLFW_KEY_K -> { if (shift) { snap(false); int[] a = selA(), b = selB(); deleteLines(a[0], b[0]); changed(); ensureVisible(); return true; } }
                case GLFW.GLFW_KEY_HOME -> { cl = 0; cc = 0; if (!shift) { al = cl; ac = cc; } ensureVisible(); return true; }
                case GLFW.GLFW_KEY_END -> { cl = lines.size() - 1; cc = lines.get(cl).length(); if (!shift) { al = cl; ac = cc; } ensureVisible(); return true; }
                case GLFW.GLFW_KEY_SPACE -> { updateCompletion(true); return true; }
                default -> {}
            }
        }
        if (alt && (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN)) { moveLines(key == GLFW.GLFW_KEY_UP ? -1 : 1); return true; }
        switch (key) {
            case GLFW.GLFW_KEY_LEFT -> {
                comp.clear();
                if (hasSel() && !shift) { int[] a = selA(); cl = al = a[0]; cc = ac = a[1]; return true; }
                if (ctrl) cc = wordLeft(); else if (cc > 0) cc--; else if (cl > 0) { cl--; cc = lines.get(cl).length(); }
                moved(shift); return true;
            }
            case GLFW.GLFW_KEY_RIGHT -> {
                comp.clear();
                if (hasSel() && !shift) { int[] b = selB(); cl = al = b[0]; cc = ac = b[1]; return true; }
                if (ctrl) cc = wordRight(); else if (cc < lines.get(cl).length()) cc++; else if (cl < lines.size() - 1) { cl++; cc = 0; }
                moved(shift); return true;
            }
            case GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_PAGE_UP, GLFW.GLFW_KEY_PAGE_DOWN -> {
                comp.clear();
                int d = key == GLFW.GLFW_KEY_UP ? -1 : key == GLFW.GLFW_KEY_DOWN ? 1 : key == GLFW.GLFW_KEY_PAGE_UP ? -viewLines() + 1 : viewLines() - 1;
                if (ctrl && Math.abs(d) == 1) { targetY += d; clampScroll(); return true; }
                if (wantX < 0) wantX = colX(cl, cc);
                int nl = Math.max(0, Math.min(lines.size() - 1, cl + d));
                if (nl == cl) cc = d < 0 ? 0 : lines.get(cl).length();
                else { cl = nl; cc = colAt(cl, wantX); }
                if (!shift) { al = cl; ac = cc; }
                ensureVisible(); return true;
            }
            case GLFW.GLFW_KEY_HOME -> {
                int ind = indentOf(lines.get(cl));
                cc = cc == ind ? 0 : ind; moved(shift); return true;
            }
            case GLFW.GLFW_KEY_END -> { cc = lines.get(cl).length(); moved(shift); return true; }
            case GLFW.GLFW_KEY_BACKSPACE -> { backspace(ctrl); return true; }
            case GLFW.GLFW_KEY_DELETE -> { del(ctrl); return true; }
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> { newline(); return true; }
            case GLFW.GLFW_KEY_TAB -> { tab(shift); return true; }
            default -> {}
        }
        return false;
    }

    void moved(boolean shift) { wantX = -1; if (!shift) { al = cl; ac = cc; } ensureVisible(); }

    int wordLeft() {
        String s = lines.get(cl); int i = cc;
        if (i == 0) { if (cl > 0) { cl--; return lines.get(cl).length(); } return 0; }
        while (i > 0 && s.charAt(i - 1) == ' ') i--;
        boolean w = i > 0 && LuaLexer.id(s.charAt(i - 1));
        while (i > 0 && s.charAt(i - 1) != ' ' && LuaLexer.id(s.charAt(i - 1)) == w) i--;
        return i;
    }

    int wordRight() {
        String s = lines.get(cl); int i = cc;
        if (i >= s.length()) { if (cl < lines.size() - 1) { cl++; return 0; } return i; }
        boolean w = LuaLexer.id(s.charAt(i));
        while (i < s.length() && s.charAt(i) != ' ' && LuaLexer.id(s.charAt(i)) == w) i++;
        while (i < s.length() && s.charAt(i) == ' ') i++;
        return i;
    }

    void backspace(boolean word) {
        if (hasSel()) { snap(false); deleteSel(); changed(); ensureVisible(); comp.clear(); return; }
        if (cc == 0 && cl == 0) return;
        snap(!word);
        String s = lines.get(cl);
        if (cc == 0) {
            String prev = lines.get(cl - 1);
            lines.set(cl - 1, prev + s); lines.remove(cl); cl--; cc = prev.length();
        } else if (word) {
            int to = wordLeft(); lines.set(cl, s.substring(0, to) + s.substring(cc)); cc = to;
        } else {
            char a = s.charAt(cc - 1), b = cc < s.length() ? s.charAt(cc) : 0;
            boolean pair = (a == '(' && b == ')') || (a == '[' && b == ']') || (a == '{' && b == '}') || (a == '"' && b == '"') || (a == '\'' && b == '\'');
            int ind = indentOf(s);
            if (cc <= ind && cc >= IND && cc % IND == 0) { lines.set(cl, s.substring(IND)); cc -= IND; }
            else { lines.set(cl, s.substring(0, cc - 1) + s.substring(cc + (pair ? 1 : 0))); cc--; }
        }
        al = cl; ac = cc; changed(); ensureVisible();
        if (!comp.isEmpty()) updateCompletion();
    }

    void del(boolean word) {
        if (hasSel()) { snap(false); deleteSel(); changed(); return; }
        String s = lines.get(cl);
        if (cc >= s.length()) { if (cl + 1 < lines.size()) { snap(false); lines.set(cl, s + lines.get(cl + 1)); lines.remove(cl + 1); changed(); } return; }
        snap(!word);
        if (word) { int l0 = cl, to = wordRight(); cl = l0; lines.set(cl, s.substring(0, cc) + s.substring(Math.max(cc, Math.min(to, s.length())))); }
        else lines.set(cl, s.substring(0, cc) + s.substring(cc + 1));
        al = cl; ac = cc; changed();
    }

    void newline() {
        snap(false);
        comp.clear();
        deleteSel();
        String s = lines.get(cl), head = s.substring(0, cc), tail = s.substring(cc);
        int ind = indentOf(s);
        if (cc < ind) ind = cc;
        boolean open = opensBlock(head.trim());
        String pad = " ".repeat(ind), inner = " ".repeat(open ? ind + IND : ind);
        String tailT = tail.trim();
        boolean closerTail = !tailT.isEmpty() && "})]".indexOf(tailT.charAt(0)) >= 0 && (head.trim().endsWith("{") || head.trim().endsWith("(") || head.trim().endsWith("["));
        lines.set(cl, head.replaceAll("\\s+$", ""));
        if (closerTail) {
            lines.add(cl + 1, inner);
            lines.add(cl + 2, pad + tailT);
            cl++; cc = inner.length();
        } else {
            lines.add(cl + 1, inner + tail.stripLeading());
            cl++; cc = inner.length();
            // auto-insert "end" (like Roblox Studio) for unclosed blocks
            String h = stripComment(head).trim();
            boolean block = open && !h.endsWith("{") && !h.endsWith("(") && !h.equals("else") && !h.startsWith("elseif") && !h.equals("repeat");
            boolean closersTail = tailT.matches("^[)\\]},;]+$");
            if (block && closersTail) {
                lines.set(cl, inner);
                lines.add(cl + 1, pad + "end" + tailT);
            } else if (block && tailT.isEmpty()) {
                int nx = cl + 1;
                while (nx < lines.size() && lines.get(nx).isBlank()) nx++;
                boolean nextInside = nx < lines.size() && indentOf(lines.get(nx)) > ind;
                if (!nextInside && blockBalance() > 0) {
                    boolean paren = h.matches(".*\\(\\s*function\\b.*") && countChar(h, '(') > countChar(h, ')');
                    lines.add(cl + 1, pad + "end" + (paren ? ")" : ""));
                }
            } else if (open && h.equals("repeat") && blockBalance() > 0) lines.add(cl + 1, pad + "until ");
        }
        al = cl; ac = cc; changed(); ensureVisible();
    }

    static int countChar(String s, char c) { int n = 0; for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) n++; return n; }

    void tab(boolean shift) {
        comp.clear();
        int[] a = selA(), b = selB();
        if (shift || (hasSel() && a[0] != b[0])) {
            snap(false);
            for (int i = a[0]; i <= b[0]; i++) {
                String s = lines.get(i);
                if (shift) { int r = Math.min(IND, indentOf(s)); lines.set(i, s.substring(r)); if (i == cl) cc = Math.max(0, cc - r); if (i == al) ac = Math.max(0, ac - r); }
                else if (!s.isEmpty()) { lines.set(i, " ".repeat(IND) + s); if (i == cl) cc += IND; if (i == al) ac += IND; }
            }
            changed(); return;
        }
        snap(true);
        int n = IND - (cc % IND);
        insert(" ".repeat(n));
        ensureVisible();
    }

    void duplicate() {
        snap(false);
        if (hasSel() && selA()[0] == selB()[0]) { String t = selected(); int[] b = selB(); cl = al = b[0]; cc = ac = b[1]; insert(t); return; }
        int[] a = selA(), b = selB();
        List<String> block = new ArrayList<>(lines.subList(a[0], b[0] + 1));
        lines.addAll(b[0] + 1, block);
        cl += block.size(); al += block.size();
        changed(); ensureVisible();
    }

    void deleteLines(int from, int to) {
        for (int i = to; i >= from; i--) lines.remove(i);
        if (lines.isEmpty()) lines.add("");
        cl = Math.min(from, lines.size() - 1); cc = Math.min(cc, lines.get(cl).length()); al = cl; ac = cc;
    }

    void moveLines(int d) {
        int[] a = selA(), b = selB();
        if ((d < 0 && a[0] == 0) || (d > 0 && b[0] >= lines.size() - 1)) return;
        snap(false);
        if (d < 0) { String m = lines.remove(a[0] - 1); lines.add(b[0], m); }
        else { String m = lines.remove(b[0] + 1); lines.add(a[0], m); }
        cl += d; al += d; changed(); ensureVisible();
    }

    void toggleComment() {
        snap(false);
        int[] a = selA(), b = selB();
        boolean all = true;
        int minInd = Integer.MAX_VALUE;
        for (int i = a[0]; i <= b[0]; i++) {
            String s = lines.get(i);
            if (s.isBlank()) continue;
            minInd = Math.min(minInd, indentOf(s));
            if (!s.trim().startsWith("--")) all = false;
        }
        if (minInd == Integer.MAX_VALUE) minInd = 0;
        for (int i = a[0]; i <= b[0]; i++) {
            String s = lines.get(i);
            if (s.isBlank() && a[0] != b[0]) continue;
            int d;
            if (all) {
                int k = s.indexOf("--"); int len = s.startsWith("-- ", k) ? 3 : 2;
                lines.set(i, s.substring(0, k) + s.substring(k + len)); d = -len;
            } else { lines.set(i, s.substring(0, Math.min(minInd, s.length())) + "-- " + s.substring(Math.min(minInd, s.length()))); d = 3; }
            if (i == cl) cc = Math.max(0, cc + d);
            if (i == al) ac = Math.max(0, ac + d);
        }
        cc = Math.min(cc, lines.get(cl).length()); ac = Math.min(ac, lines.get(al).length());
        changed();
    }

    // ------------------------------------------------------------------ mouse
    public boolean mouseClicked(double mx, double my, int button) {
        if (!in(mx, my, x, y, x + w, y + h)) return false;
        blink = System.currentTimeMillis();
        comp.clear();
        if (findOpen) {
            int fx = x + w - 230, fy = y + 2, fw = 222;
            int fh = FIND_H - 2 + (replaceOpen ? FIND_H - 4 : 0);
            if (in(mx, my, fx, fy, fx + fw, fy + fh)) {
                findFocus = true;
                if (in(mx, my, fx + fw - 12, fy, fx + fw, fy + 14)) { findOpen = false; findFocus = false; }
                else if (replaceOpen && in(mx, my, fx + 148, fy + FIND_H - 1, fx + 178, fy + FIND_H + 11)) replaceOne();
                else if (replaceOpen && in(mx, my, fx + 182, fy + FIND_H - 1, fx + 216, fy + FIND_H + 11)) replaceAll();
                else findField = replaceOpen && my >= fy + FIND_H - 2 ? 1 : 0;
                return true;
            }
        }
        findFocus = false;
        if (mx >= x + w - 6 && lines.size() > viewLines()) { dragBar = true; dragScroll(my); return true; }
        if (button != 0) return true;
        int l = lineAt(my);
        long now = System.currentTimeMillis();
        clicks = now - lastClick < 300 && l == cl ? clicks + 1 : 1;
        lastClick = now;
        if (mx < x + gutterW()) { al = l; ac = 0; cl = Math.min(l + 1, lines.size() - 1); cc = l + 1 < lines.size() ? 0 : lines.get(l).length(); dragging = true; return true; }
        int c = colAt(l, mx - textX());
        if (clicks == 2) {
            String s = lines.get(l); int a = c, b = c;
            while (a > 0 && LuaLexer.id(s.charAt(a - 1))) a--;
            while (b < s.length() && LuaLexer.id(s.charAt(b))) b++;
            cl = al = l; ac = a; cc = b; return true;
        }
        if (clicks >= 3) { cl = al = l; ac = 0; cc = lines.get(l).length(); return true; }
        cl = l; cc = c; wantX = -1;
        if (!Screen.hasShiftDown()) { al = cl; ac = cc; }
        dragging = true;
        return true;
    }

    void dragScroll(double my) {
        int tp = top(), trackH = y + h - tp;
        targetY = (float) ((my - tp) / trackH * lines.size() - viewLines() / 2.0);
        clampScroll(); scrollY = targetY;
    }

    public boolean mouseDragged(double mx, double my) {
        if (dragBar) { dragScroll(my); return true; }
        if (!dragging) return false;
        if (my < top()) targetY = Math.max(0, targetY - 0.5f);
        if (my > y + h) { targetY += 0.5f; clampScroll(); }
        cl = lineAt(my); cc = colAt(cl, mx - textX());
        return true;
    }

    public void mouseReleased() { dragging = false; dragBar = false; }

    public boolean mouseScrolled(double mx, double my, double delta) {
        if (!in(mx, my, x, y, x + w, y + h)) return false;
        if (Screen.hasShiftDown()) scrollX = Math.max(0, scrollX - (int) (delta * 24));
        else { targetY -= (float) (delta * 3); clampScroll(); }
        return true;
    }

    public void gotoLine(int l) { cl = al = Math.max(0, Math.min(lines.size() - 1, l)); cc = ac = indentOf(lines.get(cl)); targetY = cl - viewLines() / 3f; clampScroll(); }
}
