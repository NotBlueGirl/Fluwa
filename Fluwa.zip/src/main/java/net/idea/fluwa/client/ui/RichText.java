package net.idea.fluwa.client.ui;

import net.minecraft.network.chat.*;

import java.util.*;
import java.util.regex.*;

/** RichText subset: <b> <i> <u> <s> <font color="#rrggbb"> <br/> and &lt; &gt; &amp; &quot; entities. */
final class RichText {
    private RichText() {}
    static final Pattern TAG = Pattern.compile("<(/?)(b|i|u|s|font|br|stroke|uc|sc)([^>]*)>", Pattern.CASE_INSENSITIVE);
    static final Pattern COLOR = Pattern.compile("color\\s*=\\s*[\"']?(#?[0-9a-fA-F]{6}|rgb\\(\\s*\\d+\\s*,\\s*\\d+\\s*,\\s*\\d+\\s*\\))");

    static MutableComponent parse(String src, Style base) {
        MutableComponent out = Component.empty();
        Deque<Style> stack = new ArrayDeque<>();
        Style cur = base;
        Matcher m = TAG.matcher(src);
        int last = 0;
        while (m.find()) {
            if (m.start() > last) out.append(Component.literal(ent(src.substring(last, m.start()))).withStyle(cur));
            last = m.end();
            boolean close = !m.group(1).isEmpty();
            String tag = m.group(2).toLowerCase(Locale.ROOT);
            if (tag.equals("br")) { out.append(Component.literal("\n")); continue; }
            if (close) { cur = stack.isEmpty() ? base : stack.pop(); continue; }
            stack.push(cur);
            switch (tag) {
                case "b" -> cur = cur.withBold(true);
                case "i" -> cur = cur.withItalic(true);
                case "u" -> cur = cur.withUnderlined(true);
                case "s" -> cur = cur.withStrikethrough(true);
                case "font" -> {
                    Matcher c = COLOR.matcher(m.group(3));
                    if (c.find()) {
                        String v = c.group(1);
                        int rgb;
                        if (v.startsWith("rgb")) { String[] p = v.replaceAll("[^0-9,]", "").split(","); rgb = Integer.parseInt(p[0]) << 16 | Integer.parseInt(p[1]) << 8 | Integer.parseInt(p[2]); }
                        else rgb = Integer.parseInt(v.replace("#", ""), 16);
                        cur = cur.withColor(TextColor.fromRgb(rgb));
                    }
                }
                default -> {}
            }
        }
        if (last < src.length()) out.append(Component.literal(ent(src.substring(last))).withStyle(cur));
        return out;
    }

    static String ent(String s) { return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&"); }
}
