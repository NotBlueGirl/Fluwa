package net.idea.fluwa.client;

import net.idea.fluwa.lua.Browser;
import net.idea.fluwa.lua.LObj;
import net.idea.fluwa.lua.WebDom;
import net.idea.fluwa.lua.WebDom.Node;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** Client renderer for Chromium Browser objects (lite engine): simple block/inline HTML layout, links, forms, scrolling. */
public final class BrowserRender {
    private BrowserRender() {}

    static final List<Browser> DRAWN = new ArrayList<>();
    static Browser keyTarget;

    record Op(int kind, int x, int y, int w, int h, String text, int color, float scale, boolean bold, boolean underline, boolean italic) {}
    static final class Layout { int version = -1, width; final List<Op> ops = new ArrayList<>(); int height; int bg = 0xFFFFFFFF; }
    static final WeakHashMap<Browser, Layout> LAYOUTS = new WeakHashMap<>();
    static final WeakHashMap<Browser, long[]> FPS = new WeakHashMap<>();

    static Font font() { return Minecraft.getInstance().font; }

    /** render Browser children of a UI object inside the parent rectangle */
    public static void drawChildren(List<LObj> children, GuiGraphics g, int px, int py, int pw, int ph, int mx, int my, double alpha) {
        for (LObj c : children) if (c instanceof Browser b && b.visible && !b.isDestroyed()) draw(b, g, px, py, pw, ph, mx, my, alpha);
    }

    static void draw(Browser b, GuiGraphics g, int px, int py, int pw, int ph, int mx, int my, double alpha) {
        int x = px + (int) Math.round(b.position.xs * pw + b.position.xo), y = py + (int) Math.round(b.position.ys * ph + b.position.yo);
        int w = (int) Math.round(b.size.xs * pw + b.size.xo), h = (int) Math.round(b.size.ys * ph + b.size.yo);
        if (w <= 2 || h <= 2) return;
        b.ax = x; b.ay = y; b.aw = w; b.ah = h;
        long now = System.currentTimeMillis();
        long[] f = FPS.computeIfAbsent(b, k -> new long[]{now, 0});
        f[1]++;
        if (now - f[0] >= 1000) { b.fps = f[1] * 1000.0 / (now - f[0]); f[0] = now; f[1] = 0; }
        b.drawnFrame = now;
        DRAWN.remove(b); DRAWN.add(b);
        float a = (float) (alpha * (1 - b.transparency));
        int cw = (int) Math.max(40, w / b.zoom);
        Layout l = LAYOUTS.computeIfAbsent(b, k -> new Layout());
        if (l.version != b.version || l.width != cw) layout(b, l, cw);
        b.contentH = l.height;
        if (!b.transparent) g.fill(x, y, x + w, y + h, mul(l.bg, a));
        g.enableScissor(x, y, x + w, y + h);
        g.pose().pushPose();
        g.pose().translate(x - b.scrollX * b.zoom, y - b.scrollY * b.zoom, 0);
        g.pose().scale((float) b.zoom, (float) b.zoom, 1);
        int top = (int) b.scrollY, bottom = (int) (b.scrollY + h / b.zoom);
        Font fn = font();
        for (Op o : l.ops) {
            if (o.y + o.h < top || o.y > bottom) continue;
            switch (o.kind) {
                case 0 -> { // text
                    Style st = Style.EMPTY.withBold(o.bold).withUnderlined(o.underline).withItalic(o.italic);
                    if (o.scale != 1) { g.pose().pushPose(); g.pose().translate(o.x, o.y, 0); g.pose().scale(o.scale, o.scale, 1); g.drawString(fn, Component.literal(o.text).withStyle(st), 0, 0, mul(o.color, a), false); g.pose().popPose(); }
                    else g.drawString(fn, Component.literal(o.text).withStyle(st), o.x, o.y, mul(o.color, a), false);
                }
                case 1 -> g.fill(o.x, o.y, o.x + o.w, o.y + o.h, mul(o.color, a)); // box
                case 2 -> { // outlined control
                    g.fill(o.x, o.y, o.x + o.w, o.y + o.h, mul(o.color, a));
                    int bc = mul(0xFF8A8A9A, a);
                    g.fill(o.x, o.y, o.x + o.w, o.y + 1, bc); g.fill(o.x, o.y + o.h - 1, o.x + o.w, o.y + o.h, bc);
                    g.fill(o.x, o.y, o.x + 1, o.y + o.h, bc); g.fill(o.x + o.w - 1, o.y, o.x + o.w, o.y + o.h, bc);
                }
            }
        }
        if (b.focusNode != null && (System.currentTimeMillis() / 500) % 2 == 0) {
            for (Object[] hh : b.hits) if (hh[4] == b.focusNode) { g.fill((int) hh[2] - 4, (int) hh[1] + 3, (int) hh[2] - 3, (int) hh[3] - 3, mul(0xFF202020, a)); break; }
        }
        g.pose().popPose();
        // scrollbar + loading bar
        double ch = l.height * b.zoom;
        if (ch > h) {
            int th = Math.max(10, (int) (h * h / ch));
            int ty = y + (int) ((h - th) * (b.scrollY * b.zoom) / Math.max(1, ch - h));
            g.fill(x + w - 3, ty, x + w - 1, ty + th, mul(0x80808080, a));
        }
        if (b.loading) { int lw = (int) ((now / 4) % w); g.fill(x, y, x + lw, y + 2, mul(0xFF4F8BFF, a)); }
        g.disableScissor();
    }

    static int mul(int c, float a) { int al = (int) (((c >>> 24) & 255) * Math.max(0, Math.min(1, a))); return (al << 24) | (c & 0xFFFFFF); }

    // ------------------------------------------------------------------ layout
    static final class Ctx {
        int color = 0xFF111111; float scale = 1; boolean bold, underline, italic, pre, center; Node link;
        Ctx copy() { Ctx c = new Ctx(); c.color = color; c.scale = scale; c.bold = bold; c.underline = underline; c.italic = italic; c.pre = pre; c.center = center; c.link = link; return c; }
    }
    static final class St { Browser b; Layout l; int width, cx, cy, lineH = 10, margin = 6, lineStart; List<Integer> lineOps = new ArrayList<>(); boolean lineCenter; }

    static void layout(Browser b, Layout l, int width) {
        l.ops.clear(); b.hits.clear();
        l.version = b.version; l.width = width;
        St s = new St(); s.b = b; s.l = l; s.width = width; s.cx = s.margin; s.cy = s.margin;
        Node body = b.dom.find("body");
        Ctx c = new Ctx();
        l.bg = 0xFFFFFFFF;
        if (body != null) {
            Map<String, String> bs = b.style(body);
            Integer bg = color(bs.getOrDefault("background-color", bs.getOrDefault("background", body.attr("bgcolor"))));
            if (bg != null) l.bg = bg;
            Integer fg = color(bs.getOrDefault("color", body.attr("text")));
            if (fg != null) c.color = fg;
        }
        if (!b.transparent && lum(l.bg) < 0.4 && c.color == 0xFF111111) c.color = 0xFFEEEEEE;
        walk(body != null ? body : b.dom, c, s);
        newline(s);
        l.height = s.cy + s.margin;
    }

    static double lum(int c) { return (((c >> 16) & 255) * 0.299 + ((c >> 8) & 255) * 0.587 + (c & 255) * 0.114) / 255.0; }

    static void newline(St s) {
        if (s.lineCenter && !s.lineOps.isEmpty()) {
            int lineW = s.cx - s.margin, shift = Math.max(0, (s.width - 2 * s.margin - lineW) / 2);
            for (int i : s.lineOps) { Op o = s.l.ops.get(i); s.l.ops.set(i, new Op(o.kind, o.x + shift, o.y, o.w, o.h, o.text, o.color, o.scale, o.bold, o.underline, o.italic)); }
            for (Object[] h : s.b.hits) if ((int) h[1] >= s.cy && (int) h[1] < s.cy + s.lineH) { h[0] = (int) h[0] + shift; h[2] = (int) h[2] + shift; }
        }
        s.lineOps.clear();
        if (s.cx > s.margin) { s.cy += s.lineH; }
        s.cx = s.margin; s.lineH = 10;
    }
    static void blockBreak(St s, int extra) { newline(s); s.cy += extra; }

    static void emit(St s, Op o) { s.lineOps.add(s.l.ops.size()); s.l.ops.add(o); }

    static void walk(Node n, Ctx c, St s) {
        if (n.isText()) { text(n.text, c, s); return; }
        String t = n.tag;
        if (t.equals("#comment") || t.equals("head") || t.equals("script") || t.equals("style") || t.equals("title") || t.equals("meta") || t.equals("link") || t.equals("noscript")) return;
        Map<String, String> st = t.startsWith("#") ? Map.of() : s.b.style(n);
        if ("none".equals(st.get("display")) || n.attrs.containsKey("hidden")) return;
        Ctx k = c.copy();
        Integer col = color(st.get("color"));
        if (col != null) k.color = col;
        if (t.equals("font")) { Integer fc = color(n.attr("color")); if (fc != null) k.color = fc; }
        String fw = st.getOrDefault("font-weight", "");
        if (fw.equals("bold") || fw.matches("[6-9]00")) k.bold = true;
        if ("italic".equals(st.get("font-style"))) k.italic = true;
        if ("center".equals(st.get("text-align")) || t.equals("center") || "center".equalsIgnoreCase(n.attr("align"))) k.center = true;
        String fs = st.get("font-size");
        if (fs != null) { try { if (fs.endsWith("px")) k.scale = Math.max(0.5f, Math.min(4, Float.parseFloat(fs.replace("px", "").trim()) / 12f)); else if (fs.endsWith("em")) k.scale *= Float.parseFloat(fs.replace("em", "").trim()); } catch (Exception ignored) {} }
        boolean block = WebDom.BLOCK.contains(t) || "block".equals(st.get("display"));
        int bgStart = -1, yStart = 0;
        switch (t) {
            case "h1" -> { k.scale = 2f; k.bold = true; }
            case "h2" -> { k.scale = 1.6f; k.bold = true; }
            case "h3" -> { k.scale = 1.3f; k.bold = true; }
            case "h4", "h5", "h6" -> k.bold = true;
            case "b", "strong", "th" -> k.bold = true;
            case "i", "em" -> k.italic = true;
            case "u" -> k.underline = true;
            case "small" -> k.scale *= 0.8f;
            case "pre", "code" -> k.pre = t.equals("pre");
            case "a" -> { if (col == null) k.color = 0xFF2A6BE0; k.underline = true; k.link = n; }
        }
        if (block) {
            blockBreak(s, t.matches("h[1-6]|p|ul|ol|table|blockquote|pre|form") ? 4 : 0);
            Integer bg = color(st.getOrDefault("background-color", st.get("background")));
            if (bg != null) { bgStart = s.l.ops.size(); yStart = s.cy; }
        }
        s.lineCenter = k.center;
        switch (t) {
            case "br" -> { if (s.cx == s.margin) s.cy += s.lineH; newline(s); return; }
            case "hr" -> { newline(s); s.l.ops.add(new Op(1, s.margin, s.cy + 3, s.width - 2 * s.margin, 1, null, 0xFFAAAAAA, 1, false, false, false)); s.cy += 8; return; }
            case "img" -> { control(n, "[" + (n.attr("alt").isEmpty() ? "image" : n.attr("alt")) + "]", 0x22000000, k, s, 0); return; }
            case "input" -> {
                String type = n.attr("type").toLowerCase(Locale.ROOT);
                if (type.equals("hidden")) return;
                if (type.equals("submit") || type.equals("button") || type.equals("reset")) { control(n, n.attr("value").isEmpty() ? "Submit" : n.attr("value"), 0xFFE4E4EA, k, s, 0); return; }
                if (type.equals("checkbox") || type.equals("radio")) { control(n, n.attrs.containsKey("checked") ? "☑" : "☐", 0x00000000, k, s, 0); return; }
                String v = n.attr("value");
                if (type.equals("password")) v = "•".repeat(v.length());
                boolean ph = v.isEmpty();
                control(n, ph ? n.attr("placeholder") : v, 0xFFFFFFFF, k, s, 140, ph);
                return;
            }
            case "textarea" -> { control(n, n.text.isEmpty() ? n.attr("placeholder") : n.text.replace('\n', ' '), 0xFFFFFFFF, k, s, 180, n.text.isEmpty()); return; }
            case "button" -> { control(n, n.innerText(), 0xFFE4E4EA, k, s, 0); return; }
            case "select" -> { List<Node> o = WebDom.select(n, "option", 1); control(n, (o.isEmpty() ? "" : o.get(0).innerText()) + " ▾", 0xFFFFFFFF, k, s, 0); return; }
            case "li" -> text("• ", k, s);
            case "td", "th" -> { if (s.cx > s.margin) s.cx += 8; }
        }
        for (Node ch : new ArrayList<>(n.kids)) walk(ch, k, s);
        if (n.attrs.containsKey("onclick") && !t.equals("a")) {
            // whole element clickable
            s.b.hits.add(0, new Object[]{s.margin, yStart == 0 ? Math.max(0, s.cy - s.lineH) : yStart, s.width - s.margin, s.cy + s.lineH, n});
        }
        if (block) {
            newline(s);
            if (bgStart >= 0) {
                Integer bg = color(st.getOrDefault("background-color", st.get("background")));
                s.l.ops.add(bgStart, new Op(1, s.margin - 3, yStart - 2, s.width - 2 * s.margin + 6, s.cy - yStart + 4, null, bg, 1, false, false, false));
                s.cy += 4;
            }
            s.cy += t.matches("h[1-6]|p|ul|ol|table|blockquote|pre") ? 4 : 0;
            s.lineCenter = c.center;
        }
    }

    static void control(Node n, String label, int bg, Ctx k, St s, int minW) { control(n, label, bg, k, s, minW, false); }
    static void control(Node n, String label, int bg, Ctx k, St s, int minW, boolean placeholder) {
        Font f = font();
        int w = Math.max(minW, f.width(label) + 10), h = 13;
        if (s.cx + w > s.width - s.margin && s.cx > s.margin) newline(s);
        s.lineH = Math.max(s.lineH, h + 3);
        int x = s.cx, y = s.cy;
        if ((bg >>> 24) != 0) emit(s, new Op(2, x, y, w, h, null, bg, 1, false, false, false));
        emit(s, new Op(0, x + 5, y + 3, 0, 9, f.plainSubstrByWidth(label, w - 8), placeholder ? 0xFF8A8A8A : 0xFF111111, 1, false, false, false));
        s.b.hits.add(new Object[]{x, y, x + w, y + h, n});
        s.cx += w + 4;
    }

    static void text(String raw, Ctx c, St s) {
        Font f = font();
        if (c.pre) {
            String[] lines = raw.split("\n", -1);
            for (int i = 0; i < lines.length; i++) {
                if (i > 0) newline(s);
                if (!lines[i].isEmpty()) word(lines[i].replace("\t", "    "), c, s, f);
            }
            return;
        }
        String t = raw.replaceAll("\\s+", " ").replace('\u00A0', ' ');
        if (t.isBlank()) { if (s.cx > s.margin) s.cx += (int) (f.width(" ") * c.scale); return; }
        boolean lead = t.startsWith(" ");
        if (lead && s.cx > s.margin) s.cx += (int) (f.width(" ") * c.scale);
        String[] words = t.trim().split(" ");
        for (int i = 0; i < words.length; i++) {
            word(words[i], c, s, f);
            if (i < words.length - 1 || t.endsWith(" ")) s.cx += (int) (f.width(" ") * c.scale);
        }
    }

    static void word(String w, Ctx c, St s, Font f) {
        Component comp = Component.literal(w).withStyle(Style.EMPTY.withBold(c.bold));
        int ww = (int) Math.ceil(f.width(comp) * c.scale), hh = (int) Math.ceil(9 * c.scale) + 2;
        int avail = s.width - 2 * s.margin;
        if (s.cx + ww > s.width - s.margin && s.cx > s.margin) newline(s);
        if (ww > avail) { // very long word: hard split
            String cut = f.plainSubstrByWidth(w, (int) (avail / c.scale));
            if (!cut.isEmpty() && cut.length() < w.length()) { word(cut, c, s, f); newline(s); word(w.substring(cut.length()), c, s, f); return; }
        }
        s.lineH = Math.max(s.lineH, hh);
        emit(s, new Op(0, s.cx, s.cy, ww, hh, w, c.color, c.scale, c.bold, c.underline, c.italic));
        if (c.link != null) s.b.hits.add(new Object[]{s.cx, s.cy, s.cx + ww, s.cy + hh, c.link});
        s.cx += ww;
    }

    static final Map<String, Integer> NAMED = Map.ofEntries(Map.entry("black", 0x000000), Map.entry("white", 0xFFFFFF), Map.entry("red", 0xFF0000),
            Map.entry("green", 0x008000), Map.entry("blue", 0x0000FF), Map.entry("gray", 0x808080), Map.entry("grey", 0x808080), Map.entry("yellow", 0xFFFF00),
            Map.entry("orange", 0xFFA500), Map.entry("purple", 0x800080), Map.entry("pink", 0xFFC0CB), Map.entry("cyan", 0x00FFFF), Map.entry("magenta", 0xFF00FF),
            Map.entry("lightgray", 0xD3D3D3), Map.entry("lightgrey", 0xD3D3D3), Map.entry("darkgray", 0xA9A9A9), Map.entry("navy", 0x000080), Map.entry("teal", 0x008080),
            Map.entry("lime", 0x00FF00), Map.entry("maroon", 0x800000), Map.entry("silver", 0xC0C0C0), Map.entry("brown", 0xA52A2A), Map.entry("gold", 0xFFD700),
            Map.entry("whitesmoke", 0xF5F5F5), Map.entry("aqua", 0x00FFFF), Map.entry("olive", 0x808000), Map.entry("indigo", 0x4B0082), Map.entry("violet", 0xEE82EE));

    static Integer color(String v) {
        if (v == null) return null;
        v = v.trim().toLowerCase(Locale.ROOT);
        if (v.isEmpty() || v.equals("transparent") || v.equals("none") || v.equals("inherit")) return null;
        try {
            if (v.startsWith("#")) {
                String h = v.substring(1);
                if (h.length() == 3) h = "" + h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
                if (h.length() >= 6) return 0xFF000000 | Integer.parseInt(h.substring(0, 6), 16);
            }
            if (v.startsWith("rgb")) {
                String[] p = v.replaceAll("[^0-9.,]", "").split(",");
                int a = p.length > 3 ? (int) (Double.parseDouble(p[3]) * 255) : 255;
                return (a << 24) | (Integer.parseInt(p[0].split("\\.")[0]) << 16) | (Integer.parseInt(p[1].split("\\.")[0]) << 8) | Integer.parseInt(p[2].split("\\.")[0]);
            }
            String first = v.split("\\s+")[0];
            Integer n = NAMED.get(first);
            if (n != null) return 0xFF000000 | n;
            if (first.startsWith("#") || first.startsWith("rgb")) return color(first);
        } catch (Exception ignored) {}
        return null;
    }

    // ------------------------------------------------------------------ input
    static Browser under(double mx, double my) {
        long now = System.currentTimeMillis();
        for (int i = DRAWN.size() - 1; i >= 0; i--) {
            Browser b = DRAWN.get(i);
            if (b.isDestroyed() || now - b.drawnFrame > 250 || !b.visible) continue;
            if (mx >= b.ax && my >= b.ay && mx < b.ax + b.aw && my < b.ay + b.ah) return b;
        }
        return null;
    }

    static <T> T within(java.util.function.Supplier<T> s) {
        ClientRuntime r = GameRuntime_client();
        return r == null ? s.get() : r.within(s::get);
    }
    static ClientRuntime GameRuntime_client() { return net.idea.fluwa.api.GameRuntime.CLIENT instanceof ClientRuntime r && !r.closed ? r : null; }

    public static boolean click(double mx, double my, int button) {
        Browser b = under(mx, my);
        if (b == null) { keyTarget = null; return false; }
        keyTarget = b;
        within(() -> { b.clickAt(mx - b.ax, my - b.ay, button); return null; });
        return true;
    }
    public static boolean scroll(double mx, double my, double d) {
        Browser b = under(mx, my);
        if (b == null) return false;
        within(() -> { b.scroll(0, -d * 30); return null; });
        return true;
    }
    public static boolean key(int key) {
        Browser b = keyTarget;
        if (b == null || b.isDestroyed()) return false;
        String k = switch (key) {
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> "Enter";
            case GLFW.GLFW_KEY_BACKSPACE -> "Backspace";
            case GLFW.GLFW_KEY_TAB -> "Tab";
            case GLFW.GLFW_KEY_PAGE_UP -> "PageUp";
            case GLFW.GLFW_KEY_PAGE_DOWN -> "PageDown";
            case GLFW.GLFW_KEY_UP -> "Up";
            case GLFW.GLFW_KEY_DOWN -> "Down";
            case GLFW.GLFW_KEY_HOME -> "Home";
            case GLFW.GLFW_KEY_END -> "End";
            default -> null;
        };
        if (k == null) return false;
        if (b.focusNode == null && (k.equals("Enter") || k.equals("Backspace") || k.equals("Tab"))) return false;
        String fk = k;
        within(() -> { b.keyPress(fk); return null; });
        return true;
    }
    public static boolean chr(char c) {
        Browser b = keyTarget;
        if (b == null || b.isDestroyed() || b.focusNode == null || c < 32) return false;
        within(() -> { b.typeText(String.valueOf(c)); return null; });
        return true;
    }

    /** browsers parented directly to UI with Focused = true capture mouse & keyboard through this screen */
    public static final class BrowserScreen extends Screen {
        final Browser b;
        public BrowserScreen(Browser b) { super(Component.literal("Browser")); this.b = b; keyTarget = b; }
        @Override public boolean mouseClicked(double mx, double my, int button) { if (!click(mx, my, button)) { b.focused = false; onClose(); } return true; }
        @Override public boolean mouseScrolled(double mx, double my, double d) { return scroll(mx, my, d); }
        @Override public boolean keyPressed(int key, int sc, int mods) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { b.focused = false; onClose(); return true; }
            return key(key) || super.keyPressed(key, sc, mods);
        }
        @Override public boolean charTyped(char c, int mods) { return chr(c); }
        @Override public void tick() { if (!b.focused || b.isDestroyed()) onClose(); }
        @Override public boolean isPauseScreen() { return false; }
        @Override public void renderBackground(GuiGraphics g) {}
    }

    /** called from the HUD pass: browsers parented directly to UI */
    public static void drawRoot(LObj ui, GuiGraphics g, int w, int h, int mx, int my) {
        drawChildren(ui.children, g, 0, 0, w, h, mx, my, 1);
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null) for (LObj c : ui.children) if (c instanceof Browser b && b.focused && b.visible && !b.isDestroyed()) { mc.setScreen(new BrowserScreen(b)); break; }
    }

    static { ChatFormatting.values(); }
}
