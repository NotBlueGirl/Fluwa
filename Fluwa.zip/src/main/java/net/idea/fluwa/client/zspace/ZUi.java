package net.idea.fluwa.client.zspace;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** ZSpace theme colours and small drawing helpers (flat, minimal, slightly rounded). */
public final class ZUi {
    private ZUi() {}

    /** ZSpace window offset (the screen is drawn translated; scissor rectangles are absolute) */
    public static int OX, OY;
    /** ZSpace UI scale (texts and layout follow the window size, not fixed pixel offsets) */
    public static float SC = 1;
    public static void scissor(GuiGraphics g, int x1, int y1, int x2, int y2) {
        g.enableScissor(OX + (int) Math.floor(x1 * SC), OY + (int) Math.floor(y1 * SC), OX + (int) Math.ceil(x2 * SC), OY + (int) Math.ceil(y2 * SC));
    }

    static final java.util.Map<String, net.minecraft.resources.ResourceLocation> ICONS = new java.util.HashMap<>();
    /** tab / class icon from assets/fluwa/textures/zspace/<name>.png (resource packs can replace them); false if missing */
    public static boolean icon(GuiGraphics g, String name, int x, int y, int size) {
        String key = name.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_]", "");
        net.minecraft.resources.ResourceLocation rl = ICONS.computeIfAbsent(key, k -> {
            var r = new net.minecraft.resources.ResourceLocation("fluwa", "textures/zspace/" + k + ".png");
            return net.minecraft.client.Minecraft.getInstance().getResourceManager().getResource(r).isPresent() ? r : null;
        });
        if (rl == null) return false;
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        g.blit(rl, x, y, size, size, 0, 0, 16, 16, 16, 16);
        return true;
    }

    public static final int BG = 0xF00E0E14, SIDE = 0xF313131B, PANEL = 0xF518181F, EDITOR = 0xF7141419,
            GUTTER = 0xF7111116, TOP = 0xFA101016, LINE = 0xFF262632, HOVER = 0x22FFFFFF, SELROW = 0x338B7CFF,
            TEXT = 0xFFE4E4EE, DIM = 0xFF7C7C92, FAINT = 0xFF4A4A5C,
            OK = 0xFF5BD68A, ERR = 0xFFFF6B7A, WARN = 0xFFFFC66B;
    /** accent colours (Options → Accent) */
    public static int ACCENT = 0xFF8B7CFF, ACCENT2 = 0xFF4FD1C5;
    public static final int[][] ACCENTS = {{0xFF8B7CFF, 0xFF4FD1C5}, {0xFF4F9DFF, 0xFF7CF0FF}, {0xFF3DDC84, 0xFFD4FF6B}, {0xFFFF7A59, 0xFFFFC66B}, {0xFFFF5FA2, 0xFFB98BFF}};

    public static int folderColor(String f) {
        return switch (f) {
            case "Workspace" -> 0xFF5BD68A;
            case "UI" -> 0xFFFF7EB6;
            case "InitScripts" -> 0xFFFFC66B;
            case "ServerScripts" -> 0xFF6FA8FF;
            case "ClientScripts" -> 0xFF4FD1C5;
            case "Console" -> 0xFFB0B0C8;
            default -> ACCENT;
        };
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int r = 0;
        for (int s = 0; s < 32; s += 8) {
            int ca = (a >>> s) & 255, cb = (b >>> s) & 255;
            r |= (Math.round(ca + (cb - ca) * t) & 255) << s;
        }
        return r;
    }

    public static int alpha(int c, float a) {
        int al = Math.round(((c >>> 24) & 255) * Math.max(0, Math.min(1, a)));
        return (c & 0xFFFFFF) | (al << 24);
    }

    /** rectangle with 1px rounded corners */
    public static void round(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
        if (x2 - x1 < 3 || y2 - y1 < 3) { g.fill(x1, y1, x2, y2, c); return; }
        g.fill(x1 + 1, y1, x2 - 1, y2, c);
        g.fill(x1, y1 + 1, x1 + 1, y2 - 1, c);
        g.fill(x2 - 1, y1 + 1, x2, y2 - 1, c);
    }

    public static void outline(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
        g.fill(x1 + 1, y1, x2 - 1, y1 + 1, c);
        g.fill(x1 + 1, y2 - 1, x2 - 1, y2, c);
        g.fill(x1, y1 + 1, x1 + 1, y2 - 1, c);
        g.fill(x2 - 1, y1 + 1, x2, y2 - 1, c);
    }

    /** horizontal gradient a→b; phase (0..1) makes it flow */
    public static void hGrad(GuiGraphics g, int x1, int y1, int x2, int y2, int a, int b, float phase) {
        int w = Math.max(1, x2 - x1);
        for (int x = x1; x < x2; x += 3) {
            float t = (float) (x - x1) / w;
            float k = (float) (0.5 + 0.5 * Math.sin((t + phase) * Math.PI * 2));
            g.fill(x, y1, Math.min(x + 3, x2), y2, lerp(a, b, k));
        }
    }

    public static void shadow(GuiGraphics g, int x1, int y1, int x2, int y2) {
        for (int i = 1; i <= 4; i++) round(g, x1 - i, y1 - i + 2, x2 + i, y2 + i + 2, (0x10 - i * 2) << 24);
    }

    public static void text(GuiGraphics g, Font f, String s, int x, int y, int c) { g.drawString(f, s, x, y, c, false); }

    public static void small(GuiGraphics g, Font f, String s, int x, int y, int c) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(0.75f, 0.75f, 1);
        g.drawString(f, s, 0, 0, c, false);
        g.pose().popPose();
    }

    public static void centered(GuiGraphics g, Font f, String s, int cx, int y, int c) {
        g.drawString(f, s, cx - f.width(s) / 2, y, c, false);
    }

    public static String ellipsize(Font f, String s, int w) {
        if (f.width(s) <= w) return s;
        while (s.length() > 1 && f.width(s + "…") > w) s = s.substring(0, s.length() - 1);
        return s + "…";
    }

    public static boolean in(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    public static float ease(float t) { t = Math.max(0, Math.min(1, t)); return 1 - (1 - t) * (1 - t) * (1 - t); }
}
