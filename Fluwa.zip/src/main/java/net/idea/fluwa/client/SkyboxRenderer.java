package net.idea.fluwa.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.idea.fluwa.client.ui.UiTextures;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/**
 * Custom skybox: one PNG with 6 faces in a 3x2 grid
 * (row 1: bottom, top, north | row 2: south, east, west), from .minecraft/fluwa/skyboxes/ or a resource location.
 */
public final class SkyboxRenderer {
    private SkyboxRenderer() {}

    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;
        if (Minecraft.getInstance().level == null) return;
        try { LightingClient.renderSkybox(e); LightingClient.renderCelestial(e); }
        catch (RuntimeException ex) { net.idea.fluwa.Fluwa.LOGGER.debug("sky", ex); }
    }

    /** draws a 3x2 skybox image */
    public static boolean draw(PoseStack ps, String file) {
        ResourceLocation tex = UiTextures.get(file, "skyboxes");
        if (tex == null) return false;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        Tesselator t = Tesselator.getInstance();
        BufferBuilder b = t.getBuilder();
        for (int i = 0; i < 6; i++) {
            ps.pushPose();
            switch (i) {
                case 1 -> ps.mulPose(Axis.XP.rotationDegrees(180));
                case 2 -> ps.mulPose(Axis.XP.rotationDegrees(90));
                case 3 -> ps.mulPose(Axis.XP.rotationDegrees(-90));
                case 4 -> ps.mulPose(Axis.ZP.rotationDegrees(90));
                case 5 -> ps.mulPose(Axis.ZP.rotationDegrees(-90));
            }
            float u0 = (i % 3) / 3f, v0 = (i / 3) / 2f, u1 = u0 + 1 / 3f, v1 = v0 + 0.5f;
            Matrix4f m = ps.last().pose();
            b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
            b.vertex(m, -100, -100, -100).uv(u0, v0).endVertex();
            b.vertex(m, -100, -100, 100).uv(u0, v1).endVertex();
            b.vertex(m, 100, -100, 100).uv(u1, v1).endVertex();
            b.vertex(m, 100, -100, -100).uv(u1, v0).endVertex();
            t.end();
            ps.popPose();
        }
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        return true;
    }
}
