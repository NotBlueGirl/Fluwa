package net.idea.fluwa.client.zspace;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferUploader;
import net.idea.fluwa.client.ShaderDT;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.*;

import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

import static net.idea.fluwa.client.zspace.ZUi.*;

/**
 * ZSpace → ☰ → Tools → Shader DK: write GLSL post-processing shaders with a live preview on a snapshot of the world,
 * edit uniforms, apply to the game, try vanilla presets, save to .minecraft/fluwa/shaders and export as a ClientScript.
 */
public class ShaderDKScreen extends ZWindow {
    static final LinkedHashMap<String, String> TEMPLATES = new LinkedHashMap<>();
    static {
        TEMPLATES.put("Passthrough", "void main() {\n    fragColor = texture(DiffuseSampler, texCoord);\n}\n");
        TEMPLATES.put("Grayscale", "uniform float Strength;\n\nvoid main() {\n    vec4 c = texture(DiffuseSampler, texCoord);\n    float g = dot(c.rgb, vec3(0.299, 0.587, 0.114));\n    fragColor = vec4(mix(c.rgb, vec3(g), Strength), 1.0);\n}\n");
        TEMPLATES.put("Vignette", "uniform float Strength;\n\nvoid main() {\n    vec4 c = texture(DiffuseSampler, texCoord);\n    float d = distance(texCoord, vec2(0.5));\n    c.rgb *= 1.0 - smoothstep(0.3, 0.8, d) * Strength;\n    fragColor = vec4(c.rgb, 1.0);\n}\n");
        TEMPLATES.put("Wave", "uniform float Strength;\n\nvoid main() {\n    vec2 uv = texCoord;\n    uv.x += sin(uv.y * 30.0 + Time * 3.0) * 0.01 * Strength;\n    fragColor = vec4(texture(DiffuseSampler, uv).rgb, 1.0);\n}\n");
        TEMPLATES.put("Pixelate", "uniform float Strength;\n\nvoid main() {\n    float px = max(1.0, Strength * 12.0);\n    vec2 cell = px / ScreenSize;\n    vec2 uv = floor(texCoord / cell) * cell + cell * 0.5;\n    fragColor = vec4(texture(DiffuseSampler, uv).rgb, 1.0);\n}\n");
        TEMPLATES.put("Night vision", "uniform float Strength;\n\nvoid main() {\n    vec3 c = texture(DiffuseSampler, texCoord).rgb;\n    float l = dot(c, vec3(0.3, 0.6, 0.1));\n    vec3 nv = vec3(0.1, 1.0, 0.2) * pow(l, 0.6) * 1.6;\n    nv *= 0.9 + 0.1 * sin(texCoord.y * ScreenSize.y * 1.5 + Time * 20.0);\n    fragColor = vec4(mix(c, nv, Strength), 1.0);\n}\n");
        TEMPLATES.put("Chromatic", "uniform float Strength;\n\nvoid main() {\n    vec2 o = (texCoord - 0.5) * 0.012 * Strength;\n    float r = texture(DiffuseSampler, texCoord + o).r;\n    float g = texture(DiffuseSampler, texCoord).g;\n    float b = texture(DiffuseSampler, texCoord - o).b;\n    fragColor = vec4(r, g, b, 1.0);\n}\n");
        TEMPLATES.put("Tint", "uniform vec3 TintColor;\nuniform float Strength;\n\nvoid main() {\n    vec3 c = texture(DiffuseSampler, texCoord).rgb;\n    fragColor = vec4(mix(c, c * TintColor, Strength), 1.0);\n}\n");
    }
    static final Pattern UNIFORM = Pattern.compile("uniform\\s+(float|vec2|vec3|vec4)\\s+(\\w+)\\s*;");
    static final Pattern GLERR = Pattern.compile("0[:(](\\d+)\\)?\\s*:?\\s*(?:error)?\\s*:?\\s*(.*)");

    static String curName = "my_shader", curSrc;
    static final Map<String, String> UVALS = new HashMap<>();
    static boolean applied;

    final CodeEditor ed;
    int program; String log = ""; int lastHash; long editedAt;
    int listScroll;
    String tab = "files";
    long deleteArm;

    public ShaderDKScreen(Screen parent) {
        super("Shader DK", parent, 540, 300);
        ed = new CodeEditor(Minecraft.getInstance().font);
        ed.luaCheck = false;
        ed.setText(curSrc != null ? curSrc : TEMPLATES.get("Vignette"));
        ed.markSaved();
    }

    static Path dir() { return Minecraft.getInstance().gameDirectory.toPath().resolve("fluwa").resolve("shaders"); }
    static List<String> files() {
        List<String> l = new ArrayList<>();
        try { if (Files.isDirectory(dir())) try (var st = Files.list(dir())) { st.filter(p -> p.toString().endsWith(".glsl")).forEach(p -> l.add(p.getFileName().toString().replaceAll("\\.glsl$", ""))); } } catch (Exception ignored) {}
        Collections.sort(l);
        return l;
    }

    // ------------------------------------------------------------------ compile / uniforms
    void compile() {
        String src = ed.getText();
        lastHash = src.hashCode();
        StringBuilder sb = new StringBuilder();
        int p = ShaderDT.link(src, sb);
        if (program != 0 && program != ShaderDT.studioProgram()) GL20.glDeleteProgram(program);
        program = p;
        log = sb.toString();
        ed.errLine = -1; ed.errMsg = null;
        if (p == 0) {
            for (String line : log.split("\n")) {
                Matcher m = GLERR.matcher(line.trim());
                if (m.find()) { ed.errLine = Math.max(0, Integer.parseInt(m.group(1)) - 1); ed.errMsg = m.group(2).trim(); break; }
            }
            if (ed.errMsg == null && !log.isBlank()) ed.errMsg = log.split("\n")[0];
            setStatus(false, "Compile error: " + (ed.errMsg == null ? "?" : ed.errMsg));
        } else {
            setStatus(true, "Compiled ✓");
            if (applied) ShaderDT.studio(program, uniforms());
        }
    }

    List<String[]> declared() {
        List<String[]> l = new ArrayList<>();
        Matcher m = UNIFORM.matcher(ed.getText());
        while (m.find()) if (!Set.of("Time").contains(m.group(2)) && !m.group(2).equals("ScreenSize")) l.add(new String[]{m.group(1), m.group(2)});
        return l;
    }

    Map<String, float[]> uniforms() {
        Map<String, float[]> u = new LinkedHashMap<>();
        for (String[] d : declared()) {
            int n = d[0].equals("float") ? 1 : d[0].charAt(3) - '0';
            String v = UVALS.getOrDefault(d[1], n == 1 ? "1" : "1, 1, 1, 1");
            String[] parts = v.split("[,; ]+");
            float[] f = new float[n];
            for (int i = 0; i < n; i++) { try { f[i] = Float.parseFloat(parts[Math.min(i, parts.length - 1)]); } catch (Exception e) { f[i] = 1; } }
            u.put(d[1], f);
        }
        return u;
    }

    void toggleApply() {
        applied = !applied;
        if (applied && program == 0) compile();
        ShaderDT.studio(applied ? program : 0, uniforms());
        setStatus(true, applied ? "Shader applied to the game view" : "Shader removed from the game view");
    }

    void save() {
        String n = box("name", "name").getValue().trim().replaceAll("[^\\w\\-]", "_");
        if (n.isEmpty()) { setStatus(false, "Type a name"); return; }
        try { Files.createDirectories(dir()); Files.writeString(dir().resolve(n + ".glsl"), ed.getText()); curName = n; ed.markSaved(); setStatus(true, "Saved .minecraft/fluwa/shaders/" + n + ".glsl"); }
        catch (Exception e) { setStatus(false, "Can't save: " + e.getMessage()); }
    }

    void open(String n) {
        try { ed.setText(Files.readString(dir().resolve(n + ".glsl"))); ed.markSaved(); curName = n; box("name", "name").setValue(n); compile(); }
        catch (Exception e) { setStatus(false, "Can't open: " + e.getMessage()); }
    }

    void export() {
        String n = box("name", "name").getValue().trim().replaceAll("[^\\w\\-]", "_");
        if (n.isEmpty()) n = "shader";
        StringBuilder sb = new StringBuilder("-- " + n + "  ·  made with Shader DK\nlocal ShaderDT = getAccess(\"ShaderDT\")\nlocal shader = ShaderDT:Create([==[\n")
                .append(ed.getText()).append("]==])\n");
        for (var e : uniforms().entrySet()) {
            float[] f = e.getValue();
            sb.append("shader:SetUniform(\"").append(e.getKey()).append("\", ");
            if (f.length == 1) sb.append(f[0]); else { sb.append('{'); for (int i = 0; i < f.length; i++) { if (i > 0) sb.append(", "); sb.append(f[i]); } sb.append('}'); }
            sb.append(")\n");
        }
        FluwaNet.toServer(new Pkt(Pkt.C_ZSAVE, List.of("ClientScripts", "Shaders/" + n, sb.toString()), new int[]{ZOptions.reloadOnSave ? 1 : 0}, null));
        setStatus(true, "Exported to ClientScripts/Shaders/" + n + ".lua");
    }

    // ------------------------------------------------------------------ render
    @Override protected String subtitle() { return "GLSL post-processing"; }
    @Override protected String hint() { return "F5 / Ctrl+Enter compile · uniforms: DiffuseSampler, Time, ScreenSize, texCoord → fragColor"; }

    @Override protected void renderBody(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my, float pt) {
        ShaderDT.snapshotWanted = System.currentTimeMillis();
        int listW = Math.max(110, (x1 - x0) * 20 / 100), prevW = Math.max(150, (x1 - x0) * 34 / 100);
        // ---- list
        g.fill(x0, y0, x0 + listW, y1, SIDE);
        String[] tabs = {"files", "templates", "presets"};
        int tw = (listW - 8) / 3;
        for (int i = 0; i < 3; i++) { String t = tabs[i]; button(g, "tab" + t, x0 + 4 + i * tw, y0 + 4, tw - 2, 13, t.substring(0, 1).toUpperCase() + t.substring(1), t.equals(tab) ? 3 : 0, mx, my, () -> { tab = t; listScroll = 0; }); }
        List<String> items = switch (tab) { case "templates" -> new ArrayList<>(TEMPLATES.keySet()); case "presets" -> new ArrayList<>(ShaderDT.presets()); default -> files(); };
        int top = y0 + 21, bot = y1 - 4;
        scissor(g, x0, top, x0 + listW, bot);
        int y = top - listScroll;
        if (items.isEmpty()) small(g, font, tab.equals("files") ? "No saved shaders yet" : "-", x0 + 8, top + 4, FAINT);
        for (String it : items) {
            boolean sel = tab.equals("presets") ? it.equals(ShaderDT.currentPreset()) : tab.equals("files") && it.equals(curName);
            boolean hov = in(mx, my, x0 + 2, y, x0 + listW - 2, y + ROW) && my >= top && my < bot;
            if (sel) round(g, x0 + 2, y, x0 + listW - 2, y + ROW, SELROW); else if (hov) round(g, x0 + 2, y, x0 + listW - 2, y + ROW, HOVER);
            text(g, font, ellipsize(font, it, listW - 14), x0 + 8, y + 3, sel ? 0xFFFFFFFF : 0xFFC8C8D8);
            final String f = it;
            if (y + ROW > top && y < bot) hits.add(new Hit(x0 + 2, Math.max(top, y), x0 + listW - 2, Math.min(bot, y + ROW), () -> {
                switch (tab) {
                    case "templates" -> { ed.setText(TEMPLATES.get(f)); ed.markUnsaved(); box("name", "name").setValue(f.toLowerCase(Locale.ROOT).replace(' ', '_')); compile(); }
                    case "presets" -> { ShaderDT.loadPreset(f.equals(ShaderDT.currentPreset()) ? null : f); setStatus(true, ShaderDT.currentPreset() == null ? "Preset off" : "Vanilla preset '" + f + "' applied to the game view (ShaderDT:Preset)"); }
                    default -> open(f);
                }
            }));
            y += ROW;
        }
        g.disableScissor();
        g.fill(x0 + listW, y0, x0 + listW + 1, y1, LINE);
        // ---- editor
        int ex0 = x0 + listW + 1, ex1 = x1 - prevW;
        g.fill(ex0, y0, ex1, y0 + 20, 0xF20F0F15);
        EditBox nb = box("name", "name");
        if (nb.getValue().isEmpty() && getFocused() != nb) nb.setValue(curName);
        place(g, nb, ex0 + 4, y0 + 3, Math.max(50, (ex1 - ex0) / 3));
        int bx = ex1 - 4;
        int w = bw("Export"); bx -= w; button(g, "exp", bx, y0 + 3, w, 14, "Export", 0, mx, my, this::export);
        w = bw(ed.modified() ? "● Save" : "Save"); bx -= w + 3; button(g, "save", bx, y0 + 3, w, 14, ed.modified() ? "● Save" : "Save", 0, mx, my, this::save);
        w = bw("Compile"); bx -= w + 3; button(g, "comp", bx, y0 + 3, w, 14, "Compile", 1, mx, my, this::compile);
        ed.x = ex0; ed.y = y0 + 20; ed.w = ex1 - ex0; ed.h = y1 - y0 - 20 - (log.isBlank() || program != 0 ? 0 : 30);
        ed.render(g, mx, my, (System.currentTimeMillis() % 100000) / 1000f);
        if (!log.isBlank() && program == 0) {
            int ly = y1 - 30;
            g.fill(ex0, ly, ex1, y1, 0xF2160E12);
            int yy = ly + 3;
            for (String l : log.split("\n")) { if (yy > y1 - 8) break; small(g, font, ellipsize(font, l, (ex1 - ex0 - 12) * 4 / 3), ex0 + 6, yy, ERR); yy += 8; }
        }
        // auto compile shortly after typing
        int h = ed.getText().hashCode();
        if (h != lastHash) { if (editedAt == 0) editedAt = System.currentTimeMillis(); else if (System.currentTimeMillis() - editedAt > 700) { editedAt = 0; compile(); } }
        g.fill(ex1, y0, ex1 + 1, y1, LINE);
        // ---- preview + uniforms
        int px0 = ex1 + 1, px1 = x1;
        g.fill(px0, y0, px1, y1, PANEL);
        label(g, "Preview", px0 + 8, y0 + 6);
        int ab = bw(applied ? "Applied ✓" : "Apply in game");
        button(g, "apply", px1 - 6 - ab, y0 + 3, ab, 13, applied ? "Applied ✓" : "Apply in game", applied ? 1 : 0, mx, my, this::toggleApply);
        int pw = px1 - px0 - 16, ph = Math.max(40, Math.min(pw * 9 / 16, (y1 - y0) / 2));
        int ppx = px0 + 8, ppy = y0 + 20;
        round(g, ppx - 1, ppy - 1, ppx + pw + 1, ppy + ph + 1, 0xFF000000);
        drawPreview(g, ppx, ppy, pw, ph);
        if (program == 0) centered(g, font, "compile error", ppx + pw / 2, ppy + ph / 2 - 4, ERR);
        // uniforms
        int uy = ppy + ph + 8;
        label(g, "Uniforms", px0 + 8, uy); uy += 10;
        List<String[]> us = declared();
        if (us.isEmpty()) small(g, font, "declare: uniform float Strength;", px0 + 8, uy + 2, FAINT);
        for (String[] u : us) {
            if (uy > y1 - 16) break;
            text(g, font, ellipsize(font, u[1], 60), px0 + 8, uy + 3, DIM);
            EditBox b = box("u:" + u[1], u[0].equals("float") ? "1.0" : "r, g, b");
            if (b.getValue().isEmpty() && getFocused() != b) b.setValue(UVALS.getOrDefault(u[1], u[0].equals("float") ? "1" : "1, 1, 1, 1"));
            place(g, b, px0 + 70, uy, px1 - px0 - 78);
            if (!b.getValue().equals(UVALS.get(u[1]))) { UVALS.put(u[1], b.getValue()); if (applied) ShaderDT.studioUniforms(uniforms()); }
            uy += 17;
        }
    }

    static int vao;
    void drawPreview(GuiGraphics g, int x, int y, int w, int h) {
        var snap = ShaderDT.snapshot;
        if (program == 0 || snap == null) { g.fill(x, y, x + w, y + h, 0xFF101018); return; }
        g.flush();
        var win = Minecraft.getInstance().getWindow();
        double gs = win.getGuiScale();
        int fx = (int) Math.round((wx + x * S) * gs), fw = (int) Math.round(w * S * gs), fh = (int) Math.round(h * S * gs);
        int fy = win.getHeight() - (int) Math.round((wy + (y + h) * S) * gs);
        if (vao == 0) vao = GL30.glGenVertexArrays();
        try {
            RenderSystem.viewport(fx, fy, fw, fh);
            RenderSystem.disableDepthTest(); RenderSystem.disableBlend(); RenderSystem.disableCull();
            GlStateManager._glUseProgram(program);
            RenderSystem.activeTexture(GL13.GL_TEXTURE0);
            RenderSystem.bindTexture(snap.getColorTextureId());
            GL20.glUniform1i(GL20.glGetUniformLocation(program, "DiffuseSampler"), 0);
            GL20.glUniform1f(GL20.glGetUniformLocation(program, "Time"), (System.currentTimeMillis() % 3_600_000) / 1000f);
            GL20.glUniform2f(GL20.glGetUniformLocation(program, "ScreenSize"), fw, fh);
            for (var u : uniforms().entrySet()) {
                int loc = GL20.glGetUniformLocation(program, u.getKey());
                if (loc < 0) continue;
                float[] f = u.getValue();
                switch (f.length) { case 1 -> GL20.glUniform1f(loc, f[0]); case 2 -> GL20.glUniform2f(loc, f[0], f[1]); case 3 -> GL20.glUniform3f(loc, f[0], f[1], f[2]); default -> GL20.glUniform4f(loc, f[0], f[1], f[2], f[3]); }
            }
            GL30.glBindVertexArray(vao);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
            GL30.glBindVertexArray(0);
        } catch (RuntimeException e) {
            setStatus(false, "Preview error: " + e.getMessage());
        } finally {
            BufferUploader.invalidate();
            GlStateManager._glUseProgram(0);
            RenderSystem.viewport(0, 0, win.getWidth(), win.getHeight());
            RenderSystem.enableDepthTest(); RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        }
    }

    // ------------------------------------------------------------------ input
    boolean inEd(double mx, double my) { return in(mx, my, ed.x, ed.y, ed.x + ed.w, ed.y + ed.h); }
    @Override protected boolean bodyClick(double mx, double my, int b) {
        if (inEd(mx, my)) { setFocused(null); ed.focused = true; return ed.mouseClicked(mx, my, b); }
        ed.focused = false;
        return false;
    }
    @Override protected boolean bodyDrag(double mx, double my, int b, double dx, double dy) { return ed.mouseDragged(mx, my); }
    @Override protected boolean bodyRelease(double mx, double my, int b) { ed.mouseReleased(); return false; }
    @Override protected boolean bodyScroll(double mx, double my, double d) {
        if (inEd(mx, my)) return ed.mouseScrolled(mx, my, d);
        listScroll = Math.max(0, listScroll - (int) (d * ROW * 2));
        return true;
    }
    @Override protected boolean bodyKey(int key, int mods) {
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
        if (key == GLFW.GLFW_KEY_F5 || (ctrl && key == GLFW.GLFW_KEY_ENTER)) { compile(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_S) { save(); return true; }
        if (ed.focused) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { ed.focused = false; return true; }
            return ed.keyPressed(key, mods) || key == GLFW.GLFW_KEY_TAB;
        }
        return false;
    }
    @Override protected boolean bodyChar(char c) { return ed.focused && ed.charTyped(c); }
    @Override protected void onInit() { if (program == 0) compile(); }
    @Override public void tick() { super.tick(); ed.tick(); }
    @Override public void removed() {
        curSrc = ed.getText();
        if (program != 0 && program != ShaderDT.studioProgram()) { GL20.glDeleteProgram(program); program = 0; }
        super.removed();
    }
}
