package net.idea.fluwa.client;

import net.idea.fluwa.api.*;
import net.idea.fluwa.client.ui.*;
import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.idea.fluwa.server.ServerRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.luaj.vm2.*;

import java.util.*;

/** Lua runtime on the client: runs InitScripts, UI, ClientScripts received from the server. */
public class ClientRuntime extends GameRuntime {
    final Map<String, Map<String, String>> scripts;
    public final LObj ui = new WorldObj.Container("UI");
    final Map<String, LuaValue> clientObjects = new HashMap<>();
    private final NetBridge bridge = new NetBridge() {
        public void fireServer(String e, LuaValue a) { FluwaNet.toServer(new Pkt(Pkt.C_REMOTE, List.of(e), null, LuaSer.encode(a))); }
        public void firePlayer(LObj p, String e, int k, LuaValue a) { throw new LuaError("Event:FirePlayer is only Server-Side"); }
        public void fireAllPlayers(String e, LuaValue a) { throw new LuaError("Event:FireAllPlayers is only Server-Side"); }
        public void fireRadius(String e, LuaValue a, double r, Vec3L c, LObj d) { throw new LuaError("Event:FireAll is only Server-Side"); }
    };

    public ClientRuntime(Map<String, Map<String, String>> scripts) { super(false); this.scripts = scripts; }

    static Minecraft mc() { return Minecraft.getInstance(); }

    @Override protected void setupGlobals() {
        LightingClient.init();
        world = new WorldObj();
        g.set("game", new ServerRuntime.GameObj(this));
        g.set("World", world);
        g.set("Workspace", world);
        g.set("workspace", world);
        g.set("Players", world.players);
        g.set("Lighting", world.lighting);
        g.set("Terrain", world.terrain);
        g.set("UI", ui);
        g.set("IsServer", LuaValue.FALSE);
        g.set("IsClient", LuaValue.TRUE);
        ItemTree.root(this, "InitScripts"); ItemTree.root(this, "ClientScripts");
        refreshDimension();
        registerService("ShaderDT", ShaderDT::new);
        registerService("UserInputService", () -> uis == null ? (uis = new UserInputService(this)) : uis);
        net.idea.fluwa.lua.Chromium.CLIENT_OPEN = PageScreen::open;
        net.idea.fluwa.lua.Chromium.CLIENT_PAGE = PageScreen::show;
        net.idea.fluwa.lua.Browser.CLIENT_DEVTOOLS = PageScreen::show;
        for (var t : UiFactory.TYPES.entrySet()) { var sup = t.getValue(); factory.put(t.getKey(), sup::get); }
        net.idea.fluwa.api.Projector.CLIENT_SINK = ClientProjector::handle;
        net.idea.fluwa.api.Projector.CLIENT_OPEN_GUI = this::openScreen;
        g.set("getAllGUIs", new org.luaj.vm2.lib.ZeroArgFunction() { public LuaValue call() { return allGuis(); } });
        factory.put("Item", () -> new ItemObj(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.STONE)));
        factory.put("Block", BlockObj::new);
        factory.put("Entity", () -> new net.idea.fluwa.api.EntityObj((Entity) null));
        for (String t : new String[]{"Structure", "Dimension", "Player"})
            factory.put(t, () -> { throw new LuaError(t + " can only be created on the server"); });
    }

    /** global Dimension = the client's current dimension */
    public void refreshDimension() { g.set("Dimension", mc().level == null ? LuaValue.NIL : within(() -> wrap(mc().level))); }

    public void start() {
        within(() -> { ItemTree.build(this, scripts); return null; });
        for (String f : new String[]{"InitScripts", "UI", "ClientScripts"})
            for (var e : scripts.getOrDefault(f, Map.of()).entrySet()) runScript(f + "/" + e.getKey(), e.getValue());
    }

    @Override public void output(int level, String msg) {
        if (level == 2) LOG.error("[Fluwa client] {}", msg); else LOG.info("[Fluwa client] {}", msg);
        ClientState.CONSOLE.addLast("[client] " + msg);
        while (ClientState.CONSOLE.size() > 300) ClientState.CONSOLE.removeFirst();
        if (mc().player != null && (level > 0 || mc().player.hasPermissions(2) || mc().hasSingleplayerServer()))
            mc().player.displayClientMessage(Component.literal((level == 2 ? "§c" : level == 1 ? "§e" : "§7") + "[Fluwa client] " + msg), false);
    }

    @Override protected String findModule(String name) {
        for (String f : new String[]{"InitScripts", "UI", "ClientScripts"}) {
            String s = scripts.getOrDefault(f, Map.of()).get(name);
            if (s != null) return s;
        }
        return null;
    }

    @Override public Player resolvePlayer(UUID id) { return mc().level == null ? null : mc().level.getPlayerByUUID(id); }
    @Override public Level resolveLevel(ResourceKey<Level> key) { return mc().level != null && mc().level.dimension() == key ? mc().level : null; }
    @Override public Collection<? extends Player> allPlayers() { return mc().level == null ? List.of() : mc().level.players(); }
    @Override public Collection<? extends Level> levels() { return mc().level == null ? List.of() : List.of(mc().level); }
    @Override public NetBridge bridge() { return bridge; }
    @Override public Iterable<Entity> clientEntities() { return mc().level == null ? List.of() : mc().level.entitiesForRendering(); }
    static int nextLocalId = -1000;
    @Override public Entity spawnLocal(String type, net.minecraft.world.phys.Vec3 pos) {
        var lvl = mc().level;
        if (lvl == null) throw new LuaError("No client level");
        Entity en = net.minecraft.world.entity.EntityType.byString(type).map(t -> t.create(lvl)).orElseThrow(() -> new LuaError("Unknown entity type " + type));
        en.setId(nextLocalId--);
        en.moveTo(pos.x, pos.y, pos.z, 0, 0);
        lvl.putNonPlayerEntity(en.getId(), en);
        return en;
    }
    @Override public void removeLocal(Entity e) { if (mc().level != null) mc().level.removeEntity(e.getId(), Entity.RemovalReason.DISCARDED); }
    @Override public net.idea.fluwa.mesh.Mesh meshOf(java.util.UUID id) { return ClientModels.mesh(id); }
    @Override public boolean partHidden(java.util.UUID id, String part) { return ClientModels.hidden(id, part); }
    @Override public String modelDesc(java.util.UUID id) { return ClientModels.desc(id); }
    @Override public net.minecraft.world.entity.Entity entityByUuid(java.util.UUID id) {
        var l = net.minecraft.client.Minecraft.getInstance().level;
        if (l != null) for (var en : l.entitiesForRendering()) if (en.getUUID().equals(id)) return en;
        return null;
    }
    @Override public float[] partTransform(java.util.UUID id, String part) { return ClientModels.transform(id, part); }
    @Override public java.util.List<String> modelPartNames(net.minecraft.world.entity.Entity e) {
        java.util.List<String> l = new java.util.ArrayList<>();
        net.idea.fluwa.mesh.Mesh m = ClientModels.mesh(e.getUUID());
        if (m != null) for (var p : m.parts) l.add(p.name); else l.addAll(ModelParts.namesFor(e));
        l.remove("Model");
        return l;
    }
    @Override public void setPartTransform(java.util.UUID id, String part, float[] xf) { ClientModels.setTransform(id, part, xf); }
    @Override public void setPartHidden(java.util.UUID id, String part, boolean hidden) { ClientModels.setHidden(id, part, hidden); }
    @Override public void localFlag(java.util.UUID id, String flag, boolean on) {
        ClientModels.entityFlag(new net.idea.fluwa.net.Pkt(net.idea.fluwa.net.Pkt.S_ENTFLAG, java.util.List.of(id.toString(), flag), new int[]{on ? 1 : 0}, null));
    }
    @Override public net.idea.fluwa.lua.LObj localPlayerObj() {
        if (mc().player != null) return wrap(mc().player);
        var c = mc().getConnection();
        if (c == null) return null;
        var gp = c.getLocalGameProfile();
        return players.computeIfAbsent(gp.getId(), u -> within(() -> new net.idea.fluwa.api.PlayerObj(u, gp.getName())));
    }
    @Override public LuaValue localPlayer() { return mc().player == null ? LuaValue.NIL : wrap(mc().player); }

    @Override public void checkClientWrite() {
        if (!ClientState.asynced) throw new LuaError("Client-side world changes need Player:Async() (server) first");
    }

    @Override public int clientPing(UUID id) {
        var c = mc().getConnection();
        var info = c == null ? null : c.getPlayerInfo(id);
        return info == null ? 0 : info.getLatency();
    }

    @Override public LuaValue clientInfo(String what) {
        if (what.equals("ResourcePack")) {
            List<LuaValue> l = new ArrayList<>();
            for (String s : mc().getResourcePackRepository().getSelectedIds()) l.add(LuaValue.valueOf(s));
            return LObj.list(l);
        }
        if (what.equals("Shader")) {
            var pc = mc().gameRenderer.currentEffect();
            return pc == null ? LuaValue.NIL : LuaValue.valueOf(pc.getName());
        }
        return LuaValue.NIL;
    }

    @Override public void playLocalSound(PlayerObj p, String id, float vol, float pitch) {
        if (LocalAudio.isFile(id)) { LocalAudio.play(id, vol, pitch); return; }
        mc().getSoundManager().play(SimpleSoundInstance.forUI(Conv.sound(id), pitch, vol));
    }

    @Override public LuaValue clientObject(String what, PlayerObj p) {
        if (mc().player == null || !p.uuid.equals(mc().player.getUUID())) throw new LuaError("Player:Get" + what + "() works only for Players.LocalPlayer");
        return clientObjects.computeIfAbsent(what, w -> within(() -> switch (w) {
            case "Mouse" -> new ClientObjects.Mouse();
            case "Camera" -> new ClientObjects.Camera();
            case "PlayerGui", "CoreGui" -> ui;
            default -> ClientObjects.model();
        }));
    }

    public ClientObjects.Mouse mouse() { LuaValue m = clientObjects.get("Mouse"); return m instanceof ClientObjects.Mouse mm ? mm : null; }

    /** Opens a ScreenGUI from UI by name (Block:ConnectScreen) */
    public void openScreen(String name) {
        within(() -> {
            for (LObj o : ui.listChildren()) if (o instanceof ScreenGuiObj s && !s.overlay && s.getName().equals(name)) { s.setEnabled(true); return null; }
            output(1, "Block screen '" + name + "' not found in UI");
            return null;
        });
    }

    /** ScreenGUI shown by its own pausing screen (PauseGame = true) */
    static boolean hosted(ScreenGuiObj s) { return mc().screen instanceof FluwaUiScreen fs && !fs.focusOnly && fs.gui == s; }

    /** an enabled ScreenGUI with Modal = true frees the cursor (no Minecraft screen, movement keys keep working) */
    public boolean modalActive() {
        if (closed) return false;
        for (LObj o : ui.listChildren()) if (o instanceof ScreenGuiObj s && !s.overlay && s.enabled && s.modal && s.visible && !hosted(s)) return true;
        return false;
    }
    boolean wasModal;
    double lastMx = Double.NaN, lastMy;

    /** every frame: release / re-grab the cursor for modal ScreenGUIs, drag for sliders and scrolling frames */
    public void uiFrame() {
        var mc = mc();
        boolean modal = mc.screen == null && mc.player != null && modalActive();
        if (modal && mc.mouseHandler.isMouseGrabbed()) mc.mouseHandler.releaseMouse();
        if (!modal && wasModal && mc.screen == null && !mc.mouseHandler.isMouseGrabbed() && mc.isWindowActive()) mc.mouseHandler.grabMouse();
        wasModal = modal;
        double[] p = guiMouse();
        if (modal && !Double.isNaN(lastMx) && (p[0] != lastMx || p[1] != lastMy)
                && org.lwjgl.glfw.GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), 0) == org.lwjgl.glfw.GLFW.GLFW_PRESS) {
            double dx = p[0] - lastMx, dy = p[1] - lastMy;
            within(() -> UiInput.drag(p[0], p[1], dx, dy));
        }
        lastMx = p[0]; lastMy = p[1];
    }

    public static double[] guiMouse() {
        var w = mc().getWindow();
        return new double[]{mc().mouseHandler.xpos() * w.getGuiScaledWidth() / Math.max(1, w.getScreenWidth()),
                mc().mouseHandler.ypos() * w.getGuiScaledHeight() / Math.max(1, w.getScreenHeight())};
    }

    /** scroll over GUIs while a modal ScreenGUI is open; true = consumed */
    public boolean overlayScroll(double d) {
        if (closed) return false;
        double[] p = guiMouse();
        return within(() -> {
            List<ScreenGuiObj> l = overlays();
            for (int i = l.size() - 1; i >= 0; i--) if (UiInput.scroll(l.get(i), p[0], p[1], d)) return true;
            return false;
        });
    }

    /** Esc while a modal ScreenGUI with CloseOnEsc is open closes the top one; true = handled */
    public boolean escCloses() {
        if (closed) return false;
        return within(() -> {
            List<ScreenGuiObj> l = overlays();
            for (int i = l.size() - 1; i >= 0; i--) { ScreenGuiObj s = l.get(i); if (!s.overlay && s.modal && s.closeOnEsc) { s.setEnabled(false); return true; } }
            return false;
        });
    }

    /** overlays sorted by DisplayOrder */
    public List<ScreenGuiObj> overlays() {
        List<ScreenGuiObj> l = new ArrayList<>();
        for (LObj o : ui.listChildren()) if (o instanceof ScreenGuiObj s && s.enabled && (s.overlay || !hosted(s))) l.add(s);
        l.sort(Comparator.comparingInt((ScreenGuiObj s) -> s.displayOrder).thenComparing(s -> !s.overlay));
        return l;
    }

    public void renderOverlays(net.minecraft.client.gui.GuiGraphics g, int w, int h) {
        if (closed) return;
        int mx = -1, my = -1;
        if (mc().screen != null || !mc().mouseHandler.isMouseGrabbed()) {
            mx = (int) (mc().mouseHandler.xpos() * w / mc().getWindow().getScreenWidth());
            my = (int) (mc().mouseHandler.ypos() * h / mc().getWindow().getScreenHeight());
        }
        int fx = mx, fy = my;
        within(() -> { for (ScreenGuiObj s : overlays()) s.renderRoot(g, w, h, fx, fy); BrowserRender.drawRoot(ui, g, w, h, fx, fy); return null; });
    }

    /** clicks on overlays with ClickThrough = false while another screen (chat, inventory...) frees the mouse */
    public boolean overlayMouse(double mx, double my, int button, boolean down) {
        if (closed) return false;
        return within(() -> {
            if (!down) return UiInput.up(mx, my, button);
            if (BrowserRender.click(mx, my, button)) return true;
            List<ScreenGuiObj> l = overlays();
            for (int i = l.size() - 1; i >= 0; i--) if ((!l.get(i).overlay || !l.get(i).clickThrough) && UiInput.down(l.get(i), mx, my, button)) return true;
            return false;
        });
    }

    /** ResetOnSpawn: ScreenGUIs with ResetOnSpawn are closed when the local player respawns */
    public void onRespawn() {
        within(() -> { for (LObj o : ui.listChildren()) if (o instanceof ScreenGuiObj s && !s.overlay && s.enabled && s.resetOnSpawn) s.setEnabled(false); return null; });
    }

    /** getAllGUIs(): Fluwa GUIs + the current Minecraft/mod screen + registered HUD overlays */
    LuaTable allGuis() {
        LuaTable t = new LuaTable(); int i = 1;
        for (LObj o : ui.listChildren()) if (o instanceof ScreenGuiObj s && (s.enabled || s.overlay && s.visible && s.enabled)) t.set(i++, s);
        var sc = mc().screen;
        if (sc != null && !(sc instanceof FluwaUiScreen)) {
            LuaTable x = new LuaTable();
            x.set("Name", LuaValue.valueOf(sc.getTitle().getString()));
            x.set("ClassName", LuaValue.valueOf("MinecraftScreen"));
            x.set("Class", LuaValue.valueOf(sc.getClass().getName()));
            x.set("Source", LuaValue.valueOf(sourceOf(sc.getClass())));
            x.set("Pause", LuaValue.valueOf(sc.isPauseScreen()));
            if (sc instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?> acs) x.set("Container", LuaValue.valueOf(acs.getMenu().getClass().getSimpleName()));
            t.set(i++, x);
        }
        for (var ov : ClientEvents.hudOverlays()) {
            LuaTable x = new LuaTable();
            x.set("Name", LuaValue.valueOf(ov.toString()));
            x.set("ClassName", LuaValue.valueOf("HUDOverlay"));
            x.set("Source", LuaValue.valueOf(ov.getNamespace()));
            t.set(i++, x);
        }
        return t;
    }
    static String sourceOf(Class<?> c) {
        String n = c.getName();
        return n.startsWith("net.minecraft.") ? "minecraft" : n.startsWith("net.idea.fluwa") ? "fluwa" : n.contains(".") ? n.substring(0, n.lastIndexOf('.')) : n;
    }

    /** getAccess("UserInputService") (created on first use) */
    public UserInputService uis;

    @Override public void close() {
        UserInputService.restore();
        within(() -> { for (LObj o : ui.listChildren()) if (o instanceof ScreenGuiObj s && !s.overlay && s.enabled) s.setEnabled(false); return null; });
        super.close();
    }
}
