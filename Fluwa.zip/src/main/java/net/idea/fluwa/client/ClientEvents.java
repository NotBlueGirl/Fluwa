package net.idea.fluwa.client;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.ArrayList;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.api.GameRuntime;
import net.idea.fluwa.api.PlayerObj;
import net.idea.fluwa.client.ui.UiTextures;
import net.idea.fluwa.lua.Vec3L;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public final class ClientEvents {
    public static final KeyMapping ZSPACE = new KeyMapping("key.fluwa.zspace", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F8, "key.categories.fluwa");
    static double tickAcc;
    static Vec3L lastPos;

    private ClientEvents() {}

    /** ids of every registered HUD overlay (vanilla, Forge, other mods) for getAllGUIs() */
    public static java.util.List<net.minecraft.resources.ResourceLocation> hudOverlays() {
        java.util.List<net.minecraft.resources.ResourceLocation> l = new java.util.ArrayList<>();
        for (var o : net.minecraftforge.client.gui.overlay.GuiOverlayManager.getOverlays()) l.add(o.id());
        return l;
    }

    static ClientRuntime rt() { return GameRuntime.CLIENT instanceof ClientRuntime r && !r.closed ? r : null; }

    @Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent public static void keys(RegisterKeyMappingsEvent e) { e.register(ZSPACE); }
        /** Item:SetIcon - draws the custom icon over the item in every slot */
        @SubscribeEvent public static void decorations(net.minecraftforge.client.event.RegisterItemDecorationsEvent e) {
            net.minecraftforge.client.IItemDecorator d = (g, font, stack, x, y) -> {
                String icon = net.idea.fluwa.api.ItemObj.icon(stack);
                if (icon == null) return false;
                g.pose().pushPose();
                g.pose().translate(0, 0, 210);
                net.idea.fluwa.client.ui.UiTextures.blit(g, icon, x, y, 16, 16);
                g.pose().popPose();
                return true;
            };
            for (var it : net.minecraft.core.registries.BuiltInRegistries.ITEM) if (it != net.minecraft.world.item.Items.AIR) e.register(it, d);
        }
        @SubscribeEvent public static void overlays(RegisterGuiOverlaysEvent e) {
            e.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "fluwa_ui", (gui, g, pt, w, h) -> { ClientRuntime r = rt(); if (r != null) r.renderOverlays(g, w, h); });
        }
    }

    @Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            while (ZSPACE.consumeClick()) if (mc.player != null) FluwaNet.toServer(new Pkt(Pkt.C_ZREQUEST));
            FreeCam.tick();
            UserInputService.tick();
            if (ClientState.frozen && ClientState.freezeCam && mc.player != null) {
                mc.player.setYRot(ClientState.frozenYaw); mc.player.setXRot(ClientState.frozenPitch);
            }
            ClientRuntime r = rt();
            if (r == null || mc.player == null) return;
            r.within(() -> {
                r.onTick();
                for (var eo : new ArrayList<>(r.entities.values())) if (eo != null && !(eo instanceof PlayerObj)) net.idea.fluwa.server.ServerEvents.tickEntity(r, eo);
                PlayerObj lp = r.players.get(mc.player.getUUID());
                if (lp != null) {
                    if (lp.listens("E_Tick")) {
                        tickAcc += ClientState.asynced ? ClientState.asyncTick / 20.0 : 1;
                        while (tickAcc >= 1) { tickAcc--; lp.fire("E_Tick"); }
                    }
                    if (lp.listens("E_Move")) {
                        Vec3L p = Vec3L.of(mc.player.position());
                        if (lastPos == null || lastPos.sub(p).mag() > 1e-3) { if (lastPos != null) lp.fire("E_Move", p); lastPos = p; }
                    }
                }
                return null;
            });
        }

        /** v0.5.2: remember the layout of every Minecraft / mod screen (GUI Maker → Open / Import) */
        @SubscribeEvent
        public static void screenInit(ScreenEvent.Init.Post e) {
            net.idea.fluwa.client.zspace.GuiImport.captured(e.getScreen());
            net.idea.fluwa.client.zspace.ScreenOverrides.apply(e);   // GUI Maker edits of this screen
        }

        /** v0.5.2: F8 in the main menu (no world) opens GUI Maker; config mainMenuGuiMaker */
        @SubscribeEvent
        public static void menuKey(ScreenEvent.KeyPressed.Pre e) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level != null || !net.idea.fluwa.Config.mainMenuGuiMaker) return;
            var sc = e.getScreen();
            if (sc == null || sc.getClass().getName().startsWith("net.idea.fluwa.")) return;
            if (sc.getFocused() instanceof net.minecraft.client.gui.components.EditBox) return;
            if (!ZSPACE.matches(e.getKeyCode(), e.getScanCode())) return;
            mc.setScreen(new net.idea.fluwa.client.zspace.GuiMakerScreen(sc, null));
            e.setCanceled(true);
        }

        @SubscribeEvent
        public static void renderFrame(TickEvent.RenderTickEvent e) {
            if (e.phase == TickEvent.Phase.START) { FreeCam.frame(); UserInputService.frame(); ClientRuntime r = rt(); if (r != null) r.uiFrame(); }
        }

        @SubscribeEvent
        public static void input(MovementInputUpdateEvent e) {
            net.idea.fluwa.client.zspace.WorldEditorScreen.movement(e.getInput());
            if (ClientState.frozen || FreeCam.active() || UserInputService.blockMovement()) {
                var in = e.getInput();
                in.forwardImpulse = 0; in.leftImpulse = 0; in.jumping = false; in.shiftKeyDown = false;
                in.up = in.down = in.left = in.right = false;
            }
        }

        @SubscribeEvent
        public static void mouse(InputEvent.MouseButton.Post e) {
            ClientRuntime r = rt();
            if (r == null || Minecraft.getInstance().screen != null) return;
            var m = r.mouse();
            if (m == null) return;
            r.within(() -> {
                boolean down = e.getAction() == GLFW.GLFW_PRESS;
                if (e.getButton() == 0) (down ? m.b1d : m.b1u).fire();
                if (e.getButton() == 1) (down ? m.b2d : m.b2u).fire();
                return null;
            });
        }

        @SubscribeEvent
        public static void uisKey(InputEvent.Key e) { UserInputService.onKey(e.getKey(), e.getAction()); }
        @SubscribeEvent
        public static void uisMouse(InputEvent.MouseButton.Pre e) {
            UserInputService.onMouse(e.getButton(), e.getAction());
            // modal ScreenGUI open (no Minecraft screen): clicks go to the GUIs, never to the world / cursor grab
            ClientRuntime r = rt();
            if (r != null && Minecraft.getInstance().screen == null && r.modalActive()) {
                double[] p = ClientRuntime.guiMouse();
                if (e.getAction() != GLFW.GLFW_REPEAT) r.overlayMouse(p[0], p[1], e.getButton(), e.getAction() == GLFW.GLFW_PRESS);
                e.setCanceled(true);
            }
        }
        @SubscribeEvent
        public static void escGui(ScreenEvent.Opening e) {
            ClientRuntime r = rt();
            Minecraft mc = Minecraft.getInstance();
            if (r != null && mc.screen == null && e.getNewScreen() instanceof net.minecraft.client.gui.screens.PauseScreen
                    && InputConstants.isKeyDown(mc.getWindow().getWindow(), GLFW.GLFW_KEY_ESCAPE) && r.modalActive() && r.escCloses()) e.setCanceled(true);
        }
        @SubscribeEvent
        public static void uisScreenScroll(ScreenEvent.MouseScrolled.Pre e) { UserInputService.onScroll(e.getScrollDelta()); }

        @SubscribeEvent
        public static void wheel(InputEvent.MouseScrollingEvent e) {
            UserInputService.onScroll(e.getScrollDelta());
            ClientRuntime r0 = rt();
            if (r0 != null && Minecraft.getInstance().screen == null && r0.modalActive()) { r0.overlayScroll(e.getScrollDelta()); e.setCanceled(true); return; }
            ClientRuntime r = rt();
            if (r == null || Minecraft.getInstance().screen != null) return;
            var m = r.mouse();
            if (m != null) r.within(() -> { (e.getScrollDelta() > 0 ? m.wf : m.wb).fire(); return null; });
        }

        @SubscribeEvent public static void sky(RenderLevelStageEvent e) {
            SkyboxRenderer.render(e);
            net.idea.fluwa.client.zspace.WorldEditorScreen.renderWorld(e);
            if (e.getStage() == RenderLevelStageEvent.Stage.AFTER_PARTICLES) { try { LightingClient.renderLights(e); } catch (RuntimeException ex) { Fluwa.LOGGER.debug("lights", ex); } }
            LightingPost.render(e);
        }
        @SubscribeEvent public static void fog(ViewportEvent.RenderFog e) { try { LightingClient.fog(e); } catch (RuntimeException ignored) {} }
        @SubscribeEvent public static void fogColor(ViewportEvent.ComputeFogColor e) { try { LightingClient.fogColor(e); } catch (RuntimeException ignored) {} }

        @SubscribeEvent
        public static void screenMouse(ScreenEvent.MouseButtonPressed.Pre e) {
            ClientRuntime r = rt();
            if (r != null && !(e.getScreen() instanceof net.idea.fluwa.client.ui.FluwaUiScreen) && r.overlayMouse(e.getMouseX(), e.getMouseY(), e.getButton(), true)) e.setCanceled(true);
        }
        @SubscribeEvent
        public static void screenMouseUp(ScreenEvent.MouseButtonReleased.Pre e) {
            ClientRuntime r = rt();
            if (r != null && !(e.getScreen() instanceof net.idea.fluwa.client.ui.FluwaUiScreen) && r.overlayMouse(e.getMouseX(), e.getMouseY(), e.getButton(), false)) e.setCanceled(true);
        }
        @SubscribeEvent
        public static void respawned(ClientPlayerNetworkEvent.Clone e) { ClientRuntime r = rt(); if (r != null) r.onRespawn(); }

        @SubscribeEvent
        public static void renderPlayer(RenderPlayerEvent.Pre e) {
            if (ClientState.HIDDEN_PARTS.isEmpty() || e.getEntity() != Minecraft.getInstance().player) return;
            PlayerModel<?> m = e.getRenderer().getModel();
            m.head.visible = !ClientState.HIDDEN_PARTS.getOrDefault("Head", false);
            m.hat.visible = !ClientState.HIDDEN_PARTS.getOrDefault("Hat", false);
            m.body.visible = !ClientState.HIDDEN_PARTS.getOrDefault("Body", false);
            m.rightArm.visible = !ClientState.HIDDEN_PARTS.getOrDefault("RightArm", false);
            m.leftArm.visible = !ClientState.HIDDEN_PARTS.getOrDefault("LeftArm", false);
            m.rightLeg.visible = !ClientState.HIDDEN_PARTS.getOrDefault("RightLeg", false);
            m.leftLeg.visible = !ClientState.HIDDEN_PARTS.getOrDefault("LeftLeg", false);
        }

        @SubscribeEvent
        public static void renderPlayerPost(RenderPlayerEvent.Post e) {
            if (ClientState.HIDDEN_PARTS.isEmpty()) return;
            PlayerModel<?> m = e.getRenderer().getModel();
            m.head.visible = m.hat.visible = m.body.visible = m.rightArm.visible = m.leftArm.visible = m.rightLeg.visible = m.leftLeg.visible = true;
        }

        @SubscribeEvent
        public static void levelLoad(LevelEvent.Load e) {
            ClientRuntime r = rt();
            if (r != null && e.getLevel().isClientSide()) Minecraft.getInstance().execute(r::refreshDimension);
        }

        /** v0.5.2: tell the server the model part names of every entity type (Entity:GetModel, World Editor) */
        @SubscribeEvent
        public static void loginParts(ClientPlayerNetworkEvent.LoggingIn e) { net.idea.fluwa.client.ModelParts.report(); }

        @SubscribeEvent
        public static void logout(ClientPlayerNetworkEvent.LoggingOut e) {
            if (GameRuntime.CLIENT != null) GameRuntime.CLIENT.close();
            GameRuntime.CLIENT = null;
            ClientState.reset();
            LightingClient.reset();
            UiTextures.clear();
            net.idea.fluwa.api.NoCollide.clearClient();
            ClientModels.clear();
            ClientProjector.clearAll();
            net.idea.fluwa.client.ui.UiInput.reset();
            ShaderDT.reset();
            LocalAudio.stopAll();
            if (FreeCam.active()) FreeCam.toggle();
            UserInputService.restore();
        }
    }
}
