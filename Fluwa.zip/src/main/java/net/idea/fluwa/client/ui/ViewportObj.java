package net.idea.fluwa.client.ui;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.systems.RenderSystem;
import net.idea.fluwa.api.ProjectorObj;
import net.idea.fluwa.client.ClientProjector;
import net.idea.fluwa.lua.*;
import net.minecraft.client.gui.GuiGraphics;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.luaj.vm2.*;

/** ViewportFrame: renders its ProjectorObject children (client objects) with a camera, ambient and light. */
public class ViewportObj extends UiObj {
    public LuaValue camera = NIL;
    public int ambient = 0xC8C8C8, lightColor = 0xFFFFFF;
    public Vec3L lightDir = new Vec3L(-1, -1, -1);
    public double fov = 70;

    public ViewportObj() { super("ViewportFrame"); bg = 0x000000; bgTransparency = 1; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "CurrentCamera": case "Camera": return camera;
            case "Ambient": return col(ambient);
            case "LightColor": return col(lightColor);
            case "LightDirection": return lightDir;
            case "FieldOfView": return valueOf(fov);
        }
        return super.getProp(k);
    }
    @Override protected boolean setUi(String k, LuaValue v) {
        switch (k) {
            case "CurrentCamera": case "Camera": camera = v; return true;
            case "Ambient": ambient = ColorL.check(v); return true;
            case "LightColor": lightColor = ColorL.check(v); return true;
            case "LightDirection": lightDir = Vec3L.check(v); return true;
            case "FieldOfView": fov = Math.max(1, Math.min(170, v.checkdouble())); return true;
        }
        return super.setUi(k, v);
    }

    CFrameL cameraCF(ProjectorObj first) {
        LuaValue c = camera;
        if (c instanceof CFrameL cf) return cf;
        if (c instanceof LObj o) { try { LuaValue x = o.get("CFrame"); if (x instanceof CFrameL cf) return cf; } catch (LuaError ignored) {} }
        // auto camera: look at the first object from the front
        double[] b = first == null ? new double[]{-1, -1, -1, 1, 1, 1} : bounds(first);
        double cx = (b[0] + b[3]) / 2, cy = (b[1] + b[4]) / 2, cz = (b[2] + b[5]) / 2;
        double r = Math.max(0.5, Math.sqrt(Math.pow(b[3] - b[0], 2) + Math.pow(b[4] - b[1], 2) + Math.pow(b[5] - b[2], 2)) / 2);
        double d = r / Math.tan(Math.toRadians(fov / 2)) * 1.1;
        return CFrameL.lookAt(new Vec3L(cx + d * 0.35, cy + d * 0.3, cz + d), new Vec3L(cx, cy, cz));
    }

    static double[] bounds(ProjectorObj o) {
        float[] b = o.mesh.bounds();
        CFrameL w = o.cf;
        double[] r = {1e9, 1e9, 1e9, -1e9, -1e9, -1e9};
        for (int i = 0; i < 8; i++) {
            Vec3L p = w.point(new Vec3L(((i & 1) == 0 ? b[0] : b[3]) * o.sx, ((i & 2) == 0 ? b[1] : b[4]) * o.sy, ((i & 4) == 0 ? b[2] : b[5]) * o.sz));
            r[0] = Math.min(r[0], p.x); r[1] = Math.min(r[1], p.y); r[2] = Math.min(r[2], p.z);
            r[3] = Math.max(r[3], p.x); r[4] = Math.max(r[4], p.y); r[5] = Math.max(r[5], p.z);
        }
        return r;
    }

    @Override protected void drawSelf(GuiGraphics g, int mx, int my, double ga) {
        super.drawSelf(g, mx, my, ga);
        ProjectorObj first = null;
        for (LObj c : listChildren()) if (c instanceof ProjectorObj p) { first = p; break; }
        if (first == null || aw <= 0 || ah <= 0) return;
        CFrameL cam = cameraCF(first), inv = cam.inverse();
        g.flush();
        g.enableScissor(ax, ay, ax + aw, ay + ah);
        Lighting.setupForEntityInInventory();
        Vector3f ld = new Vector3f((float) -lightDir.x, (float) -lightDir.y, (float) -lightDir.z);
        if (ld.lengthSquared() > 0) { ld.normalize(); RenderSystem.setShaderLights(ld, new Vector3f(ld).negate().mul(0.3f)); }
        int tint = mixTint();
        for (LObj c : listChildren()) {
            if (!(c instanceof ProjectorObj p) || !p.visible) continue;
            ClientProjector.Entry e = ClientProjector.ENTRIES.get(p.id);
            if (e == null) continue;
            CFrameL rel = inv.times(p.cf);
            double depth = Math.max(0.05, -rel.z);
            double k = (Math.min(aw, ah) / 2.0) / (depth * Math.tan(Math.toRadians(fov / 2)));
            double[] r = rel.r;
            Matrix4f m = new Matrix4f(
                    (float) r[0], (float) r[3], (float) r[6], 0,
                    (float) r[1], (float) r[4], (float) r[7], 0,
                    (float) r[2], (float) r[5], (float) r[8], 0,
                    (float) rel.x, (float) rel.y, (float) (rel.z + depth), 1).scale((float) p.sx, (float) p.sy, (float) p.sz);
            Matrix4f gui = new Matrix4f().translate(ax + aw / 2f, ay + ah / 2f, 150).scale((float) k, (float) -k, (float) k).mul(m);
            int oldTint = e.r.tint; float oldA = e.r.alpha;
            e.r.tint = tint; e.r.alpha = (float) ((1 - p.transparency) * (1 - imageTransparency) * ga);
            ClientProjector.draw(e, g.pose(), g.bufferSource(), gui, 0xF000F0);
            g.flush();
            e.r.tint = oldTint; e.r.alpha = oldA;
        }
        Lighting.setupFor3DItems();
        g.disableScissor();
    }

    int mixTint() {
        int r = Math.min(255, ((ambient >> 16 & 255) / 2 + (lightColor >> 16 & 255) / 2) * (imageColor >> 16 & 255) / 255 + 40);
        int gg = Math.min(255, ((ambient >> 8 & 255) / 2 + (lightColor >> 8 & 255) / 2) * (imageColor >> 8 & 255) / 255 + 40);
        int b = Math.min(255, ((ambient & 255) / 2 + (lightColor & 255) / 2) * (imageColor & 255) / 255 + 40);
        return (r << 16) | (gg << 8) | b;
    }

    static {
        reg(ViewportObj.class, "SetCamera|SetCurrentCamera", (s, a) -> set(s, "CurrentCamera", a.arg1()));
        reg(ViewportObj.class, "SetAmbient", (s, a) -> set(s, "Ambient", a.arg1()));
        reg(ViewportObj.class, "SetLightColor", (s, a) -> set(s, "LightColor", a.arg1()));
        reg(ViewportObj.class, "SetLightDirection", (s, a) -> set(s, "LightDirection", a.arg1()));
    }
}
