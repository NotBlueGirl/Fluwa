package net.idea.fluwa.client.zspace;

import com.google.gson.*;
import net.idea.fluwa.api.GameRuntime;
import net.idea.fluwa.client.ClientRuntime;
import net.idea.fluwa.client.ui.UiTextures;
import net.idea.fluwa.lua.LObj;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import org.lwjgl.glfw.GLFW;

import java.util.*;

import static net.idea.fluwa.client.zspace.ZUi.*;

/**
 * ZSpace → ☰ → Tools → GUI Maker: visual editor for ScreenGUI / Overlay layouts with a WYSIWYG canvas and an in-game preview.
 * Positions and sizes are stored as UDim2 (Scale + Offset); "Save" writes a UI script that rebuilds the GUI
 * (the layout is kept inside the script, so it can be reopened later).
 */
public class GuiMakerScreen extends ZWindow {
    static final String[] PALETTE = {"Frame", "TextLabel", "TextButton", "TextBox", "ImageLabel", "ImageButton", "ScrollingFrame"};
    static final String MARK = "--[[FLUWA_GUI";

    public static final class El {
        String cls, name, parent = "";
        double sx, sy, ox, oy, wsx, wsy, wox, woy;
        String bg = "#2A2A3A", fg = "#FFFFFF", text = "", image = "";
        double bgT = 0, corner = 0; int textSize = 14, z = 1; boolean visible = true;
        /** v0.5.2 screen editing: widget key of the original screen, its original rect / text, saved delta, button action */
        String src = "", text0 = "", action = "";
        double x0, y0, w0, h0, dx, dy, nw, nh;
        El copy() { El e = new Gson().fromJson(new Gson().toJson(this), El.class); return e; }
    }

    static final List<El> ELS = new ArrayList<>();
    static String guiName = "MyGui", kind = "ScreenGUI";
    static boolean snap = true, useScale = true;
    /** v0.5.2: class of the Minecraft / mod screen being edited ("" = normal Fluwa GUI), keys of its imported widgets */
    static String target = "", saveTo = "Screen";
    static List<String> targetKeys = new ArrayList<>();
    final Map<String, Map<String, String>> scripts;
    El sel;
    int drag; double dragMX, dragMY; El dragStart;
    int cx0, cy0, cw, ch; // canvas rect (logical)
    final Map<String, String> pushed = new HashMap<>();
    boolean preview, loadOpen;
    int propScroll;
    final Deque<String> undo = new ArrayDeque<>();

    /** true = opened from the main menu (no world): layouts are kept in <game>/fluwa/guis */
    final boolean local;
    int loadScroll;

    public GuiMakerScreen(Screen parent, Map<String, Map<String, String>> scripts) {
        super("GUI Maker", parent, 560, 320);
        this.local = scripts == null;
        this.scripts = scripts != null ? scripts : new HashMap<>();
    }

    static java.nio.file.Path localDir() { return net.minecraftforge.fml.loading.FMLPaths.GAMEDIR.get().resolve("fluwa").resolve("guis"); }
    static List<String> localFiles() {
        List<String> l = new ArrayList<>();
        try (var st = java.nio.file.Files.list(localDir())) { st.filter(f -> f.toString().endsWith(".lua")).forEach(f -> l.add(f.getFileName().toString())); }
        catch (Exception ignored) {}
        Collections.sort(l);
        return l;
    }

    static int vw() { return Minecraft.getInstance().getWindow().getGuiScaledWidth(); }
    static int vh() { return Minecraft.getInstance().getWindow().getGuiScaledHeight(); }

    void snapshot() { undo.addLast(new Gson().toJson(ELS)); while (undo.size() > 50) undo.pollFirst(); }
    void undoLast() {
        String s = undo.pollLast();
        if (s == null) { setStatus(false, "Nothing to undo"); return; }
        ELS.clear(); ELS.addAll(Arrays.asList(new Gson().fromJson(s, El[].class)));
        sel = null; pushed.clear();
    }

    El byName(String n) { for (El e : ELS) if (e.name.equals(n)) return e; return null; }

    /** absolute rect in virtual screen pixels */
    double[] abs(El e, int depth) {
        double px = 0, py = 0, pw = vw(), ph = vh();
        El p = e.parent.isEmpty() || depth > 20 ? null : byName(e.parent);
        if (p != null) { double[] r = abs(p, depth + 1); px = r[0]; py = r[1]; pw = r[2]; ph = r[3]; }
        double w = e.wsx * pw + e.wox, h = e.wsy * ph + e.woy;
        return new double[]{px + e.sx * pw + e.ox, py + e.sy * ph + e.oy, w, h, pw, ph};
    }

    void add(String cls) {
        snapshot();
        El e = new El();
        e.cls = cls;
        int i = 1; while (byName(cls + i) != null) i++;
        e.name = cls + i;
        e.wsx = cls.equals("Frame") || cls.equals("ScrollingFrame") ? 0.3 : 0.18; e.wsy = cls.equals("Frame") || cls.equals("ScrollingFrame") ? 0.3 : 0.07;
        e.sx = 0.5 - e.wsx / 2; e.sy = 0.5 - e.wsy / 2;
        if (sel != null && (sel.cls.equals("Frame") || sel.cls.equals("ScrollingFrame"))) { e.parent = sel.name; e.sx = 0.1; e.sy = 0.1 + 0.15 * (count(sel.name) % 5); e.wsx = 0.8; e.wsy = 0.12; }
        if (cls.startsWith("Text")) e.text = cls.equals("TextBox") ? "" : cls.equals("TextButton") ? "Button" : "Label";
        if (cls.startsWith("Text")) e.bg = cls.equals("TextLabel") ? "#000000" : "#3B3B52";
        if (cls.equals("TextLabel")) e.bgT = 1;
        if (cls.startsWith("Image")) e.image = "minecraft:textures/item/diamond.png";
        e.z = ELS.size() + 1;
        ELS.add(e);
        select(e);
    }
    int count(String parent) { int n = 0; for (El e : ELS) if (e.parent.equals(parent)) n++; return n; }

    void select(El e) { sel = e; pushed.clear(); propScroll = 0; if (e != null) syncBoxes(); }

    static String f(double d) { return d == Math.rint(d) ? String.valueOf((long) d) : String.format(Locale.ROOT, "%.3f", d).replaceAll("0+$", ""); }

    String[][] props() {
        return new String[][]{{"Name", sel.name}, {"Parent", sel.parent}, {"PosScaleX", f(sel.sx)}, {"PosScaleY", f(sel.sy)}, {"PosOffsetX", f(sel.ox)}, {"PosOffsetY", f(sel.oy)},
                {"SizeScaleX", f(sel.wsx)}, {"SizeScaleY", f(sel.wsy)}, {"SizeOffsetX", f(sel.wox)}, {"SizeOffsetY", f(sel.woy)},
                {"BackgroundColor3", sel.bg}, {"BackgroundTransparency", f(sel.bgT)}, {"Text", sel.text}, {"TextColor3", sel.fg}, {"TextSize", String.valueOf(sel.textSize)},
                {"Image", sel.image}, {"CornerRadius", f(sel.corner)}, {"ZIndex", String.valueOf(sel.z)}, {"Visible", String.valueOf(sel.visible)},
                {"Action", sel.action}};
    }

    void syncBoxes() {
        for (String[] p : props()) { box("p:" + p[0], "").setValue(p[1]); pushed.put(p[0], p[1]); }
    }

    static double num(String s, double d) { try { return Double.parseDouble(s.trim().replace(',', '.')); } catch (Exception e) { return d; } }

    void applyProp(String k, String v) {
        switch (k) {
            case "Name" -> { String n = v.trim().replaceAll("[^\\w]", "_"); if (!n.isEmpty() && (byName(n) == null || byName(n) == sel)) { for (El e : ELS) if (e.parent.equals(sel.name)) e.parent = n; sel.name = n; } }
            case "Parent" -> { El p = byName(v.trim()); sel.parent = p != null && p != sel ? p.name : ""; }
            case "PosScaleX" -> sel.sx = num(v, sel.sx); case "PosScaleY" -> sel.sy = num(v, sel.sy);
            case "PosOffsetX" -> sel.ox = num(v, sel.ox); case "PosOffsetY" -> sel.oy = num(v, sel.oy);
            case "SizeScaleX" -> sel.wsx = num(v, sel.wsx); case "SizeScaleY" -> sel.wsy = num(v, sel.wsy);
            case "SizeOffsetX" -> sel.wox = num(v, sel.wox); case "SizeOffsetY" -> sel.woy = num(v, sel.woy);
            case "BackgroundColor3" -> sel.bg = v.trim(); case "BackgroundTransparency" -> sel.bgT = Math.max(0, Math.min(1, num(v, sel.bgT)));
            case "Text" -> sel.text = v; case "TextColor3" -> sel.fg = v.trim(); case "TextSize" -> sel.textSize = (int) num(v, sel.textSize);
            case "Image" -> sel.image = v.trim(); case "CornerRadius" -> sel.corner = Math.max(0, num(v, sel.corner));
            case "ZIndex" -> sel.z = (int) num(v, sel.z); case "Visible" -> sel.visible = v.trim().equalsIgnoreCase("true");
            case "Action" -> sel.action = v.trim();
            default -> {}
        }
    }

    static int color(String s, int d) { try { s = s.trim().replace("#", ""); return Integer.parseInt(s, 16) & 0xFFFFFF; } catch (Exception e) { return d; } }

    // ------------------------------------------------------------------ code generation
    String code(boolean forPreview) {
        StringBuilder sb = new StringBuilder();
        String cls = forPreview ? "Overlay" : kind;
        sb.append("-- ").append(guiName).append("  ·  made with GUI Maker (ZSpace → Tools)\n");
        sb.append(MARK).append("\n").append(new Gson().toJson(Map.of("name", guiName, "kind", kind, "elements", ELS))).append("\n]]\n");
        sb.append("local gui = Instance:new(\"").append(cls).append("\", UI)\ngui.Name = \"").append(guiName).append("\"\n");
        if (forPreview) sb.append("gui.ClickThrough = true\n");
        sb.append("local el = {}\n");
        List<El> order = new ArrayList<>();
        Set<String> done = new HashSet<>();
        for (int pass = 0; pass < 25 && order.size() < ELS.size(); pass++)
            for (El e : ELS) if (!done.contains(e.name) && (e.parent.isEmpty() || done.contains(e.parent) || byName(e.parent) == null)) { order.add(e); done.add(e.name); }
        for (El e : order) {
            String v = "el." + e.name;
            String par = e.parent.isEmpty() || byName(e.parent) == null ? "gui" : "el." + e.parent;
            sb.append("\n").append(v).append(" = Instance:new(\"").append(e.cls).append("\", ").append(par).append(")\n");
            sb.append(v).append(".Name = \"").append(e.name).append("\"\n");
            sb.append(v).append(".Position = UDim2.new(").append(f(e.sx)).append(", ").append(f(e.ox)).append(", ").append(f(e.sy)).append(", ").append(f(e.oy)).append(")\n");
            sb.append(v).append(".Size = UDim2.new(").append(f(e.wsx)).append(", ").append(f(e.wox)).append(", ").append(f(e.wsy)).append(", ").append(f(e.woy)).append(")\n");
            sb.append(v).append(".BackgroundColor3 = Color3.fromHex(\"").append(e.bg).append("\")\n");
            if (e.bgT != 0) sb.append(v).append(".BackgroundTransparency = ").append(f(e.bgT)).append("\n");
            if (e.cls.startsWith("Text")) {
                if (e.cls.equals("TextBox")) sb.append(v).append(".PlaceholderText = \"").append(lua(e.text.isEmpty() ? "Type here..." : e.text)).append("\"\n");
                else sb.append(v).append(".Text = \"").append(lua(e.text)).append("\"\n");
                sb.append(v).append(".TextColor3 = Color3.fromHex(\"").append(e.fg).append("\")\n");
                sb.append(v).append(".TextSize = ").append(e.textSize).append("\n");
            }
            if (e.cls.startsWith("Image") && !e.image.isEmpty()) sb.append(v).append(".Image = \"").append(lua(e.image)).append("\"\n");
            if (e.z != 1) sb.append(v).append(".ZIndex = ").append(e.z).append("\n");
            if (!e.visible) sb.append(v).append(".Visible = false\n");
            if (e.corner > 0) sb.append("Instance:new(\"UICorner\", ").append(v).append(").CornerRadius = UDim.new(0, ").append(f(e.corner)).append(")\n");
            if (e.cls.endsWith("Button")) sb.append(v).append(".MouseButton1Click:Connect(function()\n    print(\"").append(e.name).append(" clicked\")\nend)\n");
        }
        if (!forPreview && kind.equals("ScreenGUI")) sb.append("\n-- open it: gui.Enabled = true   (Esc closes it)\n");
        sb.append("\nreturn gui\n");
        return sb.toString();
    }
    static String lua(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n"); }

    void save() {
        if (!target.isEmpty() && saveTo.equals("Screen")) { saveScreen(); return; }
        String n = guiName.replaceAll("[^\\w\\-]", "_");
        String src = code(false);
        if (local) { saveLocal(n, src); return; }
        scripts.computeIfAbsent("UI", k -> new TreeMap<>()).put("GUIs/" + n, src);
        FluwaNet.toServer(new Pkt(Pkt.C_ZSAVE, List.of("UI", "GUIs/" + n, src), new int[]{ZOptions.reloadOnSave ? 1 : 0}, null));
        setStatus(true, "Saved UI/GUIs/" + n + ".lua" + (ZOptions.reloadOnSave ? " (scripts reloaded)" : " (press Reload to apply)"));
    }
    /** v0.5.2: writes the edit of a Minecraft / mod screen - the real screen uses it every time it opens */
    void saveScreen() {
        for (El e : ELS) if (!e.src.isEmpty()) {
            double[] r = abs(e, 0);
            e.dx = r[0] - e.x0; e.dy = r[1] - e.y0; e.nw = r[2]; e.nh = r[3];
        }
        try {
            ScreenOverrides.save(target, ELS, targetKeys);
            setStatus(true, GuiImport.shortName(target) + " now opens with your changes (.minecraft/fluwa/screens) · Restore = original");
        } catch (Exception ex) { setStatus(false, "Can't save: " + ex.getMessage()); }
    }
    void restoreScreen() {
        if (target.isEmpty()) return;
        boolean ok = ScreenOverrides.restore(target);
        setStatus(ok, ok ? GuiImport.shortName(target) + " restored to the original" : GuiImport.shortName(target) + " was not edited");
        String t = target;
        if (ok) importScreen(t);
    }

    /** main menu: <game>/fluwa/guis/<name>.lua (open it later in a world: Open… → Local designs) */
    void saveLocal(String n, String src) {
        try {
            java.nio.file.Files.createDirectories(localDir());
            java.nio.file.Files.writeString(localDir().resolve(n + ".lua"), src);
            setStatus(true, "Saved .minecraft/fluwa/guis/" + n + ".lua");
        } catch (Exception e) { setStatus(false, "Can't save: " + e.getMessage()); }
    }
    void exportLocal() {
        String n = guiName.replaceAll("[^\\w\\-]", "_");
        saveLocal(n, code(false));
    }

    void togglePreview() {
        if (local || !(GameRuntime.CLIENT instanceof ClientRuntime r) || r.closed) { setStatus(false, "Preview in game needs a world (the canvas shows the layout)"); return; }
        stopPreview(r);
        preview = !preview;
        if (preview) {
            r.runScript("GUIMaker/preview", code(true).replace("gui.Name = \"" + guiName + "\"", "gui.Name = \"__GuiMakerPreview\""));
            setStatus(true, "Preview is shown in the game HUD — move this window to see it");
        }
    }
    void stopPreview(ClientRuntime r) {
        r.within(() -> { for (LObj o : r.ui.listChildren()) if (o.getName().equals("__GuiMakerPreview")) o.destroy(); return null; });
    }

    List<String> saved() {
        List<String> l = new ArrayList<>();
        for (var e : scripts.getOrDefault("UI", Map.of()).entrySet()) if (e.getValue().contains(MARK)) l.add(e.getKey());
        Collections.sort(l);
        return l;
    }

    void load(String script) {
        String src = scripts.getOrDefault("UI", Map.of()).get(script);
        if (src == null) return;
        loadSource(script, src);
    }
    void loadLocal(String file) {
        try { loadSource(file, java.nio.file.Files.readString(localDir().resolve(file))); }
        catch (Exception e) { setStatus(false, "Can't read " + file + ": " + e.getMessage()); }
    }
    /** replaces the canvas with imported elements */
    void loadEls(String name, String k, List<El> els, String from) {
        snapshot();
        ELS.clear(); ELS.addAll(els);
        guiName = name.replaceAll("[^\\w\\-]", "_"); if (guiName.isEmpty()) guiName = "ImportedGui";
        if (k != null) kind = k;
        box("guiname", "").setValue(guiName);
        select(null);
        loadOpen = false;
        setStatus(true, "Imported " + els.size() + " elements from " + from + " — edit and Save to get a Fluwa UI script");
    }
    void importLive(String guiObjName) {
        target = "";
        if (!(GameRuntime.CLIENT instanceof ClientRuntime r) || r.closed) { setStatus(false, "No client runtime"); return; }
        List<El>[] res = new List[1]; String[] k = {"ScreenGUI"};
        r.within(() -> {
            for (LObj o : r.ui.listChildren()) if (o.getName().equals(guiObjName)) {
                res[0] = GuiImport.fromLive(o);
                if (o instanceof net.idea.fluwa.client.ui.ScreenGuiObj sg && sg.overlay) k[0] = "Overlay";
                break;
            }
            return null; });
        if (res[0] == null) { setStatus(false, guiObjName + " no longer exists"); return; }
        loadEls(guiObjName, k[0], res[0], "live GUI " + guiObjName);
    }
    void importScreen(String cls) {
        try {
            List<El> edited = ScreenOverrides.elements(cls);
            if (edited != null) {
                loadEls(GuiImport.shortName(cls).replace("Screen", "") + "Gui", "ScreenGUI", edited, GuiImport.shortName(cls));
                target = cls; targetKeys = new ArrayList<>(ScreenOverrides.keys(cls)); saveTo = "Screen";
                setStatus(true, "Your edit of " + GuiImport.shortName(cls) + " · Save rewrites the screen, Restore = original");
                return;
            }
            GuiImport.Snap sn = GuiImport.SEEN.get(cls);
            List<El> els;
            if (sn != null) { els = new ArrayList<>(); for (El e : sn.els()) els.add(e.copy()); }
            else { Screen sc = GuiImport.construct(cls, vw(), vh()); els = GuiImport.fromScreen(sc, vw(), vh()); }
            if (els.isEmpty()) { setStatus(false, GuiImport.shortName(cls) + " has no widgets to import (it draws everything itself)"); return; }
            for (El e : els) { if (e.wsx == 0 && e.wox > 0) { /* keep pixel sizes */ } }
            loadEls(GuiImport.shortName(cls).replace("Screen", "") + "Gui", "ScreenGUI", els, GuiImport.shortName(cls));
            target = cls; saveTo = "Screen";
            targetKeys = new ArrayList<>(); for (El e : els) if (!e.src.isEmpty()) targetKeys.add(e.src);
            setStatus(true, "Imported " + els.size() + " elements of " + GuiImport.shortName(cls) + " · Save rewrites the real screen (buttons keep working)");
        } catch (Throwable e) { setStatus(false, "Can't open " + GuiImport.shortName(cls) + ": " + e); }
    }
    void loadSource(String script, String src) {
        target = "";
        int a = src.indexOf(MARK), b = src.indexOf("\n]]", a);
        if (a < 0 || b < 0) { setStatus(false, "No GUI Maker layout in " + script); return; }
        try {
            JsonObject o = JsonParser.parseString(src.substring(a + MARK.length(), b)).getAsJsonObject();
            snapshot();
            ELS.clear();
            ELS.addAll(Arrays.asList(new Gson().fromJson(o.get("elements"), El[].class)));
            guiName = o.get("name").getAsString(); kind = o.get("kind").getAsString();
            box("guiname", "").setValue(guiName);
            select(null);
            setStatus(true, "Loaded " + script);
        } catch (Exception e) { setStatus(false, "Can't read layout: " + e.getMessage()); }
        loadOpen = false;
    }

    // ------------------------------------------------------------------ render
    @Override protected String subtitle() { if (!target.isEmpty()) return "editing " + GuiImport.shortName(target) + " · Save rewrites the real screen · button Action: /cmd, close, screen:<class>, url:, lua:"; return local ? "main menu · designs are saved to .minecraft/fluwa/guis" : "visual ScreenGUI / Overlay editor"; }
    @Override protected String hint() { return "drag to move · corner to resize · Del delete · Ctrl+D duplicate · Ctrl+Z undo · arrows nudge"; }

    @Override protected void renderBody(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my, float pt) {
        int palW = Math.max(96, (x1 - x0) * 17 / 100), propW = Math.max(150, (x1 - x0) * 30 / 100);
        // toolbar
        g.fill(x0, y0, x1, y0 + 20, 0xF20F0F15);
        EditBox nb = box("guiname", "GUI name");
        if (nb.getValue().isEmpty() && getFocused() != nb) nb.setValue(guiName);
        place(g, nb, x0 + 4, y0 + 3, 90);
        if (!nb.getValue().isBlank()) guiName = nb.getValue().trim();
        boolean scr = !target.isEmpty();
        if (scr) {
            small(g, font, "save to", x0 + 98, y0 + 7, DIM);
            choice(g, "saveto", x0 + 98 + font.width("save to") * 3 / 4 + 4, y0 + 3, 54, saveTo, new String[]{"Screen", "Fluwa"}, mx, my, v -> saveTo = v);
        } else choice(g, "kind", x0 + 98, y0 + 3, 70, kind, new String[]{"ScreenGUI", "Overlay"}, mx, my, v -> kind = v);
        int bx = x1 - 4, w;
        w = bw("Save"); bx -= w; button(g, "save", bx, y0 + 3, w, 14, "Save", 1, mx, my, this::save);
        if (scr) { w = bw("Restore original"); bx -= w + 3; button(g, "restore", bx, y0 + 3, w, 14, "Restore original", 3, mx, my, this::restoreScreen); }
        else { w = bw(preview ? "Stop preview" : "Preview in game"); bx -= w + 3; button(g, "prev", bx, y0 + 3, w, 14, preview ? "Stop preview" : "Preview in game", preview ? 3 : 0, mx, my, this::togglePreview); }
        w = bw("Copy Lua"); bx -= w + 3; button(g, "copy", bx, y0 + 3, w, 14, "Copy Lua", 0, mx, my, () -> { minecraft.keyboardHandler.setClipboard(code(false)); setStatus(true, "Lua code copied to the clipboard"); });
        w = bw("Open / Import…"); bx -= w + 3; button(g, "open", bx, y0 + 3, w, 14, "Open / Import…", loadOpen ? 1 : 0, mx, my, () -> { loadOpen = !loadOpen; loadScroll = 0; });
        w = bw("New"); bx -= w + 3; button(g, "new", bx, y0 + 3, w, 14, "New", 0, mx, my, () -> { snapshot(); ELS.clear(); select(null); target = ""; });
        int top = y0 + 21;
        // palette
        g.fill(x0, top, x0 + palW, y1, SIDE);
        label(g, "Insert", x0 + 6, top + 5);
        int py = top + 15;
        for (String c : PALETTE) {
            boolean hov = in(mx, my, x0 + 3, py, x0 + palW - 3, py + 14);
            round(g, x0 + 3, py, x0 + palW - 3, py + 14, hov ? 0x26FFFFFF : 0x10FFFFFF);
            if (!icon(g, c, x0 + 6, py + 3, 9)) round(g, x0 + 7, py + 4, x0 + 13, py + 10, ACCENT);
            text(g, font, ellipsize(font, c, palW - 24), x0 + 18, py + 3, 0xFFC8C8D8);
            hits.add(new Hit(x0 + 3, py, x0 + palW - 3, py + 14, () -> add(c)));
            py += 16;
        }
        py += 4;
        label(g, "Hierarchy", x0 + 6, py); py += 10;
        for (El e : tree()) {
            if (py > y1 - 30) break;
            int depth = depth(e);
            boolean s2 = e == sel;
            if (s2) round(g, x0 + 3, py, x0 + palW - 3, py + 11, SELROW);
            small(g, font, ellipsize(font, e.name, (palW - 12 - depth * 6) * 4 / 3), x0 + 7 + depth * 6, py + 2, s2 ? 0xFFFFFFFF : 0xFFB0B0C4);
            hits.add(new Hit(x0 + 3, py, x0 + palW - 3, py + 11, () -> select(e)));
            py += 11;
        }
        toggle(g, "snap", x0 + 6, y1 - 28, snap, mx, my, () -> snap = !snap);
        small(g, font, "snap 1%", x0 + 30, y1 - 25, DIM);
        toggle(g, "scale", x0 + 6, y1 - 14, useScale, mx, my, () -> useScale = !useScale);
        small(g, font, useScale ? "drag: Scale" : "drag: Offset", x0 + 30, y1 - 11, DIM);
        g.fill(x0 + palW, top, x0 + palW + 1, y1, LINE);
        // canvas
        int ax0 = x0 + palW + 1, ax1 = x1 - propW;
        g.fill(ax0, top, ax1, y1, EDITOR);
        double vwd = vw(), vhd = vh();
        double k = Math.min((ax1 - ax0 - 16) / vwd, (y1 - top - 16) / vhd);
        cw = (int) (vwd * k); ch = (int) (vhd * k);
        cx0 = ax0 + (ax1 - ax0 - cw) / 2; cy0 = top + (y1 - top - ch) / 2;
        // checker "world" background
        for (int yy = 0; yy < ch; yy += 8) for (int xx = 0; xx < cw; xx += 8)
            g.fill(cx0 + xx, cy0 + yy, cx0 + Math.min(cw, xx + 8), cy0 + Math.min(ch, yy + 8), ((xx + yy) / 8) % 2 == 0 ? 0xFF1C2A1C : 0xFF203020);
        outline(g, cx0 - 1, cy0 - 1, cx0 + cw + 1, cy0 + ch + 1, 0xFF3A3A4C);
        small(g, font, vw() + "×" + vh() + " (GUI px)", cx0, cy0 - 8, FAINT);
        scissor(g, cx0, cy0, cx0 + cw, cy0 + ch);
        List<El> byZ = new ArrayList<>(tree());
        byZ.sort(Comparator.comparingInt((El e) -> depth(e)).thenComparingInt(e -> e.z));
        for (El e : byZ) drawEl(g, e, k);
        g.disableScissor();
        if (sel != null) {
            double[] r = abs(sel, 0);
            int sx = cx0 + (int) (r[0] * k), sy = cy0 + (int) (r[1] * k), ex = cx0 + (int) ((r[0] + r[2]) * k), ey = cy0 + (int) ((r[1] + r[3]) * k);
            outline(g, sx - 1, sy - 1, ex + 1, ey + 1, ACCENT);
            g.fill(ex - 2, ey - 2, ex + 3, ey + 3, ACCENT2);
            small(g, font, sel.name, sx, sy - 8, ACCENT);
        }
        g.fill(ax1, top, ax1 + 1, y1, LINE);
        renderProps(g, ax1 + 1, top, x1, y1, mx, my);
        if (loadOpen) renderLoad(g, mx, my);
    }

    List<El> tree() {
        List<El> out = new ArrayList<>();
        for (El e : ELS) if (e.parent.isEmpty() || byName(e.parent) == null) walk(e, out, 0);
        return out;
    }
    void walk(El e, List<El> out, int d) { if (d > 20 || out.contains(e)) return; out.add(e); for (El c : ELS) if (c.parent.equals(e.name)) walk(c, out, d + 1); }
    int depth(El e) { int d = 0; El p = byName(e.parent); while (p != null && d < 20) { d++; p = byName(p.parent); } return d; }

    void drawEl(GuiGraphics g, El e, double k) {
        if (!e.visible) return;
        double[] r = abs(e, 0);
        int x = cx0 + (int) (r[0] * k), y = cy0 + (int) (r[1] * k), x2 = cx0 + (int) ((r[0] + r[2]) * k), y2 = cy0 + (int) ((r[1] + r[3]) * k);
        int a = (int) Math.round((1 - e.bgT) * 255);
        if (a > 0) {
            int c = (a << 24) | color(e.bg, 0x2A2A3A);
            if (e.corner > 0) round(g, x, y, x2, y2, c); else g.fill(x, y, x2, y2, c);
        }
        if (e.cls.startsWith("Image") && !e.image.isEmpty()) { try { UiTextures.blit(g, e.image, x, y, Math.max(1, x2 - x), Math.max(1, y2 - y)); } catch (Exception ignored) {} }
        if (e.cls.equals("ScrollingFrame")) g.fill(x2 - 2, y + 2, x2, Math.max(y + 3, y + (y2 - y) / 3), 0x88FFFFFF);
        String t = e.cls.equals("TextBox") ? (e.text.isEmpty() ? "Type here..." : e.text) : e.text;
        if (e.cls.startsWith("Text") && !t.isEmpty()) {
            float ts = (float) (e.textSize / 9.0 * k);
            g.pose().pushPose();
            g.pose().translate((x + x2) / 2f, (y + y2) / 2f - 4 * ts, 0);
            g.pose().scale(ts, ts, 1);
            g.drawString(font, t, -font.width(t) / 2, 0, 0xFF000000 | color(e.fg, 0xFFFFFF) | (e.cls.equals("TextBox") && e.text.isEmpty() ? 0 : 0), false);
            g.pose().popPose();
        }
    }

    void renderProps(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my) {
        g.fill(x0, y0, x1, y1, PANEL);
        label(g, "Properties", x0 + 8, y0 + 5);
        if (sel == null) { small(g, font, "Select or insert an element", x0 + 8, y0 + 18, FAINT); return; }
        int bx = x1 - 6, w;
        w = bw("Delete"); bx -= w; button(g, "del", bx, y0 + 2, w, 12, "Delete", 2, mx, my, this::deleteSel);
        w = bw("Duplicate"); bx -= w + 3; button(g, "dup", bx, y0 + 2, w, 12, "Duplicate", 0, mx, my, this::duplicate);
        small(g, font, sel.cls, x0 + 8, y0 + 16, ACCENT2);
        int top = y0 + 26, bot = y1 - 2;
        int lw = Math.max(70, (x1 - x0) * 46 / 100);
        String[][] ps = props();
        int rowH = 16;
        propScroll = Math.max(0, Math.min(propScroll, Math.max(0, ps.length * rowH - (bot - top))));
        scissor(g, x0, top, x1, bot);
        int y = top - propScroll;
        for (String[] p : ps) {
            if (y >= top && y + 14 <= bot) {
                text(g, font, ellipsize(font, p[0], lw - 10), x0 + 8, y + 3, DIM);
                if (p[0].equals("Visible")) {
                    boolean on = sel.visible;
                    toggle(g, "vis", x0 + lw, y + 1, on, mx, my, () -> { snapshot(); sel.visible = !sel.visible; syncBoxes(); });
                } else if (p[0].equals("Parent")) {
                    List<String> opts = new ArrayList<>(); opts.add("");
                    for (El e : ELS) if (e != sel && (e.cls.equals("Frame") || e.cls.equals("ScrollingFrame"))) opts.add(e.name);
                    choice(g, "par", x0 + lw, y, x1 - x0 - lw - 8, sel.parent.isEmpty() ? "<gui>" : sel.parent, opts.stream().map(o -> o.isEmpty() ? "<gui>" : o).toArray(String[]::new), mx, my,
                            v -> { snapshot(); sel.parent = v.equals("<gui>") ? "" : v; syncBoxes(); });
                } else {
                    EditBox b = box("p:" + p[0], "");
                    place(g, b, x0 + lw, y, x1 - x0 - lw - 8 - (p[0].endsWith("Color3") ? 14 : 0));
                    if (p[0].endsWith("Color3")) round(g, x1 - 20, y + 1, x1 - 8, y + 13, 0xFF000000 | color(b.getValue(), 0));
                    String v = b.getValue();
                    if (!v.equals(pushed.get(p[0]))) { pushed.put(p[0], v); applyProp(p[0], v); }
                }
            }
            y += rowH;
        }
        g.disableScissor();
    }

    record Entry(String header, String label, String sub, Runnable r) {}

    List<Entry> loadEntries() {
        List<Entry> l = new ArrayList<>();
        List<String> sv = saved();
        if (!local) {
            l.add(new Entry("GUI MAKER LAYOUTS (UI scripts)", null, null, null));
            if (sv.isEmpty()) l.add(new Entry(null, "none yet", null, null));
            for (String x : sv) l.add(new Entry(null, x, "", () -> load(x)));
        }
        List<String> lf = localFiles();
        l.add(new Entry("LOCAL DESIGNS (.minecraft/fluwa/guis)", null, null, null));
        if (lf.isEmpty()) l.add(new Entry(null, local ? "none yet - Save stores designs here" : "none (made in the main menu)", null, null));
        for (String x : lf) l.add(new Entry(null, x, "", () -> loadLocal(x)));
        if (!local && GameRuntime.CLIENT instanceof ClientRuntime r && !r.closed) {
            List<String[]> live = new ArrayList<>();
            r.within(() -> {
                for (LObj o : r.ui.listChildren()) if (o instanceof net.idea.fluwa.client.ui.ScreenGuiObj sg && !o.getName().equals("__GuiMakerPreview"))
                    live.add(new String[]{o.getName(), (sg.overlay ? "Overlay" : "ScreenGUI") + " · " + o.listChildren().size() + " children"});
                return null; });
            l.add(new Entry("RUNNING FLUWA GUIs (any script)", null, null, null));
            if (live.isEmpty()) l.add(new Entry(null, "no GUI objects exist right now", null, null));
            for (String[] x : live) l.add(new Entry(null, x[0], x[1], () -> importLive(x[0])));
        }
        List<String> ed = ScreenOverrides.list();
        if (!ed.isEmpty()) {
            l.add(new Entry("EDITED SCREENS (.minecraft/fluwa/screens)", null, null, null));
            for (String c : ed) l.add(new Entry(null, GuiImport.shortName(c), "edited", () -> importScreen(c)));
        }
        l.add(new Entry("SCREENS SEEN THIS SESSION (Minecraft & mods)", null, null, null));
        List<GuiImport.Snap> seen = new ArrayList<>(GuiImport.SEEN.values());
        Collections.reverse(seen);
        if (seen.isEmpty()) l.add(new Entry(null, "open any screen once, it appears here", null, null));
        for (GuiImport.Snap x : seen) l.add(new Entry(null, GuiImport.shortName(x.cls()), (ScreenOverrides.has(x.cls()) ? "✎ " : "") + x.title() + " · " + x.els().size() + " widgets", () -> importScreen(x.cls())));
        l.add(new Entry("MINECRAFT SCREENS", null, null, null));
        for (String[] v : GuiImport.VANILLA) if (!GuiImport.SEEN.containsKey(v[1])) l.add(new Entry(null, v[0], GuiImport.shortName(v[1]), () -> importScreen(v[1])));
        return l;
    }

    void renderLoad(GuiGraphics g, int mx, int my) {
        List<Entry> l = loadEntries();
        int w = Math.min(width - 20, 240), x = width - w - 10, y = TOPH + 22;
        int maxH = height - y - STATH - 8;
        int listH = 0; for (Entry e : l) listH += e.header() != null ? 14 : 13;
        int h = Math.min(maxH, 46 + listH);
        hits.add(new Hit(0, 0, width, height, () -> loadOpen = false));
        shadow(g, x, y, x + w, y + h);
        round(g, x, y, x + w, y + h, 0xFA1A1A24);
        outline(g, x, y, x + w, y + h, alpha(ACCENT, 0.7f));
        hits.add(new Hit(x, y, x + w, y + h, () -> {}));
        text(g, font, "Open / import a GUI", x + 8, y + 6, TEXT);
        // any screen class (other mods): type the class name
        EditBox cb = box("impcls", "Screen class, e.g. com.mod.client.MyScreen");
        int bw2 = bw("Import");
        place(g, cb, x + 6, y + 18, w - bw2 - 16);
        button(g, "impgo", x + w - bw2 - 6, y + 18, bw2, 14, "Import", 1, mx, my, () -> { if (!cb.getValue().isBlank()) importScreen(cb.getValue().trim()); });
        int top = y + 36, bot = y + h - 4;
        loadScroll = Math.max(0, Math.min(loadScroll, Math.max(0, listH - (bot - top))));
        scissor(g, x, top, x + w, bot);
        int yy = top - loadScroll;
        for (Entry e : l) {
            if (e.header() != null) {
                if (yy + 14 > top && yy < bot) small(g, font, e.header(), x + 8, yy + 4, ACCENT2);
                yy += 14; continue;
            }
            boolean vis = yy + 12 > top && yy < bot;
            if (vis) {
                boolean hov = e.r() != null && in(mx, my, x + 4, yy, x + w - 4, yy + 12) && my >= top && my < bot;
                if (hov) round(g, x + 4, yy, x + w - 4, yy + 12, HOVER);
                int sw2 = e.sub() == null || e.sub().isEmpty() ? 0 : Math.min(w / 2, (int) (font.width(e.sub()) * 0.75f) + 4);
                text(g, font, ellipsize(font, e.label(), w - 20 - sw2), x + 10, yy + 2, e.r() == null ? FAINT : 0xFFD0D0DC);
                if (sw2 > 0) small(g, font, ellipsize(font, e.sub(), (sw2 - 4) * 4 / 3), x + w - 8 - sw2, yy + 3, DIM);
                if (e.r() != null) { int cy1 = Math.max(yy, top), cy2 = Math.min(yy + 12, bot); hits.add(new Hit(x + 4, cy1, x + w - 4, cy2, e.r())); }
            }
            yy += 13;
        }
        g.disableScissor();
        if (listH > bot - top) {
            int th = Math.max(12, (bot - top) * (bot - top) / listH), ty = top + (bot - top - th) * loadScroll / Math.max(1, listH - (bot - top));
            round(g, x + w - 4, ty, x + w - 2, ty + th, 0x50FFFFFF);
        }
    }

    void deleteSel() {
        if (sel == null) return;
        snapshot();
        String n = sel.name;
        ELS.removeIf(e -> e == sel);
        for (El e : new ArrayList<>(ELS)) if (e.parent.equals(n)) e.parent = "";
        select(null);
    }
    void duplicate() {
        if (sel == null) return;
        snapshot();
        El c = sel.copy();
        int i = 2; while (byName(sel.name + "_" + i) != null) i++;
        c.name = sel.name + "_" + i; c.ox += 6; c.oy += 6;
        ELS.add(c);
        select(c);
    }

    // ------------------------------------------------------------------ canvas input
    El pick(double mx, double my) {
        double k = cw / (double) vw();
        List<El> l = new ArrayList<>(tree());
        l.sort(Comparator.comparingInt((El e) -> depth(e)).thenComparingInt(e -> e.z));
        for (int i = l.size() - 1; i >= 0; i--) {
            El e = l.get(i);
            double[] r = abs(e, 0);
            if (in(mx, my, cx0 + (int) (r[0] * k), cy0 + (int) (r[1] * k), cx0 + (int) ((r[0] + r[2]) * k) + 1, cy0 + (int) ((r[1] + r[3]) * k) + 1)) return e;
        }
        return null;
    }

    @Override protected boolean bodyClick(double mx, double my, int b) {
        if (!in(mx, my, cx0, cy0, cx0 + cw, cy0 + ch)) return false;
        double k = cw / (double) vw();
        if (sel != null) {
            double[] r = abs(sel, 0);
            int ex = cx0 + (int) ((r[0] + r[2]) * k), ey = cy0 + (int) ((r[1] + r[3]) * k);
            if (in(mx, my, ex - 4, ey - 4, ex + 5, ey + 5)) { snapshot(); drag = 2; dragMX = mx; dragMY = my; dragStart = sel.copy(); return true; }
        }
        El e = pick(mx, my);
        select(e);
        if (e != null) { snapshot(); drag = 1; dragMX = mx; dragMY = my; dragStart = e.copy(); }
        return true;
    }

    @Override protected boolean bodyDrag(double mx, double my, int b, double dx, double dy) {
        if (drag == 0 || sel == null) return false;
        double k = cw / (double) vw();
        double[] r = abs(sel, 0);
        double pw = r[4], ph = r[5];
        double ddx = (mx - dragMX) / k, ddy = (my - dragMY) / k;
        if (drag == 1) {
            if (useScale) { sel.sx = sn(dragStart.sx + ddx / pw); sel.sy = sn(dragStart.sy + ddy / ph); }
            else { sel.ox = Math.round(dragStart.ox + ddx); sel.oy = Math.round(dragStart.oy + ddy); }
        } else {
            if (useScale) { sel.wsx = Math.max(0.005, sn(dragStart.wsx + ddx / pw)); sel.wsy = Math.max(0.005, sn(dragStart.wsy + ddy / ph)); }
            else { sel.wox = Math.round(dragStart.wox + ddx); sel.woy = Math.round(dragStart.woy + ddy); }
        }
        syncBoxes();
        return true;
    }
    double sn(double v) { return snap ? Math.round(v * 100) / 100.0 : Math.round(v * 1000) / 1000.0; }

    @Override protected boolean bodyRelease(double mx, double my, int b) { drag = 0; return false; }

    @Override protected boolean bodyScroll(double mx, double my, double d) {
        if (loadOpen) { loadScroll = Math.max(0, loadScroll - (int) (d * 13 * 3)); return true; }
        propScroll = Math.max(0, propScroll - (int) (d * 16 * 2)); return true; }

    @Override protected boolean bodyKey(int key, int mods) {
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
        if (ctrl && key == GLFW.GLFW_KEY_Z) { undoLast(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_S) { save(); return true; }
        if (sel == null) return false;
        if (key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) { deleteSel(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_D) { duplicate(); return true; }
        double step = (mods & GLFW.GLFW_MOD_SHIFT) != 0 ? 0.05 : 0.01;
        int dx = key == GLFW.GLFW_KEY_LEFT ? -1 : key == GLFW.GLFW_KEY_RIGHT ? 1 : 0, dy = key == GLFW.GLFW_KEY_UP ? -1 : key == GLFW.GLFW_KEY_DOWN ? 1 : 0;
        if (dx != 0 || dy != 0) {
            if (useScale) { sel.sx = Math.round((sel.sx + dx * step) * 1000) / 1000.0; sel.sy = Math.round((sel.sy + dy * step) * 1000) / 1000.0; }
            else { sel.ox += dx * (step > 0.01 ? 5 : 1); sel.oy += dy * (step > 0.01 ? 5 : 1); }
            syncBoxes();
            return true;
        }
        return false;
    }

    @Override public void removed() {
        if (preview && GameRuntime.CLIENT instanceof ClientRuntime r && !r.closed) stopPreview(r);
        preview = false;
        super.removed();
    }
}
