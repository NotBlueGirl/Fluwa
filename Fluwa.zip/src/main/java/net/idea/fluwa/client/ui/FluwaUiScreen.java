package net.idea.fluwa.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Minecraft screen that shows a Lua ScreenGUI (or, focusOnly, just captures keyboard for an overlay TextBox). */
public class FluwaUiScreen extends Screen {
    public final ScreenGuiObj gui;
    public final boolean focusOnly;
    public boolean closing;

    public FluwaUiScreen(ScreenGuiObj g, boolean focusOnly) { super(Component.literal(g.getName())); gui = g; this.focusOnly = focusOnly; }

    <T> T in(java.util.function.Supplier<T> s, T def) {
        if (gui.rt == null || gui.rt.closed) return def;
        return gui.rt.within(s);
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        if (!focusOnly) in(() -> { gui.renderRoot(g, width, height, mx, my); return null; }, null);
        super.render(g, mx, my, pt);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (net.idea.fluwa.client.BrowserRender.click(mx, my, button)) return true;
        if (in(() -> UiInput.down(gui, mx, my, button), false)) return true;
        if (focusOnly) { onClose(); return true; }
        return super.mouseClicked(mx, my, button);
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (in(() -> UiInput.up(mx, my, button), false)) return true;
        return super.mouseReleased(mx, my, button);
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && in(() -> UiInput.drag(mx, my, dx, dy), false)) return true;
        return super.mouseDragged(mx, my, button, dx, dy);
    }
    @Override public boolean mouseScrolled(double mx, double my, double d) {
        if (net.idea.fluwa.client.BrowserRender.scroll(mx, my, d)) return true;
        if (in(() -> UiInput.scroll(gui, mx, my, d), false)) return true;
        return super.mouseScrolled(mx, my, d);
    }
    @Override public boolean keyPressed(int key, int scan, int mods) {
        TextBoxObj f = UiInput.focus;
        if (f != null && in(() -> f.key(key, mods), false)) return true;
        if (f == null && net.idea.fluwa.client.BrowserRender.key(key)) return true;
        return super.keyPressed(key, scan, mods);
    }
    @Override public boolean charTyped(char c, int mods) {
        TextBoxObj f = UiInput.focus;
        if (f != null && in(() -> f.charTyped(c), false)) return true;
        if (f == null && net.idea.fluwa.client.BrowserRender.chr(c)) return true;
        return super.charTyped(c, mods);
    }

    @Override public boolean shouldCloseOnEsc() { return focusOnly || gui.closeOnEsc; }
    @Override public boolean isPauseScreen() { return !focusOnly && gui.pauseGame; }

    @Override public void removed() {
        closing = true;
        TextBoxObj f = UiInput.focus;
        if (f != null) in(() -> { f.release(false); return null; }, null);
        if (!focusOnly && gui.enabled && gui.rt != null && !gui.rt.closed) gui.rt.within(() -> { gui.enabled = false; gui.fire("E_Closed"); return null; });
    }
}
