package net.idea.fluwa.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferUploader;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.lighting.FxObj;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Vector4f;
import org.lwjgl.opengl.*;

/** v0.5 post effects of Lighting: Bloom, Blur, ColorCorrection, DepthOfField, SunRays and ExposureCompensation. */
public final class LightingPost {
    private LightingPost() {}

    static final String BLUR = """
            uniform vec2 Dir;
            uniform float Threshold;
            void main() {
                vec3 acc = vec3(0.0); float ws = 0.0;
                for (int i = -6; i <= 6; i++) {
                    float w = exp(-float(i * i) / 18.0);
                    vec3 c = texture(DiffuseSampler, texCoord + Dir * float(i)).rgb;
                    if (Threshold >= 0.0) { float l = dot(c, vec3(0.2126, 0.7152, 0.0722)); c *= smoothstep(Threshold, Threshold + 0.2, l); }
                    acc += c * w; ws += w;
                }
                fragColor = vec4(acc / ws, 1.0);
            }
            """;
    static final String COMPOSITE = """
            uniform sampler2D DepthSampler;
            uniform sampler2D BlurSampler;
            uniform sampler2D BloomSampler;
            uniform float Near; uniform float Far;
            uniform vec4 Dof; uniform float DofOn;
            uniform float BlurAmt; uniform float BloomAmt; uniform float Exposure;
            uniform vec4 CC; uniform vec3 Tint;
            uniform vec3 SunPos; uniform float SunSpread; uniform vec3 SunColor;
            float lin(float d) { float z = d * 2.0 - 1.0; return 2.0 * Near * Far / (Far + Near - z * (Far - Near)); }
            // ---- Lighting.Technology (Voxel / ShadowMap / Future)
            uniform float Tech;
            uniform mat4 InvProj; uniform mat4 InvView; uniform mat4 ViewProj;
            uniform vec3 SunDir; uniform vec3 SunCol2; uniform float ShadowAmt; uniform float Soft;
            uniform int LightCount; uniform vec4 LightPos[8]; uniform vec4 LightCol[8]; uniform vec4 LightDir[8];
            vec3 wpos(vec2 uv, float d) { vec4 v = InvProj * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0); v /= v.w; return (InvView * vec4(v.xyz, 1.0)).xyz; }
            vec3 proj(vec3 w) { vec4 c = ViewProj * vec4(w, 1.0); return c.xyz / c.w * 0.5 + 0.5; }
            float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
            float trace(vec3 p, vec3 dir, float len, int steps, float jit) {
                for (int i = 1; i <= 24; i++) {
                    if (i > steps) break;
                    float t = len * pow((float(i) - 1.0 + jit) / float(steps), 1.6) + 0.05;
                    vec3 s = proj(p + dir * t);
                    if (s.x < 0.0 || s.y < 0.0 || s.x > 1.0 || s.y > 1.0 || s.z > 1.0) break;
                    float dz = lin(s.z) - lin(texture(DepthSampler, s.xy).r);
                    if (dz > 0.03 && dz < 1.5 + t * 0.15) return 1.0;
                }
                return 0.0;
            }
            float ssao(vec3 P, vec3 N, float r, float jit) {
                vec3 t = normalize(abs(N.y) < 0.9 ? cross(N, vec3(0.0, 1.0, 0.0)) : cross(N, vec3(1.0, 0.0, 0.0)));
                vec3 b = cross(N, t); float occ = 0.0;
                for (int i = 0; i < 8; i++) {
                    float a = (float(i) + jit) * 2.39996, h = (float(i) + 0.5) / 8.0;
                    vec3 k = (t * cos(a) + b * sin(a)) * sqrt(1.0 - h * h) + N * h;
                    vec3 s = proj(P + N * 0.05 + k * r * mix(0.3, 1.0, float(i) / 7.0));
                    if (s.x < 0.0 || s.y < 0.0 || s.x > 1.0 || s.y > 1.0) continue;
                    float dz = lin(s.z) - lin(texture(DepthSampler, s.xy).r);
                    if (dz > 0.02 && dz < r * 2.0) occ += 1.0;
                }
                return occ / 8.0;
            }
            vec3 technology(vec3 c, float d) {
                if (Tech < 1.5 || d >= 0.99999) return c;
                vec3 P = wpos(texCoord, d);
                vec3 N = normalize(cross(dFdx(P), dFdy(P)));
                if (dot(N, P) > 0.0) N = -N;
                float fade = 1.0 - smoothstep(48.0, 96.0, length(P));
                if (fade <= 0.0) return c;
                float jit = hash(texCoord * ScreenSize);
                float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
                // ambient occlusion: Voxel soft & wide, ShadowMap/Future tighter
                float ao = ssao(P, N, Tech < 2.5 ? 1.2 : 0.8, jit);
                c *= 1.0 - ao * (Tech < 2.5 ? 0.3 : Tech < 3.5 ? 0.4 : 0.5) * fade;
                // sun shadows: Voxel = blurry voxel-like, ShadowMap/Future = sharp (ShadowSoftness blurs them)
                vec3 L = normalize(SunDir); float ndl = dot(N, L); float sh = 0.0;
                if (ShadowAmt > 0.0) {
                    if (ndl <= 0.02) sh = 0.6;
                    else {
                        bool voxel = Tech < 2.5;
                        int steps = voxel ? 10 : 20; float len = voxel ? 12.0 : 24.0;
                        sh = trace(P + N * 0.06, L, len, steps, jit);
                        float spread = voxel ? 0.35 : Soft * 0.3;
                        if (spread > 0.0) {
                            vec3 L2 = normalize(L + (vec3(hash(texCoord + 1.3), hash(texCoord + 2.7), hash(texCoord + 4.1)) - 0.5) * spread);
                            sh = 0.5 * sh + 0.5 * trace(P + N * 0.06, L2, len, steps, 1.0 - jit);
                        }
                    }
                    float k = ShadowAmt * fade * smoothstep(0.12, 0.55, lum);
                    c *= 1.0 - sh * k * 0.55;
                    if (Tech > 2.5) c *= mix(vec3(1.0), SunCol2, 0.15 * (1.0 - sh) * max(ndl, 0.0) * k);
                }
                // Future: per-pixel shadowed lights + specular
                if (Tech > 3.5) {
                    vec3 V = normalize(-P);
                    for (int i = 0; i < 8; i++) {
                        if (i >= LightCount) break;
                        vec3 lv = LightPos[i].xyz - P; float ld = length(lv), range = LightPos[i].w;
                        if (ld > range || ld < 1.0e-3) continue;
                        vec3 ldir = lv / ld;
                        float att = pow(1.0 - ld / range, 2.0);
                        if (LightDir[i].w > -1.5) att *= smoothstep(LightDir[i].w, LightDir[i].w + 0.08, dot(-ldir, normalize(LightDir[i].xyz)));
                        float nl = max(dot(N, ldir), 0.0);
                        if (nl <= 0.0 || att <= 0.0) continue;
                        float vis = 1.0 - trace(P + N * 0.06, ldir, max(0.3, min(ld - 0.3, 16.0)), 12, jit);
                        float spec = pow(max(dot(N, normalize(ldir + V)), 0.0), 48.0) * 0.6;
                        c += (c * 1.2 + spec) * LightCol[i].rgb * att * nl * vis;
                    }
                    if (ShadowAmt > 0.0 && ndl > 0.0)
                        c += SunCol2 * pow(max(dot(N, normalize(L + V)), 0.0), 64.0) * 0.25 * (1.0 - sh) * fade * ShadowAmt;
                }
                return c;
            }
            void main() {
                vec3 c = texture(DiffuseSampler, texCoord).rgb;
                float d = texture(DepthSampler, texCoord).r;
                vec3 bl = texture(BlurSampler, texCoord).rgb;
                c = technology(c, d);
                if (DofOn > 0.5) {
                    float z = d >= 0.99999 ? 1.0e6 : lin(d);
                    float f = 0.0;
                    if (z > Dof.x + Dof.y) f = clamp((z - (Dof.x + Dof.y)) / max(Dof.y, 4.0), 0.0, 1.0) * Dof.w;
                    else if (z < Dof.x - Dof.y) f = clamp(((Dof.x - Dof.y) - z) / max(Dof.y * 0.5, 1.0), 0.0, 1.0) * Dof.z;
                    c = mix(c, bl, f);
                }
                if (BlurAmt > 0.0) c = mix(c, bl, BlurAmt);
                if (SunPos.z > 0.0) {
                    vec2 dl = (SunPos.xy - texCoord) * (SunSpread * 0.9 + 0.1) / 32.0;
                    vec2 uv = texCoord; float decay = 1.0; vec3 acc = vec3(0.0);
                    for (int i = 0; i < 32; i++) {
                        uv += dl;
                        if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) break;
                        float sd = texture(DepthSampler, uv).r;
                        vec3 sc = texture(DiffuseSampler, uv).rgb;
                        float sky = sd >= 0.99999 ? 1.0 : 0.0;
                        acc += sc * sky * decay * smoothstep(0.5, 1.0, dot(sc, vec3(0.333)));
                        decay *= 0.94;
                    }
                    c += acc / 32.0 * SunPos.z * SunColor * 6.0;
                }
                if (BloomAmt > 0.0) c += texture(BloomSampler, texCoord).rgb * BloomAmt;
                c *= Exposure;
                if (CC.w > 0.5) {
                    c += CC.x;
                    c = (c - 0.5) * (1.0 + CC.y) + 0.5;
                    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
                    c = mix(vec3(l), c, 1.0 + CC.z);
                    c *= Tint;
                }
                fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
            }
            """;

    static int blurProg, compProg, vao; static boolean failed;
    static TextureTarget scene, depth, h1, h2, b1, b2;

    static TextureTarget fit(TextureTarget t, int w, int h, boolean dep) {
        if (t == null) { t = new TextureTarget(w, h, dep, Minecraft.ON_OSX); t.setFilterMode(GL11.GL_LINEAR); }
        else if (t.width != w || t.height != h) { t.resize(w, h, Minecraft.ON_OSX); t.setFilterMode(GL11.GL_LINEAR); }
        return t;
    }

    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || failed) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        // ---- gather the active effects
        float bloom = 0, bloomThr = 0.8f, bloomSize = 0, blurSize = 0, ccB = 0, ccC = 0, ccS = 0; float[] tint = {1, 1, 1};
        boolean cc = false; FxObj dof = null, rays = null;
        for (FxObj f : LightingClient.effects()) {
            if (f.schema().get("Enabled") != null && !f.bool("Enabled")) continue;
            switch (f.className) {
                case "Bloom" -> { bloom += (float) f.num("Intensity"); bloomThr = (float) (f.num("Threshold") / 2.5); bloomSize = Math.max(bloomSize, (float) f.num("Size")); }
                case "Blur" -> blurSize = Math.max(blurSize, (float) f.num("Size"));
                case "ColorCorrection" -> { cc = true; ccB += (float) f.num("Brightness"); ccC += (float) f.num("Contrast"); ccS += (float) f.num("Saturation");
                    float[] t = LightingClient.col(f.value("TintColor")); tint[0] *= t[0]; tint[1] *= t[1]; tint[2] *= t[2]; }
                case "DepthOfField" -> dof = f;
                case "SunRays" -> rays = f;
            }
        }
        float exposure = (float) Math.pow(2, LightingClient.num("ExposureCompensation"));
        int tech = LightingClient.techLevel(); // 0 Legacy, 1 Compatibility (lightmap only), 2 Voxel, 3 ShadowMap, 4 Future
        if (tech < 2 && bloom <= 0 && blurSize <= 0 && !cc && dof == null && rays == null && Math.abs(exposure - 1) < 1e-4) return;
        try {
            if (vao == 0) {
                StringBuilder log = new StringBuilder();
                blurProg = ShaderDT.link(BLUR, log);
                compProg = ShaderDT.link(COMPOSITE, log);
                if (blurProg == 0 || compProg == 0) { failed = true; Fluwa.LOGGER.error("Fluwa Lighting post shaders failed: {}", log); return; }
                vao = GL30.glGenVertexArrays();
            }
            RenderTarget main = mc.getMainRenderTarget();
            int w = main.width, h = main.height, hw = Math.max(1, w / 2), hh = Math.max(1, h / 2);
            scene = fit(scene, w, h, false);
            depth = fit(depth, w, h, true);
            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.frameBufferId);
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, scene.frameBufferId);
            GlStateManager._glBlitFrameBuffer(0, 0, w, h, 0, 0, w, h, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_NEAREST);
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, depth.frameBufferId);
            GlStateManager._glBlitFrameBuffer(0, 0, w, h, 0, 0, w, h, GL11.GL_DEPTH_BUFFER_BIT, GL11.GL_NEAREST);
            RenderSystem.disableDepthTest(); RenderSystem.depthMask(false); RenderSystem.disableBlend(); RenderSystem.disableCull();
            GL30.glBindVertexArray(vao);
            float blurR = Math.max(blurSize, dof != null ? 14 : 0);
            if (blurR > 0) {
                h1 = fit(h1, hw, hh, false); h2 = fit(h2, hw, hh, false);
                pass(blurProg, scene.getColorTextureId(), h1, blurR / 6f / w, 0, -1, w, h);
                pass(blurProg, h1.getColorTextureId(), h2, 0, blurR / 6f / h, -1, w, h);
            }
            if (bloom > 0) {
                b1 = fit(b1, hw, hh, false); b2 = fit(b2, hw, hh, false);
                float r = Math.max(2, bloomSize);
                pass(blurProg, scene.getColorTextureId(), b1, r / 6f / w, 0, bloomThr, w, h);
                pass(blurProg, b1.getColorTextureId(), b2, 0, r / 6f / h, -1, w, h);
            }
            // ---- composite into the main target
            main.bindWrite(true);
            GlStateManager._glUseProgram(compProg);
            int p = compProg;
            tex(p, "DiffuseSampler", 0, scene.getColorTextureId());
            tex(p, "DepthSampler", 1, depth.getDepthTextureId());
            tex(p, "BlurSampler", 2, blurR > 0 ? h2.getColorTextureId() : scene.getColorTextureId());
            tex(p, "BloomSampler", 3, bloom > 0 ? b2.getColorTextureId() : scene.getColorTextureId());
            u(p, "ScreenSize", w, h);
            u(p, "Near", 0.05f); u(p, "Far", mc.gameRenderer.getDepthFar());
            if (dof != null) { u(p, "DofOn", 1); u4(p, "Dof", (float) dof.num("FocusDistance"), (float) dof.num("InFocusRadius"), (float) dof.num("NearIntensity"), (float) dof.num("FarIntensity")); }
            else u(p, "DofOn", 0);
            u(p, "BlurAmt", blurSize > 0 ? 1 : 0);
            u(p, "BloomAmt", bloom);
            u(p, "Exposure", exposure);
            u4(p, "CC", ccB, ccC, ccS, cc ? 1 : 0);
            GL20.glUniform3f(GL20.glGetUniformLocation(p, "Tint"), tint[0], tint[1], tint[2]);
            float sx = 0, sy = 0, strength = 0;
            if (rays != null) {
                Vec3 sd = LightingClient.sunDir(e.getPartialTick());
                Vector4f v = new Vector4f((float) sd.x * 100, (float) sd.y * 100, (float) sd.z * 100, 1);
                e.getPoseStack().last().pose().transform(v);
                e.getProjectionMatrix().transform(v);
                if (v.w > 0) {
                    sx = (v.x / v.w) * 0.5f + 0.5f; sy = (v.y / v.w) * 0.5f + 0.5f;
                    float day = (float) Math.max(0, Math.min(1, sd.y * 4 + 0.3));
                    strength = (float) rays.num("Intensity") * day * (1 - mc.level.getRainLevel(e.getPartialTick()));
                }
                u(p, "SunSpread", (float) rays.num("Spread"));
            }
            GL20.glUniform3f(GL20.glGetUniformLocation(p, "SunPos"), sx, sy, strength);
            float[] sc = LightingClient.snap().sunColor;
            GL20.glUniform3f(GL20.glGetUniformLocation(p, "SunColor"), sc[0], sc[1], sc[2]);
            techUniforms(p, e, tech);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
        } catch (RuntimeException ex) {
            failed = true;
            Fluwa.LOGGER.error("Fluwa Lighting post effects disabled after a render error", ex);
        } finally {
            GL30.glBindVertexArray(0);
            for (int i = 3; i >= 0; i--) { RenderSystem.activeTexture(GL13.GL_TEXTURE0 + i); RenderSystem.bindTexture(0); }
            BufferUploader.invalidate();
            GlStateManager._glUseProgram(0);
            RenderSystem.depthMask(true); RenderSystem.enableDepthTest(); RenderSystem.enableCull();
            mc.getMainRenderTarget().bindWrite(true);
        }
    }

    /** uniforms of the Lighting.Technology pass (matrices are camera-relative, like the level renderer) */
    static void techUniforms(int p, RenderLevelStageEvent e, int tech) {
        Minecraft mc = Minecraft.getInstance();
        u(p, "Tech", tech);
        if (tech < 2) return;
        org.joml.Matrix4f view = new org.joml.Matrix4f(e.getPoseStack().last().pose());
        org.joml.Matrix4f prj = new org.joml.Matrix4f(e.getProjectionMatrix());
        mat(p, "InvProj", new org.joml.Matrix4f(prj).invert());
        mat(p, "InvView", new org.joml.Matrix4f(view).invert());
        mat(p, "ViewProj", new org.joml.Matrix4f(prj).mul(view));
        float pt = e.getPartialTick();
        Vec3 sd = LightingClient.sunDir(pt);
        LightingClient.Snap s = LightingClient.snap();
        boolean sky = mc.level.dimensionType().hasSkyLight();
        float day = (float) Math.max(0, Math.min(1, sd.y * 4 + 0.3));
        float amt = s.shadows && sky ? day * (1 - mc.level.getRainLevel(pt) * 0.7f) : 0;
        GL20.glUniform3f(GL20.glGetUniformLocation(p, "SunDir"), (float) sd.x, (float) sd.y, (float) sd.z);
        GL20.glUniform3f(GL20.glGetUniformLocation(p, "SunCol2"), s.sunColor[0], s.sunColor[1], s.sunColor[2]);
        u(p, "ShadowAmt", amt);
        u(p, "Soft", Math.max(0, Math.min(1, s.softness)));
        int n = 0;
        if (tech >= 4) {
            Vec3 cam = e.getCamera().getPosition();
            java.util.List<LightingClient.L> ls = new java.util.ArrayList<>(LightingClient.lights());
            ls.removeIf(l -> l.pos().distanceToSqr(cam) > (l.range() + 64) * (l.range() + 64));
            ls.sort(java.util.Comparator.comparingDouble(l -> l.pos().distanceToSqr(cam)));
            for (LightingClient.L l : ls) {
                if (n >= 8) break;
                float k = (float) (l.bright() * (1 - l.transp()) * 0.6);
                if (k <= 0) continue;
                Vec3 r = l.pos().subtract(cam);
                GL20.glUniform4f(GL20.glGetUniformLocation(p, "LightPos[" + n + "]"), (float) r.x, (float) r.y, (float) r.z, (float) Math.max(0.5, l.range()));
                GL20.glUniform4f(GL20.glGetUniformLocation(p, "LightCol[" + n + "]"), l.color()[0] * k, l.color()[1] * k, l.color()[2] * k, 1);
                Vec3 dir = l.dir() == null ? new Vec3(0, -1, 0) : l.dir();
                float cone = l.beam() ? (float) Math.cos(Math.toRadians(Math.max(1, Math.min(179, l.angle())) / 2)) : -2;
                GL20.glUniform4f(GL20.glGetUniformLocation(p, "LightDir[" + n + "]"), (float) dir.x, (float) dir.y, (float) dir.z, cone);
                n++;
            }
        }
        GL20.glUniform1i(GL20.glGetUniformLocation(p, "LightCount"), n);
    }
    static void mat(int p, String n, org.joml.Matrix4f m) { float[] a = new float[16]; m.get(a); GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(p, n), false, a); }

    static void pass(int prog, int srcTex, TextureTarget dst, float dx, float dy, float thr, int w, int h) {
        dst.bindWrite(true);
        GlStateManager._glUseProgram(prog);
        tex(prog, "DiffuseSampler", 0, srcTex);
        u(prog, "ScreenSize", w, h);
        GL20.glUniform2f(GL20.glGetUniformLocation(prog, "Dir"), dx, dy);
        u(prog, "Threshold", thr);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    }

    static void tex(int p, String n, int unit, int id) {
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + unit);
        RenderSystem.bindTexture(id);
        GL20.glUniform1i(GL20.glGetUniformLocation(p, n), unit);
    }
    static void u(int p, String n, float v) { GL20.glUniform1f(GL20.glGetUniformLocation(p, n), v); }
    static void u(int p, String n, float a, float b) { GL20.glUniform2f(GL20.glGetUniformLocation(p, n), a, b); }
    static void u4(int p, String n, float a, float b, float c, float d) { GL20.glUniform4f(GL20.glGetUniformLocation(p, n), a, b, c, d); }
}
