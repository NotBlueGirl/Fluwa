package net.idea.fluwa.client.zspace;

import net.idea.fluwa.lua.ColorL;
import net.idea.fluwa.lua.LObj;
import net.idea.fluwa.lua.UDim2L;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.luaj.vm2.LuaValue;

import java.lang.reflect.Constructor;
import java.util.*;

/**
 * v0.5.2 GUI Maker import: turns an existing GUI into editable GUI Maker elements -
 *  - live Fluwa GUIs (ScreenGUI / Overlay objects of the client runtime, also hand-written ones),
 *  - any Minecraft or mod screen: screens opened during this session are captured automatically,
 *    well-known vanilla screens (and any class name) are constructed and laid out off-screen.
 */
public final class GuiImport {
    private GuiImport() {}

    public record Snap(String cls, String title, List<GuiMakerScreen.El> els, long time) {}
    /** screens seen this session (class -> last layout) */
    public static final LinkedHashMap<String, Snap> SEEN = new LinkedHashMap<>();

    public static final String[][] VANILLA = {
            {"Title screen", "net.minecraft.client.gui.screens.TitleScreen"},
            {"Pause menu", "net.minecraft.client.gui.screens.PauseScreen"},
            {"Options", "net.minecraft.client.gui.screens.OptionsScreen"},
            {"Video settings", "net.minecraft.client.gui.screens.VideoSettingsScreen"},
            {"Controls", "net.minecraft.client.gui.screens.controls.ControlsScreen"},
            {"Sound options", "net.minecraft.client.gui.screens.SoundOptionsScreen"},
            {"Accessibility", "net.minecraft.client.gui.screens.AccessibilityOptionsScreen"},
            {"Chat options", "net.minecraft.client.gui.screens.ChatOptionsScreen"},
            {"Skin customization", "net.minecraft.client.gui.screens.SkinCustomizationScreen"},
            {"Language", "net.minecraft.client.gui.screens.LanguageSelectScreen"},
            {"Singleplayer", "net.minecraft.client.gui.screens.worldselection.SelectWorldScreen"},
            {"Multiplayer", "net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen"},
            {"Direct connect", "net.minecraft.client.gui.screens.DirectJoinServerScreen"},
            {"Death screen", "net.minecraft.client.gui.screens.DeathScreen"},
            {"Connecting", "net.minecraft.client.gui.screens.ConnectScreen"},
            {"Chat", "net.minecraft.client.gui.screens.ChatScreen"},
            {"Mods list (Forge)", "net.minecraftforge.client.gui.ModListScreen"},
    };

    static boolean own(Screen s) {
        String n = s.getClass().getName();
        return n.startsWith("net.idea.fluwa.");
    }

    /** ScreenEvent.Init.Post: remember the layout of every foreign screen */
    public static void captured(Screen s) {
        if (s == null || own(s)) return;
        try {
            List<GuiMakerScreen.El> els = fromScreen(s, s.width, s.height);
            SEEN.remove(s.getClass().getName());
            SEEN.put(s.getClass().getName(), new Snap(s.getClass().getName(), s.getTitle().getString(), els, System.currentTimeMillis()));
            while (SEEN.size() > 40) SEEN.remove(SEEN.keySet().iterator().next());
        } catch (Throwable ignored) {}
    }

    static String hex(int rgb) { return String.format(Locale.ROOT, "#%06X", rgb & 0xFFFFFF); }
    static String shortName(String cls) { int i = cls.lastIndexOf('.'); return i < 0 ? cls : cls.substring(i + 1); }

    // ------------------------------------------------------------------ Minecraft / mod screens
    public static List<GuiMakerScreen.El> fromScreen(Screen s, int w, int h) {
        List<GuiMakerScreen.El> out = new ArrayList<>();
        Map<String, Integer> names = new HashMap<>();
        String t = s.getTitle().getString();
        if (!t.isBlank()) {
            GuiMakerScreen.El e = el("TextLabel", "Title", names);
            e.text = t; e.bgT = 1; e.fg = "#FFFFFF";
            e.wox = Math.min(w, Minecraft.getInstance().font.width(t) + 20); e.woy = 14;
            e.sx = 0.5; e.ox = -e.wox / 2; e.oy = 6;
            e.src = "title"; e.text0 = t; origin(e, w / 2.0 - e.wox / 2, 6, e.wox, e.woy);
            out.add(e);
        }
        for (Object[] wk : widgets(s)) {
            GuiMakerScreen.El e = widget(wk[0], w, h, names);
            if (e != null) { e.src = (String) wk[1]; out.add(e); }
        }
        int z = 1; for (GuiMakerScreen.El e : out) e.z = z++;
        return out;
    }

    static void origin(GuiMakerScreen.El e, double x, double y, double w, double h) { e.x0 = x; e.y0 = y; e.w0 = w; e.h0 = h; }

    /** every widget of a screen with a stable key (class | translation key or text # occurrence), also invisible ones */
    public static List<Object[]> widgets(Screen s) {
        List<Object[]> out = new ArrayList<>();
        Set<Object> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        Map<String, Integer> count = new HashMap<>();
        List<Object> all = new ArrayList<>();
        all.addAll(s.renderables);
        all.addAll(s.children());
        for (Object o : all) {
            if (!seen.add(o) || o instanceof ScreenOverrides.ElWidget || o instanceof ScreenOverrides.AddedBox) continue;
            if (!(o instanceof AbstractWidget) && !(o instanceof AbstractSelectionList<?>)) continue;
            String k = shortName(o.getClass().getName()) + "|" + messageKey(o);
            int n = count.merge(k, 1, Integer::sum);
            out.add(new Object[]{o, k + "#" + n});
        }
        return out;
    }

    static String messageKey(Object o) {
        if (!(o instanceof AbstractWidget aw) || aw instanceof EditBox) return "";
        Component m = aw.getMessage();
        if (m == null) return "";
        if (m.getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents tc) return tc.getKey();
        String t = m.getString();
        return t.length() > 40 ? t.substring(0, 40) : t;
    }

    static GuiMakerScreen.El el(String cls, String base, Map<String, Integer> names) {
        GuiMakerScreen.El e = new GuiMakerScreen.El();
        e.cls = cls;
        String b = base.replaceAll("[^\\w]", "_");
        if (b.isEmpty() || Character.isDigit(b.charAt(0))) b = cls + "_" + b;
        if (b.length() > 24) b = b.substring(0, 24);
        int n = names.merge(b, 1, Integer::sum);
        e.name = n == 1 ? b : b + n;
        return e;
    }

    static GuiMakerScreen.El widget(Object o, int w, int h, Map<String, Integer> names) {
        int x, y, ww, hh; String text = ""; String cls;
        if (o instanceof AbstractSelectionList<?> l) {
            x = l.getLeft(); y = l.getTop(); ww = l.getWidth(); hh = l.getHeight(); cls = "ScrollingFrame";
        } else if (o instanceof AbstractWidget aw) {
            if (!aw.visible) return null;
            x = aw.getX(); y = aw.getY(); ww = aw.getWidth(); hh = aw.getHeight();
            text = aw.getMessage() == null ? "" : aw.getMessage().getString();
            if (aw instanceof EditBox eb) { cls = "TextBox"; text = eb.getValue(); }
            else if (aw instanceof ImageButton) cls = "ImageButton";
            else if (aw instanceof AbstractStringWidget || aw instanceof MultiLineTextWidget) cls = "TextLabel";
            else if (aw instanceof AbstractButton || aw instanceof AbstractSliderButton) cls = "TextButton";
            else cls = "Frame";
        } else return null;
        if (ww <= 0 || hh <= 0) return null;
        GuiMakerScreen.El e = el(cls, text.isBlank() ? shortName(o.getClass().getName()) : text, names);
        // position: Scale (follows the screen size like vanilla layouts), size: Offset (fixed pixels)
        e.sx = Math.round(x / (double) Math.max(1, w) * 1000) / 1000.0;
        e.sy = Math.round(y / (double) Math.max(1, h) * 1000) / 1000.0;
        e.wox = ww; e.woy = hh; e.wsx = 0; e.wsy = 0;
        e.text = text; e.text0 = text;
        origin(e, x, y, ww, hh);
        switch (cls) {
            case "TextButton", "ImageButton" -> { e.bg = "#5A5A5A"; e.fg = "#FFFFFF"; e.corner = 0; e.textSize = 14; }
            case "TextBox" -> { e.bg = "#000000"; e.fg = "#E0E0E0"; }
            case "TextLabel" -> { e.bgT = 1; e.fg = "#FFFFFF"; }
            case "ScrollingFrame" -> { e.bg = "#000000"; e.bgT = 0.5; }
            default -> { e.bg = "#303040"; e.bgT = 0.3; }
        }
        if (cls.equals("ImageButton")) e.image = "minecraft:textures/gui/widgets.png";
        return e;
    }

    /** constructs a screen by class name (constructor arguments are guessed) and lays it out at w×h */
    public static Screen construct(String className, int w, int h) throws Exception {
        Class<?> c = Class.forName(className.trim(), true, GuiImport.class.getClassLoader());
        if (!Screen.class.isAssignableFrom(c)) throw new IllegalArgumentException(className + " is not a Screen");
        Minecraft mc = Minecraft.getInstance();
        List<Constructor<?>> cs = new ArrayList<>(Arrays.asList(c.getDeclaredConstructors()));
        cs.sort(Comparator.comparingInt(Constructor::getParameterCount));
        Exception last = null;
        for (Constructor<?> k : cs) {
            Object[] args = new Object[k.getParameterCount()];
            Class<?>[] pt = k.getParameterTypes();
            boolean ok = true;
            for (int i = 0; i < pt.length; i++) {
                Class<?> p = pt[i];
                if (Screen.class.isAssignableFrom(p)) { Screen sc = mc.screen; args[i] = sc != null && p.isInstance(sc) && !own(sc) ? sc : null; }
                else if (p == net.minecraft.client.Options.class) args[i] = mc.options;
                else if (p == boolean.class) args[i] = true;
                else if (p == int.class) args[i] = 0;
                else if (p == float.class) args[i] = 0f;
                else if (p == String.class) args[i] = "";
                else if (p == Component.class) args[i] = Component.literal(shortName(className));
                else if (p == net.minecraft.client.resources.language.LanguageManager.class) args[i] = mc.getLanguageManager();
                else if (p == Minecraft.class) args[i] = mc;
                else if (p.isPrimitive()) { ok = false; break; }
                else args[i] = null;
            }
            if (!ok) continue;
            try {
                k.setAccessible(true);
                Screen s = (Screen) k.newInstance(args);
                s.init(mc, w, h);
                return s;
            } catch (Exception e) { last = e; }
            catch (Throwable t) { last = new Exception(t.toString()); }
        }
        throw last != null ? last : new IllegalArgumentException("No usable constructor in " + className);
    }

    // ------------------------------------------------------------------ live Fluwa GUIs
    static final Map<String, String> MAP = Map.of("Button", "TextButton", "Image", "ImageLabel", "AnimImage", "ImageLabel",
            "ViewportFrame", "Frame", "VideoFrame", "Frame", "CanvasGroup", "Frame");

    /** GUI object -> elements (runs inside the client runtime) */
    public static List<GuiMakerScreen.El> fromLive(LObj gui) {
        List<GuiMakerScreen.El> out = new ArrayList<>();
        Map<String, Integer> names = new HashMap<>();
        walk(gui, "", out, names, 0);
        int z = 1; for (GuiMakerScreen.El e : out) if (e.z <= 1) e.z = z++;
        return out;
    }

    static void walk(LObj parent, String parentName, List<GuiMakerScreen.El> out, Map<String, Integer> names, int depth) {
        if (depth > 20) return;
        for (LObj o : parent.listChildren()) {
            String c = MAP.getOrDefault(o.className, o.className);
            if (c.equals("UICorner") && !parentName.isEmpty()) {
                for (GuiMakerScreen.El e : out) if (e.name.equals(parentName)) {
                    LuaValue r = safe(o, "CornerRadius");
                    if (r instanceof net.idea.fluwa.lua.UDimL u) e.corner = u.o;
                }
                continue;
            }
            if (!Arrays.asList(GuiMakerScreen.PALETTE).contains(c)) continue;
            GuiMakerScreen.El e = el(c, o.getName(), names);
            e.parent = parentName;
            if (safe(o, "Position") instanceof UDim2L p) { e.sx = p.xs; e.ox = p.xo; e.sy = p.ys; e.oy = p.yo; }
            if (safe(o, "Size") instanceof UDim2L p) { e.wsx = p.xs; e.wox = p.xo; e.wsy = p.ys; e.woy = p.yo; }
            if (safe(o, "BackgroundColor3") instanceof ColorL k) e.bg = hex(k.r << 16 | k.g << 8 | k.b);
            if (safe(o, "TextColor3") instanceof ColorL k) e.fg = hex(k.r << 16 | k.g << 8 | k.b);
            LuaValue v;
            if ((v = safe(o, "BackgroundTransparency")).isnumber()) e.bgT = v.todouble();
            if (c.equals("TextBox") && (v = safe(o, "PlaceholderText")).isstring() && !v.tojstring().isEmpty()) e.text = v.tojstring();
            else if ((v = safe(o, "Text")).isstring()) e.text = v.tojstring();
            if ((v = safe(o, "TextSize")).isnumber()) e.textSize = v.toint();
            if ((v = safe(o, "Image")).isstring()) e.image = v.tojstring();
            if ((v = safe(o, "ZIndex")).isnumber()) e.z = v.toint();
            if ((v = safe(o, "Visible")).isboolean()) e.visible = v.toboolean();
            out.add(e);
            walk(o, e.name, out, names, depth + 1);
        }
    }

    static LuaValue safe(LObj o, String k) {
        try { return o.get(k); } catch (Exception e) { return LuaValue.NIL; }
    }
}
