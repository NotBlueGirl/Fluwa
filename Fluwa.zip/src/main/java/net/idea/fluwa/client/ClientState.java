package net.idea.fluwa.client;

import java.util.*;

/** State pushed by the server for the local player. */
public final class ClientState {
    public static boolean asynced, frozen, freezeCam;
    public static int asyncTick = 20;
    public static float frozenYaw, frozenPitch;
    public static final Map<String, String> SKYBOX = new HashMap<>(); // dimension id -> file
    public static final Map<String, Boolean> HIDDEN_PARTS = new HashMap<>();
    public static final Deque<String> CONSOLE = new ArrayDeque<>();
    private ClientState() {}

    public static void reset() {
        asynced = frozen = freezeCam = false; asyncTick = 20; SKYBOX.clear(); HIDDEN_PARTS.clear();
    }
}
