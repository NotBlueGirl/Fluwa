package net.idea.fluwa.client.ui;

import net.idea.fluwa.lua.*;
import net.minecraft.client.gui.GuiGraphics;
import org.luaj.vm2.*;

/** ScrollingFrame: clipped canvas scrolled with the mouse wheel or by dragging. */
public class ScrollObj extends UiObj {
    public UDim2L canvas = new UDim2L(0, 0, 2, 0);
    public double cx, cy;
    public int thickness = 12, barColor = 0x000000;
    public double barTransparency;
    public boolean scrolling = true;
    public String elastic = "WhenScrollable", hInset = "None", vInset = "None", autoCanvas = "None";
    public LuaValue barImage = NIL;
    int cw, ch;

    public ScrollObj() { super("ScrollingFrame"); clips = true; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "CanvasSize": return canvas;
            case "CanvasPosition": return new Vec2L(cx, cy);
            case "ScrollBarThickness": return valueOf(thickness);
            case "ScrollBarImageColor3": return col(barColor);
            case "ScrollBarImageTransparency": return valueOf(barTransparency);
            case "ScrollingEnabled": return valueOf(scrolling);
            case "ElasticBehavior": return valueOf(elastic);
            case "HorizontalScrollBarInset": return valueOf(hInset);
            case "VerticalScrollBarInset": return valueOf(vInset);
            case "AutomaticCanvasSize": return valueOf(autoCanvas);
            case "AbsoluteCanvasSize": return new Vec2L(cw, ch);
            case "AbsoluteWindowSize": return new Vec2L(aw, ah);
            case "ScrollBarImage": case "TopImage": case "MidImage": case "BottomImage": return barImage;
        }
        return super.getProp(k);
    }
    @Override protected boolean setUi(String k, LuaValue v) {
        switch (k) {
            case "CanvasSize": canvas = UDim2L.check(v); return true;
            case "CanvasPosition": { Vec2L p = Vec2L.check(v); setPos(p.x, p.y); return true; }
            case "ScrollBarThickness": thickness = Math.max(0, v.checkint()); return true;
            case "ScrollBarImageColor3": barColor = ColorL.check(v); return true;
            case "ScrollBarImageTransparency": barTransparency = v.checkdouble(); return true;
            case "ScrollingEnabled": scrolling = v.toboolean(); return true;
            case "ElasticBehavior": elastic = en(v); return true;
            case "HorizontalScrollBarInset": hInset = en(v); return true;
            case "VerticalScrollBarInset": vInset = en(v); return true;
            case "AutomaticCanvasSize": autoCanvas = en(v); return true;
            case "ScrollBarImage": case "TopImage": case "MidImage": case "BottomImage": barImage = v; return true;
        }
        return super.setUi(k, v);
    }

    void setPos(double x, double y) {
        double nx = Math.max(0, Math.min(Math.max(0, cw - aw), x)), ny = Math.max(0, Math.min(Math.max(0, ch - ah), y));
        if (cw == 0 && ch == 0) { nx = Math.max(0, x); ny = Math.max(0, y); }
        if (nx != cx || ny != cy) { cx = nx; cy = ny; fire("E_CanvasPositionChanged", new Vec2L(cx, cy)); }
    }

    boolean scrollBy(double dy) {
        if (!scrolling) return false;
        double old = cy;
        setPos(cx, cy + dy);
        return old != cy || ch > ah;
    }
    void dragBy(double dy) { if (scrolling) setPos(cx, cy - dy); }

    @Override protected int[] childArea() {
        int[] c = content();
        cw = (int) Math.round(canvas.xs * c[2] + canvas.xo);
        ch = (int) Math.round(canvas.ys * c[3] + canvas.yo);
        if (!"None".equals(autoCanvas)) {
            int mx = 0, my = 0;
            UiMods.ListLayout ll = mod(UiMods.ListLayout.class);
            UiMods.GridLayout gl = mod(UiMods.GridLayout.class);
            if (ll != null) { int[] s = ll.contentSize(this); mx = s[0]; my = s[1]; }
            else if (gl != null) { mx = gl.lastSize[0]; my = gl.lastSize[1]; }
            else for (UiObj u : uiChildren()) { u.layout(0, 0, c[2], c[3]); mx = Math.max(mx, u.ax + u.aw); my = Math.max(my, u.ay + u.ah); }
            if (autoCanvas.contains("X")) cw = Math.max(cw, mx);
            if (autoCanvas.contains("Y")) ch = Math.max(ch, my);
        }
        cw = Math.max(cw, c[2]); ch = Math.max(ch, c[3]);
        cx = Math.max(0, Math.min(cx, cw - c[2])); cy = Math.max(0, Math.min(cy, ch - c[3]));
        boolean vBar = ch > c[3] && "ScrollBar".equals(vInset), hBar = cw > c[2] && "ScrollBar".equals(hInset);
        return new int[]{(int) (c[0] - cx), (int) (c[1] - cy), cw - (vBar ? thickness : 0), ch - (hBar ? thickness : 0)};
    }

    @Override protected void drawOver(GuiGraphics g, double ga) { bars(g, ga); }
    @Override protected void drawSelf(GuiGraphics g, int mx, int my, double ga) { super.drawSelf(g, mx, my, ga); if (uiChildren().isEmpty()) bars(g, ga); }

    void bars(GuiGraphics g, double ga) {
        if (thickness <= 0) return;
        int col = argb(barColor == 0 ? 0x808080 : barColor, barTransparency, ga * 0.85);
        if (ch > ah && ah > 0) {
            int len = Math.max(10, ah * ah / ch), pos = (int) ((ah - len) * (cy / Math.max(1, ch - ah)));
            g.fill(ax + aw - thickness, ay + pos, ax + aw, ay + pos + len, col);
        }
        if (cw > aw && aw > 0) {
            int len = Math.max(10, aw * aw / cw), pos = (int) ((aw - len) * (cx / Math.max(1, cw - aw)));
            g.fill(ax + pos, ay + ah - thickness, ax + pos + len, ay + ah, col);
        }
    }

    @Override protected void copyTo(UiObj c) {
        super.copyTo(c);
        if (c instanceof ScrollObj s) { s.canvas = canvas; s.thickness = thickness; s.barColor = barColor; s.barTransparency = barTransparency;
            s.scrolling = scrolling; s.elastic = elastic; s.autoCanvas = autoCanvas; s.hInset = hInset; s.vInset = vInset; }
    }

    static {
        reg(ScrollObj.class, "SetCanvasSize", (s, a) -> set(s, "CanvasSize", a.arg1()));
        reg(ScrollObj.class, "SetScrollBarThickness", (s, a) -> set(s, "ScrollBarThickness", a.arg1()));
        reg(ScrollObj.class, "SetScrollBarImage", (s, a) -> set(s, "ScrollBarImage", a.arg1()));
        reg(ScrollObj.class, "SetScrollingEnabled", (s, a) -> set(s, "ScrollingEnabled", a.arg1()));
        reg(ScrollObj.class, "ScrollToTop", (s, a) -> { ScrollObj o = (ScrollObj) s; o.setPos(o.cx, 0); return NONE; });
        reg(ScrollObj.class, "ScrollToBottom", (s, a) -> { ScrollObj o = (ScrollObj) s; o.setPos(o.cx, Math.max(0, o.ch - o.ah)); if (o.ch == 0) o.cy = 1e9; return NONE; });
    }
}
