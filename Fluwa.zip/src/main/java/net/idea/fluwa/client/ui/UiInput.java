package net.idea.fluwa.client.ui;

import net.idea.fluwa.lua.LObj;

/** Mouse press / selection / keyboard focus state shared by ScreenGUIs and overlays. */
public final class UiInput {
    private UiInput() {}
    static UiObj pressed, pressed2, selection;
    public static TextBoxObj focus;

    static void select(UiObj o) {
        if (selection == o) return;
        if (selection != null && !selection.isDestroyed()) selection.fire("E_SelectionLost");
        selection = o;
        if (o != null) o.fire("E_SelectionGained");
    }

    /** root = ScreenGUI / Overlay; returns true when consumed */
    public static boolean down(ScreenGuiObj root, double mx, double my, int button) {
        UiObj hit = null;
        var ch = root.uiChildren();
        for (int i = ch.size() - 1; i >= 0 && hit == null; i--) hit = ch.get(i).pick(mx, my);
        if (focus != null && focus != hit) focus.release(false);
        if (hit == null) return false;
        if (button == 0) pressed = hit; else pressed2 = hit;
        hit.mouseDown(mx, my, button);
        if (hit instanceof TextBoxObj tb && button == 0) tb.capture();
        return true;
    }

    public static boolean up(double mx, double my, int button) {
        UiObj p = button == 0 ? pressed : pressed2;
        if (button == 0) pressed = null; else pressed2 = null;
        if (p == null || p.isDestroyed()) return false;
        p.mouseUp(mx, my, button, p.inside(mx, my));
        return true;
    }

    public static boolean drag(double mx, double my, double dx, double dy) {
        if (pressed == null || pressed.isDestroyed()) return false;
        if (pressed instanceof ScrollObj s) s.dragBy(dy);
        pressed.drag(mx, my, dx, dy);
        return true;
    }

    public static boolean scroll(ScreenGuiObj root, double mx, double my, double d) {
        var ch = root.uiChildren();
        for (int i = ch.size() - 1; i >= 0; i--) {
            UiObj u = ch.get(i).pick(mx, my);
            for (LObj x = u; x instanceof UiObj o; x = x.getParentObj()) {
                o.scroll(mx, my, d);
                if (o instanceof ScrollObj s && s.scrollBy(-d * 20)) return true;
            }
            if (u != null) return true;
        }
        return false;
    }

    public static void reset() { pressed = pressed2 = selection = null; focus = null; }
}
