package net.idea.fluwa.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.mesh.Mesh;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderNameTagEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

/**
 * Client side of Entity/Player:SetModel - renders a 3D mesh (.obj/.gltf/.glb/.fbx, sent pre-parsed by the server)
 * or another entity instead of any living entity. Also applies server-side hidden parts and entity flags.
 */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientModels {
    private ClientModels() {}

    static final class M {
        String kind, entity, desc; float scale = 1;
        MeshRender mesh;
        Entity ent; double lx, lz;
    }
    static final Map<UUID, M> MODELS = new HashMap<>();
    /** server-driven hidden parts per entity uuid */
    public static final Map<UUID, Set<String>> HIDDEN = new HashMap<>();
    /** server flags per entity uuid ("hidename", ...) */
    public static final Map<UUID, Set<String>> FLAGS = new HashMap<>();
    public static final String[] HUMANOID_PARTS = {"Head", "Hat", "Body", "RightArm", "LeftArm", "RightLeg", "LeftLeg"};

    public static void set(UUID id, Pkt p) {
        remove(id);
        String kind = p.s(1);
        if (kind.isEmpty()) return;
        M m = new M();
        m.kind = kind; m.entity = p.s(2); m.desc = p.s(4).isEmpty() ? (kind.equals("entity") ? p.s(2) : "mesh") : p.s(4);
        try { m.scale = Float.parseFloat(p.s(3)); } catch (Exception ignored) {}
        if (kind.equals("mesh")) {
            try { m.mesh = new MeshRender(Mesh.fromBytes(p.data)); m.mesh.playing = !m.mesh.mesh.anims.isEmpty(); }
            catch (Exception e) { Fluwa.LOGGER.warn("Fluwa: bad model data: {}", e.toString()); return; }
            Set<String> h = HIDDEN.get(id);
            if (h != null) m.mesh.hidden.addAll(h);
            Map<String, float[]> x = XF.get(id);
            if (x != null) m.mesh.xf.putAll(x);
        }
        MODELS.put(id, m);
    }

    /** mesh currently used by an entity (or null) - used by client GetModel */
    public static Mesh mesh(UUID id) { M m = MODELS.get(id); return m == null || m.mesh == null ? null : m.mesh.mesh; }
    public static boolean hasModel(UUID id) { return MODELS.containsKey(id); }
    public static String desc(UUID id) { M m = MODELS.get(id); return m == null ? null : m.desc; }

    // ---------------------------------------------------------------- part transforms (offset, rotation°, scale)
    public static final Map<UUID, Map<String, float[]>> XF = new HashMap<>();
    /** substitute entities ("look like a zombie") -> owner uuid */
    static final Map<UUID, UUID> ALIAS = new HashMap<>();
    public static void setTransform(UUID id, String part, float[] xf) {
        boolean id0 = net.idea.fluwa.api.ModelSync.isIdentity(xf);
        if (id0) { Map<String, float[]> m = XF.get(id); if (m != null) { m.remove(part); if (m.isEmpty()) XF.remove(id); } }
        else XF.computeIfAbsent(id, k -> new HashMap<>()).put(part, xf.clone());
        M m = MODELS.get(id);
        if (m != null && m.mesh != null) { if (id0) m.mesh.xf.remove(part); else m.mesh.xf.put(part, xf.clone()); }
    }
    public static float[] transform(UUID id, String part) {
        Map<String, float[]> m = XF.get(id); float[] f = m == null ? null : m.get(part);
        return f == null ? net.idea.fluwa.api.ModelSync.IDENTITY_XF.clone() : f.clone();
    }
    static Map<String, float[]> xfOf(Entity e) {
        if (XF.isEmpty()) return null;
        UUID id = e.getUUID();
        Map<String, float[]> m = XF.get(id);
        if (m == null) { UUID o = ALIAS.get(id); if (o != null) m = XF.get(o); }
        return m;
    }
    /** whole-model transform ("Model" part): pose already pushed by the mixin */
    public static void applyWhole(LivingEntity e, PoseStack ps) {
        Map<String, float[]> m = XF.isEmpty() ? null : XF.get(e.getUUID()); // not via ALIAS: the owner's pose already contains it
        float[] f = m == null ? null : m.get("Model");
        if (f == null) return;
        ps.translate(f[0], f[1], f[2]);
        float h = e.getBbHeight() / 2;
        ps.translate(0, h, 0);
        ps.mulPose(Axis.YP.rotationDegrees(f[4])); ps.mulPose(Axis.XP.rotationDegrees(f[3])); ps.mulPose(Axis.ZP.rotationDegrees(f[5]));
        ps.scale(f[6], f[7], f[8]);
        ps.translate(0, -h, 0);
    }
    static final List<Object[]> PART_RESTORE = new ArrayList<>();
    /** humanoid part transforms, applied after setupAnim and restored after drawing */
    public static void applyParts(LivingEntity e, net.minecraft.client.model.EntityModel<?> model) {
        PART_RESTORE.clear();
        Map<String, float[]> m = xfOf(e);
        Set<String> hid = hiddenOf(e);
        if (m == null && hid == null) return;
        if (m != null) for (var en : m.entrySet()) {
            if (en.getKey().equals("Model")) continue;
            float[] f = en.getValue();
            for (net.minecraft.client.model.geom.ModelPart p : partsNamed(model, en.getKey())) {
                PART_RESTORE.add(new Object[]{p, p.storePose(), new float[]{p.xScale, p.yScale, p.zScale}, p.visible});
                // model space: x and y are mirrored, 16 units per block
                p.x -= f[0] * 16; p.y -= f[1] * 16; p.z += f[2] * 16;
                p.xRot += (float) Math.toRadians(f[3]); p.yRot -= (float) Math.toRadians(f[4]); p.zRot -= (float) Math.toRadians(f[5]);
                p.xScale *= f[6]; p.yScale *= f[7]; p.zScale *= f[8];
            }
        }
        if (hid != null) for (String h : hid) {
            if (h.equals("Model")) continue;
            for (net.minecraft.client.model.geom.ModelPart p : partsNamed(model, h)) {
                PART_RESTORE.add(new Object[]{p, p.storePose(), new float[]{p.xScale, p.yScale, p.zScale}, p.visible});
                p.visible = false;
            }
        }
    }
    /** a named part of any entity model (humanoid names also move the outer layer: Head+Hat, Body+Jacket, ...) */
    static List<net.minecraft.client.model.geom.ModelPart> partsNamed(net.minecraft.client.model.EntityModel<?> model, String n) {
        if (model instanceof HumanoidModel<?> hm) { var l = humanoidParts(hm, n); if (!l.isEmpty()) return l; }
        var p = ModelParts.of(model).get(n);
        return p == null ? List.of() : List.of(p);
    }
    static Set<String> hiddenOf(Entity e) {
        if (HIDDEN.isEmpty()) return null;
        UUID id = e.getUUID();
        Set<String> s = HIDDEN.get(id);
        if (s == null) { UUID o = ALIAS.get(id); if (o != null) s = HIDDEN.get(o); }
        return s == null || s.isEmpty() ? null : s;
    }
    public static void restoreParts() {
        if (PART_RESTORE.isEmpty()) return;
        for (int i = PART_RESTORE.size() - 1; i >= 0; i--) {
            Object[] r = PART_RESTORE.get(i);
            var p = (net.minecraft.client.model.geom.ModelPart) r[0];
            p.loadPose((net.minecraft.client.model.geom.PartPose) r[1]);
            float[] sc = (float[]) r[2]; p.xScale = sc[0]; p.yScale = sc[1]; p.zScale = sc[2];
            p.visible = (Boolean) r[3];
        }
        PART_RESTORE.clear();
    }
    static List<net.minecraft.client.model.geom.ModelPart> humanoidParts(HumanoidModel<?> m, String n) {
        List<net.minecraft.client.model.geom.ModelPart> l = new ArrayList<>();
        PlayerModel<?> pm = m instanceof PlayerModel<?> x ? x : null;
        switch (n) {
            case "Head" -> { l.add(m.head); l.add(m.hat); }
            case "Hat" -> l.add(m.hat);
            case "Body" -> { l.add(m.body); if (pm != null) l.add(pm.jacket); }
            case "RightArm" -> { l.add(m.rightArm); if (pm != null) l.add(pm.rightSleeve); }
            case "LeftArm" -> { l.add(m.leftArm); if (pm != null) l.add(pm.leftSleeve); }
            case "RightLeg" -> { l.add(m.rightLeg); if (pm != null) l.add(pm.rightPants); }
            case "LeftLeg" -> { l.add(m.leftLeg); if (pm != null) l.add(pm.leftPants); }
        }
        return l;
    }

    public static void setHidden(UUID id, String part, boolean hidden) {
        Set<String> s = HIDDEN.computeIfAbsent(id, k -> new HashSet<>());
        if (hidden) s.add(part); else s.remove(part);
        M m = MODELS.get(id);
        if (m != null && m.mesh != null) { if (hidden) m.mesh.hidden.add(part); else m.mesh.hidden.remove(part); }
    }
    public static boolean hidden(UUID id, String part) { Set<String> s = HIDDEN.get(id); return s != null && s.contains(part); }

    /** S_ENTFLAG: s = {uuid, flag}, n = {0/1} */
    public static void entityFlag(Pkt p) {
        UUID id = UUID.fromString(p.s(0));
        Set<String> s = FLAGS.computeIfAbsent(id, k -> new HashSet<>());
        if (p.n(0) != 0) s.add(p.s(1)); else s.remove(p.s(1));
    }
    public static boolean flag(UUID id, String f) { Set<String> s = FLAGS.get(id); return s != null && s.contains(f); }

    static void remove(UUID id) {
        M old = MODELS.remove(id);
        if (old != null && old.ent != null) ALIAS.remove(old.ent.getUUID());
        if (old != null && old.mesh != null) old.mesh.release();
    }

    public static void clear() { for (UUID id : new ArrayList<>(MODELS.keySet())) remove(id); HIDDEN.clear(); FLAGS.clear(); XF.clear(); ALIAS.clear(); }

    @SubscribeEvent
    public static void nameTag(RenderNameTagEvent e) {
        if (!FLAGS.isEmpty() && flag(e.getEntity().getUUID(), "hidename")) e.setResult(Event.Result.DENY);
    }

    static final List<boolean[]> RESTORE = new ArrayList<>();

    @SubscribeEvent
    public static void render(RenderLivingEvent.Pre<?, ?> e) {
        LivingEntity pl = e.getEntity();
        UUID uuid = pl.getUUID();
        if (FLAGS.containsKey(uuid) && flag(uuid, "invisible")) { e.setCanceled(true); return; }
        M m = MODELS.isEmpty() ? null : MODELS.get(uuid);
        if (m == null) {
            Set<String> h = HIDDEN.get(uuid);
            if (h != null && h.contains("Model")) { e.setCanceled(true); return; }
            if (h != null && !h.isEmpty() && e.getRenderer().getModel() instanceof HumanoidModel<?> hm) applyHidden(hm, h);
            return;
        }
        e.setCanceled(true);
        Set<String> hh = HIDDEN.get(uuid);
        if (hh != null && hh.contains("Model")) return;
        float pt = e.getPartialTick();
        PoseStack ps = e.getPoseStack();
        if (m.kind.equals("entity")) {
            if (m.ent == null || m.ent.level() != pl.level()) {
                m.ent = EntityType.byString(m.entity).map(t -> t.create(pl.level())).orElse(null);
                if (m.ent == null) return;
                ALIAS.put(m.ent.getUUID(), uuid);
            }
            Entity en = m.ent;
            en.setPos(pl.getX(), pl.getY(), pl.getZ());
            en.xo = pl.xo; en.yo = pl.yo; en.zo = pl.zo;
            en.setYRot(pl.getYRot()); en.yRotO = pl.yRotO; en.setXRot(pl.getXRot()); en.xRotO = pl.xRotO;
            en.setOnGround(pl.onGround());
            if (en instanceof LivingEntity le) {
                le.yBodyRot = pl.yBodyRot; le.yBodyRotO = pl.yBodyRotO; le.yHeadRot = pl.yHeadRot; le.yHeadRotO = pl.yHeadRotO;
            }
            ps.pushPose();
            if (m.scale != 1) ps.scale(m.scale, m.scale, m.scale);
            Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(en)
                    .render(en, Mth.lerp(pt, pl.yRotO, pl.getYRot()), pt, ps, e.getMultiBufferSource(), e.getPackedLight());
            ps.popPose();
            return;
        }
        if (m.mesh == null) return;
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180f - Mth.rotLerp(pt, pl.yBodyRotO, pl.yBodyRot)));
        ps.scale(m.scale, m.scale, m.scale);
        m.mesh.draw(ps, e.getMultiBufferSource(), e.getPackedLight());
        ps.popPose();
    }

    @SubscribeEvent
    public static void renderPost(RenderLivingEvent.Post<?, ?> e) {
        if (HIDDEN.isEmpty()) return;
        Set<String> h = HIDDEN.get(e.getEntity().getUUID());
        if (h != null && !h.isEmpty() && e.getRenderer().getModel() instanceof HumanoidModel<?> hm) {
            hm.head.visible = hm.hat.visible = hm.body.visible = hm.rightArm.visible = hm.leftArm.visible = hm.rightLeg.visible = hm.leftLeg.visible = true;
            if (hm instanceof PlayerModel<?> p) p.jacket.visible = p.leftSleeve.visible = p.rightSleeve.visible = p.leftPants.visible = p.rightPants.visible = true;
        }
    }

    static void applyHidden(HumanoidModel<?> m, Set<String> h) {
        if (h.contains("Head")) m.head.visible = false;
        if (h.contains("Hat") || h.contains("Head")) m.hat.visible = false;
        if (h.contains("Body")) m.body.visible = false;
        if (h.contains("RightArm")) m.rightArm.visible = false;
        if (h.contains("LeftArm")) m.leftArm.visible = false;
        if (h.contains("RightLeg")) m.rightLeg.visible = false;
        if (h.contains("LeftLeg")) m.leftLeg.visible = false;
        if (m instanceof PlayerModel<?> p) {
            if (h.contains("Body")) p.jacket.visible = false;
            if (h.contains("RightArm")) p.rightSleeve.visible = false;
            if (h.contains("LeftArm")) p.leftSleeve.visible = false;
            if (h.contains("RightLeg")) p.rightPants.visible = false;
            if (h.contains("LeftLeg")) p.leftPants.visible = false;
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        LocalAudio.tick();
        ClientProjector.tick();
        var level = Minecraft.getInstance().level;
        if (level == null || MODELS.isEmpty()) return;
        Map<UUID, Entity> byId = new HashMap<>();
        for (Entity en : level.entitiesForRendering()) if (MODELS.containsKey(en.getUUID())) byId.put(en.getUUID(), en);
        for (var en : MODELS.entrySet()) {
            M m = en.getValue();
            if (!(m.ent instanceof LivingEntity le)) continue;
            Entity pl = byId.get(en.getKey());
            if (pl == null) continue;
            double dx = pl.getX() - m.lx, dz = pl.getZ() - m.lz;
            m.lx = pl.getX(); m.lz = pl.getZ();
            le.walkAnimation.update((float) Math.min(Math.sqrt(dx * dx + dz * dz) * 4, 1), 0.4f);
            le.tickCount++;
        }
    }
}
