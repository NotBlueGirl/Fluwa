package net.idea.fluwa.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.api.WorldTween;
import net.idea.fluwa.lua.Easing;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.ColorResolver;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.lighting.LevelLightEngine;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Client side of world tweens: animates every running tween at the client's frame rate.
 *  - entities: placed on the exact eased curve each tick (prev = now, current = now + 1 tick), so the normal
 *    render interpolation gives a perfectly smooth glide;
 *  - ghost tweens (blocks / chunks / structures): the lifted blocks are baked once into vertex buffers and
 *    drawn every frame at the eased offset.
 */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientTween {
    private ClientTween() {}

    static {
        WorldTween.LOCAL = p -> Minecraft.getInstance().execute(() -> handle(p));
        net.idea.fluwa.api.Colliders.SOURCES.add((level, who, box, out) -> {
            if (!(level instanceof ClientLevel cl) || ClientTween.ACTIVE.isEmpty()) return;
            long now = System.nanoTime();
            for (CT c : ClientTween.ACTIVE.values())
                if (c.ghost && c.collide && c.curOff != null && inDim(c, cl)) net.idea.fluwa.api.Colliders.group(c.blocks, c.curOff, box, out);
        });
    }

    static final class CT {
        int id; String dim; boolean ghost; int entityId;
        Vec3 from, to, fin; boolean rot; float y0, y1, p0, p1;
        String dir, style; long startNs; double durMs;
        boolean ended; long endNs;
        // ghost
        BlockPos origin; final Map<BlockPos, BlockState> blocks = new HashMap<>(); final Map<BlockPos, Integer> light = new HashMap<>();
        final Map<RenderType, VertexBuffer> vbs = new LinkedHashMap<>(); final List<BlockPos> animated = new ArrayList<>();
        boolean baked; BlockPos sample; boolean collide; Vec3 lastOff; Vec3 prevOff, curOff; long baseNs; int ticks;
        void close() { for (VertexBuffer v : vbs.values()) v.close(); vbs.clear(); }
    }

    static final Map<Integer, CT> ACTIVE = new ConcurrentHashMap<>();
    static ClientLevel lastLevel;

    // ================================================================ packets
    public static void handle(Pkt p) {
        try {
            if (p.s(0).equals("start")) start(p);
            else if (p.s(0).equals("end")) end(p);
        } catch (Exception e) { Fluwa.LOGGER.warn("Fluwa tween packet", e); }
    }

    static Vec3 vec(String s) {
        if (s == null || s.isEmpty()) return null;
        String[] a = s.split(",");
        return new Vec3(Double.parseDouble(a[0]), Double.parseDouble(a[1]), Double.parseDouble(a[2]));
    }

    static void start(Pkt p) throws Exception {
        CT c = new CT();
        c.id = Integer.parseInt(p.s(1)); c.dim = p.s(2); c.ghost = p.s(3).equals("g"); c.entityId = Integer.parseInt(p.s(4));
        c.durMs = Long.parseLong(p.s(5));
        c.startNs = System.nanoTime() - Long.parseLong(p.s(6)) * 1_000_000L;
        c.dir = p.s(7); c.style = p.s(8); c.from = vec(p.s(9)); c.to = vec(p.s(10));
        if (!p.s(11).isEmpty()) {
            String[] r = p.s(11).split(",");
            c.rot = true; c.y0 = Float.parseFloat(r[0]); c.y1 = Float.parseFloat(r[1]); c.p0 = Float.parseFloat(r[2]); c.p1 = Float.parseFloat(r[3]);
        }
        c.collide = p.s(13).equals("1");
        c.baseNs = System.nanoTime(); c.ticks = 0;
        if (c.ghost) {
            Vec3 o = vec(p.s(12));
            c.origin = o == null ? BlockPos.containing(c.from) : BlockPos.containing(o);
            CompoundTag t = NbtIo.readCompressed(new ByteArrayInputStream(p.data));
            ListTag pl = t.getList("pal", Tag.TAG_COMPOUND);
            BlockState[] pal = new BlockState[pl.size()];
            for (int i = 0; i < pal.length; i++) pal[i] = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), pl.getCompound(i));
            int[] b = t.getIntArray("b");
            for (int i = 0; i + 4 < b.length; i += 5) {
                BlockPos rel = new BlockPos(b[i], b[i + 1], b[i + 2]);
                c.blocks.put(rel, pal[b[i + 3]]);
                c.light.put(rel, b[i + 4]);
                if (c.sample == null) c.sample = rel;
            }
        }
        CT old = ACTIVE.put(c.id, c);
        if (old != null) old.close();
    }

    static void end(Pkt p) {
        CT c = ACTIVE.get(Integer.parseInt(p.s(1)));
        if (c == null) return;
        if (p.s(3).equals("1") || !c.ghost) { ACTIVE.remove(c.id); c.close(); return; }
        c.fin = vec(p.s(2));
        c.ended = true; c.endNs = System.nanoTime();
    }

    // ================================================================ curve
    static double eased(CT c, long ns) {
        double f = c.durMs <= 0 ? 1 : (ns - c.startNs) / 1e6 / c.durMs;
        if (f >= 1) return 1;
        if (f <= 0) return 0;
        return Easing.ease(f, c.dir, c.style);
    }
    static Vec3 pos(CT c, long ns) {
        if (c.ended && c.fin != null) return c.fin;
        double e = eased(c, ns);
        return c.from.add(c.to.subtract(c.from).scale(e));
    }

    static boolean inDim(CT c, ClientLevel lv) { return lv.dimension().location().toString().equals(c.dim); }

    // ================================================================ entities (every client tick)
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        ClientLevel lv = Minecraft.getInstance().level;
        if (lv != lastLevel) { for (CT c : ACTIVE.values()) c.close(); ACTIVE.clear(); lastLevel = lv; }
        if (lv == null || ACTIVE.isEmpty()) return;
        long now = System.nanoTime();
        for (CT c : ACTIVE.values()) {
            if (!inDim(c, lv)) continue;
            if (c.ghost) {
                // physics runs on a fixed tick timeline: shape position, push/carry and drawing all use the same values
                if (e.phase == TickEvent.Phase.START && c.collide) {
                    Vec3 next = pos(c, c.baseNs + (long) c.ticks * 50_000_000L);
                    c.ticks++;
                    c.prevOff = c.curOff == null ? next : c.curOff;
                    c.curOff = next;
                    var pl = Minecraft.getInstance().player;
                    if (pl != null && pl.level() == lv) net.idea.fluwa.api.Colliders.pushCarry(pl, c.blocks, c.prevOff, c.curOff);
                }
                if (e.phase == TickEvent.Phase.END && c.ended && ghostLanded(c, lv, now)) { ACTIVE.remove(c.id); c.close(); }
                continue;
            }
            Entity en = lv.getEntity(c.entityId);
            if (en == null) continue;
            en.setDeltaMovement(Vec3.ZERO);
            en.fallDistance = 0;
            if (e.phase != TickEvent.Phase.END) continue;
            Vec3 a = pos(c, now), b = pos(c, now + 50_000_000L);
            en.xo = en.xOld = a.x; en.yo = en.yOld = a.y; en.zo = en.zOld = a.z;
            en.setPos(b.x, b.y, b.z);
            if (c.rot) {
                double ea = eased(c, now), eb = eased(c, now + 50_000_000L);
                float ya = (float) (c.y0 + (c.y1 - c.y0) * ea), yb = (float) (c.y0 + (c.y1 - c.y0) * eb);
                float pa = (float) (c.p0 + (c.p1 - c.p0) * ea), pb = (float) (c.p0 + (c.p1 - c.p0) * eb);
                en.yRotO = ya; en.setYRot(yb); en.xRotO = pa; en.setXRot(pb);
                if (en instanceof LivingEntity le) { le.yHeadRotO = ya; le.yHeadRot = yb; le.yBodyRotO = ya; le.yBodyRot = yb; }
            }
        }
    }

    /** the local player rides a moving collidable group it stands on */
    static void carryPlayer(CT c, long now) {
        Vec3 off = pos(c, now), prev = c.lastOff;
        c.lastOff = off;
        var pl = Minecraft.getInstance().player;
        if (prev == null || pl == null) return;
        Vec3 d = off.subtract(prev);
        if (d.lengthSqr() < 1e-10) return;
        if (net.idea.fluwa.api.Colliders.standsOn(c.blocks, prev, pl)) pl.setPos(pl.getX() + d.x, pl.getY() + d.y, pl.getZ() + d.z);
    }

    /** ghost stays at the goal until the real blocks arrived (no one-frame hole), max 1.5 s */
    static boolean ghostLanded(CT c, ClientLevel lv, long now) {
        if (now - c.endNs > 1_500_000_000L || c.fin == null || c.sample == null) return true;
        BlockPos w = BlockPos.containing(c.fin).offset(c.sample);
        return lv.getBlockState(w) == c.blocks.get(c.sample) && now - c.endNs > 100_000_000L;
    }

    // ================================================================ ghost rendering
    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        RenderLevelStageEvent.Stage st = e.getStage();
        boolean opaque = st == RenderLevelStageEvent.Stage.AFTER_CUTOUT_BLOCKS;
        boolean translucent = st == RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS;
        boolean entities = st == RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES;
        if (!opaque && !translucent && !entities) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel lv = mc.level;
        if (lv == null || ACTIVE.isEmpty()) return;
        long now = System.nanoTime();
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        for (CT c : ACTIVE.values()) {
            if (!c.ghost || !inDim(c, lv) || c.blocks.isEmpty()) continue;
            try {
                if (!c.baked) bake(c, lv);
                Vec3 at = c.collide && c.curOff != null ? c.prevOff.lerp(c.curOff, e.getPartialTick()) : pos(c, now);
                ps.pushPose();
                ps.translate(at.x - cam.x, at.y - cam.y, at.z - cam.z);
                if (entities) drawAnimated(c, ps, mc);
                else for (var en : c.vbs.entrySet()) {
                    boolean tr = en.getKey() == RenderType.translucent();
                    if (tr == translucent) draw(en.getKey(), en.getValue(), ps, e);
                }
                ps.popPose();
            } catch (RuntimeException ex) {
                Fluwa.LOGGER.debug("tween ghost", ex);
                c.blocks.clear(); c.close();
            }
        }
    }

    static void draw(RenderType type, VertexBuffer vb, PoseStack ps, RenderLevelStageEvent e) {
        type.setupRenderState();
        ShaderInstance sh = RenderSystem.getShader();
        if (sh != null) {
            if (sh.CHUNK_OFFSET != null) sh.CHUNK_OFFSET.set(0f, 0f, 0f);
            vb.bind();
            vb.drawWithShader(ps.last().pose(), e.getProjectionMatrix(), sh);
            VertexBuffer.unbind();
        }
        type.clearRenderState();
    }

    /** chests, signs-with-models etc. (block-entity rendered shapes) are drawn per frame */
    static void drawAnimated(CT c, PoseStack ps, Minecraft mc) {
        if (c.animated.isEmpty()) return;
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        BlockRenderDispatcher brd = mc.getBlockRenderer();
        for (BlockPos rel : c.animated) {
            ps.pushPose();
            ps.translate(rel.getX(), rel.getY(), rel.getZ());
            int l = c.light.getOrDefault(rel, 0xF0);
            brd.renderSingleBlock(c.blocks.get(rel), ps, bs, LightTexture.pack(l & 15, l >> 4 & 15), OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }
        bs.endBatch();
    }

    static void bake(CT c, ClientLevel lv) {
        c.baked = true;
        Minecraft mc = Minecraft.getInstance();
        BlockRenderDispatcher brd = mc.getBlockRenderer();
        Getter g = new Getter(c, lv);
        Map<RenderType, List<BlockPos>> byType = new LinkedHashMap<>();
        for (var en : c.blocks.entrySet()) {
            BlockState s = en.getValue();
            if (s.getRenderShape() == RenderShape.ENTITYBLOCK_ANIMATED) { c.animated.add(en.getKey()); continue; }
            if (s.getRenderShape() != RenderShape.MODEL) continue;
            RandomSource r = RandomSource.create(42);
            for (RenderType t : brd.getBlockModel(s).getRenderTypes(s, r, ModelData.EMPTY))
                byType.computeIfAbsent(t, k -> new ArrayList<>()).add(en.getKey());
        }
        BufferBuilder b = Tesselator.getInstance().getBuilder();
        PoseStack ps = new PoseStack();
        RandomSource rnd = RandomSource.create();
        for (var en : byType.entrySet()) {
            b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.BLOCK);
            for (BlockPos rel : en.getValue()) {
                ps.pushPose();
                ps.translate(rel.getX(), rel.getY(), rel.getZ());
                brd.renderBatched(c.blocks.get(rel), rel, g, ps, b, true, rnd, ModelData.EMPTY, en.getKey());
                ps.popPose();
            }
            BufferBuilder.RenderedBuffer rb = b.end();
            if (rb.isEmpty()) { rb.release(); continue; }
            VertexBuffer vb = new VertexBuffer(VertexBuffer.Usage.STATIC);
            vb.bind();
            vb.upload(rb);
            VertexBuffer.unbind();
            c.vbs.put(en.getKey(), vb);
        }
    }

    /** a tiny world that only contains the ghost blocks (inner faces get culled, light comes from the server) */
    static final class Getter implements BlockAndTintGetter {
        final CT c; final ClientLevel lv;
        Getter(CT c, ClientLevel lv) { this.c = c; this.lv = lv; }
        int light(BlockPos p) {
            Integer v = c.light.get(p);
            if (v != null) return v;
            int sky = -1, blk = 0;
            for (Direction d : Direction.values()) {
                Integer n = c.light.get(p.relative(d));
                if (n != null) { sky = Math.max(sky, n >> 4 & 15); blk = Math.max(blk, n & 15); }
            }
            return sky < 0 ? 0xF0 : sky << 4 | blk;
        }
        @Override public float getShade(Direction d, boolean shade) { return lv.getShade(d, shade); }
        @Override public LevelLightEngine getLightEngine() { return lv.getLightEngine(); }
        @Override public int getBlockTint(BlockPos p, ColorResolver r) { return lv.getBlockTint(c.origin.offset(p), r); }
        @Override public int getBrightness(LightLayer layer, BlockPos p) { int v = light(p); return layer == LightLayer.SKY ? v >> 4 & 15 : v & 15; }
        @Override public int getRawBrightness(BlockPos p, int dark) { int v = light(p); return Math.max((v >> 4 & 15) - dark, v & 15); }
        @Override public boolean canSeeSky(BlockPos p) { return (light(p) >> 4 & 15) >= 15; }
        @Override public BlockEntity getBlockEntity(BlockPos p) { return null; }
        @Override public BlockState getBlockState(BlockPos p) { BlockState s = c.blocks.get(p); return s == null ? Blocks.AIR.defaultBlockState() : s; }
        @Override public FluidState getFluidState(BlockPos p) { return getBlockState(p).getFluidState(); }
        @Override public int getHeight() { return 1 << 20; }
        @Override public int getMinBuildHeight() { return -(1 << 19); }
    }
}
