package net.idea.fluwa.client.ui;

import com.mojang.blaze3d.platform.NativeImage;
import net.idea.fluwa.lua.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import org.luaj.vm2.*;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * VideoFrame. Video = file/folder inside .minecraft/fluwa/videos:
 *   folder of .png/.jpg frames, animated .gif, or any video file (.mp4/.webm/.mkv/...) when ffmpeg is installed (decoded to frames).
 * Audio tracks are not played.
 */
public class VideoObj extends UiObj {
    public String video = "";
    public boolean vPlaying, vLoop, loaded;
    public double timePos, volume = 0.5, speed = 1, vfps = 20;
    final List<NativeImage> frames = Collections.synchronizedList(new ArrayList<>());
    List<Double> delays;   // gif per-frame delays (seconds)
    DynamicTexture tex; ResourceLocation texId; int shown = -1;
    long last; int loadGen;

    public VideoObj() { super("VideoFrame"); bg = 0x000000; }

    double duration() {
        if (delays != null) { double d = 0; for (double x : delays) d += x; return d; }
        return frames.size() / vfps;
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Video": return valueOf(video);
            case "Playing": return valueOf(vPlaying);
            case "TimePosition": return valueOf(timePos);
            case "Duration": case "TimeLength": return valueOf(duration());
            case "Volume": return valueOf(volume);
            case "Loop": case "Looped": return valueOf(vLoop);
            case "PlaybackSpeed": return valueOf(speed);
            case "IsLoaded": case "Loaded": return valueOf(loaded);
            case "FrameRate": return valueOf(vfps);
            case "Resolution": return frames.isEmpty() ? new Vec2L(0, 0) : new Vec2L(frames.get(0).getWidth(), frames.get(0).getHeight());
        }
        return super.getProp(k);
    }
    @Override protected boolean setUi(String k, LuaValue v) {
        switch (k) {
            case "Video": load(v.tojstring()); return true;
            case "Volume": volume = Math.max(0, Math.min(10, v.checkdouble())); return true;
            case "Loop": case "Looped": vLoop = v.toboolean(); return true;
            case "PlaybackSpeed": speed = v.checkdouble(); return true;
            case "FrameRate": vfps = Math.max(1, v.checkdouble()); return true;
            case "Playing": if (v.toboolean()) play(); else pause(); return true;
            case "TimePosition": timePos = Math.max(0, v.checkdouble()); return true;
        }
        return super.setUi(k, v);
    }

    void play() { if (!vPlaying) { vPlaying = true; last = System.nanoTime(); fire("E_Play"); } }
    void pause() { if (vPlaying) { vPlaying = false; fire("E_Pause"); } }

    static Path root() { return Minecraft.getInstance().gameDirectory.toPath().resolve("fluwa").resolve("videos").toAbsolutePath().normalize(); }

    void release() {
        synchronized (frames) { for (NativeImage n : frames) n.close(); frames.clear(); }
        if (texId != null) Minecraft.getInstance().getTextureManager().release(texId);
        tex = null; texId = null; shown = -1; loaded = false; delays = null;
    }

    void load(String path) {
        release();
        video = path; timePos = 0;
        if (path.isEmpty()) return;
        Path p = root().resolve(path).normalize();
        if (!p.startsWith(root())) { fire("E_Error", valueOf("Video path must stay inside .minecraft/fluwa/videos")); return; }
        int gen = ++loadGen;
        FluwaRuntime r = rt;
        Thread t = new Thread(() -> {
            String err = null; List<NativeImage> out = new ArrayList<>(); List<Double> dl = null;
            try {
                if (!Files.exists(p)) throw new IOException("Video not found: " + p);
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                if (Files.isDirectory(p)) readFolder(p, out);
                else if (n.endsWith(".gif")) dl = readGif(p, out);
                else if (n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg")) out.add(read(Files.readAllBytes(p)));
                else readFfmpeg(p, out);
                if (out.isEmpty()) throw new IOException("No frames in " + path);
            } catch (Exception e) { err = e.getMessage() == null ? e.toString() : e.getMessage(); for (NativeImage x : out) x.close(); out.clear(); }
            String fe = err; List<Double> fdl = dl;
            Minecraft.getInstance().execute(() -> {
                if (gen != loadGen || destroyed) { for (NativeImage x : out) x.close(); return; }
                if (fe != null) { if (r != null) r.within(() -> { fire("E_Error", valueOf(fe)); return null; }); return; }
                frames.addAll(out); delays = fdl; loaded = true;
                if (r != null) r.within(() -> { fire("E_Loaded"); return null; });
            });
        }, "Fluwa video loader");
        t.setDaemon(true); t.start();
    }

    static NativeImage read(byte[] b) throws IOException { return downscale(NativeImage.read(b)); }
    static NativeImage downscale(NativeImage n) {
        if (n.getWidth() <= 640) return n;
        int w = 640, h = Math.max(1, n.getHeight() * 640 / n.getWidth());
        NativeImage s = new NativeImage(w, h, false);
        n.resizeSubRectTo(0, 0, n.getWidth(), n.getHeight(), s);
        n.close();
        return s;
    }

    static void readFolder(Path dir, List<NativeImage> out) throws IOException {
        List<Path> files = new ArrayList<>();
        try (var s = Files.list(dir)) { s.filter(f -> f.toString().toLowerCase(Locale.ROOT).matches(".*\\.(png|jpg|jpeg)$")).forEach(files::add); }
        files.sort(Comparator.comparing(Path::toString));
        for (Path f : files) { if (out.size() >= 1500) break; out.add(read(Files.readAllBytes(f))); }
    }

    static List<Double> readGif(Path p, List<NativeImage> out) throws IOException {
        List<Double> delays = new ArrayList<>();
        try (var in = ImageIO.createImageInputStream(p.toFile())) {
            ImageReader rd = ImageIO.getImageReadersByFormatName("gif").next();
            rd.setInput(in);
            int n = rd.getNumImages(true);
            BufferedImage canvas = null;
            for (int i = 0; i < n && i < 1500; i++) {
                BufferedImage fr = rd.read(i);
                IIOMetadata md = rd.getImageMetadata(i);
                int x = 0, y = 0; double delay = 0.1; String disposal = "none";
                try {
                    var root = (javax.imageio.metadata.IIOMetadataNode) md.getAsTree("javax_imageio_gif_image_1.0");
                    var desc = (javax.imageio.metadata.IIOMetadataNode) root.getElementsByTagName("ImageDescriptor").item(0);
                    x = Integer.parseInt(desc.getAttribute("imageLeftPosition")); y = Integer.parseInt(desc.getAttribute("imageTopPosition"));
                    var gce = (javax.imageio.metadata.IIOMetadataNode) root.getElementsByTagName("GraphicControlExtension").item(0);
                    if (gce != null) { delay = Math.max(0.02, Integer.parseInt(gce.getAttribute("delayTime")) / 100.0); disposal = gce.getAttribute("disposalMethod"); }
                } catch (Exception ignored) {}
                if (canvas == null) canvas = new BufferedImage(Math.max(fr.getWidth() + x, rd.getWidth(0)), Math.max(fr.getHeight() + y, rd.getHeight(0)), BufferedImage.TYPE_INT_ARGB);
                var g = canvas.createGraphics(); g.drawImage(fr, x, y, null); g.dispose();
                out.add(downscale(toNative(canvas)));
                delays.add(delay);
                if ("restoreToBackgroundColor".equals(disposal)) { var g2 = canvas.createGraphics(); g2.setComposite(java.awt.AlphaComposite.Clear); g2.fillRect(x, y, fr.getWidth(), fr.getHeight()); g2.dispose(); }
            }
        }
        return delays;
    }

    static NativeImage toNative(BufferedImage b) {
        NativeImage n = new NativeImage(b.getWidth(), b.getHeight(), false);
        for (int y = 0; y < b.getHeight(); y++) for (int x = 0; x < b.getWidth(); x++) {
            int c = b.getRGB(x, y);
            n.setPixelRGBA(x, y, (c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF));
        }
        return n;
    }

    static void readFfmpeg(Path p, List<NativeImage> out) throws IOException, InterruptedException {
        Path tmp = Files.createTempDirectory("fluwa_video");
        try {
            ProcessBuilder pb = new ProcessBuilder("ffmpeg", "-loglevel", "error", "-i", p.toString(), "-vf", "fps=20,scale='min(640,iw)':-2", "-frames:v", "1500", tmp.resolve("%05d.png").toString());
            pb.redirectErrorStream(true);
            Process pr;
            try { pr = pb.start(); } catch (IOException e) { throw new IOException("Unsupported video format (install ffmpeg to play " + p.getFileName() + ", or use .gif / a folder of .png frames)"); }
            String log = new String(pr.getInputStream().readAllBytes());
            if (!pr.waitFor(300, TimeUnit.SECONDS)) { pr.destroyForcibly(); throw new IOException("ffmpeg timeout"); }
            if (pr.exitValue() != 0) throw new IOException("ffmpeg failed: " + log.trim());
            readFolder(tmp, out);
        } finally {
            try (var s = Files.list(tmp)) { s.forEach(f -> { try { Files.delete(f); } catch (IOException ignored) {} }); }
            Files.deleteIfExists(tmp);
        }
    }

    int frameAt(double t) {
        if (frames.isEmpty()) return -1;
        if (delays != null) { double acc = 0; for (int i = 0; i < delays.size(); i++) { acc += delays.get(i); if (t < acc) return i; } return delays.size() - 1; }
        return Math.min(frames.size() - 1, (int) (t * vfps));
    }

    @Override protected void drawSelf(GuiGraphics g, int mx, int my, double ga) {
        super.drawSelf(g, mx, my, ga);
        if (!loaded || frames.isEmpty()) return;
        long now = System.nanoTime();
        if (vPlaying) {
            timePos += (now - last) / 1e9 * speed;
            double d = duration();
            if (timePos >= d) {
                if (vLoop) timePos = d > 0 ? timePos % d : 0;
                else { timePos = d; vPlaying = false; fire("E_Ended"); }
            }
        }
        last = now;
        int f = frameAt(timePos);
        if (f < 0) return;
        NativeImage img = frames.get(f);
        if (tex == null || tex.getPixels() == null || tex.getPixels().getWidth() != img.getWidth() || tex.getPixels().getHeight() != img.getHeight()) {
            if (texId != null) Minecraft.getInstance().getTextureManager().release(texId);
            tex = new DynamicTexture(img.getWidth(), img.getHeight(), false);
            texId = Minecraft.getInstance().getTextureManager().register("fluwa_video", tex);
            shown = -1;
        }
        if (f != shown) { tex.getPixels().copyFrom(img); tex.upload(); shown = f; }
        // keep aspect ratio (letterbox)
        double s = Math.min(aw / (double) img.getWidth(), ah / (double) img.getHeight());
        int w = (int) (img.getWidth() * s), h = (int) (img.getHeight() * s);
        float a = (float) Math.max(0, Math.min(1, (1 - imageTransparency) * ga));
        g.setColor((imageColor >> 16 & 255) / 255f, (imageColor >> 8 & 255) / 255f, (imageColor & 255) / 255f, a);
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        g.blit(texId, ax + (aw - w) / 2, ay + (ah - h) / 2, w, h, 0, 0, img.getWidth(), img.getHeight(), img.getWidth(), img.getHeight());
        g.setColor(1, 1, 1, 1);
    }

    @Override protected void onDestroy() { release(); }

    static {
        Class<VideoObj> C = VideoObj.class;
        reg(C, "Play", (s, a) -> { ((VideoObj) s).play(); return NONE; });
        reg(C, "Pause", (s, a) -> { ((VideoObj) s).pause(); return NONE; });
        reg(C, "Stop", (s, a) -> { VideoObj v = (VideoObj) s; v.pause(); v.timePos = 0; return NONE; });
        reg(C, "SetTime", (s, a) -> { ((VideoObj) s).timePos = Math.max(0, a.checkdouble(1)); return NONE; });
        reg(C, "SetVolume", (s, a) -> set(s, "Volume", a.arg1()));
        reg(C, "SetLoop", (s, a) -> set(s, "Loop", a.arg1()));
    }
}
