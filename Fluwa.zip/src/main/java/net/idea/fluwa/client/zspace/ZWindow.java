package net.idea.fluwa.client.zspace;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.Consumer;

import static net.idea.fluwa.client.zspace.ZUi.*;

/**
 * Base of the ZSpace tool windows (Terrain DK, Shader DK, GUI Maker, Options, About, Help):
 * floating, draggable, resizable; content is laid out in logical units and scaled with the window.
 */
public abstract class ZWindow extends Screen {
    public static final int TOPH = 20, STATH = 12, ROW = 13;
    static final Map<String, int[]> GEOM = new HashMap<>();

    protected final Screen parent;
    final String key;
    final int defW, defH;
    protected int wx, wy, ww, wh, sw, sh;
    protected float S = 1;
    boolean maxed;
    int dragMode; double dragX, dragY; int[] dragG;
    long openedAt = System.currentTimeMillis(), lastTopClick;

    public record Hit(int x1, int y1, int x2, int y2, Runnable r) {}
    protected final List<Hit> hits = new ArrayList<>();
    protected final Map<String, Float> hover = new HashMap<>();
    protected int lmx, lmy, lbtn;
    protected final Map<String, EditBox> boxes = new LinkedHashMap<>();
    final Map<String, String> boxValues = new HashMap<>();
    final Set<EditBox> placed = new HashSet<>();
    protected String status = ""; protected boolean statusOk = true; protected long statusT;

    protected ZWindow(String title, Screen parent, int defW, int defH) {
        super(Component.literal(title));
        this.parent = parent; this.key = title; this.defW = defW; this.defH = defH;
    }

    // ------------------------------------------------------------------ geometry
    @Override protected void init() {
        sw = width; sh = height;
        for (var e : boxes.entrySet()) boxValues.put(e.getKey(), e.getValue().getValue());
        boxes.clear();
        int[] g = GEOM.get(key);
        if (g == null) {
            int w = Math.min(sw - 10, Math.max(defW, sw * 3 / 4)), h = Math.min(sh - 10, Math.max(defH, sh * 3 / 4));
            g = new int[]{(sw - w) / 2, (sh - h) / 2, w, h, 0};
            GEOM.put(key, g);
        }
        maxed = g[4] == 1;
        computeWin();
        onInit();
    }

    protected void onInit() {}

    void computeWin() {
        int[] g = GEOM.get(key);
        g[2] = Math.max(260, Math.min(sw, g[2])); g[3] = Math.max(170, Math.min(sh, g[3]));
        g[0] = Math.max(0, Math.min(sw - g[2], g[0])); g[1] = Math.max(0, Math.min(sh - g[3], g[1]));
        if (maxed) { wx = 0; wy = 0; ww = sw; wh = sh; } else { wx = g[0]; wy = g[1]; ww = g[2]; wh = g[3]; }
        S = ZOptions.scaleFor(ww, wh);
        width = Math.max(1, (int) (ww / S)); height = Math.max(1, (int) (wh / S));
        OX = wx; OY = wy; SC = S;
    }

    protected void toggleMax() { maxed = !maxed; GEOM.get(key)[4] = maxed ? 1 : 0; computeWin(); }

    // ------------------------------------------------------------------ widgets
    protected EditBox box(String id, String hint) {
        EditBox b = boxes.get(id);
        if (b != null) return b;
        b = new EditBox(font, 0, 0, 50, 10, Component.literal(hint));
        b.setBordered(false);
        b.setMaxLength(100_000);
        b.setTextColor(TEXT);
        b.setHint(Component.literal(hint).withStyle(ChatFormatting.DARK_GRAY));
        b.visible = false;
        String v = boxValues.remove(id);
        if (v != null) b.setValue(v);
        boxes.put(id, b);
        return addRenderableWidget(b);
    }

    /** draws the field background and shows the box at x,y (only boxes placed this frame are visible) */
    protected EditBox place(GuiGraphics g, EditBox b, int x, int y, int w) {
        boolean f = getFocused() == b;
        round(g, x, y, x + w, y + 14, f ? 0xFF1E1E2A : 0xFF15151C);
        if (f) outline(g, x, y, x + w, y + 14, alpha(ACCENT, 0.85f));
        b.setX(x + 4); b.setY(y + 3); b.setWidth(Math.max(10, w - 8));
        b.visible = true;
        placed.add(b);
        return b;
    }

    protected float anim(String id, boolean on) {
        float v = hover.getOrDefault(id, 0f);
        v += ((on ? 1 : 0) - v) * (ZOptions.animations ? 0.35f : 1f);
        hover.put(id, v);
        return v;
    }

    /** style 0 ghost, 1 accent, 2 danger, 3 selected */
    protected void button(GuiGraphics g, String id, int x, int y, int w, int h, String label, int style, int mx, int my, Runnable r) {
        boolean on = in(mx, my, x, y, x + w, y + h);
        float v = anim(id, on);
        int base = style == 1 ? ACCENT : style == 2 ? 0xFF8A2E3E : style == 3 ? alpha(ACCENT, 0.45f) : 0x18FFFFFF;
        int hi = style == 1 ? lerp(ACCENT, 0xFFFFFFFF, 0.2f) : style == 2 ? 0xFFB23A4F : style == 3 ? alpha(ACCENT, 0.6f) : 0x30FFFFFF;
        round(g, x, y, x + w, y + h, lerp(base, hi, v));
        centered(g, font, ellipsize(font, label, w - 4), x + w / 2, y + (h - 8) / 2, style == 0 ? lerp(0xFFC0C0D0, 0xFFFFFFFF, v) : 0xFFFFFFFF);
        hits.add(new Hit(x, y, x + w, y + h, r));
    }

    protected int bw(String label) { return font.width(label) + 12; }

    protected void toggle(GuiGraphics g, String id, int x, int y, boolean on, int mx, int my, Runnable r) {
        float v = anim(id, on);
        round(g, x, y + 1, x + 20, y + 11, lerp(0xFF2A2A36, ACCENT, v));
        round(g, x + 2 + Math.round(v * 9), y + 3, x + 9 + Math.round(v * 9), y + 9, 0xFFFFFFFF);
        hits.add(new Hit(x, y, x + 20, y + 12, r));
    }

    protected void setStatus(boolean ok, String m) { statusOk = ok; status = m; statusT = System.currentTimeMillis(); }

    // ------------------------------------------------------------------ render
    @Override public void render(GuiGraphics g, int amx, int amy, float pt) {
        // no world (main menu): Minecraft does not clear the frame, so everything outside the window must be
        // repainted every frame - otherwise old frames stay on screen and the window looks duplicated
        if (minecraft != null && minecraft.level == null) drawMenuBackdrop(g, pt);
        OX = wx; OY = wy; SC = S;
        if (!maxed) { shadow(g, wx, wy, wx + ww, wy + wh); g.fill(wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 0xFF34304A); }
        g.pose().pushPose();
        g.pose().translate(wx, wy, 0);
        g.pose().scale(S, S, 1);
        int mx = (int) ((amx - wx) / S), my = (int) ((amy - wy) / S);
        lmx = mx; lmy = my;
        hits.clear(); placed.clear();
        g.fill(0, 0, width, height, ZOptions.bg(0x0B0B12));
        // title bar
        g.fill(0, 0, width, TOPH, TOP);
        hGrad(g, 0, TOPH - 1, width, TOPH, ACCENT, ACCENT2, (System.currentTimeMillis() % 100000) / 12000f);
        round(g, 8, 7, 14, 13, ACCENT);
        text(g, font, title.getString(), 19, 6, TEXT);
        String sub = subtitle();
        if (!sub.isEmpty()) small(g, font, sub, 24 + font.width(title.getString()), 8, DIM);
        int bx = width - 6 - 16;
        button(g, "w:close", bx, 3, 16, 14, "✕", 0, mx, my, this::onClose);
        bx -= 19; button(g, "w:max", bx, 3, 16, 14, maxed ? "❐" : "□", 0, mx, my, this::toggleMax);
        titleButtons(g, bx - 6, mx, my);
        // body
        renderBody(g, 0, TOPH, width, height - STATH, mx, my, pt);
        // status bar
        int y = height - STATH;
        g.fill(0, y, width, height, TOP);
        g.fill(0, y, width, y + 1, LINE);
        if (!status.isEmpty()) {
            long age = System.currentTimeMillis() - statusT;
            small(g, font, ellipsize(font, status, width * 4 / 3 - 20), 6, y + 3, statusOk ? (age < 6000 ? 0xFFB8F0CC : DIM) : ERR);
        } else small(g, font, hint(), 6, y + 3, FAINT);
        for (EditBox b : boxes.values()) if (!placed.contains(b)) { b.visible = false; if (getFocused() == b) setFocused(null); }
        super.render(g, mx, my, pt);
        renderOverlay(g, mx, my, pt);
        if (!maxed) for (int i = 0; i < 3; i++) g.fill(width - 3 - i * 3, height - 3, width - 1 - i * 3, height - 1, 0x88FFFFFF);
        g.pose().popPose();
    }

    protected String subtitle() { return ""; }
    protected String hint() { return "Esc — close · drag the title to move · corner to resize"; }
    protected void titleButtons(GuiGraphics g, int right, int mx, int my) {}
    protected abstract void renderBody(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my, float pt);
    protected void renderOverlay(GuiGraphics g, int mx, int my, float pt) {}

    // ------------------------------------------------------------------ input (logical coordinates)
    protected boolean bodyClick(double mx, double my, int b) { return false; }
    protected boolean bodyDrag(double mx, double my, int b, double dx, double dy) { return false; }
    protected boolean bodyRelease(double mx, double my, int b) { return false; }
    protected boolean bodyScroll(double mx, double my, double d) { return false; }
    protected boolean bodyKey(int key, int mods) { return false; }

    @Override public boolean mouseClicked(double amx, double amy, int b) {
        double mx = (amx - wx) / S, my = (amy - wy) / S;
        if (!maxed && b == 0 && in(mx, my, width - 10, height - 10, width + 2, height + 2)) {
            dragMode = 2; dragX = amx; dragY = amy; dragG = GEOM.get(key).clone(); return true;
        }
        if (mx < 0 || my < 0 || mx >= width || my >= height) { setFocused(null); return false; }
        lmx = (int) mx; lmy = (int) my; lbtn = b;
        for (EditBox e : boxes.values()) if (e.visible && in(mx, my, e.getX() - 4, e.getY() - 3, e.getX() + e.getWidth() + 4, e.getY() + 11)) {
            setFocused(e); e.setFocused(true); e.mouseClicked(mx, my, b); return true;
        }
        if (getFocused() instanceof EditBox fb) { fb.setFocused(false); setFocused(null); onBoxBlur(fb); }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (in(mx, my, h.x1, h.y1, h.x2, h.y2)) { h.r.run(); return true; }
        }
        if (b == 0 && my < TOPH) {
            long now = System.currentTimeMillis();
            if (now - lastTopClick < 300) { toggleMax(); lastTopClick = 0; return true; }
            lastTopClick = now;
            if (!maxed) { dragMode = 1; dragX = amx; dragY = amy; dragG = GEOM.get(key).clone(); }
            return true;
        }
        return bodyClick(mx, my, b);
    }

    protected void onBoxBlur(EditBox b) {}

    @Override public boolean mouseDragged(double amx, double amy, int b, double dx, double dy) {
        int[] g = GEOM.get(key);
        if (dragMode == 1) { g[0] = dragG[0] + (int) (amx - dragX); g[1] = dragG[1] + (int) (amy - dragY); computeWin(); return true; }
        if (dragMode == 2) { g[2] = dragG[2] + (int) (amx - dragX); g[3] = dragG[3] + (int) (amy - dragY); computeWin(); return true; }
        return bodyDrag((amx - wx) / S, (amy - wy) / S, b, dx / S, dy / S);
    }

    @Override public boolean mouseReleased(double amx, double amy, int b) {
        if (dragMode != 0) { dragMode = 0; return true; }
        return bodyRelease((amx - wx) / S, (amy - wy) / S, b);
    }

    @Override public boolean mouseScrolled(double amx, double amy, double d) {
        double mx = (amx - wx) / S, my = (amy - wy) / S;
        if (mx < 0 || my < 0 || mx >= width || my >= height) return false;
        return bodyScroll(mx, my, d);
    }

    @Override public boolean keyPressed(int key, int sc, int mods) {
        if (key == GLFW.GLFW_KEY_F8) { onClose(); return true; }
        if (getFocused() instanceof EditBox b) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { b.setFocused(false); setFocused(null); onBoxBlur(b); return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { if (!onEnter(b)) { b.setFocused(false); setFocused(null); onBoxBlur(b); } return true; }
            if (key == GLFW.GLFW_KEY_TAB) { focusNext(b); return true; }
            return b.keyPressed(key, sc, mods);
        }
        if (bodyKey(key, mods)) return true;
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(key, sc, mods);
    }

    void focusNext(EditBox b) {
        List<EditBox> vis = new ArrayList<>();
        for (EditBox e : boxes.values()) if (e.visible) vis.add(e);
        if (vis.isEmpty()) return;
        int i = vis.indexOf(b);
        b.setFocused(false); onBoxBlur(b);
        EditBox n = vis.get((i + 1) % vis.size());
        setFocused(n); n.setFocused(true);
    }

    /** @return true to keep focus */
    protected boolean onEnter(EditBox b) { return false; }

    @Override public boolean charTyped(char c, int mods) {
        if (getFocused() instanceof EditBox b) return b.charTyped(c, mods);
        return bodyChar(c);
    }
    protected boolean bodyChar(char c) { return false; }

    @Override public void tick() { for (EditBox b : boxes.values()) b.tick(); }

    @Override public void onClose() {
        if (!ZOptions.rememberLayout) GEOM.remove(key);
        minecraft.setScreen(parent);
    }

    @Override public void removed() { OX = OY = 0; SC = 1; super.removed(); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g) {}

    boolean backdropFailed;
    /** parent menu screen (title screen panorama etc.) dimmed behind the window, or the dirt background */
    protected void drawMenuBackdrop(GuiGraphics g, float pt) {
        boolean drawn = false;
        if (parent != null && !(parent instanceof ZWindow) && !backdropFailed) {
            try {
                if (parent.width != width || parent.height != height) parent.init(minecraft, width, height);
                parent.render(g, -1000, -1000, pt);
                drawn = true;
            } catch (Throwable t) { backdropFailed = true; }
        }
        if (!drawn) super.renderBackground(g);
        g.fill(0, 0, width, height, 0x88000000);
        g.flush();
        com.mojang.blaze3d.systems.RenderSystem.clear(org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT, net.minecraft.client.Minecraft.ON_OSX);
    }

    // ------------------------------------------------------------------ small helpers
    protected void label(GuiGraphics g, String s, int x, int y) { small(g, font, s.toUpperCase(Locale.ROOT), x, y, DIM); }

    protected void panel(GuiGraphics g, int x0, int y0, int x1, int y1) { g.fill(x0, y0, x1, y1, PANEL); }

    /** a choice pill cycling through options */
    protected void choice(GuiGraphics g, String id, int x, int y, int w, String cur, String[] opts, int mx, int my, Consumer<String> set) {
        boolean on = in(mx, my, x, y, x + w, y + 14);
        round(g, x, y, x + w, y + 14, on ? 0xFF22222E : 0xFF15151C);
        text(g, font, ellipsize(font, cur, w - 16), x + 4, y + 3, TEXT);
        text(g, font, "⇅", x + w - 10, y + 3, DIM);
        hits.add(new Hit(x, y, x + w, y + 14, () -> {
            int i = Arrays.asList(opts).indexOf(cur);
            set.accept(opts[Math.floorMod(i + (lbtn == 1 ? -1 : 1), opts.length)]);
        }));
    }
}
