package net.idea.fluwa.client.zspace;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Tiny line-based Lua tokenizer for highlighting (supports multi-line comments/strings). */
public final class LuaLexer {
    private LuaLexer() {}

    public static final int DEF = 0, KW = 1, CONST = 2, NUM = 3, STR = 4, COM = 5, GLOBAL = 6, CALL = 7, OP = 8, MEMBER = 9, SPACE = 10;
    public static final int[] COLORS = {0xE4E4EE, 0xC792EA, 0xFF9E64, 0xFF9E64, 0xA5E075, 0x5F6A7E, 0x7AA2F7, 0xFFCB6B, 0x89DDFF, 0xF2A2B8, 0xE4E4EE};

    public static final Set<String> KEYWORDS = Set.of("and", "break", "do", "else", "elseif", "end", "false", "for", "function",
            "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while");
    public static final Set<String> CONSTS = Set.of("true", "false", "nil");
    public static final Set<String> GLOBALS = new HashSet<>(List.of("Workspace", "workspace", "game", "Players", "World", "Lighting",
            "Terrain", "UI", "Events", "CAR", "Instance", "Vector3", "Vec3", "CFrame", "Color3", "Color", "UDim2", "getAccess",
            "GetAccess", "print", "warn", "wait", "spawn", "delay", "tick", "IsServer", "IsClient", "LocalPlayer", "Camera",
            "PlayLocalSound", "pairs", "ipairs", "next", "type", "tostring", "tonumber", "pcall", "error", "assert", "select",
            "setmetatable", "getmetatable", "rawget", "rawset", "rawequal", "unpack", "math", "string", "table", "coroutine", "os",
            "bit32", "load", "self", "_G", "_VERSION"));
    /** API names for autocomplete */
    public static final List<String> API = new ArrayList<>();

    static {
        try (var in = LuaLexer.class.getResourceAsStream("/assets/fluwa/completions.txt")) {
            if (in != null) new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)).lines()
                    .map(String::trim).filter(s -> !s.isEmpty()).forEach(API::add);
        } catch (Exception ignored) {}
        for (String s : List.of("insert", "remove", "concat", "sort", "floor", "ceil", "random", "randomseed", "sqrt", "abs",
                "min", "max", "sin", "cos", "huge", "pi", "format", "sub", "gsub", "find", "match", "gmatch", "len", "lower",
                "upper", "rep", "byte", "char", "create", "resume", "yield", "status", "wrap"))
            API.add(s);
    }

    public record Tok(int s, int e, int type) {}

    public static boolean idStart(char c) { return Character.isLetter(c) || c == '_'; }
    public static boolean id(char c) { return Character.isLetterOrDigit(c) || c == '_'; }

    /** level of a long bracket "[==[" at i, or -1 */
    static int longOpen(String s, int i) {
        if (i >= s.length() || s.charAt(i) != '[') return -1;
        int j = i + 1, lv = 0;
        while (j < s.length() && s.charAt(j) == '=') { j++; lv++; }
        return j < s.length() && s.charAt(j) == '[' ? lv : -1;
    }

    static int longEnd(String s, int from, int lv) {
        String close = "]" + "=".repeat(lv) + "]";
        int k = s.indexOf(close, Math.max(0, Math.min(from, s.length())));
        return k < 0 ? -1 : k + close.length();
    }

    static char prevNs(String s, int i) { for (int k = i - 1; k >= 0; k--) if (s.charAt(k) != ' ') return s.charAt(k); return 0; }
    static char nextNs(String s, int i) { for (int k = i; k < s.length(); k++) if (s.charAt(k) != ' ') return s.charAt(k); return 0; }

    /** tokenizes one line; state: 0 normal, 1000+lv inside long comment, 2000+lv inside long string; returns end state */
    public static int lex(String s, int state, List<Tok> out) {
        int i = 0, n = s.length();
        if (state != 0) {
            int kind = state / 1000, lv = state % 1000, type = kind == 1 ? COM : STR;
            int e = longEnd(s, 0, lv);
            if (e < 0) { if (n > 0) out.add(new Tok(0, n, type)); return state; }
            out.add(new Tok(0, e, type));
            i = e;
        }
        while (i < n) {
            char c = s.charAt(i);
            if (c == '-' && i + 1 < n && s.charAt(i + 1) == '-') {
                int lv = longOpen(s, i + 2);
                if (lv >= 0) {
                    int e = longEnd(s, i + 4 + lv, lv);
                    if (e < 0) { out.add(new Tok(i, n, COM)); return 1000 + lv; }
                    out.add(new Tok(i, e, COM)); i = e; continue;
                }
                out.add(new Tok(i, n, COM));
                return 0;
            }
            if (c == '[') {
                int lv = longOpen(s, i);
                if (lv >= 0) {
                    int e = longEnd(s, i + 2 + lv, lv);
                    if (e < 0) { out.add(new Tok(i, n, STR)); return 2000 + lv; }
                    out.add(new Tok(i, e, STR)); i = e; continue;
                }
            }
            if (c == '"' || c == '\'') {
                int j = i + 1;
                while (j < n) { char d = s.charAt(j); if (d == '\\') { j += 2; continue; } j++; if (d == c) break; }
                j = Math.min(j, n);
                out.add(new Tok(i, j, STR)); i = j; continue;
            }
            if (Character.isDigit(c) || (c == '.' && i + 1 < n && Character.isDigit(s.charAt(i + 1)))) {
                int j = i + 1;
                while (j < n) {
                    char d = s.charAt(j);
                    if (Character.isLetterOrDigit(d) || d == '.') j++;
                    else if ((d == '-' || d == '+') && (s.charAt(j - 1) == 'e' || s.charAt(j - 1) == 'E')) j++;
                    else break;
                }
                out.add(new Tok(i, j, NUM)); i = j; continue;
            }
            if (idStart(c)) {
                int j = i + 1;
                while (j < n && id(s.charAt(j))) j++;
                String w = s.substring(i, j);
                char prev = prevNs(s, i), next = nextNs(s, j);
                int type;
                if (KEYWORDS.contains(w)) type = CONSTS.contains(w) ? CONST : KW;
                else if (prev == '.' || prev == ':') type = next == '(' || next == '"' || next == '{' ? CALL : MEMBER;
                else if (GLOBALS.contains(w)) type = GLOBAL;
                else if (next == '(') type = CALL;
                else type = DEF;
                out.add(new Tok(i, j, type)); i = j; continue;
            }
            if (c == ' ') {
                int j = i;
                while (j < n && s.charAt(j) == ' ') j++;
                out.add(new Tok(i, j, SPACE)); i = j; continue;
            }
            out.add(new Tok(i, i + 1, OP)); i++;
        }
        return 0;
    }
}
