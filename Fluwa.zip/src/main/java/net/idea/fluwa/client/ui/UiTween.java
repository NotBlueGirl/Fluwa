package net.idea.fluwa.client.ui;

import net.idea.fluwa.lua.UDim2L;
import org.luaj.vm2.*;

import java.util.*;

/** GuiObject:TweenPosition / TweenSize / TweenSizeAndPosition (Roblox easing directions and styles). */
final class UiTween {
    private UiTween() {}
    UDim2L p0, p1, s0, s1; String dir, style; double time; long start; LuaValue cb;
    static final Map<UiObj, UiTween> ACTIVE = new WeakHashMap<>();

    /** a = (easingDirection, easingStyle, time, override, callback) */
    static boolean start(UiObj o, UDim2L pos, UDim2L size, Varargs a) {
        String dir = a.isnil(1) ? "Out" : UiObj.en(a.arg(1));
        String style = a.isnil(2) ? "Quad" : UiObj.en(a.arg(2));
        double time = a.optdouble(3, 1);
        boolean override = a.optboolean(4, false);
        LuaValue cb = a.arg(5);
        UiTween cur = ACTIVE.get(o);
        if (cur != null && !override) return false;
        if (cur != null && cur.cb.isfunction()) o.rt.callAsync(cur.cb, LuaValue.valueOf("Canceled"), "Tween callback");
        UiTween t = new UiTween();
        t.p0 = o.position; t.p1 = pos; t.s0 = o.size; t.s1 = size; t.dir = dir; t.style = style; t.time = Math.max(0, time);
        t.start = System.nanoTime(); t.cb = cb;
        ACTIVE.put(o, t);
        if (t.time == 0) step(o);
        return true;
    }

    static void step(UiObj o) {
        if (ACTIVE.isEmpty()) return;
        UiTween t = ACTIVE.get(o);
        if (t == null) return;
        double f = t.time <= 0 ? 1 : Math.min(1, (System.nanoTime() - t.start) / 1e9 / t.time);
        double e = ease(f, t.dir, t.style);
        if (t.p1 != null) o.position = lerp(t.p0, t.p1, e);
        if (t.s1 != null) o.size = lerp(t.s0, t.s1, e);
        if (f >= 1) {
            ACTIVE.remove(o);
            if (t.cb.isfunction()) o.rt.callAsync(t.cb, LuaValue.valueOf("Completed"), "Tween callback");
        }
    }

    static UDim2L lerp(UDim2L a, UDim2L b, double t) {
        return new UDim2L(a.xs + (b.xs - a.xs) * t, a.xo + (b.xo - a.xo) * t, a.ys + (b.ys - a.ys) * t, a.yo + (b.yo - a.yo) * t);
    }

    static double in(double t, String s) {
        return switch (s) {
            case "Linear" -> t;
            case "Sine" -> 1 - Math.cos(t * Math.PI / 2);
            case "Back" -> 2.70158 * t * t * t - 1.70158 * t * t;
            case "Quart" -> t * t * t * t;
            case "Quint" -> t * t * t * t * t;
            case "Cubic" -> t * t * t;
            case "Exponential" -> t == 0 ? 0 : Math.pow(2, 10 * t - 10);
            case "Circular" -> 1 - Math.sqrt(1 - t * t);
            case "Elastic" -> t == 0 || t == 1 ? t : -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * (2 * Math.PI) / 3);
            case "Bounce" -> 1 - bounce(1 - t);
            default -> t * t; // Quad
        };
    }
    static double bounce(double t) {
        double n = 7.5625, d = 2.75;
        if (t < 1 / d) return n * t * t;
        if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
        if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
        return n * (t -= 2.625 / d) * t + 0.984375;
    }
    static double ease(double t, String dir, String style) {
        return switch (dir) {
            case "In" -> in(t, style);
            case "InOut" -> t < 0.5 ? in(t * 2, style) / 2 : 1 - in((1 - t) * 2, style) / 2;
            default -> 1 - in(1 - t, style); // Out
        };
    }
}
