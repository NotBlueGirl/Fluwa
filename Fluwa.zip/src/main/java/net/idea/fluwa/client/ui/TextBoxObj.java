package net.idea.fluwa.client.ui;

import net.idea.fluwa.lua.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;
import org.luaj.vm2.*;

/** TextBox: editable text with focus, placeholder, multi-line and E_TextChanged / E_FocusLost / E_ReturnPressed. */
public class TextBoxObj extends UiObj {
    public String placeholder = "";
    public int placeholderColor = 0x8A8A8A;
    public boolean clearOnFocus = true, multiLine, editable = true, focused;
    public int cursor;
    long blink;

    public TextBoxObj() { super("TextBox"); text = ""; xAlign = "Left"; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "PlaceholderText": return valueOf(placeholder);
            case "PlaceholderColor3": return col(placeholderColor);
            case "ClearTextOnFocus": return valueOf(clearOnFocus);
            case "MultiLine": return valueOf(multiLine);
            case "TextEditable": return valueOf(editable);
            case "CursorPosition": return valueOf(cursor + 1);
            case "Focused": return valueOf(focused);
        }
        return super.getProp(k);
    }
    @Override protected boolean setUi(String k, LuaValue v) {
        switch (k) {
            case "PlaceholderText": placeholder = v.tojstring(); return true;
            case "PlaceholderColor3": placeholderColor = ColorL.check(v); return true;
            case "ClearTextOnFocus": clearOnFocus = v.toboolean(); return true;
            case "MultiLine": multiLine = v.toboolean(); return true;
            case "TextEditable": editable = v.toboolean(); return true;
            case "CursorPosition": cursor = Math.max(0, Math.min(text.length(), v.checkint() - 1)); return true;
            case "Text": { boolean r = super.setUi(k, v); cursor = Math.min(cursor, text.length()); return r; }
        }
        return super.setUi(k, v);
    }

    @Override protected void copyTo(UiObj c) {
        super.copyTo(c);
        if (c instanceof TextBoxObj t) { t.placeholder = placeholder; t.clearOnFocus = clearOnFocus; t.multiLine = multiLine; t.editable = editable; }
    }

    public void capture() {
        if (focused) return;
        if (UiInput.focus != null && UiInput.focus != this) UiInput.focus.release(false);
        focused = true; UiInput.focus = this;
        if (clearOnFocus && editable) { text = ""; fire("E_TextChanged", valueOf("")); }
        cursor = text.length();
        // overlays have no keyboard: open a transparent input screen
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.screen instanceof FluwaUiScreen)) {
            ScreenGuiObj root = root();
            if (root != null) mc.setScreen(new FluwaUiScreen(root, true));
        }
        fire("E_Focused");
    }

    public void release(boolean enter) {
        if (!focused) return;
        focused = false;
        if (UiInput.focus == this) UiInput.focus = null;
        fire("E_FocusLost", valueOf(enter), input("Keyboard", "End", ax, ay));
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof FluwaUiScreen s && s.focusOnly && !s.closing) mc.setScreen(null);
    }

    ScreenGuiObj root() { for (LObj x = this; x != null; x = x.getParentObj()) if (x instanceof ScreenGuiObj s) return s; return null; }

    void changed() { fire("E_TextChanged", valueOf(text)); fire("E_Changed", valueOf("Text")); }

    public boolean charTyped(char c) {
        if (!focused || !editable || c < 32) return focused;
        text = text.substring(0, cursor) + c + text.substring(cursor);
        cursor++;
        changed();
        return true;
    }

    public boolean key(int key, int mods) {
        if (!focused) return false;
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
        switch (key) {
            case GLFW.GLFW_KEY_ESCAPE -> { release(false); return true; }
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
                if (multiLine && (mods & GLFW.GLFW_MOD_SHIFT) == 0 && editable) { text = text.substring(0, cursor) + "\n" + text.substring(cursor); cursor++; changed(); }
                else { fire("E_ReturnPressed", valueOf(text)); release(true); }
                return true;
            }
            case GLFW.GLFW_KEY_BACKSPACE -> { if (editable && cursor > 0) { text = text.substring(0, cursor - 1) + text.substring(cursor); cursor--; changed(); } return true; }
            case GLFW.GLFW_KEY_DELETE -> { if (editable && cursor < text.length()) { text = text.substring(0, cursor) + text.substring(cursor + 1); changed(); } return true; }
            case GLFW.GLFW_KEY_LEFT -> { cursor = Math.max(0, cursor - 1); return true; }
            case GLFW.GLFW_KEY_RIGHT -> { cursor = Math.min(text.length(), cursor + 1); return true; }
            case GLFW.GLFW_KEY_HOME -> { cursor = 0; return true; }
            case GLFW.GLFW_KEY_END -> { cursor = text.length(); return true; }
            case GLFW.GLFW_KEY_V -> { if (ctrl && editable) { String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (!multiLine) clip = clip.replace("\n", " ");
                text = text.substring(0, cursor) + clip + text.substring(cursor); cursor += clip.length(); changed(); } return true; }
            case GLFW.GLFW_KEY_C -> { if (ctrl) Minecraft.getInstance().keyboardHandler.setClipboard(text); return true; }
            case GLFW.GLFW_KEY_A -> { if (ctrl) cursor = text.length(); return true; }
        }
        return true;
    }

    @Override protected String displayText() { return text; }

    @Override protected void drawSelf(GuiGraphics g, int mx, int my, double ga) {
        if (text.isEmpty() && !placeholder.isEmpty() && !focused) {
            String t = text; int c = textColor; boolean ht = hasText;
            hasText = false; super.drawSelf(g, mx, my, ga); hasText = ht;
            drawText(g, placeholder, placeholderColor, ga);
            return;
        }
        super.drawSelf(g, mx, my, ga);
        if (focused && (System.currentTimeMillis() / 500) % 2 == 0) {
            var f = Minecraft.getInstance().font;
            String before = text.substring(0, Math.min(cursor, text.length()));
            int line = before.split("\n", -1).length - 1;
            String lastLine = before.substring(before.lastIndexOf('\n') + 1);
            float s = (float) textScale;
            int lines = text.split("\n", -1).length;
            float y0 = switch (yAlign) { case "Top" -> ay + 2; case "Bottom" -> ay + ah - lines * 9 * s - 1; default -> ay + (ah - lines * 9 * s) / 2f + s; };
            String full = text.split("\n", -1)[line];
            float lw = f.width(component(full)) * s;
            float x0 = switch (xAlign) { case "Right" -> ax + aw - lw - 2; case "Center" -> ax + (aw - lw) / 2f; default -> ax + 2; };
            int cx = (int) (x0 + f.width(component(lastLine)) * s);
            int cy = (int) (y0 + line * 9 * s);
            g.fill(cx, cy - 1, cx + 1, cy + (int) (9 * s), 0xFF000000 | (textColor & 0xFFFFFF));
        }
    }

    @Override protected void onDestroy() { if (focused) release(false); }

    static {
        reg(TextBoxObj.class, "CaptureFocus", (s, a) -> { ((TextBoxObj) s).capture(); return NONE; });
        reg(TextBoxObj.class, "ReleaseFocus", (s, a) -> { ((TextBoxObj) s).release(a.optboolean(1, false)); return NONE; });
        reg(TextBoxObj.class, "IsFocused", (s, a) -> valueOf(((TextBoxObj) s).focused));
        reg(TextBoxObj.class, "SetPlaceholderText", (s, a) -> set(s, "PlaceholderText", a.arg1()));
        reg(TextBoxObj.class, "SetClearTextOnFocus", (s, a) -> set(s, "ClearTextOnFocus", a.arg1()));
        reg(TextBoxObj.class, "SetMultiLine", (s, a) -> set(s, "MultiLine", a.arg1()));
    }
}
