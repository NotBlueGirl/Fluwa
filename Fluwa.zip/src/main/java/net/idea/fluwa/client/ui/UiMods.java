package net.idea.fluwa.client.ui;

import net.idea.fluwa.lua.*;
import net.minecraft.client.gui.GuiGraphics;
import org.luaj.vm2.*;

import java.util.*;

/** Non-visual UI modifiers: UIListLayout, UIGridLayout, UIPadding, UICorner, UIStroke, UIGradient. */
public final class UiMods {
    private UiMods() {}

    public abstract static class Mod extends UiObj {
        Mod(String c) { super(c); drawBg = false; }
        @Override public void renderTree(GuiGraphics g, int mx, int my, double a, int[] clip) {}
        @Override public UiObj pick(double mx, double my) { return null; }
    }

    public static final class ListLayout extends Mod {
        public UDimL padding = new UDimL(0, 0);
        public String fill = "Vertical", hAlign = "Left", vAlign = "Top", sort = "LayoutOrder";
        int[] lastSize = {0, 0};
        public ListLayout() { super("UIListLayout"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Padding": return padding;
                case "FillDirection": return valueOf(fill);
                case "HorizontalAlignment": return valueOf(hAlign);
                case "VerticalAlignment": return valueOf(vAlign);
                case "SortOrder": return valueOf(sort);
                case "AbsoluteContentSize": return new Vec2L(lastSize[0], lastSize[1]);
            }
            return super.getProp(k);
        }
        @Override protected boolean setUi(String k, LuaValue v) {
            switch (k) {
                case "Padding": padding = v.isnumber() ? new UDimL(0, v.todouble()) : UDimL.check(v); return true;
                case "FillDirection": fill = en(v); return true;
                case "HorizontalAlignment": hAlign = en(v); return true;
                case "VerticalAlignment": vAlign = en(v); return true;
                case "SortOrder": sort = en(v); return true;
            }
            return super.setUi(k, v);
        }
        List<UiObj> sorted(List<UiObj> ch) {
            List<UiObj> l = new ArrayList<>(ch);
            if ("Name".equals(sort)) l.sort(Comparator.comparing(UiObj::getName));
            else l.sort(Comparator.comparingInt(u -> u.layoutOrder));
            return l;
        }
        int[] contentSize(UiObj host) {
            boolean hor = "Horizontal".equals(fill);
            int[] c = host.content(); int main = 0, cross = 0, n = 0;
            for (UiObj u : host.uiChildren()) {
                u.layout(0, 0, c[2], c[3]);
                main += hor ? u.aw : u.ah; cross = Math.max(cross, hor ? u.ah : u.aw); n++;
            }
            int pad = (int) padding.px(hor ? c[2] : c[3]);
            if (n > 1) main += pad * (n - 1);
            return hor ? new int[]{main, cross} : new int[]{cross, main};
        }
        void apply(UiObj host, List<UiObj> ch, int[] c) {
            boolean hor = "Horizontal".equals(fill);
            List<UiObj> l = sorted(ch);
            int pad = (int) padding.px(hor ? c[2] : c[3]);
            int total = 0, cross = 0;
            for (UiObj u : l) { u.layout(0, 0, c[2], c[3]); total += hor ? u.aw : u.ah; cross = Math.max(cross, hor ? u.ah : u.aw); }
            if (l.size() > 1) total += pad * (l.size() - 1);
            lastSize = hor ? new int[]{total, cross} : new int[]{cross, total};
            int start;
            if (hor) start = "Center".equals(hAlign) ? (c[2] - total) / 2 : "Right".equals(hAlign) ? c[2] - total : 0;
            else start = "Center".equals(vAlign) ? (c[3] - total) / 2 : "Bottom".equals(vAlign) ? c[3] - total : 0;
            int pos = start;
            for (UiObj u : l) {
                if (hor) {
                    u.ax = c[0] + pos;
                    u.ay = c[1] + ("Center".equals(vAlign) ? (c[3] - u.ah) / 2 : "Bottom".equals(vAlign) ? c[3] - u.ah : 0);
                    pos += u.aw + pad;
                } else {
                    u.ay = c[1] + pos;
                    u.ax = c[0] + ("Center".equals(hAlign) ? (c[2] - u.aw) / 2 : "Right".equals(hAlign) ? c[2] - u.aw : 0);
                    pos += u.ah + pad;
                }
            }
        }
        static {
            reg(ListLayout.class, "SetPadding", (s, a) -> set(s, "Padding", a.arg1()));
            reg(ListLayout.class, "SetFillDirection", (s, a) -> set(s, "FillDirection", a.arg1()));
            reg(ListLayout.class, "SetHorizontalAlignment", (s, a) -> set(s, "HorizontalAlignment", a.arg1()));
            reg(ListLayout.class, "SetVerticalAlignment", (s, a) -> set(s, "VerticalAlignment", a.arg1()));
            reg(ListLayout.class, "SetSortOrder", (s, a) -> set(s, "SortOrder", a.arg1()));
        }
    }

    public static final class GridLayout extends Mod {
        public UDim2L cell = new UDim2L(0, 100, 0, 100), cellPad = new UDim2L(0, 5, 0, 5);
        public String fill = "Horizontal", start = "TopLeft", sort = "LayoutOrder";
        public int maxCells; int count; int[] lastSize = {0, 0};
        public GridLayout() { super("UIGridLayout"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "CellSize": return cell;
                case "CellPadding": return cellPad;
                case "FillDirection": return valueOf(fill);
                case "FillDirectionMaxCells": return valueOf(maxCells);
                case "StartCorner": return valueOf(start);
                case "SortOrder": return valueOf(sort);
                case "AbsoluteCellCount": return new Vec2L(count, 0);
                case "AbsoluteContentSize": return new Vec2L(lastSize[0], lastSize[1]);
            }
            return super.getProp(k);
        }
        @Override protected boolean setUi(String k, LuaValue v) {
            switch (k) {
                case "CellSize": cell = UDim2L.check(v); return true;
                case "CellPadding": cellPad = UDim2L.check(v); return true;
                case "FillDirection": fill = en(v); return true;
                case "FillDirectionMaxCells": maxCells = Math.max(0, v.checkint()); return true;
                case "StartCorner": start = en(v); return true;
                case "SortOrder": sort = en(v); return true;
            }
            return super.setUi(k, v);
        }
        void apply(UiObj host, List<UiObj> ch, int[] c) {
            List<UiObj> l = new ArrayList<>(ch);
            if ("Name".equals(sort)) l.sort(Comparator.comparing(UiObj::getName)); else l.sort(Comparator.comparingInt(u -> u.layoutOrder));
            int cw = (int) Math.round(cell.xs * c[2] + cell.xo), chh = (int) Math.round(cell.ys * c[3] + cell.yo);
            int px = (int) Math.round(cellPad.xs * c[2] + cellPad.xo), py = (int) Math.round(cellPad.ys * c[3] + cellPad.yo);
            boolean hor = !"Vertical".equals(fill);
            int per = hor ? Math.max(1, (c[2] + px) / Math.max(1, cw + px)) : Math.max(1, (c[3] + py) / Math.max(1, chh + py));
            if (maxCells > 0) per = Math.min(per, maxCells);
            boolean right = start.contains("Right"), bottom = start.contains("Bottom");
            int i = 0, cols = 0, rows = 0;
            for (UiObj u : l) {
                int a = i % per, b = i / per;
                int col = hor ? a : b, row = hor ? b : a;
                cols = Math.max(cols, col + 1); rows = Math.max(rows, row + 1);
                u.aw = cw; u.ah = chh;
                u.ax = right ? c[0] + c[2] - (col + 1) * cw - col * px : c[0] + col * (cw + px);
                u.ay = bottom ? c[1] + c[3] - (row + 1) * chh - row * py : c[1] + row * (chh + py);
                i++;
            }
            count = l.size();
            lastSize = new int[]{cols * cw + Math.max(0, cols - 1) * px, rows * chh + Math.max(0, rows - 1) * py};
        }
        static {
            reg(GridLayout.class, "SetCellSize", (s, a) -> set(s, "CellSize", a.arg1()));
            reg(GridLayout.class, "SetCellPadding", (s, a) -> set(s, "CellPadding", a.arg1()));
            reg(GridLayout.class, "SetFillDirection", (s, a) -> set(s, "FillDirection", a.arg1()));
            reg(GridLayout.class, "SetFillDirectionMaxCells", (s, a) -> set(s, "FillDirectionMaxCells", a.arg1()));
        }
    }

    public static final class Padding extends Mod {
        public UDimL left = new UDimL(0, 0), right = new UDimL(0, 0), top = new UDimL(0, 0), bottom = new UDimL(0, 0);
        public Padding() { super("UIPadding"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) { case "PaddingLeft": return left; case "PaddingRight": return right; case "PaddingTop": return top; case "PaddingBottom": return bottom; }
            return super.getProp(k);
        }
        @Override protected boolean setUi(String k, LuaValue v) {
            UDimL u = v.isnumber() ? new UDimL(0, v.todouble()) : k.startsWith("Padding") ? UDimL.check(v) : null;
            switch (k) { case "PaddingLeft": left = u; return true; case "PaddingRight": right = u; return true; case "PaddingTop": top = u; return true; case "PaddingBottom": bottom = u; return true; }
            return super.setUi(k, v);
        }
    }

    public static final class Corner extends Mod {
        public UDimL radius = new UDimL(0, 8);
        public Corner() { super("UICorner"); }
        @Override protected LuaValue getProp(String k) { return k.equals("CornerRadius") ? radius : super.getProp(k); }
        @Override protected boolean setUi(String k, LuaValue v) {
            if (k.equals("CornerRadius")) { radius = v.isnumber() ? new UDimL(0, v.todouble()) : UDimL.check(v); return true; }
            return super.setUi(k, v);
        }
        static { reg(Corner.class, "SetCornerRadius", (s, a) -> set(s, "CornerRadius", a.arg1())); }
    }

    public static final class Stroke extends Mod {
        public int color = 0x000000; public double thickness = 1, transparency; public String mode = "Border", join = "Round";
        public Stroke() { super("UIStroke"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Color": return col(color);
                case "Thickness": return valueOf(thickness);
                case "Transparency": return valueOf(transparency);
                case "ApplyStrokeMode": return valueOf(mode);
                case "LineJoinMode": return valueOf(join);
                case "Enabled": return valueOf(visible);
            }
            return super.getProp(k);
        }
        @Override protected boolean setUi(String k, LuaValue v) {
            switch (k) {
                case "Color": color = ColorL.check(v); return true;
                case "Thickness": thickness = v.checkdouble(); return true;
                case "Transparency": transparency = v.checkdouble(); return true;
                case "ApplyStrokeMode": mode = en(v); return true;
                case "LineJoinMode": join = en(v); return true;
                case "Enabled": visible = v.toboolean(); return true;
            }
            return super.setUi(k, v);
        }
        static {
            reg(Stroke.class, "SetColor", (s, a) -> set(s, "Color", a.arg1()));
            reg(Stroke.class, "SetThickness", (s, a) -> set(s, "Thickness", a.arg1()));
            reg(Stroke.class, "SetTransparency", (s, a) -> set(s, "Transparency", a.arg1()));
            reg(Stroke.class, "SetApplyStrokeMode", (s, a) -> set(s, "ApplyStrokeMode", a.arg1()));
        }
    }

    public static final class Gradient extends Mod {
        public SeqL color = new SeqL(true, new double[]{0, 1}, new double[]{0xFFFFFF, 0xFFFFFF});
        public SeqL transp = new SeqL(false, new double[]{0, 1}, new double[]{0, 0});
        public double rotation; public Vec2L offset = new Vec2L(0, 0); public boolean enabled = true;
        public Gradient() { super("UIGradient"); }
        @Override protected LuaValue getProp(String k) {
            switch (k) {
                case "Color": return color;
                case "Transparency": return transp;
                case "Rotation": return valueOf(rotation);
                case "Offset": return offset;
                case "Enabled": return valueOf(enabled);
            }
            return super.getProp(k);
        }
        @Override protected boolean setUi(String k, LuaValue v) {
            switch (k) {
                case "Color": color = v instanceof ColorL c ? SeqL.check(c, true) : SeqL.check(v, true); return true;
                case "Transparency": transp = SeqL.check(v, false); return true;
                case "Rotation": rotation = v.checkdouble(); return true;
                case "Offset": offset = Vec2L.check(v); return true;
                case "Enabled": enabled = v.toboolean(); return true;
            }
            return super.setUi(k, v);
        }
        static {
            reg(Gradient.class, "SetColor", (s, a) -> set(s, "Color", a.arg1()));
            reg(Gradient.class, "SetTransparency", (s, a) -> set(s, "Transparency", a.arg1()));
            reg(Gradient.class, "SetRotation", (s, a) -> set(s, "Rotation", a.arg1()));
            reg(Gradient.class, "SetOffset", (s, a) -> set(s, "Offset", a.arg1()));
        }
    }
}
