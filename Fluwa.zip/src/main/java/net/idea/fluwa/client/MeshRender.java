package net.idea.fluwa.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.mesh.Mesh;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

/** Client-side drawable for a {@link Mesh}: texture upload, animation playback, per-part visibility. */
public final class MeshRender {
    public Mesh mesh;
    ResourceLocation tex; DynamicTexture dyn;
    public final Set<String> hidden = new HashSet<>();
    /** per-part transforms: offset xyz, rotation xyz (degrees), scale xyz - around the part's centre */
    public final Map<String, float[]> xf = new HashMap<>();
    final Map<Mesh.Part, float[]> centres = new IdentityHashMap<>();
    public String anim; public float animTime, animSpeed = 1; public boolean animLoop = true, playing;
    public float alpha = 1; public int tint = 0xFFFFFF;
    long last = System.nanoTime();
    private static ResourceLocation whiteId;

    public MeshRender(Mesh m) { setMesh(m); }

    public void setMesh(Mesh m) {
        release();
        mesh = m;
        if (m != null && m.texture != null && m.texture.length > 0) {
            try {
                dyn = new DynamicTexture(NativeImage.read(m.texture));
                tex = Minecraft.getInstance().getTextureManager().register("fluwa_mesh", dyn);
            } catch (Exception e) { Fluwa.LOGGER.warn("Fluwa: bad model texture: {}", e.toString()); }
        }
    }

    public void setTexture(byte[] png) { if (mesh == null) return; mesh.texture = png == null ? new byte[0] : png; setMesh(mesh); }

    public void release() {
        if (tex != null) Minecraft.getInstance().getTextureManager().release(tex);
        tex = null; dyn = null;
    }

    static ResourceLocation white() {
        if (whiteId == null) {
            NativeImage img = new NativeImage(1, 1, false); img.setPixelRGBA(0, 0, 0xFFFFFFFF);
            whiteId = Minecraft.getInstance().getTextureManager().register("fluwa_white", new DynamicTexture(img));
        }
        return whiteId;
    }

    /** advance animation clock; returns true when a non-looping animation just ended */
    public boolean advance() {
        long now = System.nanoTime(); float dt = (now - last) / 1e9f; last = now;
        if (mesh == null || !playing) return false;
        Mesh.Anim a = mesh.findAnim(anim);
        if (a == null) { playing = false; return false; }
        animTime += dt * animSpeed;
        boolean ended = false;
        if (a.duration > 0 && animTime > a.duration) {
            if (animLoop) animTime %= a.duration; else { animTime = a.duration; playing = false; ended = true; }
        }
        for (Mesh.Node n : mesh.nodes) n.restore();
        mesh.sample(a, animTime);
        return ended;
    }

    public void draw(PoseStack ps, MultiBufferSource buf, int light) {
        if (mesh == null) return;
        advance();
        boolean translucent = alpha < 0.999f;
        for (Mesh.Part p : mesh.parts) if (((p.color >>> 24) & 255) < 255) translucent = true;
        ResourceLocation t = tex != null ? tex : white();
        VertexConsumer vc = buf.getBuffer(translucent ? RenderType.entityTranslucent(t) : RenderType.entityCutoutNoCull(t));
        var pose0 = ps.last();
        float[][] g = mesh.globals();
        for (Mesh.Part p : mesh.parts) {
            if (!p.visible || hidden.contains(p.name)) continue;
            float[] q = p.node >= 0 && p.node < g.length ? Mesh.apply(p.v, g[p.node]) : p.v;
            float[] f = xf.isEmpty() ? null : xf.get(p.name);
            var pose = pose0;
            if (f != null) {
                float[] cen = centres.computeIfAbsent(p, k -> centre(q));
                ps.pushPose();
                ps.translate(cen[0] + f[0], cen[1] + f[1], cen[2] + f[2]);
                ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(f[4])); ps.mulPose(com.mojang.math.Axis.XP.rotationDegrees(f[3])); ps.mulPose(com.mojang.math.Axis.ZP.rotationDegrees(f[5]));
                ps.scale(f[6], f[7], f[8]);
                ps.translate(-cen[0], -cen[1], -cen[2]);
                pose = ps.last();
                ps.popPose();
            }
            int c = p.color;
            int r = ((c >> 16) & 255) * ((tint >> 16) & 255) / 255, gg = ((c >> 8) & 255) * ((tint >> 8) & 255) / 255, b = (c & 255) * (tint & 255) / 255;
            int a = Math.round(((c >>> 24) & 255) * Math.max(0, Math.min(1, alpha)));
            // triangles emitted as degenerate quads (entity render types use QUADS)
            for (int i = 0; i + 23 < q.length; i += 24) {
                vert(vc, pose, q, i, r, gg, b, a, light);
                vert(vc, pose, q, i + 8, r, gg, b, a, light);
                vert(vc, pose, q, i + 16, r, gg, b, a, light);
                vert(vc, pose, q, i + 16, r, gg, b, a, light);
            }
        }
    }

    static float[] centre(float[] q) {
        float mnx = Float.MAX_VALUE, mny = Float.MAX_VALUE, mnz = Float.MAX_VALUE, mxx = -Float.MAX_VALUE, mxy = -Float.MAX_VALUE, mxz = -Float.MAX_VALUE;
        for (int i = 0; i + 7 < q.length; i += 8) {
            mnx = Math.min(mnx, q[i]); mny = Math.min(mny, q[i + 1]); mnz = Math.min(mnz, q[i + 2]);
            mxx = Math.max(mxx, q[i]); mxy = Math.max(mxy, q[i + 1]); mxz = Math.max(mxz, q[i + 2]);
        }
        return q.length < 8 ? new float[3] : new float[]{(mnx + mxx) / 2, (mny + mxy) / 2, (mnz + mxz) / 2};
    }

    static void vert(VertexConsumer vc, PoseStack.Pose pose, float[] q, int i, int r, int g, int b, int a, int light) {
        vc.vertex(pose.pose(), q[i], q[i + 1], q[i + 2]).color(r, g, b, a).uv(q[i + 3], q[i + 4])
          .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(pose.normal(), q[i + 5], q[i + 6], q[i + 7]).endVertex();
    }
}
