package net.idea.fluwa.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.api.GameRuntime;
import net.idea.fluwa.api.Projector;
import net.idea.fluwa.mesh.Mesh;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.*;

/** Client renderer for Projector objects (server-replicated via S_PROJ and local client-runtime objects). */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientProjector {
    private ClientProjector() {}

    public static final class Entry {
        public MeshRender r; public String name = "", dim = "", anim = "";
        public double[] st = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0};
        public boolean show, playing, loop = true; public int attach = -1;
    }
    public static final Map<Integer, Entry> ENTRIES = new LinkedHashMap<>();

    public static void handle(Pkt p) {
        String op = p.s(0);
        int id = p.n(0);
        switch (op) {
            case "clear" -> { if (id == -1) clearLocal(); else clearAll(); }
            case "del" -> { Entry e = ENTRIES.remove(id); if (e != null) e.r.release(); }
            case "add" -> {
                try {
                    Mesh m = Mesh.fromBytes(p.data);
                    Entry e = ENTRIES.get(id);
                    if (e == null) { e = new Entry(); e.r = new MeshRender(m); ENTRIES.put(id, e); }
                    else { Set<String> h = new HashSet<>(e.r.hidden); e.r.setMesh(m); e.r.hidden.addAll(h); }
                    e.name = p.s(1);
                } catch (Exception ex) { Fluwa.LOGGER.warn("Fluwa: bad projector mesh: {}", ex.toString()); }
            }
            case "tex" -> { Entry e = ENTRIES.get(id); if (e != null) e.r.setTexture(p.data); }
            case "state" -> {
                Entry e = ENTRIES.get(id);
                if (e == null) return;
                e.dim = p.s(1);
                String anim = p.s(2);
                String[] v = p.s(3).split(",");
                double[] st = new double[18];
                for (int i = 0; i < st.length && i < v.length; i++) try { st[i] = Double.parseDouble(v[i]); } catch (NumberFormatException ignored) {}
                boolean playing = p.n(2) == 1;
                if (!anim.equals(e.anim) || playing != e.playing) { e.r.animTime = (float) st[17]; }
                e.anim = anim; e.st = st; e.show = p.n(1) == 1; e.playing = playing; e.loop = p.n(3) == 1; e.attach = p.n(4);
                e.r.anim = anim; e.r.playing = playing; e.r.animLoop = e.loop; e.r.animSpeed = (float) st[16]; e.r.alpha = (float) (1 - st[15]);
                if (!playing && !anim.isEmpty() && e.r.mesh != null) { Mesh.Anim a = e.r.mesh.findAnim(anim); if (a != null) { for (Mesh.Node n : e.r.mesh.nodes) n.restore(); e.r.mesh.sample(a, (float) st[17]); } }
                e.r.hidden.clear();
                if (p.s.size() > 4 && !p.s(4).isEmpty()) e.r.hidden.addAll(Arrays.asList(p.s(4).split(",")));
            }
        }
    }

    public static void clearAll() { for (Entry e : ENTRIES.values()) e.r.release(); ENTRIES.clear(); }
    public static void clearLocal() { ENTRIES.entrySet().removeIf(en -> { if (en.getKey() < 0) { en.getValue().r.release(); return true; } return false; }); }

    static void tick() {}

    /** world transform matrix (column-major JOML) from the state array */
    public static Matrix4f matrix(double[] st, double ox, double oy, double oz) {
        Matrix4f m = new Matrix4f(
                (float) st[3], (float) st[6], (float) st[9], 0,
                (float) st[4], (float) st[7], (float) st[10], 0,
                (float) st[5], (float) st[8], (float) st[11], 0,
                (float) (st[0] - ox), (float) (st[1] - oy), (float) (st[2] - oz), 1);
        return m.scale((float) st[12], (float) st[13], (float) st[14]);
    }

    /** draw an entry with an arbitrary model matrix (also used by ViewportFrame) */
    public static void draw(Entry e, PoseStack ps, MultiBufferSource buf, Matrix4f model, int light) {
        ps.pushPose();
        ps.last().pose().mul(model);
        Matrix3f n = new Matrix3f(model).invert().transpose();
        ps.last().normal().mul(n);
        e.r.draw(ps, buf, light);
        ps.popPose();
    }

    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || ENTRIES.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        String dim = mc.level.dimension().location().toString();
        Vec3 cam = e.getCamera().getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        PoseStack ps = e.getPoseStack();
        for (Entry en : ENTRIES.values()) {
            if (!en.show || !dim.equals(en.dim)) continue;
            double[] st = en.st;
            if (en.attach >= 0) {
                Entity ent = mc.level.getEntity(en.attach);
                if (ent == null) continue;
            }
            if (Math.abs(st[0] - cam.x) > 512 || Math.abs(st[2] - cam.z) > 512) continue;
            int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(st[0], st[1] + 0.5, st[2]));
            draw(en, ps, buf, matrix(st, cam.x, cam.y, cam.z), light);
        }
        buf.endBatch();
    }

    // ------------------------------------------------------------------ clicking
    @SubscribeEvent
    public static void click(InputEvent.InteractionKeyMappingTriggered e) {
        if (ENTRIES.isEmpty() || (!e.isAttack() && !e.isUseItem())) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        Vec3 o = mc.player.getEyePosition(1), d = mc.player.getViewVector(1);
        double reach = 6;
        if (mc.hitResult != null && mc.hitResult.getType() != HitResult.Type.MISS) reach = Math.min(reach, mc.hitResult.getLocation().distanceTo(o) + 0.01);
        String dim = mc.level.dimension().location().toString();
        int best = 0; double bestT = reach;
        for (var en : ENTRIES.entrySet()) {
            Entry x = en.getValue();
            if (!x.show || !dim.equals(x.dim) || x.r.mesh == null) continue;
            double t = rayHit(x, o, d, bestT);
            if (t >= 0 && t < bestT) { bestT = t; best = en.getKey(); }
        }
        if (best == 0) return;
        int button = e.isAttack() ? 0 : 1;
        if (best > 0) FluwaNet.toServer(new Pkt(Pkt.C_PROJ, List.of(), new int[]{best, button}, null));
        else Projector.clickedLocal(GameRuntime.CLIENT, best, button);
        e.setCanceled(true);
        e.setSwingHand(true);
    }

    static double rayHit(Entry x, Vec3 o, Vec3 d, double max) {
        Matrix4f inv = matrix(x.st, 0, 0, 0).invert();
        org.joml.Vector3f lo = inv.transformPosition(new org.joml.Vector3f((float) o.x, (float) o.y, (float) o.z));
        org.joml.Vector3f ld = inv.transformDirection(new org.joml.Vector3f((float) d.x, (float) d.y, (float) d.z));
        float scale = ld.length(); if (scale == 0) return -1; ld.div(scale);
        double best = -1;
        for (float[] v : x.r.mesh.posed()) for (int i = 0; i + 23 < v.length; i += 24) {
            float ax = v[i], ay = v[i + 1], az = v[i + 2];
            float e1x = v[i + 8] - ax, e1y = v[i + 9] - ay, e1z = v[i + 10] - az, e2x = v[i + 16] - ax, e2y = v[i + 17] - ay, e2z = v[i + 18] - az;
            float px = ld.y * e2z - ld.z * e2y, py = ld.z * e2x - ld.x * e2z, pz = ld.x * e2y - ld.y * e2x;
            float det = e1x * px + e1y * py + e1z * pz;
            if (Math.abs(det) < 1e-9) continue;
            float inv2 = 1 / det, sx = lo.x - ax, sy = lo.y - ay, sz = lo.z - az;
            float u = (sx * px + sy * py + sz * pz) * inv2; if (u < 0 || u > 1) continue;
            float qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x;
            float w = (ld.x * qx + ld.y * qy + ld.z * qz) * inv2; if (w < 0 || u + w > 1) continue;
            float t = (e2x * qx + e2y * qy + e2z * qz) * inv2 / scale;
            if (t >= 0 && t <= max && (best < 0 || t < best)) best = t;
        }
        return best;
    }
}
