package net.idea.fluwa.client.ui;

import com.mojang.math.Axis;
import net.idea.fluwa.lua.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import org.luaj.vm2.*;

import java.util.*;

/**
 * Base of all GUI objects (Frame, Button/TextButton, ImageButton, Image/ImageLabel, AnimImage, TextLabel ...).
 * Universal properties / methods / events of the 0.3 UI spec, layout (UIListLayout/UIGridLayout/UIPadding),
 * decorations (UICorner/UIStroke/UIGradient), tweens, mouse/touch emulation and attributes.
 */
public class UiObj extends EvObj {
    // ---- universal
    public UDim2L position = new UDim2L(0, 0, 0, 0), size = new UDim2L(0, 100, 0, 30);
    public double anchorX, anchorY, rotation;
    public boolean visible = true, clips, active = true, selectable, drawBg = true;
    public int bg = 0xFFFFFF, border = 0x1B2A35, zIndex = 1, borderSize = 0, layoutOrder;
    public double bgTransparency = 0;
    public String sizeConstraint = "RelativeXY", automaticSize = "None";
    // ---- text
    public String text = "", font = "Default", xAlign = "Center", yAlign = "Center";
    public int textColor = 0x000000, strokeColor = 0x000000;
    public double textScale = 1, textTransparency, strokeTransparency = 1;
    public boolean textScaled, textWrapped, richText, hasText;
    // ---- button
    public boolean clickable, autoButtonColor = true, modal, selected;
    public String style = "Default";
    // ---- image
    public String image;
    public int imageColor = 0xFFFFFF;
    public double imageTransparency;
    public Vec2L rectOffset = new Vec2L(0, 0), rectSize = new Vec2L(0, 0), tileSize = new Vec2L(1, 1);
    public String scaleType = "Stretch";
    public double sliceScale = 1;
    public LuaValue sliceCenter = NIL;
    // ---- anim image
    public LuaTable frames; public double fps = 10; public boolean playing = true, loop = true; public int curFrame;
    double animClock; long animLast;
    // ---- canvas group
    public double groupTransparency; public int groupColor = 0xFFFFFF;

    boolean hovered, held;
    long pressTime; double pressX, pressY;
    public int ax, ay, aw, ah;
    int[] clipRect;

    public UiObj(String cls) {
        super(cls);
        switch (cls) {
            case "TextLabel" -> { bgTransparency = 1; textColor = 0xFFFFFF; hasText = true; text = "Label"; }
            case "Button", "TextButton" -> { clickable = true; bg = 0x3C3C3C; textColor = 0xFFFFFF; text = "Button"; hasText = true; selectable = true; }
            case "ImageButton" -> { clickable = true; bgTransparency = 1; selectable = true; }
            case "Image", "AnimImage", "ImageLabel" -> bgTransparency = 1;
            case "Frame", "ScrollingFrame" -> bg = 0x202020;
            case "CanvasGroup" -> bgTransparency = 1;
            case "TextBox" -> { hasText = true; bg = 0xFFFFFF; textColor = 0x000000; selectable = true; }
        }
    }

    static final Set<String> EV = new HashSet<>(List.of("E_ChildAdded", "E_ChildRemoved", "E_Changed", "E_InputBegan", "E_InputEnded", "E_InputChanged",
            "E_MouseEnter", "E_MouseLeave", "E_MouseMoved", "E_MouseWheelForward", "E_MouseWheelBackward",
            "E_MouseButton1Down", "E_MouseButton1Up", "E_MouseButton1Click", "E_MouseButton2Down", "E_MouseButton2Up", "E_MouseButton2Click",
            "E_TouchTap", "E_TouchLongPress", "E_TouchPan", "E_TouchSwipe", "E_SelectionGained", "E_SelectionLost", "E_Focused", "E_FocusLost",
            "E_Activated", "E_Deactivated", "E_Click", "E_Down", "E_Up", "E_FrameChanged", "E_Finished", "E_Looped", "E_TextChanged", "E_ReturnPressed",
            "E_CanvasPositionChanged", "E_Play", "E_Pause", "E_Ended", "E_Loaded", "E_Error", "E_AttributeChanged", "E_Opened", "E_Closed"));
    @Override protected Collection<String> eventNames() { return EV; }

    /** legacy (0.2) names -> 0.3 events */
    static String legacy(String k) {
        return switch (k) {
            case "MouseButton1Click", "Activated" -> "E_Click";
            case "MouseButton2Click" -> "E_MouseButton2Click";
            case "MouseEnter" -> "E_MouseEnter";
            case "MouseLeave" -> "E_MouseLeave";
            case "Changed" -> "E_Changed";
            case "Focused" -> "E_Focused";
            case "FocusLost" -> "E_FocusLost";
            default -> null;
        };
    }

    static ColorL col(int c) { return new ColorL(c >> 16 & 255, c >> 8 & 255, c & 255); }

    @Override protected LuaValue getProp(String k) {
        String lg = legacy(k);
        if (lg != null) return ev(lg);
        switch (k) {
            case "Position": return position;
            case "Size": return size;
            case "AnchorPoint": return new Vec2L(anchorX, anchorY);
            case "Rotation": return valueOf(rotation);
            case "Visible": return valueOf(visible);
            case "BackgroundColor": case "BackgroundColor3": return col(bg);
            case "BackgroundTransparency": return valueOf(bgTransparency);
            case "BorderColor": case "BorderColor3": return col(border);
            case "BorderSize": case "BorderSizePixel": return valueOf(borderSize);
            case "ZIndex": return valueOf(zIndex);
            case "ClipsDescendants": return valueOf(clips);
            case "Active": return valueOf(active);
            case "Selectable": return valueOf(selectable);
            case "LayoutOrder": return valueOf(layoutOrder);
            case "SizeConstraint": return valueOf(sizeConstraint);
            case "AutomaticSize": return valueOf(automaticSize);
            case "AbsolutePosition": return new Vec2L(ax, ay);
            case "AbsoluteSize": return new Vec2L(aw, ah);
            case "AbsoluteRotation": return valueOf(rotation);
            case "Hovered": return valueOf(hovered);
            case "GuiState": return valueOf(held ? "Press" : hovered ? "Hover" : "Idle");
        }
        if (hasText || clickable) switch (k) {
            case "Text": return valueOf(text);
            case "ContentText": return valueOf(richText ? stripTags(text) : text);
            case "Font": return valueOf(font);
            case "TextColor": case "TextColor3": return col(textColor);
            case "TextScale": return valueOf(textScale);
            case "TextSize": return valueOf(Math.round(textScale * 9));
            case "TextCentered": return valueOf("Center".equals(xAlign));
            case "TextTransparency": return valueOf(textTransparency);
            case "TextStrokeColor3": return col(strokeColor);
            case "TextStrokeTransparency": return valueOf(strokeTransparency);
            case "TextScaled": return valueOf(textScaled);
            case "TextWrapped": return valueOf(textWrapped);
            case "TextXAlignment": return valueOf(xAlign);
            case "TextYAlignment": return valueOf(yAlign);
            case "RichText": return valueOf(richText);
            case "TextBounds": { int[] b = textBounds(); return new Vec2L(b[0], b[1]); }
            case "TextFits": { int[] b = textBounds(); return valueOf(b[0] <= aw && b[1] <= ah); }
        }
        if (clickable) switch (k) {
            case "AutoButtonColor": return valueOf(autoButtonColor);
            case "Modal": return valueOf(modal);
            case "Selected": return valueOf(selected);
            case "Style": return valueOf(style);
        }
        switch (k) {
            case "Image": return image == null ? valueOf("") : valueOf(image);
            case "ImageColor3": case "ImageColor": return col(imageColor);
            case "ImageTransparency": return valueOf(imageTransparency);
            case "ImageRectOffset": return rectOffset;
            case "ImageRectSize": return rectSize;
            case "ScaleType": return valueOf(scaleType);
            case "SliceCenter": return sliceCenter;
            case "SliceScale": return valueOf(sliceScale);
            case "TileSize": return tileSize;
            case "Frames": return frames == null ? new LuaTable() : frames;
            case "CurrentFrame": return valueOf(curFrame + 1);
            case "FPS": return valueOf(fps);
            case "Loop": case "Looped": return valueOf(loop);
            case "Playing": return valueOf(playing);
            case "GroupTransparency": return valueOf(groupTransparency);
            case "GroupColor3": return col(groupColor);
        }
        return super.getProp(k);
    }

    @Override protected final boolean setProp(String k, LuaValue v) {
        boolean ok = setUi(k, v);
        if (ok && !"Parent".equals(k) && !"Name".equals(k)) fire("E_Changed", valueOf(k));
        else if (ok) fire("E_Changed", valueOf(k));
        if (ok) { Signal s = propSignals == null ? null : propSignals.get(k); if (s != null && s.hasHandlers()) s.fire(); }
        return ok;
    }
    Map<String, Signal> propSignals;

    static String en(LuaValue v) { return v.tojstring().replaceFirst("^Enum\\.[A-Za-z]+\\.", ""); }

    protected boolean setUi(String k, LuaValue v) {
        switch (k) {
            case "Position": position = UDim2L.check(v); return true;
            case "Size": size = UDim2L.check(v); return true;
            case "AnchorPoint": { Vec2L a = Vec2L.check(v); anchorX = a.x; anchorY = a.y; return true; }
            case "Rotation": rotation = v.checkdouble(); return true;
            case "Visible": visible = v.toboolean(); return true;
            case "BackgroundColor": case "BackgroundColor3": bg = ColorL.check(v); return true;
            case "BackgroundTransparency": bgTransparency = v.checkdouble(); return true;
            case "BorderColor": case "BorderColor3": border = ColorL.check(v); return true;
            case "BorderSize": case "BorderSizePixel": borderSize = v.checkint(); return true;
            case "ZIndex": zIndex = v.checkint(); return true;
            case "ClipsDescendants": clips = v.toboolean(); return true;
            case "Active": active = v.toboolean(); return true;
            case "Selectable": selectable = v.toboolean(); return true;
            case "LayoutOrder": layoutOrder = v.checkint(); return true;
            case "SizeConstraint": sizeConstraint = en(v); return true;
            case "AutomaticSize": automaticSize = en(v); return true;
        }
        if (hasText || clickable) switch (k) {
            case "Text": { String old = text; text = v.tojstring(); if (!old.equals(text)) fire("E_TextChanged", valueOf(text)); return true; }
            case "Font": font = en(v); return true;
            case "TextColor": case "TextColor3": textColor = ColorL.check(v); return true;
            case "TextScale": textScale = v.checkdouble(); return true;
            case "TextSize": { double d = v.checkdouble(); textScale = d <= 4 ? d : d / 9.0; return true; }
            case "TextCentered": xAlign = v.toboolean() ? "Center" : "Left"; return true;
            case "TextTransparency": textTransparency = v.checkdouble(); return true;
            case "TextStrokeColor3": strokeColor = ColorL.check(v); return true;
            case "TextStrokeTransparency": strokeTransparency = v.checkdouble(); return true;
            case "TextScaled": textScaled = v.toboolean(); return true;
            case "TextWrapped": textWrapped = v.toboolean(); return true;
            case "TextXAlignment": xAlign = en(v); return true;
            case "TextYAlignment": yAlign = en(v); return true;
            case "RichText": richText = v.toboolean(); return true;
        }
        if (clickable) switch (k) {
            case "AutoButtonColor": autoButtonColor = v.toboolean(); return true;
            case "Modal": modal = v.toboolean(); return true;
            case "Selected": selected = v.toboolean(); return true;
            case "Style": style = en(v); return true;
        }
        switch (k) {
            case "Image": image = v.isnil() || v.tojstring().isEmpty() ? null : v.tojstring(); return true;
            case "ImageColor3": case "ImageColor": imageColor = ColorL.check(v); return true;
            case "ImageTransparency": imageTransparency = v.checkdouble(); return true;
            case "ImageRectOffset": rectOffset = Vec2L.check(v); return true;
            case "ImageRectSize": rectSize = Vec2L.check(v); return true;
            case "ScaleType": scaleType = en(v); return true;
            case "SliceCenter": sliceCenter = v; return true;
            case "SliceScale": sliceScale = v.checkdouble(); return true;
            case "TileSize": tileSize = Vec2L.check(v); return true;
            case "Frames": frames = v.checktable(); curFrame = 0; return true;
            case "FPS": fps = Math.max(0.1, v.checkdouble()); return true;
            case "Loop": case "Looped": loop = v.toboolean(); return true;
            case "Playing": playing = v.toboolean(); return true;
            case "GroupTransparency": groupTransparency = v.checkdouble(); return true;
            case "GroupColor3": groupColor = ColorL.check(v); return true;
        }
        return super.setProp(k, v);
    }

    // ------------------------------------------------------------------ hierarchy helpers
    public List<UiObj> uiChildren() {
        List<UiObj> l = new ArrayList<>();
        for (LObj c : children) if (c instanceof UiObj u && u.visible && !(u instanceof UiMods.Mod)) l.add(u);
        l.sort(Comparator.comparingInt(u -> u.zIndex));
        return l;
    }
    @SuppressWarnings("unchecked")
    public <T extends UiMods.Mod> T mod(Class<T> c) {
        for (LObj o : children) if (c.isInstance(o) && (!(o instanceof UiMods.Gradient g) || g.enabled)) return (T) o;
        return null;
    }

    @Override protected LuaValue cloneObj() {
        UiObj c = UiFactory.create(className);
        copyTo(c);
        for (LObj ch : children) if (ch instanceof UiObj u) ((UiObj) u.cloneObj()).setParent(c);
        return c;
    }
    protected void copyTo(UiObj c) {
        c.name = name; c.position = position; c.size = size; c.anchorX = anchorX; c.anchorY = anchorY; c.rotation = rotation; c.visible = visible;
        c.clips = clips; c.active = active; c.selectable = selectable; c.drawBg = drawBg; c.bg = bg; c.border = border; c.zIndex = zIndex;
        c.borderSize = borderSize; c.layoutOrder = layoutOrder; c.bgTransparency = bgTransparency; c.sizeConstraint = sizeConstraint;
        c.automaticSize = automaticSize; c.text = text; c.font = font; c.xAlign = xAlign; c.yAlign = yAlign; c.textColor = textColor;
        c.strokeColor = strokeColor; c.textScale = textScale; c.textTransparency = textTransparency; c.strokeTransparency = strokeTransparency;
        c.textScaled = textScaled; c.textWrapped = textWrapped; c.richText = richText; c.hasText = hasText; c.clickable = clickable;
        c.autoButtonColor = autoButtonColor; c.modal = modal; c.selected = selected; c.style = style; c.image = image; c.imageColor = imageColor;
        c.imageTransparency = imageTransparency; c.rectOffset = rectOffset; c.rectSize = rectSize; c.tileSize = tileSize; c.scaleType = scaleType;
        c.sliceScale = sliceScale; c.sliceCenter = sliceCenter; c.frames = frames; c.fps = fps; c.playing = playing; c.loop = loop;
        c.groupTransparency = groupTransparency; c.groupColor = groupColor;
        if (attrs != null) { c.attrs = new LuaTable(); for (LuaValue k = attrs.next(NIL).arg1(); !k.isnil(); k = attrs.next(k).arg1()) c.attrs.set(k, attrs.get(k)); }
    }

    // ------------------------------------------------------------------ layout
    /** default rect from Position / Size / AnchorPoint / SizeConstraint inside the parent content rect */
    public void layout(int px, int py, int pw, int ph) {
        double bw = pw, bh = ph;
        if ("RelativeXX".equals(sizeConstraint)) bh = pw; else if ("RelativeYY".equals(sizeConstraint)) bw = ph;
        aw = (int) Math.round(size.xs * bw + size.xo);
        ah = (int) Math.round(size.ys * bh + size.yo);
        autoSize();
        ax = (int) Math.round(px + position.xs * pw + position.xo - anchorX * aw);
        ay = (int) Math.round(py + position.ys * ph + position.yo - anchorY * ah);
    }

    void autoSize() {
        if ("None".equals(automaticSize)) return;
        int w = 0, h = 0;
        if (hasText && !text.isEmpty()) { int[] b = textBounds(); w = b[0] + 4; h = b[1] + 4; }
        for (UiObj c : uiChildren()) {
            int cw = (int) Math.round(c.size.xo + c.position.xo), ch = (int) Math.round(c.size.yo + c.position.yo);
            w = Math.max(w, cw); h = Math.max(h, ch);
        }
        UiMods.ListLayout ll = mod(UiMods.ListLayout.class);
        if (ll != null) { int[] cs = ll.contentSize(this); w = Math.max(w, cs[0]); h = Math.max(h, cs[1]); }
        if (automaticSize.contains("X")) aw = Math.max(aw, w);
        if (automaticSize.contains("Y")) ah = Math.max(ah, h);
    }

    /** content rect children are laid out in (padding applied) */
    int[] content() {
        UiMods.Padding p = mod(UiMods.Padding.class);
        if (p == null) return new int[]{ax, ay, aw, ah};
        int l = (int) p.left.px(aw), r = (int) p.right.px(aw), t = (int) p.top.px(ah), b = (int) p.bottom.px(ah);
        return new int[]{ax + l, ay + t, Math.max(0, aw - l - r), Math.max(0, ah - t - b)};
    }

    /** parent rect handed to children (ScrollingFrame overrides: canvas) */
    protected int[] childArea() { return content(); }

    void layoutChildren(List<UiObj> ch) {
        int[] c = childArea();
        UiMods.ListLayout ll = mod(UiMods.ListLayout.class);
        UiMods.GridLayout gl = ll == null ? mod(UiMods.GridLayout.class) : null;
        if (ll != null) ll.apply(this, ch, c);
        else if (gl != null) gl.apply(this, ch, c);
        else for (UiObj u : ch) u.layout(c[0], c[1], c[2], c[3]);
    }

    // ------------------------------------------------------------------ rendering
    static int argb(int rgb, double transparency, double groupAlpha) {
        int a = (int) Math.round(Math.max(0, Math.min(1, (1 - transparency) * groupAlpha)) * 255);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public void render(GuiGraphics g, int px, int py, int pw, int ph, int mx, int my) {
        layout(px, py, pw, ph);
        renderTree(g, mx, my, 1, null);
    }

    /** rect already computed by the parent */
    public void renderTree(GuiGraphics g, int mx, int my, double alpha, int[] clip) {
        UiTween.step(this);
        clipRect = clip;
        boolean h = inside(mx, my);
        if (h != hovered) { hovered = h; fire(h ? "E_MouseEnter" : "E_MouseLeave", valueOf(mx - ax), valueOf(my - ay)); }
        else if (h && (mx != lastMx || my != lastMy)) fire("E_MouseMoved", valueOf(mx - ax), valueOf(my - ay));
        lastMx = mx; lastMy = my;
        if (held && h && pressTime > 0 && System.currentTimeMillis() - pressTime > 600 && !longFired) {
            longFired = true; fire("E_TouchLongPress", touches(mx, my), valueOf("Begin"));
        }
        double ga = alpha;
        if ("CanvasGroup".equals(className)) ga *= 1 - groupTransparency;
        g.pose().pushPose();
        if (rotation != 0) {
            g.pose().translate(ax + aw / 2f, ay + ah / 2f, 0);
            g.pose().mulPose(Axis.ZP.rotationDegrees((float) rotation));
            g.pose().translate(-(ax + aw / 2f), -(ay + ah / 2f), 0);
        }
        if ("CanvasGroup".equals(className) && groupColor != 0xFFFFFF) g.setColor((groupColor >> 16 & 255) / 255f, (groupColor >> 8 & 255) / 255f, (groupColor & 255) / 255f, 1);
        drawSelf(g, mx, my, ga);
        List<UiObj> ch = uiChildren();
        if (!ch.isEmpty()) {
            layoutChildren(ch);
            int[] cl = clip;
            boolean scissor = clips || this instanceof ScrollObj;
            if (scissor) {
                cl = clip == null ? new int[]{ax, ay, ax + aw, ay + ah}
                        : new int[]{Math.max(clip[0], ax), Math.max(clip[1], ay), Math.min(clip[2], ax + aw), Math.min(clip[3], ay + ah)};
                g.enableScissor(cl[0], cl[1], Math.max(cl[0], cl[2]), Math.max(cl[1], cl[3]));
            }
            for (UiObj c : ch) c.renderTree(g, mx, my, ga, cl);
            if (scissor) g.disableScissor();
            drawOver(g, ga);
        }
        if (!children.isEmpty()) net.idea.fluwa.client.BrowserRender.drawChildren(children, g, ax, ay, aw, ah, mx, my, ga);
        if ("CanvasGroup".equals(className) && groupColor != 0xFFFFFF) g.setColor(1, 1, 1, 1);
        g.pose().popPose();
    }
    int lastMx = Integer.MIN_VALUE, lastMy; boolean longFired;

    boolean inside(double mx, double my) {
        if (mx < ax || my < ay || mx >= ax + aw || my >= ay + ah) return false;
        return clipRect == null || (mx >= clipRect[0] && my >= clipRect[1] && mx < clipRect[2] && my < clipRect[3]);
    }

    /** background, border, image, text */
    protected void drawSelf(GuiGraphics g, int mx, int my, double ga) {
        UiMods.Corner corner = mod(UiMods.Corner.class);
        int radius = corner == null ? 0 : (int) Math.min(Math.min(aw, ah) / 2.0, corner.radius.px(Math.min(aw, ah)));
        if (drawBg && bgTransparency < 1) {
            int c = bg;
            if (clickable && autoButtonColor && active) { if (held) c = UiDraw.shade(c, -30); else if (hovered) c = UiDraw.shade(c, 30); }
            if (selected) c = UiDraw.shade(c, 20);
            UiMods.Gradient gr = mod(UiMods.Gradient.class);
            if (gr != null) UiDraw.gradient(g, ax, ay, aw, ah, radius, c, bgTransparency, ga, gr);
            else UiDraw.rect(g, ax, ay, aw, ah, radius, argb(c, bgTransparency, ga));
        }
        if (borderSize > 0) UiDraw.outline(g, ax, ay, aw, ah, borderSize, radius, argb(border, 0, ga));
        String img = currentImage();
        if (img != null) UiDraw.image(g, this, img, ga);
        if (hasText) drawText(g, displayText(), textColor, ga);
        UiMods.Stroke st = mod(UiMods.Stroke.class);
        if (st != null && !"Contextual".equals(st.mode)) UiDraw.outline(g, ax, ay, aw, ah, (int) Math.max(1, Math.round(st.thickness)), radius, argb(st.color, st.transparency, ga));
    }
    protected void drawOver(GuiGraphics g, double ga) {}

    protected String displayText() { return text; }

    // ------------------------------------------------------------------ text
    static ResourceLocation fontId(String f) {
        String s = f.toLowerCase(Locale.ROOT);
        if (s.contains(":")) return ResourceLocation.tryParse(s);
        if (s.contains("code") || s.contains("mono") || s.contains("uniform") || s.contains("roboto")) return new ResourceLocation("minecraft", "uniform");
        if (s.contains("arcade") || s.contains("alt") || s.contains("enchant") || s.contains("fantasy")) return new ResourceLocation("minecraft", "alt");
        return Style.DEFAULT_FONT;
    }

    Component component(String t) {
        Style base = Style.EMPTY.withFont(fontId(font));
        if (font.toLowerCase(Locale.ROOT).contains("bold")) base = base.withBold(true);
        if (font.toLowerCase(Locale.ROOT).contains("italic")) base = base.withItalic(true);
        return richText ? RichText.parse(t, base) : Component.literal(t).withStyle(base);
    }

    static String stripTags(String s) { return s.replaceAll("<[^>]+>", ""); }

    int[] textBounds() {
        Font f = Minecraft.getInstance().font;
        Component c = component(text);
        float s = (float) textScale;
        if (textWrapped && aw > 0) { List<FormattedCharSequence> l = f.split(c, Math.max(1, (int) (aw / s))); int w = 0; for (var x : l) w = Math.max(w, f.width(x)); return new int[]{(int) (w * s), (int) (l.size() * 9 * s)}; }
        int lines = text.split("\n", -1).length; int w = 0;
        for (String ln : text.split("\n", -1)) w = Math.max(w, f.width(component(ln)));
        return new int[]{(int) (w * s), (int) (lines * 9 * s)};
    }

    protected void drawText(GuiGraphics g, String t, int color, double ga) {
        if (t == null || t.isEmpty()) return;
        int alpha = (int) Math.round((1 - textTransparency) * ga * 255);
        if (alpha < 5) return;
        Font f = Minecraft.getInstance().font;
        float s = (float) textScale;
        List<FormattedCharSequence> lines = new ArrayList<>();
        if (textScaled) {
            int w = 1; String[] raw = t.split("\n", -1);
            for (String ln : raw) w = Math.max(w, f.width(component(ln)));
            s = Math.max(0.25f, Math.min((aw - 4) / (float) w, (ah - 2) / (9f * raw.length)));
            if (textWrapped) s = Math.min(s, 3);
        }
        for (String ln : t.split("\n", -1)) {
            Component c = component(ln);
            if (textWrapped && aw > 4) lines.addAll(f.split(c, Math.max(8, (int) ((aw - 4) / s))));
            else lines.add(c.getVisualOrderText());
        }
        float lh = 9 * s, total = lines.size() * lh;
        float y0 = switch (yAlign) { case "Top" -> ay + 2; case "Bottom" -> ay + ah - total - 1; default -> ay + (ah - total) / 2f + s; };
        int argb = (alpha << 24) | (color & 0xFFFFFF);
        int sa = (int) Math.round((1 - strokeTransparency) * ga * 255);
        UiMods.Stroke st = mod(UiMods.Stroke.class);
        int strokeArgb = st != null && "Contextual".equals(st.mode) ? argb(st.color, st.transparency, ga) : sa >= 5 ? (sa << 24) | (strokeColor & 0xFFFFFF) : 0;
        for (int i = 0; i < lines.size(); i++) {
            FormattedCharSequence ln = lines.get(i);
            float w = f.width(ln) * s;
            float x = switch (xAlign) { case "Left" -> ax + 2; case "Right" -> ax + aw - w - 2; default -> ax + (aw - w) / 2f; };
            g.pose().pushPose();
            g.pose().translate(x, y0 + i * lh, 0);
            g.pose().scale(s, s, 1);
            if (strokeArgb != 0) for (int[] d : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) g.drawString(f, ln, d[0], d[1], strokeArgb, false);
            g.drawString(f, ln, 0, 0, argb, false);
            g.pose().popPose();
        }
    }

    // ------------------------------------------------------------------ images / animation
    String currentImage() {
        if (frames != null && frames.length() > 0) {
            int n = frames.length();
            long now = System.nanoTime();
            if (animLast == 0) animLast = now;
            if (playing) {
                animClock += (now - animLast) / 1e9 * fps;
                int idx = (int) animClock;
                if (idx >= n) {
                    if (loop) { animClock %= n; idx = (int) animClock; fire("E_Looped"); }
                    else { idx = n - 1; animClock = idx; playing = false; fire("E_Finished"); }
                }
                if (idx != curFrame) { curFrame = idx; fire("E_FrameChanged", valueOf(idx + 1)); }
            }
            animLast = now;
            return frames.get(Math.min(curFrame, n - 1) + 1).tojstring();
        }
        return image;
    }

    // ------------------------------------------------------------------ input
    static LuaTable input(String type, String state, double x, double y) {
        LuaTable t = new LuaTable();
        t.set("UserInputType", type); t.set("UserInputState", state);
        t.set("Position", new Vec3L(x, y, 0)); t.set("X", valueOf(x)); t.set("Y", valueOf(y));
        return t;
    }
    static LuaTable touches(double x, double y) { LuaTable t = new LuaTable(); t.set(1, new Vec2L(x, y)); return t; }

    /** deepest element under the mouse that accepts input (topmost first) */
    public UiObj pick(double mx, double my) {
        List<UiObj> ch = uiChildren();
        for (int i = ch.size() - 1; i >= 0; i--) { UiObj u = ch.get(i).pick(mx, my); if (u != null) return u; }
        if (inside(mx, my) && (clickable || selectable || active && listensMouse() || this instanceof TextBoxObj || this instanceof ScrollObj)) return this;
        return null;
    }
    boolean listensMouse() {
        for (String e : new String[]{"E_InputBegan", "E_MouseButton1Down", "E_MouseButton1Click", "E_MouseButton2Click", "E_MouseButton1Up", "E_MouseButton2Down", "E_TouchTap", "E_TouchPan", "E_TouchSwipe", "E_Activated", "E_Click"})
            if (listens(e)) return true;
        return false;
    }

    public void mouseDown(double mx, double my, int button) {
        double x = mx - ax, y = my - ay;
        fire("E_InputBegan", input(button == 1 ? "MouseButton2" : "MouseButton1", "Begin", mx, my));
        if (button == 0) { held = true; pressTime = System.currentTimeMillis(); pressX = mx; pressY = my; longFired = false;
            fire("E_MouseButton1Down", valueOf(x), valueOf(y)); if (clickable) fire("E_Down", valueOf(x), valueOf(y)); }
        else if (button == 1) fire("E_MouseButton2Down", valueOf(x), valueOf(y));
        if (selectable) UiInput.select(this);
    }

    public void mouseUp(double mx, double my, int button, boolean over) {
        double x = mx - ax, y = my - ay;
        fire("E_InputEnded", input(button == 1 ? "MouseButton2" : "MouseButton1", "End", mx, my));
        if (button == 0) {
            held = false;
            fire("E_MouseButton1Up", valueOf(x), valueOf(y));
            if (clickable) fire("E_Up", valueOf(x), valueOf(y));
            double dx = mx - pressX, dy = my - pressY;
            if (Math.abs(dx) > 30 || Math.abs(dy) > 30) {
                String dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "Right" : "Left") : (dy > 0 ? "Down" : "Up");
                fire("E_TouchSwipe", valueOf(dir), valueOf(1));
            } else if (over) click(x, y, mx, my);
            pressTime = 0;
        } else if (button == 1) {
            fire("E_MouseButton2Up", valueOf(x), valueOf(y));
            if (over) fire("E_MouseButton2Click", valueOf(x), valueOf(y));
        }
    }

    public void click(double x, double y, double mx, double my) {
        if (!active && clickable) return;
        fire("E_MouseButton1Click", valueOf(x), valueOf(y));
        fire("E_TouchTap", touches(mx, my));
        if (clickable) { fire("E_Click", valueOf(x), valueOf(y)); fire("E_Activated", input("MouseButton1", "End", mx, my)); }
    }

    public void drag(double mx, double my, double dx, double dy) {
        LuaTable t = touches(mx, my);
        fire("E_TouchPan", t, new Vec2L(mx - pressX, my - pressY), new Vec2L(dx, dy), valueOf("Change"));
        fire("E_InputChanged", input("MouseMovement", "Change", mx, my));
    }

    /** @return true if consumed */
    public boolean scroll(double mx, double my, double delta) {
        fire(delta > 0 ? "E_MouseWheelForward" : "E_MouseWheelBackward", valueOf(mx - ax), valueOf(my - ay));
        return false;
    }

    // ------------------------------------------------------------------ methods
    static UiObj u(LObj s) { return (UiObj) s; }
    static Varargs set(LObj s, String prop, LuaValue v) { ((UiObj) s).setProp(prop, v); return NONE; }

    static {
        Class<UiObj> C = UiObj.class;
        // tweens (Roblox signature): TweenPosition(endPos, [dir], [style], [time], [override], [callback])
        reg(C, "TweenPosition|TP", (s, a) -> valueOf(UiTween.start(u(s), UDim2L.check(a.arg(1)), null, a.subargs(2))));
        reg(C, "TweenSize|TS", (s, a) -> valueOf(UiTween.start(u(s), null, UDim2L.check(a.arg(1)), a.subargs(2))));
        reg(C, "TweenSizeAndPosition|TSP", (s, a) -> valueOf(UiTween.start(u(s), UDim2L.check(a.arg(2)), UDim2L.check(a.arg(1)), a.subargs(3))));
        reg(C, "GetPropertyChangedSignal", (s, a) -> { UiObj o = u(s); if (o.propSignals == null) o.propSignals = new HashMap<>();
            return o.propSignals.computeIfAbsent(a.checkjstring(1), Signal::new); });
        // Frame
        reg(C, "SetBackgroundColor|SetBackgroundColor3", (s, a) -> set(s, "BackgroundColor3", a.arg1()));
        reg(C, "SetBackgroundTransparency", (s, a) -> set(s, "BackgroundTransparency", a.arg1()));
        reg(C, "SetBorderSizePixel", (s, a) -> set(s, "BorderSizePixel", a.arg1()));
        reg(C, "SetBorderColor|SetBorderColor3", (s, a) -> set(s, "BorderColor3", a.arg1()));
        reg(C, "SetVisible", (s, a) -> set(s, "Visible", a.arg1()));
        reg(C, "SetPosition", (s, a) -> set(s, "Position", a.arg1()));
        reg(C, "SetSize", (s, a) -> set(s, "Size", a.arg1()));
        // Button
        reg(C, "Click", (s, a) -> { UiObj o = u(s); o.click(0, 0, o.ax, o.ay); return NONE; });
        reg(C, "SetAutoButtonColor", (s, a) -> set(s, "AutoButtonColor", a.arg1()));
        reg(C, "SetModal", (s, a) -> set(s, "Modal", a.arg1()));
        reg(C, "SetSelected", (s, a) -> set(s, "Selected", a.arg1()));
        // Image
        reg(C, "SetImage", (s, a) -> set(s, "Image", a.arg1()));
        reg(C, "SetImageColor3|SetImageColor", (s, a) -> set(s, "ImageColor3", a.arg1()));
        reg(C, "SetImageTransparency", (s, a) -> set(s, "ImageTransparency", a.arg1()));
        // AnimImage
        reg(C, "Play", (s, a) -> { UiObj o = u(s); o.playing = true; o.animLast = 0; o.fire("E_Play"); return NONE; });
        reg(C, "Pause", (s, a) -> { UiObj o = u(s); o.playing = false; o.fire("E_Pause"); return NONE; });
        reg(C, "Stop", (s, a) -> { UiObj o = u(s); o.playing = false; o.curFrame = 0; o.animClock = 0; return NONE; });
        reg(C, "SetFrame", (s, a) -> { UiObj o = u(s); int n = o.frames == null ? 1 : Math.max(1, o.frames.length());
            o.curFrame = Math.max(0, Math.min(n - 1, a.checkint(1) - 1)); o.animClock = o.curFrame; o.fire("E_FrameChanged", valueOf(o.curFrame + 1)); return NONE; });
        reg(C, "SetFPS", (s, a) -> set(s, "FPS", a.arg1()));
        reg(C, "SetLoop", (s, a) -> set(s, "Loop", a.arg1()));
        // TextLabel
        reg(C, "SetText", (s, a) -> set(s, "Text", a.arg1()));
        reg(C, "GetText", (s, a) -> valueOf(u(s).text));
        reg(C, "SetFont", (s, a) -> set(s, "Font", a.arg1()));
        reg(C, "SetTextSize", (s, a) -> set(s, "TextSize", a.arg1()));
        reg(C, "SetTextColor|SetTextColor3", (s, a) -> set(s, "TextColor3", a.arg1()));
        reg(C, "SetTextScaled", (s, a) -> set(s, "TextScaled", a.arg1()));
        reg(C, "SetTextWrapped", (s, a) -> set(s, "TextWrapped", a.arg1()));
        reg(C, "SetTextXAlignment", (s, a) -> set(s, "TextXAlignment", a.arg1()));
        reg(C, "SetTextYAlignment", (s, a) -> set(s, "TextYAlignment", a.arg1()));
        // CanvasGroup
        reg(C, "SetGroupTransparency", (s, a) -> set(s, "GroupTransparency", a.arg1()));
        reg(C, "SetGroupColor3|SetGroupColor", (s, a) -> set(s, "GroupColor3", a.arg1()));
    }
}
