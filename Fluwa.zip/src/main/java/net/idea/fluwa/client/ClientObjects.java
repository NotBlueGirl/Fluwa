package net.idea.fluwa.client;

import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.*;
import org.luaj.vm2.*;

import java.util.*;

/** Client-side Mouse / Camera / Model objects. */
public final class ClientObjects {
    private ClientObjects() {}
    static Minecraft mc() { return Minecraft.getInstance(); }

    public static class Mouse extends LObj {
        public final Signal b1d = new Signal("Button1Down"), b1u = new Signal("Button1Up"), b2d = new Signal("Button2Down"),
                b2u = new Signal("Button2Up"), wf = new Signal("WheelForward"), wb = new Signal("WheelBackward");
        Mouse() { super("Mouse"); }
        @Override protected LuaValue getProp(String k) {
            var mh = mc().mouseHandler; var w = mc().getWindow();
            switch (k) {
                case "X": return valueOf(mh.xpos() * w.getGuiScaledWidth() / w.getScreenWidth());
                case "Y": return valueOf(mh.ypos() * w.getGuiScaledHeight() / w.getScreenHeight());
                case "ViewSizeX": return valueOf(w.getGuiScaledWidth());
                case "ViewSizeY": return valueOf(w.getGuiScaledHeight());
                case "Hit": { HitResult h = mc().hitResult; return h == null ? NIL : Vec3L.of(h.getLocation()); }
                case "Target": {
                    HitResult h = mc().hitResult;
                    GameRuntime r = (GameRuntime) rt;
                    if (h instanceof BlockHitResult b && h.getType() == HitResult.Type.BLOCK) return new BlockObj(mc().level, b.getBlockPos());
                    if (h instanceof EntityHitResult e) return r.wrapEntity(e.getEntity());
                    return NIL;
                }
                case "Button1Down": return b1d; case "Button1Up": return b1u;
                case "Button2Down": return b2d; case "Button2Up": return b2u;
                case "WheelForward": return wf; case "WheelBackward": return wb;
            }
            return super.getProp(k);
        }
    }

    public static class Camera extends LObj {
        Camera() { super("Camera"); }
        @Override protected LuaValue getProp(String k) {
            var c = mc().gameRenderer.getMainCamera();
            switch (k) {
                case "CFrame": return CFrameL.fromYawPitch(Vec3L.of(c.getPosition()), c.getYRot(), c.getXRot());
                case "Position": return Vec3L.of(c.getPosition());
                case "LookVector": return CFrameL.fromYawPitch(Vec3L.of(c.getPosition()), c.getYRot(), c.getXRot()).look();
                case "FieldOfView": return valueOf(mc().options.fov().get());
                case "ThirdPerson": return valueOf(!mc().options.getCameraType().isFirstPerson());
                case "FreeCam": return valueOf(FreeCam.active());
            }
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            switch (k) {
                case "FieldOfView": mc().options.fov().set(Math.max(30, Math.min(110, v.checkint()))); return true;
                case "ThirdPerson": mc().options.setCameraType(v.toboolean() ? CameraType.THIRD_PERSON_BACK : CameraType.FIRST_PERSON); return true;
                case "FreeCam": if (v.toboolean() != FreeCam.active()) FreeCam.toggle(); return true;
            }
            return super.setProp(k, v);
        }
    }

    public static class ModelPart extends LObj {
        ModelPart(String n) { super("ModelPart"); name = n; }
        @Override public void setName(String n) { throw new LuaError("ModelPart.Name is read-only"); }
        @Override protected LuaValue getProp(String k) {
            if (k.equals("Visible")) return valueOf(!ClientState.HIDDEN_PARTS.getOrDefault(name, false));
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            if (k.equals("Visible")) { ClientState.HIDDEN_PARTS.put(name, !v.toboolean()); return true; }
            return super.setProp(k, v);
        }
    }

    static LuaTable model() {
        List<LuaValue> l = new ArrayList<>();
        for (String n : new String[]{"Head", "Hat", "Body", "RightArm", "LeftArm", "RightLeg", "LeftLeg"}) l.add(new ModelPart(n));
        return LObj.list(l);
    }
}
