package net.idea.fluwa.client.ui;

import java.util.*;
import java.util.function.Supplier;

/** Instance:new(...) for every UI class. */
public final class UiFactory {
    private UiFactory() {}
    public static final Map<String, Supplier<UiObj>> TYPES = new LinkedHashMap<>();
    static {
        TYPES.put("ScreenGUI", () -> new ScreenGuiObj(false));
        TYPES.put("ScreenGui", () -> new ScreenGuiObj(false));
        TYPES.put("Overlay", () -> new ScreenGuiObj(true));
        for (String t : new String[]{"Frame", "Button", "TextButton", "ImageButton", "Image", "ImageLabel", "AnimImage", "TextLabel", "CanvasGroup"})
            TYPES.put(t, () -> new UiObj(t));
        TYPES.put("TextBox", TextBoxObj::new);
        TYPES.put("ScrollingFrame", ScrollObj::new);
        TYPES.put("ViewportFrame", ViewportObj::new);
        TYPES.put("VideoFrame", VideoObj::new);
        TYPES.put("UIListLayout", UiMods.ListLayout::new);
        TYPES.put("UIGridLayout", UiMods.GridLayout::new);
        TYPES.put("UIPadding", UiMods.Padding::new);
        TYPES.put("UICorner", UiMods.Corner::new);
        TYPES.put("UIStroke", UiMods.Stroke::new);
        TYPES.put("UIGradient", UiMods.Gradient::new);
    }
    public static UiObj create(String cls) {
        Supplier<UiObj> s = TYPES.get(cls);
        if (s == null) throw new org.luaj.vm2.LuaError("Unknown UI class " + cls);
        return s.get();
    }
}
