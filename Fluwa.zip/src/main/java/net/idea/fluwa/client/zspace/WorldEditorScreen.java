package net.idea.fluwa.client.zspace;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.Input;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;

import java.util.*;

import static net.idea.fluwa.client.zspace.ZUi.*;

/**
 * ZSpace → Tools → World Editor: Axiom-like editing mode. The game keeps running behind a transparent overlay:
 * WASD / Space / Shift / Ctrl move the player (also while flying), RMB-drag looks around, the cursor raycasts
 * into the world. The whole interface is laid out in logical units and scaled (ZOptions Scale × World Editor UI size).
 */
public class WorldEditorScreen extends Screen {
    static final String[] TOOLS = {"Select", "Place", "Brush", "Erase", "Paint", "Smooth", "Cube", "Paste"};
    static final String[] TIPS = {
            "LMB-drag: select a box · Shift+LMB: move the second corner", "LMB: place one block on the face", "LMB / drag: sphere of blocks (H: hollow)",
            "LMB / drag: remove a sphere", "LMB / drag: repaint the top surface", "LMB / drag: smooth terrain", "LMB / drag: cube of blocks (H: hollow)",
            "LMB: paste the clipboard at the cursor"};
    static String tool = "Select";
    static int radius = 3;
    static boolean skipAir = true, paletteOpen = true, hollow;
    static BlockPos pos1, pos2;
    static BlockHitResult hover;
    static WorldEditorScreen open;
    static String msg = "";
    static boolean msgOk = true;
    static long msgT;
    /** current block mix ("stone" or several = random mix) */
    static final List<String> MIX = new ArrayList<>(List.of("minecraft:stone"));
    static final LinkedList<String> RECENT = new LinkedList<>();
    static String fromV = "", timesV = "1", searchV = "";
    static List<Block> ALL;

    final Screen parent;
    EditBox from, times, search;
    float S = 1;
    int lw, lh;             // logical size
    int lmx, lmy;           // logical mouse
    boolean looking, selecting;
    long lastStroke;
    int palScroll;
    String tip;
    record Hit(int x1, int y1, int x2, int y2, Runnable r) {}
    final List<Hit> hits = new ArrayList<>();
    final List<EditBox> fields = new ArrayList<>();

    public WorldEditorScreen(Screen parent) { super(Component.literal("World Editor")); this.parent = parent; }

    public static void reply(Pkt p) {
        if (p.s(0).equals("2")) { data(p); return; }
        msgOk = p.s(0).equals("1"); msg = p.s(1); msgT = System.currentTimeMillis();
    }

    static String blockString() { return String.join(", ", MIX); }

    static List<Block> allBlocks() {
        if (ALL == null) {
            ALL = new ArrayList<>();
            for (Block b : BuiltInRegistries.BLOCK) if (b.asItem() != Items.AIR) ALL.add(b);
        }
        return ALL;
    }

    @Override protected void init() {
        open = this;
        fields.clear();
        from = mk(fromV, "replace what (empty = air)");
        times = mk(timesV, "×");
        search = mk(searchV, "Search blocks…");
        eSearch = mk("", "Search entities…"); sSearch = mk("", "Search structures…"); sName = mk("", "name (fluwa:my_house)");
        pOff = mk("0 0 0", "x y z"); pRot = mk("0 0 0", "x y z"); pScale = mk("1 1 1", "x y z or one number");
        ebox.clear();
        for (String k : EKEYS) ebox.put(k, mk("", k));
        dataDirty = true;
        if (!mode.equals("Blocks")) setMode(mode);
        layout();
    }

    void layout() {
        S = Math.max(0.4f, Math.round(ZOptions.scaleFor(width, height) * (float) ZOptions.weScale * 20) / 20f);
        lw = Math.max(1, (int) (width / S)); lh = Math.max(1, (int) (height / S));
    }

    EditBox mk(String v, String hint) {
        EditBox b = new EditBox(font, 0, 0, 80, 10, Component.literal(hint));
        b.setBordered(false); b.setMaxLength(1000); b.setTextColor(TEXT);
        b.setHint(Component.literal(hint).withStyle(ChatFormatting.DARK_GRAY));
        b.setValue(v);
        b.visible = false;
        fields.add(b);
        return addRenderableWidget(b);
    }

    boolean typing() { return getFocused() instanceof EditBox; }

    void send(String op, String s1, String s2, int... n) { FluwaNet.toServer(new Pkt(Pkt.C_WEDIT, List.of(op, s1, s2), n, null)); }
    void local(boolean ok, String m) { msgOk = ok; msg = m; msgT = System.currentTimeMillis(); }

    boolean hasSel() { return pos1 != null && pos2 != null; }
    int[] sel(int... extra) {
        int[] r = new int[6 + extra.length];
        r[0] = pos1.getX(); r[1] = pos1.getY(); r[2] = pos1.getZ(); r[3] = pos2.getX(); r[4] = pos2.getY(); r[5] = pos2.getZ();
        System.arraycopy(extra, 0, r, 6, extra.length);
        return r;
    }
    void selOp(String op) {
        if (!hasSel()) { local(false, "Select a region first (Select tool, LMB-drag, or [ / ] at your position)"); return; }
        if (op.equals("line")) { send(op, blockString(), "", sel(radius)); return; }
        send(op, blockString(), from.getValue(), sel());
    }
    void stack() {
        if (!hasSel()) { local(false, "Select a region first"); return; }
        var d = lookDir();
        send("stack", "", "", sel(d.getStepX(), d.getStepY(), d.getStepZ(), timesN()));
    }

    static String id(Block b) { return BuiltInRegistries.BLOCK.getKey(b).toString(); }
    static ItemStack stack(String id) {
        Block b = BuiltInRegistries.BLOCK.get(ResourceLocation.tryParse(id.contains(":") ? id : "minecraft:" + id));
        return b == null ? ItemStack.EMPTY : new ItemStack(b.asItem());
    }
    void pick(String id, boolean add) {
        if (add) { if (!MIX.contains(id)) MIX.add(id); }
        else { MIX.clear(); MIX.add(id); }
        RECENT.remove(id); RECENT.addFirst(id);
        while (RECENT.size() > 12) RECENT.removeLast();
        local(true, "Block: " + blockString());
    }

    // ------------------------------------------------------------------ world interaction
    static BlockHitResult ray(Minecraft mc, double mx, double my, int w, int h) {
        if (mc.level == null || mc.player == null) return null;
        var cam = mc.gameRenderer.getMainCamera();
        Vector3f look = cam.getLookVector(), up = cam.getUpVector(), left = cam.getLeftVector();
        double fov = Math.toRadians(mc.options.fov().get());
        double t = Math.tan(fov / 2), aspect = (double) mc.getWindow().getWidth() / Math.max(1, mc.getWindow().getHeight());
        double nx = 2 * mx / w - 1, ny = 1 - 2 * my / h;
        Vec3 dir = new Vec3(look.x(), look.y(), look.z())
                .add(new Vec3(left.x(), left.y(), left.z()).scale(-nx * t * aspect))
                .add(new Vec3(up.x(), up.y(), up.z()).scale(ny * t)).normalize();
        Vec3 from = cam.getPosition();
        HitResult r = mc.level.clip(new ClipContext(from, from.add(dir.scale(256)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, mc.player));
        return r instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK ? b : null;
    }

    void stroke(boolean first) {
        if (hover == null) return;
        long now = System.currentTimeMillis();
        if (!first && now - lastStroke < 140) return;
        lastStroke = now;
        BlockPos hp = hover.getBlockPos(), face = hp.relative(hover.getDirection());
        String b = blockString();
        switch (tool) {
            case "Place" -> { if (first) send("set", b, "", face.getX(), face.getY(), face.getZ()); }
            case "Brush" -> send("brush", b, "", face.getX(), face.getY(), face.getZ(), radius, hollow ? 1 : 0);
            case "Cube" -> send("cube", b, "", face.getX(), face.getY(), face.getZ(), radius, hollow ? 1 : 0);
            case "Erase" -> send("erase", b, "", hp.getX(), hp.getY(), hp.getZ(), radius);
            case "Paint" -> send("paint", b, "", hp.getX(), hp.getY(), hp.getZ(), radius);
            case "Smooth" -> send("smooth", b, "", hp.getX(), hp.getY(), hp.getZ(), radius);
            case "Paste" -> { if (first) send("paste", "", "", face.getX(), face.getY(), face.getZ(), skipAir ? 1 : 0); }
        }
    }

    /**
     * Movement while the editor is open. Forge key mappings are inactive inside screens (IN_GAME context),
     * so the keys are read directly and written into the player's movement input (called from MovementInputUpdateEvent).
     */
    public static void movement(Input in) {
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.screen instanceof WorldEditorScreen w) || w.typing() || mc.player == null) return;
        var o = mc.options;
        boolean up = down(o.keyUp), dn = down(o.keyDown), l = down(o.keyLeft), r = down(o.keyRight);
        in.up = up; in.down = dn; in.left = l; in.right = r;
        in.forwardImpulse = up == dn ? 0 : up ? 1 : -1;
        in.leftImpulse = l == r ? 0 : l ? 1 : -1;
        in.jumping = down(o.keyJump);
        in.shiftKeyDown = down(o.keyShift);
        if (in.shiftKeyDown && !mc.player.getAbilities().flying) { in.forwardImpulse *= 0.3f; in.leftImpulse *= 0.3f; }
        if (down(o.keySprint) && up && !mc.player.isSprinting()) mc.player.setSprinting(true);
    }
    static boolean down(KeyMapping k) {
        var key = k.getKey();
        long win = Minecraft.getInstance().getWindow().getWindow();
        return switch (key.getType()) {
            case KEYSYM -> InputConstants.isKeyDown(win, key.getValue());
            case MOUSE -> GLFW.glfwGetMouseButton(win, key.getValue()) == GLFW.GLFW_PRESS;
            default -> false;
        };
    }

    @Override public void tick() { for (EditBox b : fields) b.tick(); }

    // ------------------------------------------------------------------ widgets (logical coordinates)
    void btn(GuiGraphics g, int x, int y, int w, String label, boolean sel, Runnable r) {
        boolean on = in(lmx, lmy, x, y, x + w, y + 14);
        round(g, x, y, x + w, y + 14, sel ? ACCENT : on ? 0x40FFFFFF : 0x22FFFFFF);
        centered(g, font, ellipsize(font, label, w - 4), x + w / 2, y + 3, 0xFFFFFFFF);
        hits.add(new Hit(x, y, x + w, y + 14, r));
    }
    void field(GuiGraphics g, EditBox b, int x, int y, int w) {
        boolean f = getFocused() == b;
        round(g, x, y, x + w, y + 14, f ? 0xEE1E1E2A : 0xDD15151C);
        if (f) outline(g, x, y, x + w, y + 14, ACCENT);
        b.setX(x + 4); b.setY(y + 3); b.setWidth(Math.max(10, w - 8)); b.visible = true;
    }
    void panelBg(GuiGraphics g, int x1, int y1, int x2, int y2) { round(g, x1, y1, x2, y2, ZOptions.bg(0x0E0E14)); outline(g, x1, y1, x2, y2, 0x30FFFFFF); }

    void item(GuiGraphics g, ItemStack st, int x, int y) { if (!st.isEmpty()) g.renderItem(st, x, y); }

    static final int TB = 20, AB = 16, SB = 13, LP = 78;   // top bar, action bar, status bar heights, left panel width
    static final String[][] ACTS = {{"Fill", "fill"}, {"Replace", "replace"}, {"Walls", "walls"}, {"Outline", "outline"}, {"Hollow", "hollow"},
            {"Clear", "clear"}, {"Naturalize", "naturalize"}, {"Line", "line"}, {"Count", "count"}, {"Copy", "copy"}};
    final List<int[]> ui = new ArrayList<>();
    void ui(int x1, int y1, int x2, int y2) { ui.add(new int[]{x1, y1, x2, y2}); }
    int bw(String s) { return font.width(s) + 8; }
    static String xyz(BlockPos p) { return p == null ? "—" : p.getX() + " " + p.getY() + " " + p.getZ(); }
    String selSize() { return (Math.abs(pos1.getX() - pos2.getX()) + 1) + "×" + (Math.abs(pos1.getY() - pos2.getY()) + 1) + "×" + (Math.abs(pos1.getZ() - pos2.getZ()) + 1); }

    @Override public void render(GuiGraphics g, int amx, int amy, float pt) {
        layout();
        hits.clear(); ui.clear(); tip = null;
        for (EditBox b : fields) b.visible = false;
        lmx = (int) (amx / S); lmy = (int) (amy / S);
        if (!looking) hover = ray(minecraft, amx, amy, width, height);
        if (selecting && hover != null) pos2 = hover.getBlockPos();

        g.pose().pushPose();
        g.pose().scale(S, S, 1);
        // ---- top bar
        g.fill(0, 0, lw, TB, ZOptions.bg(0x0E0E14));
        hGrad(g, 0, TB - 1, lw, TB, ACCENT, ACCENT2, (System.currentTimeMillis() % 100000) / 12000f);
        ui(0, 0, lw, TB);
        int x = 5;
        if (lw >= 680) { text(g, font, "World Editor", 6, 6, TEXT); x = 72; }
        boolean blocksMode = mode.equals("Blocks");
        if (!blocksMode) {
            String h = mode.equals("Entities") ? "Entities · " + (selUuid == null ? "nothing selected" : selName + " (" + selType.replace("minecraft:", "") + ")") + "  ·  Tab: next mode"
                    : "Structures · " + (structSel == null ? "choose one in the list" : structSel.replace("minecraft:", "") + "  " + sRot + "°") + "  ·  Tab: next mode";
            text(g, font, ellipsize(font, h, lw - x - 120), x, 6, TEXT);
        }
        if (blocksMode) {
        // current block(s)
        boolean bh = in(lmx, lmy, x, 2, x + 132, 18);
        round(g, x, 2, x + 132, 18, bh ? 0x40FFFFFF : 0x22FFFFFF);
        int ix = x + 1;
        for (int i = 0; i < Math.min(3, MIX.size()); i++) { item(g, stack(MIX.get(i)), ix, 2); ix += 16; }
        String lbl = MIX.size() == 1 ? MIX.get(0).replace("minecraft:", "") : MIX.size() + " mixed";
        text(g, font, ellipsize(font, lbl, x + 128 - ix), ix + 2, 6, TEXT);
        hits.add(new Hit(x, 2, x + 132, 18, () -> paletteOpen = !paletteOpen));
        x += 137;
        small(g, font, "R", x, 8, DIM); x += 6;
        btn(g, x, 3, 12, "-", false, () -> radius = Math.max(0, radius - 1)); x += 13;
        centered(g, font, String.valueOf(radius), x + 7, 6, TEXT); x += 15;
        btn(g, x, 3, 12, "+", false, () -> radius = Math.min(32, radius + 1)); x += 15;
        btn(g, x, 3, 34, hollow ? "Shell" : "Solid", hollow, () -> hollow = !hollow);
        if (in(lmx, lmy, x, 3, x + 34, 17)) tip = "Brush / Cube: solid or hollow shell (H)";
        x += 38;
        small(g, font, "FROM", x, 8, DIM); x += 20;
        int right = lw - (bw("Exit") + bw("Fly") + bw("Air: keep") + bw("Blocks ▾") + 18);
        int fw = Math.max(40, Math.min(90, right - x - 40));
        field(g, from, x, 3, fw); x += fw + 4;
        small(g, font, "×", x, 7, DIM); x += 6;
        field(g, times, x, 3, 24);
        }
        int rx = lw - 4;
        rx -= bw("Exit"); btn(g, rx, 3, bw("Exit"), "Exit", false, this::onClose);
        boolean flying = minecraft.player != null && minecraft.player.getAbilities().flying;
        rx -= bw("Fly") + 3; btn(g, rx, 3, bw("Fly"), "Fly", flying, () -> send("fly", "", ""));
        if (blocksMode) {
        rx -= bw("Air: keep") + 3; btn(g, rx, 3, bw("Air: keep"), skipAir ? "Air: skip" : "Air: keep", false, () -> skipAir = !skipAir);
        rx -= bw("Blocks ▾") + 3; btn(g, rx, 3, bw("Blocks ▾"), paletteOpen ? "Blocks ▾" : "Blocks ▸", paletteOpen, () -> paletteOpen = !paletteOpen);
        }

        // ---- tools (left)
        int py = TB + 5;
        String[] tl = tools();
        int ph = 9 + MODES.length * 15 + 10 + tl.length * 15;
        panelBg(g, 2, py - 3, LP, py + ph);
        ui(2, py - 3, LP, py + ph);
        small(g, font, "MODE", 6, py, DIM); py += 9;
        for (String m : MODES) { btn(g, 5, py, LP - 7, m, mode.equals(m), () -> setMode(m)); py += 15; }
        small(g, font, "TOOLS", 6, py + 1, DIM); py += 10;
        for (int i = 0; i < tl.length; i++) { String tt = tl[i]; btn(g, 5, py, LP - 7, (i + 1) + " " + tt, curTool().equals(tt), () -> setTool(tt)); py += 15; }
        if (mode.equals("Entities")) {
            hoverEnt = looking ? null : rayEntity(amx, amy);
        } else hoverEnt = null;
        if (!mode.equals("Entities")) {
        // ---- selection panel
        py += 6;
        int sy0 = py - 3;
        panelBg(g, 2, sy0, LP, sy0 + 104);
        ui(2, sy0, LP, sy0 + 104);
        small(g, font, "SELECTION", 6, py, DIM); py += 9;
        small(g, font, ellipsize(font, "1  " + xyz(pos1), (LP - 26) * 4 / 3), 6, py + 3, 0xFF5CD68A);
        btn(g, LP - 18, py, 14, "⌂", false, () -> setCorner(1)); if (in(lmx, lmy, LP - 18, py, LP - 4, py + 14)) tip = "Pos1 = your position  [";
        py += 15;
        small(g, font, ellipsize(font, "2  " + xyz(pos2), (LP - 26) * 4 / 3), 6, py + 3, 0xFFFF6B7A);
        btn(g, LP - 18, py, 14, "⌂", false, () -> setCorner(2)); if (in(lmx, lmy, LP - 18, py, LP - 4, py + 14)) tip = "Pos2 = your position  ]";
        py += 15;
        small(g, font, hasSel() ? "size " + selSize() : "no selection", 6, py + 1, hasSel() ? TEXT : FAINT); py += 10;
        int hw = (LP - 10) / 2;
        btn(g, 5, py, hw, "Grow", false, () -> grow(1)); btn(g, 6 + hw, py, hw, "Shrink", false, () -> grow(-1)); py += 15;
        btn(g, 5, py, hw, "Here", false, () -> { setCorner(1); setCorner(2); }); btn(g, 6 + hw, py, hw, "None", false, () -> { pos1 = pos2 = null; }); py += 15;
        btn(g, 5, py, hw, "Go 1", false, () -> { if (pos1 != null) send("tp", "", "", pos1.getX(), pos1.getY(), pos1.getZ()); });
        btn(g, 6 + hw, py, hw, "Go 2", false, () -> { if (pos2 != null) send("tp", "", "", pos2.getX(), pos2.getY(), pos2.getZ()); });
        if (in(lmx, lmy, 2, sy0, LP, sy0 + 104) && tip == null) tip = "Arrows / PgUp / PgDn: move · +Shift: expand · +Alt: shrink";
        }

        // ---- right panel
        if (mode.equals("Entities")) renderEntityPanel(g);
        else if (mode.equals("Structures")) renderStructPanel(g);
        else if (paletteOpen) renderPalette(g);

        // ---- action bar (bottom)
        int ay = lh - SB - AB;
        g.fill(0, ay, lw, lh - SB, ZOptions.bg(0x0B0B10));
        ui(0, ay, lw, lh);
        List<Object[]> acts = new ArrayList<>();
        if (!mode.equals("Blocks")) acts.addAll(extraActions()); else {
        for (String[] a2 : ACTS) acts.add(new Object[]{a2[0], (Runnable) () -> selOp(a2[1])});
        acts.add(new Object[]{"Stack", (Runnable) this::stack});
        acts.add(new Object[]{"Move", (Runnable) this::move});
        acts.add(new Object[]{"Rotate", (Runnable) () -> send("rotate", "", "")});
        acts.add(new Object[]{"Flip", (Runnable) this::flip});
        acts.add(new Object[]{"Undo", (Runnable) () -> send("undo", "", "")});
        acts.add(new Object[]{"Redo", (Runnable) () -> send("redo", "", "")});
        }
        int tot = 0; for (Object[] a2 : acts) tot += bw((String) a2[0]) + 2;
        int ax = Math.max(4, (lw - tot) / 2);
        for (Object[] a2 : acts) { String l2 = (String) a2[0]; int w2 = bw(l2); btn(g, ax, ay + 1, w2, l2, false, (Runnable) a2[1]); ax += w2 + 2; }

        // ---- info (cursor)
        String pos = (hover != null ? "⌖ " + hover.getBlockPos().toShortString() + "  " : "") + (hasSel() ? "▣ " + selSize() : "");
        int infoX = paletteOpen || !mode.equals("Blocks") ? palX0() - 6 : lw - 6;
        if (hoverEnt != null) { String en = "◆ " + hoverEnt.getName().getString(); text(g, font, en, infoX - font.width(en), TB + 26, 0xFF4FD1C5); }
        text(g, font, pos, infoX - font.width(pos), TB + 5, TEXT);
        if (hover != null && minecraft.level != null) {
            String hid = id(minecraft.level.getBlockState(hover.getBlockPos()).getBlock());
            small(g, font, hid, infoX - (int) (font.width(hid) * 0.75f), TB + 16, DIM);
        }
        // ---- status
        int by = lh - SB;
        g.fill(0, by, lw, lh, ZOptions.bg(0x0E0E14));
        String info = curTip() + "  ·  Tab mode · RMB-drag look · WASD/Space/Shift move · F fly · T teleport · [ ] corners · MMB pick · Ctrl+wheel radius · Ctrl+Z/Y · Esc";
        boolean showMsg = !msg.isEmpty() && System.currentTimeMillis() - msgT < 8000;
        small(g, font, ellipsize(font, showMsg ? msg : info, lw * 4 / 3 - 12), 6, by + 3, showMsg ? (msgOk ? 0xFFB8F0CC : ERR) : DIM);

        super.render(g, lmx, lmy, pt);
        if (tip != null) {
            int tw = font.width(tip) + 8, tx = Math.min(lmx + 10, lw - tw - 2), ty = Math.min(lmy + 12, lh - 15);
            round(g, tx, ty, tx + tw, ty + 13, 0xF0101018);
            text(g, font, tip, tx + 4, ty + 3, TEXT);
        }
        g.pose().popPose();
    }

    // ------------------------------------------------------------------ selection helpers
    BlockPos playerPos() { return minecraft.player == null ? null : minecraft.player.blockPosition(); }
    void setCorner(int which) {
        BlockPos p = playerPos();
        if (p == null) return;
        if (which == 1) { pos1 = p; if (pos2 == null) pos2 = p; } else { pos2 = p; if (pos1 == null) pos1 = p; }
        local(true, "Pos" + which + " = " + xyz(p) + (hasSel() ? "  ·  " + selSize() : ""));
    }
    void grow(int d) {
        if (!hasSel()) { local(false, "Select a region first"); return; }
        BlockPos mn = new BlockPos(Math.min(pos1.getX(), pos2.getX()), Math.min(pos1.getY(), pos2.getY()), Math.min(pos1.getZ(), pos2.getZ()));
        BlockPos mx = new BlockPos(Math.max(pos1.getX(), pos2.getX()), Math.max(pos1.getY(), pos2.getY()), Math.max(pos1.getZ(), pos2.getZ()));
        if (d < 0 && (mx.getX() - mn.getX() < 2 || mx.getY() - mn.getY() < 2 || mx.getZ() - mn.getZ() < 2)) { local(false, "Selection is too small to shrink"); return; }
        pos1 = mn.offset(-d, -d, -d); pos2 = mx.offset(d, d, d);
        local(true, "Selection " + selSize());
    }
    /** horizontal look direction, or UP / DOWN when looking steeply */
    net.minecraft.core.Direction lookDir() {
        var p = minecraft.player;
        return p.getXRot() < -50 ? net.minecraft.core.Direction.UP : p.getXRot() > 50 ? net.minecraft.core.Direction.DOWN : p.getDirection();
    }
    /** mode 0 = move the selection, 1 = expand the face in d, 2 = pull that face back */
    void nudge(net.minecraft.core.Direction d, int mode) {
        if (!hasSel()) { local(false, "Select a region first"); return; }
        if (mode == 0) { pos1 = pos1.relative(d); pos2 = pos2.relative(d); }
        else {
            var ax = d.getAxis();
            int sign = d.getAxisDirection().getStep();
            int c1 = pos1.get(ax) * sign, c2 = pos2.get(ax) * sign;
            boolean firstFront = c1 >= c2;
            if (mode == 1) { if (firstFront) pos1 = pos1.relative(d); else pos2 = pos2.relative(d); }
            else {
                if (c1 == c2) { local(false, "Can't shrink below 1 block"); return; }
                if (firstFront) pos1 = pos1.relative(d.getOpposite()); else pos2 = pos2.relative(d.getOpposite());
            }
        }
        local(true, (mode == 0 ? "Moved selection " : mode == 1 ? "Expanded " : "Shrunk ") + d.getName() + "  ·  " + selSize());
    }
    int timesN() { try { return Math.max(1, Integer.parseInt(times.getValue().trim())); } catch (Exception e) { return 1; } }
    void move() {
        if (!hasSel()) { local(false, "Select a region first"); return; }
        var d = lookDir();
        int t = timesN();
        send("move", "", "", sel(d.getStepX(), d.getStepY(), d.getStepZ(), t));
        pos1 = pos1.relative(d, t); pos2 = pos2.relative(d, t);
    }
    void flip() {
        var d = lookDir();
        send("flip", "", "", d.getAxis() == net.minecraft.core.Direction.Axis.X ? 0 : d.getAxis() == net.minecraft.core.Direction.Axis.Y ? 1 : 2);
    }

    static final int CELL = 18, COLS = 8;
    int palX0() { return lw - 4 - (COLS * CELL + 12); }

    void renderPalette(GuiGraphics g) {
        int x0 = palX0(), x1 = lw - 4, y0 = TB + 3, y1 = lh - SB - AB - 3;
        panelBg(g, x0, y0, x1, y1);
        int y = y0 + 4;
        field(g, search, x0 + 4, y, x1 - x0 - 8); y += 18;
        // mix
        small(g, font, "MIX · Shift+click adds · RMB removes", x0 + 5, y, DIM); y += 8;
        int cx = x0 + 5;
        for (String m : new ArrayList<>(MIX)) {
            if (cx + CELL > x1 - 4) break;
            boolean on = in(lmx, lmy, cx, y, cx + CELL - 1, y + CELL - 1);
            round(g, cx, y, cx + CELL - 1, y + CELL - 1, on ? 0x55FF6B7A : alpha(ACCENT, 0.35f));
            item(g, stack(m), cx + 1, y + 1);
            if (on) tip = m + "  (click: remove)";
            hits.add(new Hit(cx, y, cx + CELL - 1, y + CELL - 1, () -> { if (MIX.size() > 1) MIX.remove(m); }));
            cx += CELL;
        }
        y += CELL + 3;
        if (!RECENT.isEmpty()) {
            small(g, font, "RECENT", x0 + 5, y, DIM); y += 8;
            cx = x0 + 5;
            for (String m : RECENT) {
                if (cx + CELL > x1 - 4) break;
                cell(g, cx, y, m);
                cx += CELL;
            }
            y += CELL + 3;
        }
        g.fill(x0 + 4, y, x1 - 4, y + 1, 0x30FFFFFF); y += 3;
        // grid
        String q = search.getValue().trim().toLowerCase(Locale.ROOT);
        List<String> ids = new ArrayList<>();
        for (Block b : allBlocks()) { String id = id(b); if (q.isEmpty() || id.contains(q)) ids.add(id); }
        int gy0 = y, gy1 = y1 - 4, rows = (ids.size() + COLS - 1) / COLS;
        int max = Math.max(0, rows * CELL - (gy1 - gy0));
        palScroll = Math.max(0, Math.min(palScroll, max));
        scissorL(g, x0, gy0, x1, gy1);
        int first = palScroll / CELL;
        for (int i = first * COLS; i < ids.size(); i++) {
            int r = i / COLS, c = i % COLS;
            int ccx = x0 + 5 + c * CELL, ccy = gy0 + r * CELL - palScroll;
            if (ccy > gy1) break;
            if (ccy + CELL < gy0) continue;
            cell(g, ccx, ccy, ids.get(i), gy0, gy1);
        }
        g.disableScissor();
        if (ids.isEmpty()) small(g, font, "nothing found", x0 + 8, gy0 + 4, FAINT);
        if (max > 0) {
            int th = Math.max(12, (gy1 - gy0) * (gy1 - gy0) / (rows * CELL)), ty = gy0 + (gy1 - gy0 - th) * palScroll / max;
            round(g, x1 - 4, ty, x1 - 2, ty + th, 0x50FFFFFF);
        }
        hits.add(0, new Hit(x0, y0, x1, y1, () -> {}));   // the panel swallows clicks (no world edit behind it)
        ui(x0, y0, x1, y1);
    }

    void cell(GuiGraphics g, int x, int y, String id) { cell(g, x, y, id, Integer.MIN_VALUE, Integer.MAX_VALUE); }
    void cell(GuiGraphics g, int x, int y, String id, int clipTop, int clipBot) {
        boolean sel = MIX.contains(id);
        boolean on = in(lmx, lmy, x, y, x + CELL - 1, y + CELL - 1) && lmy >= clipTop && lmy < clipBot;
        if (sel || on) round(g, x, y, x + CELL - 1, y + CELL - 1, sel ? alpha(ACCENT, 0.45f) : 0x30FFFFFF);
        item(g, stack(id), x + 1, y + 1);
        if (on) tip = id;
        if (y + CELL > clipTop && y < clipBot)
            hits.add(new Hit(x, Math.max(y, clipTop), x + CELL - 1, Math.min(y + CELL - 1, clipBot), () -> pick(id, hasShiftDown())));
    }

    /** scissor in logical units (this screen is drawn scaled from 0,0) */
    void scissorL(GuiGraphics g, int x1, int y1, int x2, int y2) {
        g.enableScissor((int) Math.floor(x1 * S), (int) Math.floor(y1 * S), (int) Math.ceil(x2 * S), (int) Math.ceil(y2 * S));
    }

    // ================================================================== v0.5.2: Entities / Structures modes
    static final String[] MODES = {"Blocks", "Entities", "Structures"};
    static final String[] ETOOLS = {"Select", "Spawn", "Move"};
    static final String[] STOOLS = {"Select", "Place"};
    static final String[] ETIPS = {"LMB: select an entity / player (shows the Inspector)", "LMB: spawn the chosen entity type on the face", "LMB: move the selected entity to the face"};
    static final String[] STIPS = {"LMB-drag: select a box (Save selection makes a structure)", "LMB: place the chosen structure (outline = footprint)"};
    static String mode = "Blocks", eTool = "Select", sTool = "Select", eTab = "Spawn";
    static String spawnType = "minecraft:zombie", selUuid = null, selType = "", selName = "", selPart = "Model";
    static final List<String[]> EPROPS = new ArrayList<>();   // key, value
    static final List<String[]> EPARTS = new ArrayList<>();   // name, hidden, xf
    static final List<String> EFILES = new ArrayList<>(), ETYPES = new ArrayList<>(), SLIST = new ArrayList<>();
    static final List<String[]> NEAR = new ArrayList<>();     // uuid, type, name, dist
    static String structSel = null, sRot = "0", sMirror = "none";
    static boolean sEnts = true;
    static int[] sSize;
    static boolean dataDirty;
    static net.minecraft.world.entity.Entity hoverEnt;
    int listScroll, insScroll;
    final Map<String, EditBox> ebox = new LinkedHashMap<>();
    static final String[] EKEYS = {"Name", "Position", "Yaw", "Health", "MaxHealth", "Model", "ModelScale", "Hitbox"};
    static final Set<String> EBOOLS = Set.of("NoAI", "Persistent", "Glowing", "Invulnerable", "Silent", "NoGravity", "NameVisible");
    EditBox eSearch, sSearch, sName, pOff, pRot, pScale;

    static void data(Pkt p) {
        String kind = p.s(1);
        List<String> rows = p.s.size() > 2 ? p.s.subList(2, p.s.size()) : List.of();
        switch (kind) {
            case "einfo" -> {
                if (rows.size() < 3) return;
                selUuid = rows.get(0); selType = rows.get(1); selName = rows.get(2);
                EPROPS.clear(); EPARTS.clear(); EFILES.clear();
                for (String r : rows.subList(3, rows.size())) {
                    String[] a = r.split("\t", -1);
                    if (a[0].equals("#part")) EPARTS.add(new String[]{a[1], a[2], a.length > 3 ? a[3] : ""});
                    else if (a[0].equals("#file")) EFILES.add(a[1]);
                    else EPROPS.add(new String[]{a[0], a.length > 1 ? a[1] : ""});
                }
                try { // parts of the real client model (any vanilla / mod entity)
                    var lvl = Minecraft.getInstance().level;
                    if (lvl != null) for (var en : lvl.entitiesForRendering()) if (en.getUUID().toString().equals(selUuid)) {
                        Set<String> have = new HashSet<>(); for (String[] x : EPARTS) have.add(x[0]);
                        for (String n : net.idea.fluwa.client.ModelParts.namesFor(en)) if (have.add(n)) EPARTS.add(new String[]{n, "0", ""});
                        break;
                    }
                } catch (Throwable ignored) {}
                boolean has = false; for (String[] x : EPARTS) if (x[0].equals(selPart)) has = true;
                if (!has) selPart = "Model";
                if (eTool.equals("Select")) eTab = "Inspect";
                dataDirty = true;
            }
            case "etypes" -> { ETYPES.clear(); ETYPES.addAll(rows); }
            case "enear" -> { NEAR.clear(); for (String r : rows) NEAR.add(r.split("\t", -1)); }
            case "slist" -> { SLIST.clear(); SLIST.addAll(rows); }
            case "sinfo" -> { if (rows.size() >= 4 && rows.get(0).equals(structSel)) try { sSize = new int[]{Integer.parseInt(rows.get(1)), Integer.parseInt(rows.get(2)), Integer.parseInt(rows.get(3))}; } catch (Exception ignored) {} }
            case "sbox" -> {
                try {
                    pos1 = new BlockPos(Integer.parseInt(rows.get(0)), Integer.parseInt(rows.get(1)), Integer.parseInt(rows.get(2)));
                    pos2 = new BlockPos(Integer.parseInt(rows.get(3)), Integer.parseInt(rows.get(4)), Integer.parseInt(rows.get(5)));
                } catch (Exception ignored) {}
            }
        }
    }

    String prop(String k) { for (String[] p : EPROPS) if (p[0].equals(k)) return p[1]; return null; }
    String[] part(String n) { for (String[] p : EPARTS) if (p[0].equals(n)) return p; return null; }

    void selectEntity(String uuid) { selUuid = uuid; send("einfo", uuid, ""); eTab = "Inspect"; }

    /** pushes fresh server values into the inspector boxes (unless the user is typing in them) */
    void syncInspector() {
        if (!dataDirty) return;
        dataDirty = false;
        for (String k : EKEYS) { EditBox b = ebox.get(k); String v = prop(k); if (b != null && getFocused() != b) b.setValue(v == null ? "" : v); }
        syncPart();
    }
    void syncPart() {
        String[] p = part(selPart);
        float[] f = p == null ? net.idea.fluwa.api.ModelSync.IDENTITY_XF : net.idea.fluwa.api.ModelSync.parseXf(p[2]);
        if (f == null) f = net.idea.fluwa.api.ModelSync.IDENTITY_XF;
        if (getFocused() != pOff) pOff.setValue(v3(f, 0));
        if (getFocused() != pRot) pRot.setValue(v3(f, 3));
        if (getFocused() != pScale) pScale.setValue(v3(f, 6));
    }
    static String v3(float[] f, int o) { return fmt(f[o]) + " " + fmt(f[o + 1]) + " " + fmt(f[o + 2]); }
    static String fmt(float v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.format(Locale.ROOT, "%.2f", v); }
    static float[] parse3(String s, float d) {
        String[] a = s.trim().split("[,; ]+");
        float[] r = {d, d, d};
        if (a.length == 1 && !a[0].isEmpty()) { try { float v = Float.parseFloat(a[0]); return new float[]{v, v, v}; } catch (Exception ignored) {} }
        for (int i = 0; i < Math.min(3, a.length); i++) try { r[i] = Float.parseFloat(a[i]); } catch (Exception ignored) {}
        return r;
    }
    void applyPart() {
        if (selUuid == null) return;
        float[] o = parse3(pOff.getValue(), 0), r = parse3(pRot.getValue(), 0), sc = parse3(pScale.getValue(), 1);
        float[] f = {o[0], o[1], o[2], r[0], r[1], r[2], sc[0], sc[1], sc[2]};
        send("epart", selUuid, selPart + "\t\t" + net.idea.fluwa.api.ModelSync.xfString(f));
    }

    /** entity under the cursor (closer than the hovered block) */
    net.minecraft.world.entity.Entity rayEntity(double mx, double my) {
        Minecraft mc = minecraft;
        if (mc.level == null || mc.player == null) return null;
        var cam = mc.gameRenderer.getMainCamera();
        Vector3f look = cam.getLookVector(), up = cam.getUpVector(), left = cam.getLeftVector();
        double fov = Math.toRadians(mc.options.fov().get());
        double t = Math.tan(fov / 2), aspect = (double) mc.getWindow().getWidth() / Math.max(1, mc.getWindow().getHeight());
        double nx = 2 * mx / width - 1, ny = 1 - 2 * my / height;
        Vec3 dir = new Vec3(look.x(), look.y(), look.z()).add(new Vec3(left.x(), left.y(), left.z()).scale(-nx * t * aspect)).add(new Vec3(up.x(), up.y(), up.z()).scale(ny * t)).normalize();
        Vec3 from = cam.getPosition();
        double max = hover != null ? hover.getLocation().distanceTo(from) + 0.5 : 128;
        Vec3 to = from.add(dir.scale(max));
        net.minecraft.world.entity.Entity best = null; double bd = Double.MAX_VALUE;
        for (net.minecraft.world.entity.Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player) continue; // use the Me button
            var hit = e.getBoundingBox().inflate(0.15).clip(from, to);
            if (hit.isPresent()) { double d = hit.get().distanceToSqr(from); if (d < bd) { bd = d; best = e; } }
        }
        return best;
    }
    net.minecraft.world.entity.Entity selectedEntity() {
        if (selUuid == null || minecraft.level == null) return null;
        for (net.minecraft.world.entity.Entity e : minecraft.level.entitiesForRendering()) if (e.getUUID().toString().equals(selUuid)) return e;
        return null;
    }

    /** footprint of the chosen structure at the hovered face (rotation / mirror like the server) */
    BlockPos[] footprint(BlockPos at) {
        if (sSize == null) return null;
        int[] a = {0, 0, 0}, b = {sSize[0] - 1, sSize[1] - 1, sSize[2] - 1};
        int[][] c = {tr(a[0], a[2]), tr(b[0], b[2]), tr(a[0], b[2]), tr(b[0], a[2])};
        int mnx = Integer.MAX_VALUE, mnz = Integer.MAX_VALUE, mxx = Integer.MIN_VALUE, mxz = Integer.MIN_VALUE;
        for (int[] q : c) { mnx = Math.min(mnx, q[0]); mxx = Math.max(mxx, q[0]); mnz = Math.min(mnz, q[1]); mxz = Math.max(mxz, q[1]); }
        return new BlockPos[]{at.offset(mnx, 0, mnz), at.offset(mxx, sSize[1] - 1, mxz)};
    }
    int[] tr(int x, int z) {
        if (sMirror.equals("x")) x = -x; else if (sMirror.equals("z")) z = -z;
        return switch (sRot) { case "90" -> new int[]{-z, x}; case "180" -> new int[]{-x, -z}; case "270" -> new int[]{z, -x}; default -> new int[]{x, z}; };
    }

    int toolCount() { return mode.equals("Entities") ? ETOOLS.length : mode.equals("Structures") ? STOOLS.length : TOOLS.length; }
    String[] tools() { return mode.equals("Entities") ? ETOOLS : mode.equals("Structures") ? STOOLS : TOOLS; }
    String curTool() { return mode.equals("Entities") ? eTool : mode.equals("Structures") ? sTool : tool; }
    void setTool(String t) { if (mode.equals("Entities")) eTool = t; else if (mode.equals("Structures")) sTool = t; else tool = t; }
    String curTip() {
        int i = Arrays.asList(tools()).indexOf(curTool());
        String[] tips = mode.equals("Entities") ? ETIPS : mode.equals("Structures") ? STIPS : TIPS;
        return tips[Math.max(0, i)];
    }
    void setMode(String m) {
        mode = m; listScroll = 0;
        if (m.equals("Entities") && ETYPES.isEmpty()) send("etypes", "", "");
        if (m.equals("Entities")) send("enear", "", "", 48);
        if (m.equals("Structures") && SLIST.isEmpty()) send("slist", "", "");
        local(true, m + " mode");
    }

    // ------------------------------------------------------------------ right panels
    int rowList(GuiGraphics g, int x0, int x1, int y, int y1, List<String[]> rows, java.util.function.Predicate<String[]> sel, java.util.function.Consumer<String[]> click, boolean icons) {
        int rh = icons ? 14 : 11;
        int max = Math.max(0, rows.size() * rh - (y1 - y));
        listScroll = Math.max(0, Math.min(listScroll, max));
        scissorL(g, x0, y, x1, y1);
        int yy = y - listScroll;
        for (String[] r : rows) {
            if (yy + rh > y && yy < y1) {
                boolean on = in(lmx, lmy, x0 + 2, yy, x1 - 3, yy + rh - 1) && lmy >= y && lmy < y1;
                boolean s = sel.test(r);
                if (s || on) round(g, x0 + 2, yy, x1 - 3, yy + rh - 1, s ? alpha(ACCENT, 0.45f) : 0x30FFFFFF);
                int tx = x0 + 5;
                if (icons) {
                    var egg = net.minecraft.world.item.SpawnEggItem.byId(BuiltInRegistries.ENTITY_TYPE.get(ResourceLocation.tryParse(r[0])));
                    if (egg != null) { g.pose().pushPose(); g.pose().translate(tx, yy + 1, 0); g.pose().scale(0.75f, 0.75f, 1); g.renderItem(new ItemStack(egg), 0, 0); g.pose().popPose(); }
                    tx += 15;
                }
                small(g, font, ellipsize(font, r[1], (x1 - tx - 8 - (r.length > 2 ? 28 : 0)) * 4 / 3), tx, yy + (icons ? 4 : 2), TEXT);
                if (r.length > 2 && !r[2].isEmpty()) small(g, font, ellipsize(font, r[2], 36), x1 - 30, yy + (icons ? 4 : 2), DIM);
                int cy1 = Math.max(yy, y), cy2 = Math.min(yy + rh - 1, y1);
                hits.add(new Hit(x0 + 2, cy1, x1 - 3, cy2, () -> click.accept(r)));
            }
            yy += rh;
        }
        g.disableScissor();
        if (max > 0) {
            int th = Math.max(10, (y1 - y) * (y1 - y) / (rows.size() * rh)), ty = y + (y1 - y - th) * listScroll / max;
            round(g, x1 - 3, ty, x1 - 1, ty + th, 0x50FFFFFF);
        }
        if (rows.isEmpty()) small(g, font, "nothing here", x0 + 6, y + 3, FAINT);
        return yy;
    }

    void tabs(GuiGraphics g, int x0, int x1, int y, String[] names, String cur, java.util.function.Consumer<String> set) {
        int w = (x1 - x0 - 8) / names.length, x = x0 + 4;
        for (String n : names) { btn(g, x, y, w - 2, n, n.equals(cur), () -> { set.accept(n); listScroll = 0; }); x += w; }
    }

    void renderEntityPanel(GuiGraphics g) {
        int x0 = palX0(), x1 = lw - 4, y0 = TB + 3, y1 = lh - SB - AB - 3;
        panelBg(g, x0, y0, x1, y1);
        hits.add(new Hit(x0, y0, x1, y1, () -> {}));
        ui(x0, y0, x1, y1);
        int y = y0 + 4;
        tabs(g, x0, x1, y, new String[]{"Spawn", "Nearby", "Inspect"}, eTab, v -> {
            eTab = v;
            if (v.equals("Nearby")) send("enear", "", "", 48);
            if (v.equals("Inspect") && selUuid != null) send("einfo", selUuid, "");
        });
        y += 18;
        switch (eTab) {
            case "Spawn" -> {
                field(g, eSearch, x0 + 4, y, x1 - x0 - 8); y += 17;
                small(g, font, "chosen: " + spawnType.replace("minecraft:", "") + " · tool Spawn", x0 + 5, y, DIM); y += 9;
                String q = eSearch.getValue().trim().toLowerCase(Locale.ROOT);
                List<String[]> rows = new ArrayList<>();
                for (String t : ETYPES) if (q.isEmpty() || t.contains(q)) rows.add(new String[]{t, t.replace("minecraft:", "")});
                if (ETYPES.isEmpty()) small(g, font, "loading…", x0 + 6, y + 2, FAINT);
                else rowList(g, x0, x1, y, y1 - 3, rows, r -> r[0].equals(spawnType), r -> { spawnType = r[0]; eTool = "Spawn"; local(true, "Spawn: " + r[1] + " — click a block"); }, true);
            }
            case "Nearby" -> {
                small(g, font, "within 48 blocks · click to inspect", x0 + 5, y, DIM); y += 10;
                List<String[]> rows = new ArrayList<>();
                for (String[] n : NEAR) rows.add(new String[]{n[0], n[2] + (n[2].equalsIgnoreCase(n[1]) ? "" : "  (" + n[1] + ")"), n[3] + "m"});
                rowList(g, x0, x1, y, y1 - 3, rows, r -> r[0].equals(selUuid), r -> selectEntity(r[0]), false);
            }
            default -> renderInspector(g, x0, x1, y, y1);
        }
    }

    void renderInspector(GuiGraphics g, int x0, int x1, int top, int y1) {
        if (selUuid == null) { small(g, font, "Select tool: click an entity or player", x0 + 6, top + 3, FAINT); small(g, font, "(or pick one in Nearby)", x0 + 6, top + 12, FAINT); return; }
        syncInspector();
        int bot = y1 - 3;
        int content = 34 + (EKEYS.length + EBOOLS.size()) * 15 + 30 + EPARTS.size() * 12 + 70;
        insScroll = Math.max(0, Math.min(insScroll, Math.max(0, content - (bot - top))));
        int y = top - insScroll;
        int lx = x0 + 5, vx = x0 + 52, vw2 = x1 - vx - 5;
        scissorL(g, x0, top, x1, bot);
        if (y + 10 > top) { text(g, font, ellipsize(font, selName, x1 - x0 - 10), lx, y + 1, TEXT); }
        y += 11;
        if (y + 8 > top) small(g, font, ellipsize(font, selType + " · " + selUuid.substring(0, 8), (x1 - x0 - 10) * 4 / 3), lx, y, DIM);
        y += 11;
        // property rows
        for (String k : EKEYS) {
            String v = prop(k);
            EditBox b = ebox.get(k);
            if (v == null) { if (b != null) b.visible = false; continue; }
            boolean vis = y >= top && y + 14 <= bot;
            if (vis) { small(g, font, k, lx, y + 4, DIM); field(g, b, vx, y, vw2); if (getFocused() == b) tip = "Enter: apply " + k; }
            y += 15;
        }
        // model file chips
        if (prop("Model") != null && !EFILES.isEmpty()) {
            int cx = vx;
            for (String f : java.util.stream.Stream.concat(java.util.stream.Stream.of("—"), EFILES.stream()).toList()) {
                int w = Math.min(vw2, (int) (font.width(f) * 0.75f) + 6);
                if (cx + w > x1 - 4) { cx = vx; y += 11; }
                if (y >= top && y + 10 <= bot) {
                    boolean on = in(lmx, lmy, cx, y, cx + w, y + 10);
                    round(g, cx, y, cx + w, y + 10, on ? 0x40FFFFFF : 0x22FFFFFF);
                    small(g, font, ellipsize(font, f, (w - 4) * 4 / 3), cx + 3, y + 2, f.equals(prop("Model")) ? ACCENT2 : TEXT);
                    String val = f.equals("—") ? "" : f;
                    hits.add(new Hit(cx, y, cx + w, y + 10, () -> send("eset", selUuid, "Model=" + val)));
                }
                cx += w + 2;
            }
            y += 13;
        }
        // flags
        int col = 0;
        for (String[] p : EPROPS) {
            if (!EBOOLS.contains(p[0])) continue;
            int hw = (x1 - x0 - 10) / 2, bx = x0 + 5 + col * (hw + 2);
            boolean on = p[1].equals("true");
            if (y >= top && y + 14 <= bot) btn(g, bx, y, hw, (on ? "✔ " : "  ") + p[0], on, () -> send("eset", selUuid, p[0] + "=" + !on));
            if (++col == 2) { col = 0; y += 15; }
        }
        if (col != 0) y += 15;
        // parts
        y += 3;
        if (y >= top && y + 8 <= bot) small(g, font, "MODEL PARTS · eye = visible · click = edit", lx, y, DIM);
        y += 10;
        for (String[] p : EPARTS) {
            boolean vis = y >= top && y + 11 <= bot;
            if (vis) {
                boolean s = p[0].equals(selPart);
                boolean on = in(lmx, lmy, x0 + 3, y, x1 - 18, y + 11);
                if (s || on) round(g, x0 + 3, y, x1 - 18, y + 11, s ? alpha(ACCENT, 0.45f) : 0x30FFFFFF);
                boolean moved = !p[2].isEmpty() && !net.idea.fluwa.api.ModelSync.isIdentity(net.idea.fluwa.api.ModelSync.parseXf(p[2]));
                small(g, font, p[0] + (moved ? "  •" : ""), lx + 2, y + 2, p[1].equals("1") ? FAINT : TEXT);
                hits.add(new Hit(x0 + 3, y, x1 - 18, y + 11, () -> { selPart = p[0]; syncPart(); }));
                boolean hid = p[1].equals("1");
                btn(g, x1 - 17, y - 1, 13, hid ? "–" : "◉", !hid, () -> send("epart", selUuid, p[0] + "\t" + (hid ? "0" : "1")));
            }
            y += 12;
        }
        y += 3;
        String[] lab = {"Offset", "Rotation°", "Scale"};
        EditBox[] bs = {pOff, pRot, pScale};
        if (y >= top && y + 8 <= bot) small(g, font, "PART " + selPart + " (blocks · degrees · ×)", lx, y, ACCENT2);
        y += 10;
        for (int i = 0; i < 3; i++) {
            if (y >= top && y + 14 <= bot) { small(g, font, lab[i], lx, y + 4, DIM); field(g, bs[i], vx, y, vw2); }
            y += 15;
        }
        if (y >= top && y + 14 <= bot) {
            int hw = (x1 - x0 - 12) / 2;
            btn(g, x0 + 5, y, hw, "Apply", true, this::applyPart);
            btn(g, x0 + 7 + hw, y, hw, "Reset", false, () -> send("epart", selUuid, selPart + "\t\t"));
        }
        g.disableScissor();
    }

    void renderStructPanel(GuiGraphics g) {
        int x0 = palX0(), x1 = lw - 4, y0 = TB + 3, y1 = lh - SB - AB - 3;
        panelBg(g, x0, y0, x1, y1);
        hits.add(new Hit(x0, y0, x1, y1, () -> {}));
        ui(x0, y0, x1, y1);
        int y = y0 + 4;
        field(g, sSearch, x0 + 4, y, x1 - x0 - 8); y += 17;
        int listBot = y1 - 108;
        String q = sSearch.getValue().trim().toLowerCase(Locale.ROOT);
        List<String[]> rows = new ArrayList<>();
        for (String t : SLIST) if (q.isEmpty() || t.contains(q)) rows.add(new String[]{t, t.replace("minecraft:", "")});
        if (SLIST.isEmpty()) small(g, font, "loading… (Refresh)", x0 + 6, y + 2, FAINT);
        else rowList(g, x0, x1, y, listBot, rows, r -> r[0].equals(structSel), r -> { structSel = r[0]; sSize = null; sTool = "Place"; send("sinfo", r[0], ""); local(true, "Structure " + r[1] + " — click to place"); }, false);
        y = listBot + 3;
        g.fill(x0 + 4, y, x1 - 4, y + 1, 0x30FFFFFF); y += 4;
        small(g, font, structSel == null ? "no structure chosen" : ellipsize(font, structSel.replace("minecraft:", ""), (x1 - x0 - 10) * 4 / 3), x0 + 5, y, structSel == null ? FAINT : TEXT); y += 9;
        if (sSize != null) small(g, font, "size " + sSize[0] + "×" + sSize[1] + "×" + sSize[2], x0 + 5, y, DIM);
        y += 10;
        int w4 = (x1 - x0 - 8) / 4;
        String[] rots = {"0", "90", "180", "270"};
        for (int i = 0; i < 4; i++) { String r = rots[i]; btn(g, x0 + 4 + i * w4, y, w4 - 2, r + "°", sRot.equals(r), () -> sRot = r); }
        y += 15;
        String[] mir = {"none", "x", "z"};
        int w3 = (x1 - x0 - 8 - 44) / 3;
        for (int i = 0; i < 3; i++) { String m = mir[i]; btn(g, x0 + 4 + i * w3, y, w3 - 2, i == 0 ? "no mirror" : "mirror " + m, sMirror.equals(m), () -> sMirror = m); }
        btn(g, x1 - 46, y, 42, sEnts ? "✔ mobs" : "  mobs", sEnts, () -> sEnts = !sEnts);
        if (in(lmx, lmy, x1 - 46, y, x1 - 4, y + 14)) tip = "Place / save entities too";
        y += 17;
        small(g, font, "SAVE SELECTION AS", x0 + 5, y, DIM); y += 9;
        int bw2 = bw("Save");
        field(g, sName, x0 + 4, y, x1 - x0 - 10 - bw2);
        btn(g, x1 - 4 - bw2, y, bw2, "Save", true, this::saveStruct);
        y += 17;
        int hw = (x1 - x0 - 10) / 2;
        btn(g, x0 + 4, y, hw, "Load to edit", false, this::loadStruct);
        if (in(lmx, lmy, x0 + 4, y, x0 + 4 + hw, y + 14)) tip = "Place at Pos1 (or your position) and select it; edit, then Save with the same name";
        btn(g, x0 + 6 + hw, y, hw, "Refresh", false, () -> send("slist", "", ""));
    }

    void saveStruct() {
        if (!hasSel()) { local(false, "Select a region first (Select tool)"); return; }
        String n = sName.getValue().trim();
        if (n.isEmpty() && structSel != null) n = structSel;
        if (n.isEmpty()) { local(false, "Enter a name"); return; }
        send("ssave", n, sEnts ? "1" : "0", sel());
        String full = n.contains(":") ? n : "fluwa:" + n;
        if (!SLIST.contains(full)) { SLIST.add(0, full); }
        structSel = full;
    }
    void loadStruct() {
        if (structSel == null) { local(false, "Choose a structure in the list"); return; }
        BlockPos at = pos1 != null ? pos1 : playerPos();
        if (at == null) return;
        send("sload", structSel, sRot + "|" + sMirror + "|" + (sEnts ? "1" : "0"), at.getX(), at.getY(), at.getZ());
        sName.setValue(structSel);
    }

    /** LMB in the world for the Entities / Structures modes; true if handled */
    boolean clickExtra() {
        if (mode.equals("Entities")) {
            switch (eTool) {
                case "Select" -> {
                    if (hoverEnt != null) selectEntity(hoverEnt.getUUID().toString());
                    else local(false, "No entity under the cursor");
                }
                case "Spawn" -> {
                    if (hover == null) return true;
                    BlockPos f = hover.getBlockPos().relative(hover.getDirection());
                    send("espawn", spawnType, "", f.getX(), f.getY(), f.getZ());
                }
                case "Move" -> {
                    if (selUuid == null) { local(false, "Select an entity first"); return true; }
                    if (hover == null) return true;
                    BlockPos f = hover.getBlockPos().relative(hover.getDirection());
                    send("emove", selUuid, "", f.getX(), f.getY(), f.getZ());
                }
            }
            return true;
        }
        if (mode.equals("Structures") && sTool.equals("Place")) {
            if (structSel == null) { local(false, "Choose a structure in the list"); return true; }
            if (hover == null) return true;
            BlockPos f = hover.getBlockPos().relative(hover.getDirection());
            send("splace", structSel, sRot + "|" + sMirror + "|" + (sEnts ? "1" : "0"), f.getX(), f.getY(), f.getZ());
            return true;
        }
        return false;
    }

    List<Object[]> extraActions() {
        List<Object[]> a = new ArrayList<>();
        if (mode.equals("Entities")) {
            a.add(new Object[]{"Me", (Runnable) () -> { if (minecraft.player != null) selectEntity(minecraft.player.getUUID().toString()); }});
            a.add(new Object[]{"Bring here", (Runnable) () -> { if (selUuid != null) send("ehere", selUuid, ""); }});
            a.add(new Object[]{"Go to", (Runnable) () -> { var e = selectedEntity(); if (e != null) send("tp", "", "", e.getBlockX(), e.getBlockY(), e.getBlockZ()); }});
            a.add(new Object[]{"Duplicate", (Runnable) () -> { if (selUuid != null) send("edup", selUuid, ""); }});
            a.add(new Object[]{"Delete", (Runnable) () -> { if (selUuid != null) { send("edel", selUuid, ""); selUuid = null; EPROPS.clear(); EPARTS.clear(); } }});
            a.add(new Object[]{"Deselect", (Runnable) () -> { selUuid = null; EPROPS.clear(); EPARTS.clear(); }});
            a.add(new Object[]{"Refresh", (Runnable) () -> { send("enear", "", "", 48); if (selUuid != null) send("einfo", selUuid, ""); }});
        } else {
            for (String[] a2 : new String[][]{{"Fill", "fill"}, {"Clear", "clear"}, {"Copy", "copy"}}) a.add(new Object[]{a2[0], (Runnable) () -> selOp(a2[1])});
            a.add(new Object[]{"Save selection", (Runnable) this::saveStruct});
            a.add(new Object[]{"Load to edit", (Runnable) this::loadStruct});
            a.add(new Object[]{"Rotate " + sRot + "°", (Runnable) () -> sRot = switch (sRot) { case "0" -> "90"; case "90" -> "180"; case "180" -> "270"; default -> "0"; }});
            a.add(new Object[]{"Undo", (Runnable) () -> send("undo", "", "")});
            a.add(new Object[]{"Redo", (Runnable) () -> send("redo", "", "")});
        }
        return a;
    }

    static void renderWorldExtra(PoseStack ps, com.mojang.blaze3d.vertex.VertexConsumer vc, WorldEditorScreen w) {
        if (mode.equals("Entities")) {
            var se = w.selectedEntity();
            if (se != null) LevelRenderer.renderLineBox(ps, vc, se.getBoundingBox().inflate(0.05), 0.31f, 0.82f, 0.77f, 1f);
            if (hoverEnt != null && hoverEnt != se && eTool.equals("Select")) LevelRenderer.renderLineBox(ps, vc, hoverEnt.getBoundingBox().inflate(0.03), 1f, 1f, 1f, 0.8f);
            if (hover != null && !eTool.equals("Select")) LevelRenderer.renderLineBox(ps, vc, new AABB(hover.getBlockPos().relative(hover.getDirection())).inflate(0.003), 1f, 1f, 1f, 0.8f);
        } else if (mode.equals("Structures") && sTool.equals("Place") && hover != null) {
            BlockPos[] fp = w.footprint(hover.getBlockPos().relative(hover.getDirection()));
            if (fp != null) LevelRenderer.renderLineBox(ps, vc, new AABB(fp[0]).minmax(new AABB(fp[1])).inflate(0.01), 1f, 0.8f, 0.3f, 1f);
            else LevelRenderer.renderLineBox(ps, vc, new AABB(hover.getBlockPos().relative(hover.getDirection())).inflate(0.003), 1f, 0.8f, 0.3f, 1f);
        }
    }

    /** selection box, hovered block and brush outline (called from RenderLevelStageEvent) */
    public static void renderWorld(RenderLevelStageEvent e) {
        if (open == null || e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != open) return;
        Vec3 c = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.translate(-c.x, -c.y, -c.z);
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        var vc = bs.getBuffer(RenderType.lines());
        float r = ((ACCENT >> 16) & 255) / 255f, gg = ((ACCENT >> 8) & 255) / 255f, b = (ACCENT & 255) / 255f;
        if (pos1 != null) {
            BlockPos p2 = pos2 != null ? pos2 : pos1;
            AABB box = new AABB(pos1).minmax(new AABB(p2)).inflate(0.005);
            LevelRenderer.renderLineBox(ps, vc, box, r, gg, b, 1f);
            LevelRenderer.renderLineBox(ps, vc, new AABB(pos1).inflate(0.01), 0.36f, 0.84f, 0.54f, 1f);
            if (pos2 != null) LevelRenderer.renderLineBox(ps, vc, new AABB(pos2).inflate(0.01), 1f, 0.42f, 0.48f, 1f);
        }
        if (!mode.equals("Blocks")) renderWorldExtra(ps, vc, open);
        else if (hover != null) {
            BlockPos hp = hover.getBlockPos();
            boolean face = tool.equals("Place") || tool.equals("Brush") || tool.equals("Cube") || tool.equals("Paste");
            BlockPos cpos = face ? hp.relative(hover.getDirection()) : hp;
            boolean area = !tool.equals("Select") && !tool.equals("Place") && !tool.equals("Paste");
            AABB hb = area ? new AABB(cpos).inflate(radius) : new AABB(cpos);
            LevelRenderer.renderLineBox(ps, vc, hb.inflate(0.003), 1f, 1f, 1f, 0.8f);
        }
        bs.endBatch(RenderType.lines());
        ps.popPose();
    }

    // ------------------------------------------------------------------ input (screen coordinates → logical)
    boolean overUi(double mx, double my) {
        for (int[] r : ui) if (mx >= r[0] && mx < r[2] && my >= r[1] && my < r[3]) return true;
        return false;
    }

    @Override public boolean mouseClicked(double amx, double amy, int b) {
        double mx = amx / S, my = amy / S;
        lmx = (int) mx; lmy = (int) my;
        for (EditBox e : fields) if (e.visible && in(mx, my, e.getX() - 4, e.getY() - 3, e.getX() + e.getWidth() + 4, e.getY() + 11)) {
            setFocused(e); e.setFocused(true); e.mouseClicked(mx, my, b); return true;
        }
        if (getFocused() instanceof EditBox fb) { fb.setFocused(false); setFocused(null); }
        if (b == 0 || b == 1) for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (in(mx, my, h.x1, h.y1, h.x2, h.y2)) {
                if (b == 1) { // RMB on a mix chip / cell: remove from the mix
                    if (paletteOpen && mx >= palX0()) { for (String m : new ArrayList<>(MIX)) if (tip != null && tip.startsWith(m) && MIX.size() > 1) MIX.remove(m); return true; }
                    break;
                }
                h.r.run(); return true;
            }
        }
        if (overUi(mx, my)) return true;
        if (b == 1) { looking = true; return true; }
        if (b == 2) {
            if (hover != null && minecraft.level != null) pick(id(minecraft.level.getBlockState(hover.getBlockPos()).getBlock()), hasShiftDown());
            return true;
        }
        if (b == 0 && !mode.equals("Blocks") && clickExtra()) return true;
        if (b == 0 && hover != null) {
            if (curTool().equals("Select")) {
                if (hasShiftDown() && pos1 != null) pos2 = hover.getBlockPos();
                else { pos1 = hover.getBlockPos(); pos2 = pos1; selecting = true; }
            } else if (mode.equals("Blocks")) stroke(true);
        }
        return true;
    }

    @Override public boolean mouseDragged(double amx, double amy, int b, double dx, double dy) {
        if (looking && b == 1) {
            double s = minecraft.options.sensitivity().get() * 0.6 + 0.2;
            minecraft.player.turn(dx * s * s * s * 8 * 2.5 * minecraft.getWindow().getGuiScale() / 2, dy * s * s * s * 8 * 2.5 * minecraft.getWindow().getGuiScale() / 2);
            return true;
        }
        if (b == 0 && mode.equals("Blocks") && !selecting && !overUi(amx / S, amy / S) && !tool.equals("Select") && !tool.equals("Place") && !tool.equals("Paste")) {
            hover = ray(minecraft, amx, amy, width, height); stroke(false);
        }
        return true;
    }

    @Override public boolean mouseReleased(double amx, double amy, int b) {
        if (b == 1) looking = false;
        if (b == 0 && selecting) {
            selecting = false;
            if (hasSel()) local(true, "Selected " + (Math.abs(pos1.getX() - pos2.getX()) + 1) + "×" + (Math.abs(pos1.getY() - pos2.getY()) + 1) + "×" + (Math.abs(pos1.getZ() - pos2.getZ()) + 1));
        }
        return true;
    }

    @Override public boolean mouseScrolled(double amx, double amy, double d) {
        double mx = amx / S;
        if (!mode.equals("Blocks") && mx >= palX0()) {
            if (mode.equals("Entities") && eTab.equals("Inspect")) insScroll = Math.max(0, insScroll - (int) (d * 24)); else listScroll = Math.max(0, listScroll - (int) (d * 24));
            return true;
        }
        if (paletteOpen && mx >= palX0()) { palScroll = Math.max(0, palScroll - (int) (d * CELL * 2)); return true; }
        if (hasControlDown()) { radius = Math.max(0, Math.min(32, radius + (d > 0 ? 1 : -1))); local(true, "Radius " + radius); return true; }
        String[] tl = tools();
        int i = Arrays.asList(tl).indexOf(curTool());
        setTool(tl[Math.floorMod(i + (d > 0 ? -1 : 1), tl.length)]);
        return true;
    }

    @Override public boolean keyPressed(int key, int sc, int mods) {
        if (getFocused() instanceof EditBox b) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                if (key != GLFW.GLFW_KEY_ESCAPE && selUuid != null) {
                    for (var en : ebox.entrySet()) if (en.getValue() == b) send("eset", selUuid, en.getKey() + "=" + b.getValue());
                    if (b == pOff || b == pRot || b == pScale) applyPart();
                }
                if (b == sName && key != GLFW.GLFW_KEY_ESCAPE) saveStruct();
                if (b == search && key != GLFW.GLFW_KEY_ESCAPE) {
                    String q = search.getValue().trim().toLowerCase(Locale.ROOT);
                    for (Block bl : allBlocks()) { String id = id(bl); if (!q.isEmpty() && id.contains(q)) { pick(id, hasShiftDown()); break; } }
                }
                b.setFocused(false); setFocused(null); return true;
            }
            return b.keyPressed(key, sc, mods);
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_F8) { onClose(); return true; }
        if (hasControlDown()) {
            switch (key) {
                case GLFW.GLFW_KEY_Z -> { send(hasShiftDown() ? "redo" : "undo", "", ""); return true; }
                case GLFW.GLFW_KEY_Y -> { send("redo", "", ""); return true; }
                case GLFW.GLFW_KEY_C -> { selOp("copy"); return true; }
                case GLFW.GLFW_KEY_V -> { tool = "Paste"; return true; }
                case GLFW.GLFW_KEY_F -> { paletteOpen = true; setFocused(search); search.setFocused(true); return true; }
            }
        }
        if (key == GLFW.GLFW_KEY_DELETE && !mode.equals("Entities")) { selOp("clear"); return true; }
        if (key == GLFW.GLFW_KEY_LEFT_BRACKET) { setCorner(1); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_BRACKET) { setCorner(2); return true; }
        if (key == GLFW.GLFW_KEY_F) { send("fly", "", ""); return true; }
        if (key == GLFW.GLFW_KEY_H) { hollow = !hollow; local(true, hollow ? "Brush / Cube: hollow" : "Brush / Cube: solid"); return true; }
        if (key == GLFW.GLFW_KEY_T) {
            if (hover == null) { local(false, "Point at a block to teleport"); return true; }
            BlockPos t = hover.getBlockPos().relative(hover.getDirection());
            send("tp", "", "", t.getX(), t.getY(), t.getZ());
            return true;
        }
        if (minecraft.player != null && (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT
                || key == GLFW.GLFW_KEY_PAGE_UP || key == GLFW.GLFW_KEY_PAGE_DOWN)) {
            var f = minecraft.player.getDirection();
            var d = switch (key) {
                case GLFW.GLFW_KEY_UP -> f; case GLFW.GLFW_KEY_DOWN -> f.getOpposite();
                case GLFW.GLFW_KEY_LEFT -> f.getCounterClockWise(); case GLFW.GLFW_KEY_RIGHT -> f.getClockWise();
                case GLFW.GLFW_KEY_PAGE_UP -> net.minecraft.core.Direction.UP; default -> net.minecraft.core.Direction.DOWN;
            };
            nudge(d, hasShiftDown() ? 1 : hasAltDown() ? 2 : 0);
            return true;
        }
        if (key == GLFW.GLFW_KEY_TAB) { int i = Arrays.asList(MODES).indexOf(mode); setMode(MODES[Math.floorMod(i + (hasShiftDown() ? -1 : 1), MODES.length)]); return true; }
        if (key == GLFW.GLFW_KEY_B && mode.equals("Blocks")) { paletteOpen = !paletteOpen; return true; }
        if (key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_8) { String[] tl = tools(); int i = key - GLFW.GLFW_KEY_1; if (i < tl.length) setTool(tl[i]); return true; }
        if (mode.equals("Entities") && selUuid != null && key == GLFW.GLFW_KEY_DELETE) { send("edel", selUuid, ""); selUuid = null; EPROPS.clear(); EPARTS.clear(); return true; }
        return true; // movement keys are read in movement()
    }

    @Override public boolean charTyped(char c, int mods) {
        if (getFocused() instanceof EditBox b) return b.charTyped(c, mods);
        return false;
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public void removed() {
        fromV = from.getValue(); timesV = times.getValue(); searchV = search.getValue();
        if (open == this) open = null;
        KeyMapping.releaseAll();
        super.removed();
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g) {}
}
