package net.idea.fluwa.client;

import net.idea.fluwa.Fluwa;
import net.idea.fluwa.client.zspace.CodeEditor;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.*;

import static net.idea.fluwa.client.zspace.ZUi.*;

/**
 * ZSpace (F8) — minimal dark IDE: explorer (Workspace, UI, InitScripts, ServerScripts, ClientScripts, Console),
 * tabbed Lua editor, docked console with a server command line, status bar, toasts, camera mode.
 */
public class ZSpaceScreen extends Screen {
    static final String[] TREE = {"Workspace", "UI", "InitScripts", "ServerScripts", "ClientScripts", "Console"};
    static final int TOPH = 22, TABH = 16, STATH = 13, ROW = 13;

    // kept between openings of ZSpace
    static final LinkedHashMap<String, CodeEditor> SESSION = new LinkedHashMap<>();
    static String lastActive, lastView = "welcome", lastFolder = "ServerScripts";
    static boolean lastConsole;
    static final Set<String> EXPANDED = new HashSet<>(List.of("ServerScripts", "ClientScripts", "InitScripts", "UI"));
    static final List<String> HISTORY = new ArrayList<>();

    final Map<String, Map<String, String>> scripts;
    final List<String> workspace;
    final List<String> serverConsole;
    final LinkedHashMap<String, CodeEditor> open = SESSION;
    String active, view, selFolder;
    boolean consoleOpen, editorFocus;
    EditBox filterBox, nameBox, conInput;
    int histIdx = -1, sideScroll, contentScroll, conScroll, sideW;
    long openedAt = System.currentTimeMillis(), deleteArm;
    String status = "";
    boolean statusOk = true;
    long statusSince;

    record Toast(String msg, boolean ok, long t) {}
    final List<Toast> toasts = new ArrayList<>();
    record Hit(int x1, int y1, int x2, int y2, Runnable r) {}
    final List<Hit> hits = new ArrayList<>();
    final Map<String, Float> hover = new HashMap<>();
    int lmx, lmy;

    // ---- floating window (resizable / draggable so the world stays visible)
    static int nx = -1, ny, nw, nh;
    static boolean maxed;
    int wx, wy, ww, wh, sw, sh, dragMode;
    double dragX, dragY; int dragNX, dragNY, dragNW, dragNH;
    long lastTopClick;

    // ---- Workspace explorer (data from the server: S_ZTREE / S_ZPROPS)
    static final Map<String, List<String[]>> ZTREE = new HashMap<>();
    static final Set<String> ZEXP = new HashSet<>(Set.of("Workspace"));
    static String zsel;
    static List<String[]> zprops = new ArrayList<>();
    int zScrollT, zScrollP, zSplit;
    EditBox propBox, insArg, insName;
    String editingProp, editingType;

    // ---- "+" insert window
    boolean insOpen;
    String insFolder = "Workspace", insClass;
    static final String[] INS_WORKSPACE = {"Entity", "Item", "Block", "Model"};
    static final String[] INS_UI = {"ScreenGUI", "Overlay", "Frame", "TextLabel", "TextButton", "ImageButton", "Image", "TextBox",
            "ScrollingFrame", "ViewportFrame", "VideoFrame", "CanvasGroup", "Script"};
    static final String[] INS_SCRIPT = {"Script", "Event", "Loop", "RemoteEvent", "NET", "Projector", "Item"};
    /** folders and values that can be created in any section */
    static final String[] ITEM_CLASSES = {"Folder", "StrValue", "IntValue", "NumValue", "BoolValue", "ObjValue"};
    static boolean isItem(String c) { return Arrays.asList(ITEM_CLASSES).contains(c); }
    EditBox insValue;

    // ---- UI scale (texts follow the window size), ☰ menu, folder / value editor popup
    float S = 1;
    int lbtn;
    boolean menuOpen, toolsSub;
    int menuX;
    static final Set<String> FOLDED = new HashSet<>();
    static String lastPath = "";
    String selPath = "";
    String popKind, popSec, popPath, popCls;
    EditBox popName, popValue;
    long popArm;

    /** server reply to Save/Delete/Run/Reload */
    void setStatus(boolean ok, String msg) {
        statusOk = ok; status = msg; statusSince = System.currentTimeMillis();
        toasts.add(new Toast(msg, ok, statusSince));
        if (toasts.size() > 4) toasts.remove(0);
    }

    public ZSpaceScreen(Map<String, Map<String, String>> scripts, List<String> workspace, List<String> console) {
        super(Component.literal("ZSpace"));
        this.scripts = scripts; this.workspace = workspace; this.serverConsole = console;
        // refresh remembered tabs with the server copy
        open.entrySet().removeIf(e -> {
            String[] k = e.getKey().split("/", 2);
            String src = scripts.getOrDefault(k[0], Map.of()).get(k[1]);
            if (src == null) return !e.getValue().modified();
            if (!e.getValue().modified()) e.getValue().reload(src);
            return false;
        });
        active = lastActive != null && open.containsKey(lastActive) ? lastActive : open.isEmpty() ? null : open.keySet().iterator().next();
        view = lastView.equals("editor") && active == null ? "welcome" : lastView;
        selFolder = lastFolder;
        selPath = lastPath;
        consoleOpen = lastConsole;
        editorFocus = view.equals("editor");
    }

    String key(String folder, String name) { return folder + "/" + name; }
    String[] split(String key) { return key.split("/", 2); }
    CodeEditor ed() { return active == null ? null : open.get(active); }

    @Override protected void init() {
        sw = width; sh = height;
        if (nx < 0 || nw == 0) { nw = Math.max(360, sw * 4 / 5); nh = Math.max(220, sh * 4 / 5); nx = (sw - nw) / 2; ny = (sh - nh) / 2; }
        computeWin();
        sideW = Math.max(120, Math.min(170, width / 5));
        filterBox = box(10, TOPH + 21, sideW - 20, "Search scripts…");
        nameBox = box(10, height - STATH - 37, sideW - 20, "");
        conInput = box(sideW + 18, height - STATH - 13, width - sideW - 26, consoleClient ? "Run Lua on this client…  (Enter · s> = server)" : "Run Lua on the server…  (Enter · c> = client)");
        conInput.visible = consoleOpen;
        propBox = box(0, 0, 100, "value"); propBox.visible = false;
        insArg = box(0, 0, 100, "id / path"); insArg.visible = false;
        insName = box(0, 0, 100, "Name"); insName.visible = false;
        insValue = box(0, 0, 100, "Value"); insValue.visible = false;
        popName = box(0, 0, 100, "Name"); popName.visible = false;
        popValue = box(0, 0, 100, "Value"); popValue.visible = false;
        for (var e : open.values()) e.focused = false;
        if (view.equals("workspace")) refreshTree();
        layoutEditor();
    }

    EditBox box(int x, int y, int w, String hint) {
        EditBox b = new EditBox(font, x, y, w, 10, Component.literal(hint));
        b.setBordered(false);
        b.setMaxLength(100_000);
        b.setTextColor(TEXT);
        b.setHint(Component.literal(hint).withStyle(ChatFormatting.DARK_GRAY));
        return addRenderableWidget(b);
    }

    void computeWin() {
        nw = Math.max(320, Math.min(sw, nw)); nh = Math.max(200, Math.min(sh, nh));
        nx = Math.max(0, Math.min(sw - nw, nx)); ny = Math.max(0, Math.min(sh - nh, ny));
        if (maxed) { wx = 0; wy = 0; ww = sw; wh = sh; } else { wx = nx; wy = ny; ww = nw; wh = nh; }
        S = net.idea.fluwa.client.zspace.ZOptions.scaleFor(ww, wh);
        width = Math.max(1, (int) (ww / S)); height = Math.max(1, (int) (wh / S));
        net.idea.fluwa.client.zspace.ZUi.OX = wx; net.idea.fluwa.client.zspace.ZUi.OY = wy; net.idea.fluwa.client.zspace.ZUi.SC = S;
    }
    void applyWin() {
        computeWin();
        sideW = Math.max(120, Math.min(170, width / 5));
        if (conInput != null) { conInput.setX(sideW + 18); conInput.setY(height - STATH - 13); conInput.setWidth(width - sideW - 26); }
        layoutEditor();
    }
    void toggleMax() { maxed = !maxed; applyWin(); }

    int conH() { return consoleOpen ? Math.max(70, (int) (height * 0.3)) : 0; }
    int contentTop() { return TOPH + TABH; }
    int contentBottom() { return height - STATH - conH(); }

    void layoutEditor() {
        CodeEditor e = ed();
        if (e == null) return;
        e.x = sideW + 1; e.y = contentTop(); e.w = width - sideW - 1; e.h = contentBottom() - contentTop();
        e.focused = editorFocus && view.equals("editor") && getFocused() == null;
    }

    // ------------------------------------------------------------------ actions
    void openScript(String folder, String name) {
        String k = key(folder, name);
        CodeEditor e = open.get(k);
        if (e == null) {
            e = new CodeEditor(font);
            e.setText(scripts.getOrDefault(folder, Map.of()).getOrDefault(name, ""));
            open.put(k, e);
        }
        active = k; view = "editor"; selFolder = folder; selPath = parentOf(name); focusEditor();
    }

    void focusEditor() { setFocused(null); editorFocus = true; layoutEditor(); }

    void closeTab(String k) {
        List<String> keys = new ArrayList<>(open.keySet());
        int i = keys.indexOf(k);
        open.remove(k);
        if (k.equals(active)) {
            keys.remove(k);
            active = keys.isEmpty() ? null : keys.get(Math.min(i, keys.size() - 1));
            if (active == null && view.equals("editor")) view = "welcome";
        }
    }

    void save() {
        CodeEditor e = ed();
        if (e == null || !view.equals("editor")) { setStatus(false, "Open a script first"); return; }
        String[] k = split(active);
        String src = e.getText();
        scripts.computeIfAbsent(k[0], x -> new TreeMap<>()).put(k[1], src);
        e.markSaved();
        FluwaNet.toServer(new Pkt(Pkt.C_ZSAVE, List.of(k[0], k[1], src), new int[]{net.idea.fluwa.client.zspace.ZOptions.reloadOnSave ? 1 : 0}, null));
        status = "Saving " + active + "…"; statusOk = true; statusSince = System.currentTimeMillis();
    }

    void delete() {
        if (active == null || !view.equals("editor")) return;
        long now = System.currentTimeMillis();
        if (now - deleteArm > 3000) { deleteArm = now; return; }
        deleteArm = 0;
        String[] k = split(active);
        FluwaNet.toServer(new Pkt(Pkt.C_ZDELETE, List.of(k[0], k[1]), new int[]{net.idea.fluwa.client.zspace.ZOptions.reloadOnSave ? 1 : 0}, null));
        scripts.getOrDefault(k[0], new TreeMap<>()).remove(k[1]);
        open.remove(active);
        active = open.isEmpty() ? null : open.keySet().iterator().next();
        view = "folder"; selFolder = k[0];
        status = "Deleting…";
    }

    void run() {
        CodeEditor e = ed();
        if (e == null || !view.equals("editor")) { setStatus(false, "Open a script first"); return; }
        String folder = split(active)[0];
        // UI / ClientScripts run on this client (ScreenGUI, Overlay, UserInputService... exist only there),
        // InitScripts on both sides, everything else on the server
        boolean client = folder.equals("UI") || folder.equals("ClientScripts"), both = folder.equals("InitScripts");
        if (client || both) {
            if (!runOnClient(active, e.getText())) return;
        }
        if (!client) FluwaNet.toServer(new Pkt(Pkt.C_ZRUN, List.of(e.getText()), null, null));
        status = "Running " + active + (client ? " on this client…" : both ? " on server + client…" : " on the server…"); statusSince = System.currentTimeMillis();
        if (!consoleOpen) toggleConsole();
    }

    /** run Lua in this client's runtime (the one that runs UI / ClientScripts) */
    static boolean runOnClient(String name, String src) {
        if (!(net.idea.fluwa.api.GameRuntime.CLIENT instanceof ClientRuntime r) || r.closed) {
            ClientState.CONSOLE.add("[client] Client scripts are not running (join a world with Fluwa on the server)");
            return false;
        }
        r.runScript("ZSpace/" + name, src);
        return true;
    }

    void reloadAll() {
        FluwaNet.toServer(new Pkt(Pkt.C_ZRELOAD));
        status = "Reloading…"; statusSince = System.currentTimeMillis();
    }

    void create() {
        String n = nameBox.getValue().trim().replaceAll("\\.lua$", "").replaceAll("[\\\\/:*?\"<>|]", "_");
        if (n.isEmpty()) { setStatus(false, "Type a name first"); return; }
        String folder = target();
        if (folder.equals(selFolder) && !selPath.isEmpty()) n = selPath + "/" + n;
        if (scripts.getOrDefault(folder, Map.of()).containsKey(n)) { openScript(folder, n); nameBox.setValue(""); return; }
        nameBox.setValue("");
        createWith(folder, n, defaultTpl(folder, n));
    }

    static String defaultTpl(String folder, String n) {
        return switch (folder) {
            case "ServerScripts" -> "-- " + n + "  ·  runs on the server\n\n";
            case "ClientScripts" -> "-- " + n + "  ·  runs on every client\nlocal player = Players.LocalPlayer\n\n";
            case "UI" -> "-- " + n + "  ·  user interface\nlocal gui = Instance:new(\"ScreenGUI\", UI)\n\n";
            case "InitScripts" -> "-- " + n + "  ·  shared module (server + clients)\n\n";
            default -> "-- " + n + "\n";
        };
    }

    void createWith(String folder, String n, String tpl) {
        if (scripts.getOrDefault(folder, Map.of()).containsKey(n)) { int i = 2; while (scripts.get(folder).containsKey(n + i)) i++; n = n + i; }
        scripts.computeIfAbsent(folder, k -> new TreeMap<>()).put(n, tpl);
        EXPANDED.add(folder);
        openScript(folder, n);
        ed().markUnsaved();
        ed().gotoLine(ed().lineCount() - 1);
        setStatus(true, "Created " + folder + "/" + n + " — Ctrl+S to save");
    }

    String target() { return selFolder.equals("Workspace") || selFolder.equals("Console") ? "ServerScripts" : selFolder; }

    void toggleConsole() {
        consoleOpen = !consoleOpen;
        conInput.visible = consoleOpen;
        if (consoleOpen) { setFocused(conInput); editorFocus = false; } else if (getFocused() == conInput) setFocused(null);
        layoutEditor();
    }

    /** console target: false = server, true = this client (toggle in the console header, or prefix a line with "c>" / "s>") */
    static boolean consoleClient;

    void runConsole() {
        String c = conInput.getValue().trim();
        if (c.isEmpty()) return;
        boolean client = consoleClient;
        if (c.startsWith("c>")) { client = true; c = c.substring(2).trim(); }
        else if (c.startsWith("s>")) { client = false; c = c.substring(2).trim(); }
        if (client) runOnClient("console", c); else FluwaNet.toServer(new Pkt(Pkt.C_ZRUN, List.of(c), null, null));
        ClientState.CONSOLE.add((client ? "c> " : "> ") + c);
        HISTORY.remove(c); HISTORY.add(c); histIdx = -1;
        conInput.setValue(""); conScroll = 0;
    }

    // ------------------------------------------------------------------ render
    @Override public void render(GuiGraphics g, int amx, int amy, float pt) {
        net.idea.fluwa.client.zspace.ZUi.OX = wx; net.idea.fluwa.client.zspace.ZUi.OY = wy; net.idea.fluwa.client.zspace.ZUi.SC = S;
        if (!maxed) { shadow(g, wx, wy, wx + ww, wy + wh); g.fill(wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 0xFF34304A); }
        g.pose().pushPose();
        g.pose().translate(wx, wy, 0);
        g.pose().scale(S, S, 1);
        renderInner(g, (int) ((amx - wx) / S), (int) ((amy - wy) / S), pt);
        if (!maxed) for (int i = 0; i < 3; i++) g.fill(width - 3 - i * 3, height - 3, width - 1 - i * 3, height - 1, 0x88FFFFFF);
        g.pose().popPose();
    }

    void renderInner(GuiGraphics g, int mx, int my, float pt) {
        lmx = mx; lmy = my;
        hits.clear();
        float t = (System.currentTimeMillis() % 100000) / 1000f;
        float a = ease((System.currentTimeMillis() - openedAt) / 260f);
        g.fill(0, 0, width, height, alpha(net.idea.fluwa.client.zspace.ZOptions.bg(0x090910), a));
        g.pose().pushPose();
        g.pose().translate(0, (1 - a) * 6, 0);
        layoutEditor();

        renderSidebar(g, mx, my, t);
        renderMain(g, mx, my, t);
        renderTop(g, mx, my, t);
        renderStatus(g, mx, my);
        if (!view.equals("workspace") && propBox != null) { propBox.visible = false; if (getFocused() == propBox) setFocused(null); }
        if (insOpen) renderInsert(g, mx, my); else if (insArg != null) { insArg.visible = insName.visible = insValue.visible = false; }
        if (popKind != null) renderPopup(g, mx, my); else if (popName != null) { popName.visible = popValue.visible = false; }

        // input fields backgrounds are drawn by panels; widgets on top
        super.render(g, mx, my, pt);
        if (ed() != null && view.equals("editor")) ed().renderOverlay(g, mx, my);
        renderToasts(g);
        if (menuOpen) renderMenu(g, mx, my);
        g.pose().popPose();
    }

    float anim(String id, boolean on) {
        float v = hover.getOrDefault(id, 0f);
        v += ((on ? 1 : 0) - v) * (net.idea.fluwa.client.zspace.ZOptions.animations ? 0.35f : 1f);
        hover.put(id, v);
        return v;
    }

    /** style 0 ghost, 1 accent, 2 danger */
    void button(GuiGraphics g, String id, int x, int y, int w, int h, String label, int style, int mx, int my, Runnable r) {
        boolean on = in(mx, my, x, y, x + w, y + h);
        float v = anim(id, on);
        int base = style == 1 ? lerp(ACCENT, 0xFF000000, 0.15f) : style == 2 ? 0xFF8A2E3E : 0x18FFFFFF;
        int hi = style == 1 ? ACCENT : style == 2 ? 0xFFB23A4F : 0x30FFFFFF;
        round(g, x, y, x + w, y + h, lerp(base, hi, v));
        if (style == 1) g.fill(x + 1, y, x + w - 1, y + 1, 0x40FFFFFF);
        centered(g, font, label, x + w / 2, y + (h - 8) / 2, style == 0 ? lerp(0xFFC0C0D0, 0xFFFFFFFF, v) : 0xFFFFFFFF);
        hits.add(new Hit(x, y, x + w, y + h, r));
    }

    void renderTop(GuiGraphics g, int mx, int my, float t) {
        g.fill(0, 0, width, TOPH, TOP);
        hGrad(g, 0, TOPH - 1, width, TOPH, ACCENT, ACCENT2, t * 0.08f);
        // logo
        int lc = lerp(ACCENT, ACCENT2, (float) (0.5 + 0.5 * Math.sin(t * 1.6)));
        int cx = 12, cy = 10;
        for (int i = 0; i <= 4; i++) g.fill(cx - i, cy - 4 + i, cx + i + 1, cy - 3 + i, lc);
        for (int i = 0; i < 4; i++) g.fill(cx - 3 + i, cy + 1 + i, cx + 4 - i, cy + 2 + i, lc);
        g.fill(cx, cy - 1, cx + 1, cy + 2, TOP);
        text(g, font, "ZSpace", 22, 7, TEXT);
        small(g, font, "Fluwa " + Fluwa.VERSION, 22 + font.width("ZSpace") + 5, 9, DIM);

        int bx = width - 6, by = 4, bh = 14;
        bx -= 16; button(g, "close", bx, by, 16, bh, "✕", 0, mx, my, this::onClose);
        bx -= 19; button(g, "max", bx, by, 16, bh, maxed ? "❐" : "□", 0, mx, my, this::toggleMax);
        bx -= 19; menuX = bx; button(g, "menu", bx, by, 16, bh, "☰", menuOpen ? 1 : 0, mx, my, () -> { menuOpen = !menuOpen; toolsSub = false; setFocused(null); });
        bx -= 8;
        boolean ed = ed() != null && view.equals("editor");
        int w;
        w = font.width("⟳ Reload") + 12; bx -= w; button(g, "reload", bx, by, w, bh, "⟳ Reload", 0, mx, my, this::reloadAll);
        if (ed) {
            boolean armed = System.currentTimeMillis() - deleteArm < 3000;
            String dl = armed ? "Confirm?" : "Delete";
            w = font.width(dl) + 12; bx -= w + 3; button(g, "delete", bx, by, w, bh, dl, armed ? 2 : 0, mx, my, this::delete);
            String sl = ed().modified() ? "● Save" : "Save";
            w = font.width(sl) + 12; bx -= w + 3; button(g, "save", bx, by, w, bh, sl, 0, mx, my, this::save);
            w = font.width("▶ Run") + 14; bx -= w + 3; button(g, "run", bx, by, w, bh, "▶ Run", 1, mx, my, this::run);
        }
        // center: current location breadcrumb
        String crumb = switch (view) {
            case "editor" -> active == null ? "" : active.replace("/", "  ›  ") + ".lua";
            case "workspace" -> "Workspace";
            case "folder" -> selFolder;
            default -> "";
        };
        int left = 22 + font.width("ZSpace") + 50, right = bx - 10;
        crumb = ellipsize(font, crumb, Math.max(0, right - left));
        if (!crumb.isEmpty()) centered(g, font, crumb, Math.max(left + font.width(crumb) / 2, Math.min(width / 2, right - font.width(crumb) / 2)), 7, DIM);
    }

    // ------------------------------------------------------------------ sidebar
    /** kind: 0 section, 1 script, 2 folder, 3 value */
    record Row(String folder, String name, int kind, int depth, String path, String cls, String value) {
        Row(String folder, String name) { this(folder, name, name == null ? 0 : 1, 0, name, "", ""); }
    }

    static String parentOf(String p) { int i = p.lastIndexOf('/'); return i < 0 ? "" : p.substring(0, i); }
    static String leaf(String p) { return p.substring(p.lastIndexOf('/') + 1); }
    Map<String, String> items(String sec) { return scripts.getOrDefault("#" + sec, Map.of()); }

    List<Row> rows() {
        List<Row> r = new ArrayList<>();
        String f = filterBox == null ? "" : filterBox.getValue().trim().toLowerCase(Locale.ROOT);
        for (String folder : TREE) {
            if (!isScriptFolder(folder)) {
                if (!f.isEmpty() && !folder.toLowerCase(Locale.ROOT).contains(f)) continue;
                r.add(new Row(folder, null));
                continue;
            }
            List<String> names = new ArrayList<>(scripts.getOrDefault(folder, Map.of()).keySet());
            for (String k : open.keySet()) { String[] s = split(k); if (s[0].equals(folder) && !names.contains(s[1])) names.add(s[1]); }
            Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
            Map<String, String> it = items(folder);
            if (!f.isEmpty()) {
                names.removeIf(n -> !n.toLowerCase(Locale.ROOT).contains(f));
                List<Row> found = new ArrayList<>();
                for (var e : it.entrySet()) if (leaf(e.getKey()).toLowerCase(Locale.ROOT).contains(f)) {
                    String[] cv = e.getValue().split("\t", 2);
                    found.add(new Row(folder, null, cv[0].equals("Folder") ? 2 : 3, 0, e.getKey(), cv[0], cv.length > 1 ? cv[1] : ""));
                }
                if (names.isEmpty() && found.isEmpty() && !folder.toLowerCase(Locale.ROOT).contains(f)) continue;
                r.add(new Row(folder, null));
                for (String n : names) r.add(new Row(folder, n));
                r.addAll(found);
                continue;
            }
            r.add(new Row(folder, null));
            if (!EXPANDED.contains(folder)) continue;
            TreeSet<String> folders = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            for (var e : it.entrySet()) {
                if (e.getValue().startsWith("Folder\t")) folders.add(e.getKey());
                for (String q = parentOf(e.getKey()); !q.isEmpty(); q = parentOf(q)) folders.add(q);
            }
            for (String n : names) for (String q = parentOf(n); !q.isEmpty(); q = parentOf(q)) folders.add(q);
            walk(folder, "", 0, folders, it, names, r);
        }
        return r;
    }

    void walk(String sec, String prefix, int depth, TreeSet<String> folders, Map<String, String> it, List<String> names, List<Row> out) {
        for (String fp : folders) if (parentOf(fp).equals(prefix)) {
            out.add(new Row(sec, null, 2, depth, fp, "Folder", ""));
            if (!FOLDED.contains(sec + "/" + fp)) walk(sec, fp, depth + 1, folders, it, names, out);
        }
        for (var e : it.entrySet()) if (!e.getValue().startsWith("Folder\t") && parentOf(e.getKey()).equals(prefix)) {
            String[] cv = e.getValue().split("\t", 2);
            out.add(new Row(sec, null, 3, depth, e.getKey(), cv[0], cv.length > 1 ? cv[1] : ""));
        }
        for (String n : names) if (parentOf(n).equals(prefix)) out.add(new Row(sec, n, 1, depth, n, "Script", ""));
    }

    static int itemColor(String c) {
        return switch (c) {
            case "Folder" -> 0xFFFFC66B;
            case "StrValue" -> 0xFF6FA8FF;
            case "IntValue" -> 0xFF5BD68A;
            case "BoolValue" -> 0xFFFFD166;
            case "NumValue" -> 0xFF4FD1C5;
            case "ObjValue", "ObjectValue" -> 0xFFFF7EB6;
            default -> 0xFF7C7C92;
        };
    }
    static String itemLetter(String c) {
        return switch (c) { case "StrValue" -> "S"; case "IntValue" -> "I"; case "NumValue" -> "N"; case "BoolValue" -> "B"; case "ObjValue", "ObjectValue" -> "O"; default -> "?"; };
    }

    boolean isScriptFolder(String f) { return !f.equals("Workspace") && !f.equals("Console"); }

    void renderSidebar(GuiGraphics g, int mx, int my, float t) {
        g.fill(0, TOPH, sideW, height - STATH, SIDE);
        g.fill(sideW, TOPH, sideW + 1, height - STATH, LINE);
        small(g, font, "EXPLORER", 10, TOPH + 7, DIM);
        // search
        int sy = TOPH + 17;
        round(g, 6, sy, sideW - 6, sy + 16, filterBox.isFocused() ? 0xFF1E1E2A : 0xFF18181F);
        if (filterBox.isFocused()) outline(g, 6, sy, sideW - 6, sy + 16, alpha(ACCENT, 0.8f));
        filterBox.setX(20); filterBox.setWidth(sideW - 30); filterBox.setY(sy + 4);
        text(g, font, "⌕", 10, sy + 4, DIM);

        int top = TOPH + 38, bottom = height - STATH - 46;
        List<Row> rows = rows();
        int maxScroll = Math.max(0, rows.size() * ROW - (bottom - top));
        sideScroll = Math.min(sideScroll, maxScroll);
        scissor(g, 0, top, sideW, bottom);
        int y = top - sideScroll;
        for (Row r : rows) {
            if (y + ROW > top && y < bottom) {
                boolean hov = in(mx, my, 4, y, sideW - 4, y + ROW) && my >= top && my < bottom;
                boolean sel = r.kind == 0
                        ? (r.folder.equals("Workspace") && view.equals("workspace")) || (view.equals("folder") && r.folder.equals(selFolder) && selPath.isEmpty()) || (r.folder.equals("Console") && consoleOpen)
                        : r.kind == 1 && view.equals("editor") && key(r.folder, r.name).equals(active);
                float hv = anim("row:" + r.folder + "/" + r.kind + r.path, hov);
                if (sel) { round(g, 4, y, sideW - 4, y + ROW, SELROW); g.fill(4, y + 2, 6, y + ROW - 2, folderColor(r.folder)); }
                else if (hv > 0.02f) round(g, 4, y, sideW - 4, y + ROW, alpha(HOVER, hv));
                int col = folderColor(r.folder);
                if (r.kind == 0) {
                    boolean exp = EXPANDED.contains(r.folder) || !filterBox.getValue().isBlank();
                    if (isScriptFolder(r.folder)) text(g, font, exp ? "▾" : "▸", 9, y + 2, DIM);
                    if (!icon(g, r.folder, 17, y + 2, 9)) { round(g, 18, y + 3, 25, y + 10, col); g.fill(19, y + 4, 24, y + 5, 0x55FFFFFF); }
                    text(g, font, r.folder, 30, y + 3, sel ? 0xFFFFFFFF : 0xFFD4D4E0);
                    if (r.folder.equals("Workspace") && hov) {
                        boolean ph = in(mx, my, sideW - 18, y, sideW - 6, y + ROW);
                        text(g, font, "+", sideW - 14, y + 3, ph ? ACCENT2 : DIM);
                    }
                    if (isScriptFolder(r.folder)) {
                        int n = scripts.getOrDefault(r.folder, Map.of()).size();
                        if (hov) {
                            boolean ph = in(mx, my, sideW - 18, y, sideW - 6, y + ROW);
                            text(g, font, "+", sideW - 14, y + 3, ph ? ACCENT2 : DIM);
                        } else if (n > 0) small(g, font, String.valueOf(n), sideW - 12 - font.width(String.valueOf(n)) * 3 / 4, y + 4, FAINT);
                    }
                } else if (r.kind == 2) {
                    int ix = 22 + r.depth * 9;
                    boolean fsel = view.equals("folder") && r.folder.equals(selFolder) && r.path.equals(selPath);
                    if (fsel) { round(g, 4, y, sideW - 4, y + ROW, SELROW); g.fill(4, y + 2, 6, y + ROW - 2, col); }
                    text(g, font, FOLDED.contains(r.folder + "/" + r.path) ? "▸" : "▾", ix - 8, y + 2, DIM);
                    if (!icon(g, "Folder", ix, y + 2, 9)) { g.fill(ix, y + 4, ix + 8, y + 10, itemColor("Folder")); g.fill(ix, y + 3, ix + 4, y + 4, itemColor("Folder")); }
                    text(g, font, ellipsize(font, leaf(r.path), sideW - ix - 30), ix + 11, y + 3, 0xFFE0D8C0);
                    if (hov) { boolean ph = in(mx, my, sideW - 18, y, sideW - 6, y + ROW); text(g, font, "+", sideW - 14, y + 3, ph ? ACCENT2 : DIM); }
                } else if (r.kind == 3) {
                    int ix = 26 + r.depth * 9, ic = itemColor(r.cls);
                    if (!icon(g, r.cls, ix - 1, y + 2, 9)) { round(g, ix - 1, y + 2, ix + 7, y + 11, alpha(ic, 0.3f)); small(g, font, itemLetter(r.cls), ix + 1, y + 4, ic); }
                    String nm = ellipsize(font, leaf(r.path), (sideW - ix) / 2);
                    text(g, font, nm, ix + 10, y + 3, 0xFFC8D0E0);
                    int vx = ix + 14 + font.width(nm);
                    String v = r.value.isEmpty() ? "\"\"" : r.value;
                    small(g, font, ellipsize(font, "= " + v, (sideW - 10 - vx) * 4 / 3), vx, y + 4, FAINT);
                } else {
                    int ix = 26 + r.depth * 9;
                    g.fill(ix, y + 3, ix + 5, y + 10, alpha(col, 0.35f));
                    g.fill(ix, y + 3, ix + 5, y + 4, col);
                    boolean flat = !filterBox.getValue().isBlank();
                    String nm = ellipsize(font, flat ? r.name : leaf(r.name), sideW - ix - 26);
                    CodeEditor e = open.get(key(r.folder, r.name));
                    text(g, font, nm, ix + 9, y + 3, sel ? 0xFFFFFFFF : e != null ? 0xFFD0D0DC : 0xFFA8A8BA);
                    if (e != null && e.modified()) g.fill(sideW - 12, y + 5, sideW - 9, y + 8, ACCENT);
                    else if (e != null && e.errLine >= 0) g.fill(sideW - 12, y + 5, sideW - 9, y + 8, ERR);
                }
            }
            final Row fr = r; final int ry = y;
            if (y + ROW > top && y < bottom) hits.add(new Hit(4, Math.max(y, top), sideW - 4, Math.min(y + ROW, bottom), () -> clickRow(fr, ry)));
            y += ROW;
        }
        g.disableScissor();
        if (maxScroll > 0) {
            int th = Math.max(12, (bottom - top) * (bottom - top) / (rows.size() * ROW));
            int ty = top + (bottom - top - th) * sideScroll / maxScroll;
            round(g, sideW - 3, ty, sideW - 1, ty + th, 0x30FFFFFF);
        }

        // new script
        int ny = height - STATH - 41;
        g.fill(6, ny - 4, sideW - 6, ny - 3, LINE);
        round(g, 6, ny, sideW - 6, ny + 16, nameBox.isFocused() ? 0xFF1E1E2A : 0xFF18181F);
        if (nameBox.isFocused()) outline(g, 6, ny, sideW - 6, ny + 16, alpha(folderColor(target()), 0.9f));
        text(g, font, "+", 10, ny + 4, folderColor(target()));
        nameBox.setX(20); nameBox.setY(ny + 4); nameBox.setWidth(sideW - 30);
        nameBox.setHint(Component.literal("New in " + target() + (target().equals(selFolder) && !selPath.isEmpty() ? "/" + selPath : "") + "…").withStyle(ChatFormatting.DARK_GRAY));

        // camera mode chip (bottom-left)
        boolean cam = FreeCam.active();
        int cy = height - STATH - 21;
        boolean ch = in(mx, my, 6, cy, sideW - 6, cy + 16);
        float cv = anim("cam", ch);
        round(g, 6, cy, sideW - 6, cy + 16, cam ? lerp(0x3324C08A, 0x5524C08A, cv) : lerp(0x14FFFFFF, 0x26FFFFFF, cv));
        int dot = cam ? OK : DIM;
        float pulse = cam ? (float) (0.6 + 0.4 * Math.sin(t * 4)) : 1;
        round(g, 11, cy + 5, 17, cy + 11, alpha(dot, pulse));
        text(g, font, cam ? "Camera mode · on" : "Camera mode", 22, cy + 4, cam ? 0xFFDFFFEF : 0xFFB8B8C8);
        hits.add(new Hit(6, cy, sideW - 6, cy + 16, FreeCam::toggle));
    }

    void clickRow(Row r, int ry) {
        if (r.kind == 1) { openScript(r.folder, r.name); return; }
        if (r.kind == 2) {
            setFocused(null);
            selFolder = r.folder; selPath = r.path;
            if (lbtn == 1) { openPopup(r); return; }
            if (lmx >= sideW - 18) { openInsert(r.folder); return; }
            String k = r.folder + "/" + r.path;
            if (view.equals("folder") || lmx < 22 + r.depth * 9 + 2) { if (!FOLDED.remove(k)) FOLDED.add(k); }
            view = "folder"; contentScroll = 0;
            return;
        }
        if (r.kind == 3) { openPopup(r); return; }
        setFocused(null);
        selPath = "";
        switch (r.folder) {
            case "Workspace" -> {
                if (lmx >= sideW - 18) { openInsert("Workspace"); return; }
                view = "workspace"; selFolder = "Workspace"; contentScroll = 0; refreshTree();
            }
            case "Console" -> toggleConsole();
            default -> {
                if (lmx >= sideW - 18) { selFolder = r.folder; EXPANDED.add(r.folder); openInsert(r.folder); return; }
                if (!EXPANDED.remove(r.folder)) EXPANDED.add(r.folder);
                view = "folder"; selFolder = r.folder; contentScroll = 0;
            }
        }
    }

    // ------------------------------------------------------------------ main area
    void renderMain(GuiGraphics g, int mx, int my, float t) {
        int x0 = sideW + 1, x1 = width;
        renderTabs(g, mx, my, x0, x1);
        int top = contentTop(), bot = contentBottom();
        switch (view) {
            case "editor" -> {
                if (ed() != null) ed().render(g, mx, my, t);
                else renderWelcome(g, x0, top, x1, bot, t);
            }
            case "workspace" -> renderWorkspace(g, x0, top, x1, bot, mx, my);
            case "folder" -> renderFolder(g, x0, top, x1, bot, mx, my);
            default -> renderWelcome(g, x0, top, x1, bot, t);
        }
        if (consoleOpen) renderConsole(g, x0, bot, x1, height - STATH, mx, my);
    }

    void renderTabs(GuiGraphics g, int mx, int my, int x0, int x1) {
        int y = TOPH;
        g.fill(x0, y, x1, y + TABH, 0xF20F0F15);
        g.fill(x0, y + TABH - 1, x1, y + TABH, LINE);
        List<String> keys = new ArrayList<>(open.keySet());
        int[] ws = new int[keys.size()];
        int total = 0;
        for (int i = 0; i < keys.size(); i++) { ws[i] = Math.min(140, font.width(split(keys.get(i))[1]) + 30); total += ws[i]; }
        int start = 0;
        int ai = keys.indexOf(active);
        if (total > x1 - x0 && ai > 0) {
            int acc = 0;
            for (int i = ai; i >= 0; i--) { acc += ws[i]; if (acc > x1 - x0 - 10) { start = i + 1; break; } }
        }
        int x = x0;
        for (int i = start; i < keys.size() && x < x1; i++) {
            String k = keys.get(i);
            String[] s = split(k);
            CodeEditor e = open.get(k);
            boolean act = k.equals(active) && view.equals("editor");
            boolean hov = in(mx, my, x, y, x + ws[i], y + TABH);
            float hv = anim("tab:" + k, hov);
            if (act) { g.fill(x, y, x + ws[i], y + TABH, EDITOR); g.fill(x, y, x + ws[i], y + 1, folderColor(s[0])); }
            else if (hv > 0.02f) g.fill(x, y, x + ws[i], y + TABH - 1, alpha(HOVER, hv));
            g.fill(x + ws[i] - 1, y + 3, x + ws[i], y + TABH - 3, LINE);
            round(g, x + 7, y + 6, x + 11, y + 10, folderColor(s[0]));
            text(g, font, ellipsize(font, s[1], ws[i] - 32), x + 15, y + 4, act ? 0xFFFFFFFF : 0xFF9A9AAE);
            int cx = x + ws[i] - 13;
            boolean ch = in(mx, my, cx - 2, y + 2, cx + 9, y + TABH - 2);
            if (ch) round(g, cx - 2, y + 3, cx + 8, y + TABH - 3, 0x30FFFFFF);
            if (e.modified() && !ch) round(g, cx + 1, y + 6, cx + 5, y + 10, act ? TEXT : DIM);
            else if (hov || act) text(g, font, "×", cx + 1, y + 3, ch ? TEXT : DIM);
            final String fk = k; final int fx = x, fw = ws[i];
            hits.add(new Hit(x, y, x + ws[i], y + TABH, () -> {
                if (lmx >= fx + fw - 15) closeTab(fk);
                else { active = fk; view = "editor"; selFolder = split(fk)[0]; focusEditor(); }
            }));
            x += ws[i];
        }
        if (keys.isEmpty()) small(g, font, "No open scripts", x0 + 8, y + 5, FAINT);
    }

    void renderWelcome(GuiGraphics g, int x0, int y0, int x1, int y1, float t) {
        g.fill(x0, y0, x1, y1, EDITOR);
        int cx = (x0 + x1) / 2, cy = y0 + (y1 - y0) / 2 - 50;
        // soft glow
        for (int i = 6; i >= 1; i--) round(g, cx - 40 - i * 10, cy - 8 - i * 3, cx + 40 + i * 10, cy + 22 + i * 3, alpha(ACCENT, 0.012f * (7 - i)));
        String title = "ZSpace";
        float sc = 3f;
        int tw = (int) (font.width(title) * sc);
        g.pose().pushPose();
        g.pose().translate(cx - tw / 2f, cy, 0);
        g.pose().scale(sc, sc, 1);
        int px = 0;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            int c = lerp(ACCENT, ACCENT2, (float) (0.5 + 0.5 * Math.sin(t * 1.5 - i * 0.6)));
            g.drawString(font, ch, px, 0, c, false);
            px += font.width(ch);
        }
        g.pose().popPose();
        centered(g, font, "Lua scripting for your world", cx, cy + 32, DIM);

        String[][] keys = {{"Ctrl+S", "Save & reload"}, {"F5", "Run (UI/ClientScripts on client)"}, {"Ctrl+F / Ctrl+H", "Find / Replace"},
                {"Ctrl+/", "Toggle comment"}, {"Ctrl+D", "Duplicate line"}, {"Alt+↑/↓", "Move line"},
                {"Ctrl+Space", "Autocomplete"}, {"Ctrl+J", "Console"}, {"Ctrl+W", "Close tab"}, {"F8", "Close ZSpace"}};
        int ky = cy + 54, colW = 150;
        for (int i = 0; i < keys.length; i++) {
            int col = i % 2, row = i / 2;
            int kx = cx - colW + col * colW + 8, yy = ky + row * 13;
            if (yy > y1 - 12) break;
            int kw = font.width(keys[i][0]) + 8;
            round(g, kx, yy - 2, kx + kw, yy + 9, 0x22FFFFFF);
            text(g, font, keys[i][0], kx + 4, yy, 0xFFCFCFE0);
            text(g, font, keys[i][1], kx + kw + 6, yy, DIM);
        }
    }

    void card(GuiGraphics g, int x0, int y0, int x1, int y1, String title, int col) {
        round(g, x0, y0, x1, y1, PANEL);
        outline(g, x0, y0, x1, y1, 0xFF22222C);
        round(g, x0 + 8, y0 + 8, x0 + 15, y0 + 15, col);
        text(g, font, title, x0 + 20, y0 + 8, TEXT);
    }

    // ------------------------------------------------------------------ Workspace explorer
    void refreshTree() {
        FluwaNet.toServer(new Pkt(Pkt.C_ZTREE, "Workspace"));
        for (String id : ZEXP) if (!id.equals("Workspace")) FluwaNet.toServer(new Pkt(Pkt.C_ZTREE, id));
        if (zsel != null) FluwaNet.toServer(new Pkt(Pkt.C_ZPROPS, zsel));
    }

    /** server replies (tree children / properties / messages) */
    public void explorerReply(Pkt p) {
        if (p.type == Pkt.S_ZTREE) {
            List<String[]> l = new ArrayList<>();
            for (int i = 1; i < p.s.size(); i++) l.add(p.s.get(i).split("\t", -1));
            ZTREE.put(p.s(0), l);
            return;
        }
        String id = p.s(0);
        if (id.equals("#msg")) { setStatus(!p.s(1).startsWith("Error"), p.s(1)); return; }
        if (id.equals("#lua")) { minecraft.keyboardHandler.setClipboard(p.s(1)); setStatus(true, "Lua snippet copied to the clipboard"); return; }
        if (id.equals(zsel)) {
            List<String[]> l = new ArrayList<>();
            for (int i = 1; i < p.s.size(); i++) l.add(p.s.get(i).split("\t", -1));
            zprops = l;
        }
    }

    static boolean propsable(String id) { return !Set.of("Entities", "Players", "Dimensions", "Models", "#more").contains(id); }

    void clickNode(String id, boolean kids, boolean arrow) {
        if (kids && (arrow || !propsable(id) || id.equals(zsel))) {
            if (!ZEXP.remove(id)) { ZEXP.add(id); FluwaNet.toServer(new Pkt(Pkt.C_ZTREE, id)); }
        }
        if (propsable(id) && !id.equals(zsel)) {
            zsel = id; zprops = new ArrayList<>(); zScrollP = 0; editingProp = null; propBox.visible = false;
            FluwaNet.toServer(new Pkt(Pkt.C_ZPROPS, id));
        }
    }

    void flatten(String id, int depth, List<Object[]> out) {
        List<String[]> l = ZTREE.get(id);
        if (l == null) return;
        for (String[] r : l) {
            if (r.length < 4) continue;
            out.add(new Object[]{r, depth});
            if (r[3].equals("1") && ZEXP.contains(r[0])) flatten(r[0], depth + 1, out);
        }
    }

    static int classColor(String c) {
        return switch (c) {
            case "Player", "Players" -> 0xFF4FD1C5;
            case "Entity", "Entities" -> 0xFFFFA26B;
            case "Dimension", "Dimensions" -> 0xFF8B7CFF;
            case "Lighting" -> 0xFFFFD166;
            case "Terrain" -> 0xFF5BD68A;
            case "ProjectorObject", "Models" -> 0xFFE66BD6;
            case "Folder", "StrValue", "IntValue", "NumValue", "BoolValue", "ObjValue", "ObjectValue" -> itemColor(c);
            default -> 0xFF7C7C92;
        };
    }

    void renderWorkspace(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my) {
        g.fill(x0, y0, x1, y1, EDITOR);
        int split = zSplit = x0 + Math.max(140, (x1 - x0) * 45 / 100);
        // ---- tree
        int hy = y0 + 4;
        if (!icon(g, "Workspace", x0 + 8, hy + 2, 9)) round(g, x0 + 8, hy + 3, x0 + 15, hy + 10, folderColor("Workspace"));
        text(g, font, "Workspace", x0 + 21, hy + 2, TEXT);
        button(g, "zref", split - 46, hy, 18, 12, "⟳", 0, mx, my, this::refreshTree);
        button(g, "zadd", split - 24, hy, 18, 12, "+", 1, mx, my, () -> openInsert("Workspace"));
        int top = y0 + 20, bot = y1 - 2;
        g.fill(x0, top - 2, split, top - 1, LINE);
        List<Object[]> rows = new ArrayList<>();
        flatten("Workspace", 0, rows);
        int max = Math.max(0, rows.size() * ROW - (bot - top));
        zScrollT = Math.max(0, Math.min(zScrollT, max));
        scissor(g, x0, top, split, bot);
        int y = top - zScrollT;
        if (rows.isEmpty()) small(g, font, ZTREE.isEmpty() ? "Loading… (needs Creator rights)" : "empty", x0 + 10, top + 4, FAINT);
        for (Object[] o : rows) {
            String[] r = (String[]) o[0]; int depth = (int) o[1];
            if (y + ROW > top && y < bot) {
                boolean sel = r[0].equals(zsel), hov = in(mx, my, x0, y, split, y + ROW) && my >= top && my < bot;
                if (sel) round(g, x0 + 3, y, split - 3, y + ROW, SELROW);
                else if (hov) round(g, x0 + 3, y, split - 3, y + ROW, HOVER);
                int x = x0 + 8 + depth * 10;
                boolean kids = r[3].equals("1");
                if (kids) text(g, font, ZEXP.contains(r[0]) ? "▾" : "▸", x, y + 2, DIM);
                if (!icon(g, r[2], x + 9, y + 2, 9)) round(g, x + 10, y + 3, x + 17, y + 10, classColor(r[2]));
                text(g, font, ellipsize(font, r[1], split - x - 24), x + 21, y + 3, sel ? 0xFFFFFFFF : 0xFFC8C8D8);
                final String id = r[0]; final int ax = x;
                if (!id.startsWith("#")) hits.add(new Hit(x0 + 3, Math.max(y, top), split - 3, Math.min(y + ROW, bot), () -> clickNode(id, kids, lmx < ax + 9)));
            }
            y += ROW;
        }
        g.disableScissor();
        g.fill(split, y0, split + 1, y1, LINE);
        // ---- properties
        int px0 = split + 1, px1 = x1;
        small(g, font, "PROPERTIES", px0 + 8, hy + 3, DIM);
        if (zsel == null) { small(g, font, "Select an object in the explorer", px0 + 10, top + 4, FAINT); propBox.visible = false; return; }
        int bx = px1 - 6;
        int w = font.width("Delete") + 10; bx -= w; button(g, "zdel", bx, hy, w, 12, "Delete", 2, mx, my, () -> FluwaNet.toServer(new Pkt(Pkt.C_ZACTION, zsel, "delete")));
        w = font.width("Lua") + 10; bx -= w + 3; button(g, "zlua", bx, hy, w, 12, "Lua", 0, mx, my, () -> FluwaNet.toServer(new Pkt(Pkt.C_ZACTION, zsel, "lua")));
        w = font.width("Bring") + 10; bx -= w + 3; button(g, "zbring", bx, hy, w, 12, "Bring", 0, mx, my, () -> FluwaNet.toServer(new Pkt(Pkt.C_ZACTION, zsel, "bring")));
        w = font.width("Go to") + 10; bx -= w + 3; button(g, "zgoto", bx, hy, w, 12, "Go to", 0, mx, my, () -> FluwaNet.toServer(new Pkt(Pkt.C_ZACTION, zsel, "goto")));
        g.fill(px0, top - 2, px1, top - 1, LINE);
        int nameW = Math.max(70, (px1 - px0) * 38 / 100);
        int maxP = Math.max(0, zprops.size() * (ROW + 2) - (bot - top));
        zScrollP = Math.max(0, Math.min(zScrollP, maxP));
        scissor(g, px0, top, px1, bot);
        y = top - zScrollP;
        boolean editingShown = false;
        for (String[] r : zprops) {
            if (r.length < 4) continue;
            boolean rw = r[3].equals("1");
            boolean hov = in(mx, my, px0, y, px1, y + ROW + 2) && my >= top && my < bot;
            if (hov && rw) round(g, px0 + 3, y, px1 - 3, y + ROW + 1, HOVER);
            text(g, font, ellipsize(font, r[0], nameW - 14), px0 + 10, y + 3, DIM);
            g.fill(px0 + nameW, y, px0 + nameW + 1, y + ROW + 1, LINE);
            int vx = px0 + nameW + 6;
            if (r[0].equals(editingProp)) {
                round(g, vx - 3, y + 1, px1 - 6, y + ROW, 0xFF1E1E2A);
                outline(g, vx - 3, y + 1, px1 - 6, y + ROW, alpha(ACCENT, 0.8f));
                propBox.setX(vx + wx * 0); propBox.setY(y + 3); propBox.setWidth(px1 - vx - 12); propBox.visible = y >= top && y < bot;
                editingShown = true;
            } else {
                int col = !rw ? FAINT : r[1].equals("bool") ? (r[2].equals("true") ? OK : ERR) : r[1].equals("number") ? 0xFF8FC8FF : r[1].startsWith("vec") || r[1].equals("cframe") ? WARN : TEXT;
                text(g, font, ellipsize(font, r[2], px1 - vx - 10), vx, y + 3, col);
            }
            if (rw && y + ROW > top && y < bot) {
                final String[] fr = r;
                hits.add(new Hit(px0 + 3, Math.max(y, top), px1 - 3, Math.min(y + ROW + 1, bot), () -> editProp(fr)));
            }
            y += ROW + 2;
        }
        g.disableScissor();
        if (!editingShown) propBox.visible = false;
    }

    void editProp(String[] r) {
        if (r[1].equals("bool")) { FluwaNet.toServer(new Pkt(Pkt.C_ZSET, zsel, r[0], r[2].equals("true") ? "false" : "true")); return; }
        editingProp = r[0]; editingType = r[1];
        propBox.setValue(r[2]); propBox.visible = true;
        setFocused(propBox); editorFocus = false;
    }
    void commitProp() {
        if (editingProp != null && zsel != null) FluwaNet.toServer(new Pkt(Pkt.C_ZSET, zsel, editingProp, propBox.getValue()));
        editingProp = null; propBox.visible = false; setFocused(null);
    }

    // ------------------------------------------------------------------ "+" insert window
    void openInsert(String folder) {
        insOpen = true; insFolder = folder;
        String[] opts = insertOptions();
        insClass = opts[0];
        insArg.setValue(""); insName.setValue(""); insValue.setValue("");
        editorFocus = false;
        setFocused(folder.equals("Workspace") ? insArg : insName);
    }
    String[] insertOptions() {
        String[] base = insFolder.equals("Workspace") ? INS_WORKSPACE : insFolder.equals("UI") ? INS_UI : INS_SCRIPT;
        String[] r = Arrays.copyOf(base, base.length + ITEM_CLASSES.length);
        System.arraycopy(ITEM_CLASSES, 0, r, base.length, ITEM_CLASSES.length);
        return r;
    }

    /** target folder of a new Workspace item: the selected W: folder (or the folder of the selected value) */
    String wsBase() {
        if (zsel == null || !zsel.startsWith("W:")) return "";
        for (List<String[]> l : ZTREE.values()) for (String[] r : l) if (r.length > 2 && r[0].equals(zsel))
            return r[2].equals("Folder") ? zsel.substring(2) : parentOf(zsel.substring(2));
        return "";
    }
    /** a player (or one of its values) is selected in the explorer: values are inserted into that player */
    static boolean playerSel() { return zsel != null && (zsel.startsWith("P:") || zsel.startsWith("PV:")); }
    String itemBase() { return insFolder.equals("Workspace") ? wsBase() : insFolder.equals(selFolder) ? selPath : ""; }

    static String valueHint(String c) {
        return switch (c) {
            case "IntValue" -> "Value (whole number, 0)";
            case "BoolValue" -> "Value (true / false)";
            case "NumValue" -> "Value (number, 0.5)";
            case "ObjValue" -> "Object path (Workspace.Spawn) — optional";
            default -> "Value (text)";
        };
    }

    void sendItem(String op, String sec, String path, String a, String b, String c) {
        FluwaNet.toServer(new Pkt(Pkt.C_ZITEM, List.of(op, sec, path, a, b, c), null, null));
    }
    void localItem(String sec, String path, String cls, String val, boolean del) {
        var m = scripts.computeIfAbsent("#" + sec, k -> new TreeMap<>());
        if (del) m.keySet().removeIf(k -> k.equals(path) || k.startsWith(path + "/")); else m.put(path, cls + "\t" + val);
    }
    static String boolText(String v) { v = v.trim().toLowerCase(Locale.ROOT); return v.equals("true") || v.equals("1") || v.equals("yes") || v.equals("on") ? "true" : "false"; }
    static String cleanItem(String n) { return n.trim().replaceAll("[^\\w\\- ]", "_"); }

    static String argHint(String c) {
        return switch (c) {
            case "Entity" -> "Entity type (minecraft:pig)";
            case "Item" -> "Item id (minecraft:diamond)";
            case "Block" -> "Block id (minecraft:stone)";
            case "Model" -> "File in world/fluwa/models (car.glb)";
            default -> "";
        };
    }

    void renderInsert(GuiGraphics g, int mx, int my) {
        hits.add(new Hit(0, 0, width, height, () -> { insOpen = false; setFocused(null); }));
        String[] opts = insertOptions();
        int cols = 3, bw = 84, bh = 16;
        int rowsN = (opts.length + cols - 1) / cols;
        int pw = cols * (bw + 4) + 16, ph = 40 + rowsN * (bh + 4) + 52;
        int px = (width - pw) / 2, py = Math.max(TOPH + 8, (height - ph) / 2);
        shadow(g, px, py, px + pw, py + ph);
        round(g, px, py, px + pw, py + ph, 0xFA1A1A24);
        outline(g, px, py, px + pw, py + ph, alpha(folderColor(insFolder), 0.8f));
        hits.add(new Hit(px, py, px + pw, py + ph, () -> {}));
        if (!icon(g, insFolder, px + 8, py + 7, 9)) round(g, px + 8, py + 8, px + 15, py + 15, folderColor(insFolder));
        text(g, font, "Insert into " + insFolder, px + 21, py + 8, TEXT);
        button(g, "insx", px + pw - 20, py + 5, 14, 12, "✕", 0, mx, my, () -> { insOpen = false; setFocused(null); });
        int y = py + 26;
        for (int i = 0; i < opts.length; i++) {
            int bx = px + 8 + (i % cols) * (bw + 4), by = y + (i / cols) * (bh + 4);
            String c = opts[i];
            boolean sel = c.equals(insClass), hov = in(mx, my, bx, by, bx + bw, by + bh);
            round(g, bx, by, bx + bw, by + bh, sel ? 0x558B7CFF : hov ? 0x26FFFFFF : 0x12FFFFFF);
            if (sel) outline(g, bx, by, bx + bw, by + bh, ACCENT);
            if (!icon(g, c, bx + 4, by + 3, 9)) round(g, bx + 4, by + 4, bx + 11, by + 11, classColor(c));
            text(g, font, ellipsize(font, c, bw - 20), bx + 16, by + 4, sel ? 0xFFFFFFFF : 0xFFC8C8D8);
            hits.add(new Hit(bx, by, bx + bw, by + bh, () -> { insClass = c; setFocused(insFolder.equals("Workspace") && !isItem(c) ? insArg : insName); }));
        }
        y += rowsN * (bh + 4) + 4;
        boolean item = isItem(insClass);
        boolean ws = insFolder.equals("Workspace") && !item;
        EditBox b = ws ? insArg : insName;
        insArg.visible = ws; insName.visible = !ws;
        int nw2 = item && !insClass.equals("Folder") ? (pw - 20) / 2 : pw - 16;
        round(g, px + 8, y, px + 8 + nw2, y + 16, 0xFF141419);
        if (getFocused() == b) outline(g, px + 8, y, px + 8 + nw2, y + 16, alpha(ACCENT, 0.8f));
        b.setX(px + 13); b.setY(y + 4); b.setWidth(nw2 - 10);
        b.setHint(Component.literal(ws ? argHint(insClass) : item ? insClass + " name" : "Script name (" + insClass + ")").withStyle(ChatFormatting.DARK_GRAY));
        insValue.visible = item && !insClass.equals("Folder");
        if (insValue.visible) {
            int vx = px + 12 + nw2;
            round(g, vx, y, px + pw - 8, y + 16, 0xFF141419);
            if (getFocused() == insValue) outline(g, vx, y, px + pw - 8, y + 16, alpha(ACCENT, 0.8f));
            insValue.setX(vx + 5); insValue.setY(y + 4); insValue.setWidth(px + pw - 8 - vx - 10);
            insValue.setHint(Component.literal(valueHint(insClass)).withStyle(ChatFormatting.DARK_GRAY));
        }
        y += 22;
        if (ws) small(g, font, "Spawns in front of you" + (zsel != null && zsel.startsWith("D:") ? " · " + zsel.substring(2) : ""), px + 9, y + 4, FAINT);
        else if (item && insFolder.equals("Workspace") && playerSel()) small(g, font, "In the selected player · runtime value, replicated to that player's client", px + 9, y + 4, FAINT);
        else if (item) { String base = itemBase(); small(g, font, ellipsize(font, "In " + insFolder + (base.isEmpty() ? "" : "/" + base) + " · saved with the world", (pw - 70) * 4 / 3), px + 9, y + 4, FAINT); }
        else if (insFolder.equals(selFolder) && !selPath.isEmpty()) small(g, font, ellipsize(font, "In " + insFolder + "/" + selPath, (pw - 70) * 4 / 3), px + 9, y + 4, FAINT);
        int iw = font.width("Insert") + 16;
        button(g, "insok", px + pw - 8 - iw, y, iw, 14, "Insert", 1, mx, my, this::doInsert);
    }

    void doInsert() {
        if (insClass == null) return;
        if (isItem(insClass) && insFolder.equals("Workspace") && playerSel()) {
            String n = cleanItem(insName.getValue());
            if (n.isEmpty()) n = insClass;
            String v = insClass.equals("Folder") ? "" : insValue.getValue().trim();
            if (insClass.equals("BoolValue")) v = boolText(v);
            FluwaNet.toServer(new Pkt(Pkt.C_ZINSERT, zsel, insClass, n, v));
            ZEXP.add(zsel);
            insOpen = false; insArg.visible = insName.visible = insValue.visible = false;
            if (getFocused() == insArg || getFocused() == insName || getFocused() == insValue) setFocused(null);
            return;
        }
        if (isItem(insClass)) {
            String n = cleanItem(insName.getValue());
            if (n.isEmpty()) n = insClass;
            String base = itemBase(), path = base.isEmpty() ? n : base + "/" + n;
            String v = insClass.equals("Folder") ? "" : insValue.getValue().trim();
            if (v.isEmpty() && (insClass.equals("IntValue") || insClass.equals("NumValue"))) v = "0";
            if (insClass.equals("BoolValue")) v = boolText(v);
            sendItem("save", insFolder, path, insClass, v, "");
            localItem(insFolder, path, insClass, v, false);
            if (insFolder.equals("Workspace")) { if (!base.isEmpty()) ZEXP.add("W:" + base); refreshTree(); }
            else { EXPANDED.add(insFolder); FOLDED.remove(insFolder + "/" + base); }
            insOpen = false; insArg.visible = insName.visible = insValue.visible = false;
            if (getFocused() == insArg || getFocused() == insName || getFocused() == insValue) setFocused(null);
            return;
        }
        if (insFolder.equals("Workspace")) {
            String parent = zsel != null && zsel.startsWith("D:") ? zsel : "Workspace";
            FluwaNet.toServer(new Pkt(Pkt.C_ZINSERT, parent, insClass, insArg.getValue()));
            ZEXP.add(insClass.equals("Model") ? "Models" : "Entities");
        } else {
            String n = insName.getValue().trim().replaceAll("\\.lua$", "").replaceAll("[\\\\/:*?\"<>|]", "_");
            if (n.isEmpty()) n = insClass;
            String full = insFolder.equals(selFolder) && !selPath.isEmpty() ? selPath + "/" + n : n;
            selFolder = insFolder;
            createWith(insFolder, full, template(insFolder, insClass, n));
        }
        insOpen = false; insArg.visible = insName.visible = false;
        if (getFocused() == insArg || getFocused() == insName) setFocused(null);
    }

    static String template(String folder, String cls, String n) {
        if (folder.equals("UI")) {
            if (cls.equals("Script")) return defaultTpl(folder, n);
            String head = "-- " + n + "  ·  user interface\n";
            if (cls.equals("ScreenGUI") || cls.equals("Overlay"))
                return head + "local gui = Instance:new(\"" + cls + "\", UI)\ngui.Name = \"" + n + "\"\n\n";
            String extra = switch (cls) {
                case "TextLabel", "TextButton" -> "obj.Text = \"" + n + "\"\n";
                case "TextBox" -> "obj.PlaceholderText = \"Type here...\"\n";
                case "Image", "ImageButton" -> "obj.Image = \"minecraft:textures/item/diamond.png\"\n";
                case "VideoFrame" -> "obj.Video = \"intro\"  -- .minecraft/fluwa/videos/intro\nobj:Play()\n";
                default -> "";
            };
            return head + "local gui = Instance:new(\"ScreenGUI\", UI)\nlocal obj = Instance:new(\"" + cls + "\", gui)\nobj.Name = \"" + n + "\"\n"
                    + "obj.Size = UDim2.new(0, 200, 0, 60)\nobj.Position = UDim2.new(0.5, -100, 0.5, -30)\n" + extra + "\n";
        }
        String head = defaultTpl(folder, n);
        return switch (cls) {
            case "Event" -> head + "Players.E_Join:Connect(function(player)\n    print(player.Name .. \" joined\")\nend)\n";
            case "Loop" -> head + "while true do\n    wait(1)\n    \nend\n";
            case "RemoteEvent" -> head + "local remote = Instance:new(\"RemoteEvent\", Events)\nremote.Name = \"" + n + "\"\n";
            case "NET" -> head + "local NET = getAccess(\"NET\")\nlocal res = NET:HTTP(\"https://example.com\")\nprint(res.StatusCode)\n";
            case "Projector" -> head + "local Projector = getAccess(\"Projector\")\nlocal model = Projector:Import(\"model.glb\")\nmodel.Position = Vec3.new(0, 100, 0)\n";
            case "Item" -> head + "local item = Instance:new(\"Item\")\nitem.Name = \"" + n + "\"\nitem.Type = \"minecraft:diamond_sword\"\nitem.E_Used:Connect(function(player)\n    print(player.Name .. \" used " + n + "\")\nend)\n";
            default -> head;
        };
    }

    // ------------------------------------------------------------------ folder / value editor popup
    void openPopup(Row r) {
        popKind = r.kind == 2 ? "folder" : "value"; popSec = r.folder; popPath = r.path; popCls = r.cls; popArm = 0;
        popName.setValue(leaf(r.path)); popValue.setValue(r.value);
        editorFocus = false; menuOpen = false;
        setFocused(r.kind == 2 ? popName : popValue);
    }
    void closePopup() { popKind = null; popName.visible = popValue.visible = false; if (getFocused() == popName || getFocused() == popValue) setFocused(null); }

    void popPrimary() {
        if (popKind == null) return;
        String n = cleanItem(popName.getValue());
        if (n.isEmpty()) { setStatus(false, "Name is empty"); return; }
        String np = parentOf(popPath).isEmpty() ? n : parentOf(popPath) + "/" + n;
        if (popKind.equals("folder")) {
            if (!np.equals(popPath)) { sendItem("rename", popSec, popPath, np, "", ""); setStatus(true, "Renaming…"); }
        } else {
            String v = popValue.getValue();
            if (popCls.equals("BoolValue")) v = boolText(v);
            sendItem("save", popSec, np, popCls, v, popPath);
            if (!np.equals(popPath)) localItem(popSec, popPath, "", "", true);
            localItem(popSec, np, popCls, v, false);
        }
        closePopup();
    }
    void popDelete() {
        long now = System.currentTimeMillis();
        if (now - popArm > 3000) { popArm = now; return; }
        sendItem("delete", popSec, popPath, "", "", "");
        localItem(popSec, popPath, "", "", true);
        if (popKind.equals("folder") && popSec.equals(selFolder) && (selPath.equals(popPath) || selPath.startsWith(popPath + "/"))) selPath = "";
        closePopup();
    }

    void renderPopup(GuiGraphics g, int mx, int my) {
        hits.add(new Hit(0, 0, width, height, this::closePopup));
        boolean folder = popKind.equals("folder");
        int pw = Math.min(width - 20, 250), ph = folder ? 92 : 112;
        int px = (width - pw) / 2, py = Math.max(TOPH + 8, (height - ph) / 2);
        int ic = itemColor(popCls);
        shadow(g, px, py, px + pw, py + ph);
        round(g, px, py, px + pw, py + ph, 0xFA1A1A24);
        outline(g, px, py, px + pw, py + ph, alpha(ic, 0.8f));
        hits.add(new Hit(px, py, px + pw, py + ph, () -> {}));
        round(g, px + 8, py + 8, px + 15, py + 15, ic);
        text(g, font, ellipsize(font, popCls + "  ·  " + popSec + "/" + popPath, pw - 40), px + 21, py + 8, TEXT);
        button(g, "popx", px + pw - 20, py + 5, 14, 12, "✕", 0, mx, my, this::closePopup);
        int y = py + 26;
        small(g, font, "NAME", px + 9, y, DIM); y += 8;
        round(g, px + 8, y, px + pw - 8, y + 16, 0xFF141419);
        if (getFocused() == popName) outline(g, px + 8, y, px + pw - 8, y + 16, alpha(ACCENT, 0.8f));
        popName.setX(px + 13); popName.setY(y + 4); popName.setWidth(pw - 26); popName.visible = true;
        y += 22;
        popValue.visible = !folder;
        if (!folder) {
            small(g, font, "VALUE", px + 9, y, DIM); y += 8;
            round(g, px + 8, y, px + pw - 8, y + 16, 0xFF141419);
            if (getFocused() == popValue) outline(g, px + 8, y, px + pw - 8, y + 16, alpha(ACCENT, 0.8f));
            popValue.setX(px + 13); popValue.setY(y + 4); popValue.setWidth(pw - 26);
            popValue.setHint(Component.literal(valueHint(popCls)).withStyle(ChatFormatting.DARK_GRAY));
            y += 22;
        }
        y = py + ph - 20;
        boolean armed = System.currentTimeMillis() - popArm < 3000;
        String dl = armed ? (folder ? "Confirm? (all inside)" : "Confirm?") : "Delete";
        int w = font.width(dl) + 12;
        button(g, "popdel", px + 8, y, w, 14, dl, 2, mx, my, this::popDelete);
        String ok = folder ? "Rename" : "Save";
        int ow = font.width(ok) + 16, bx = px + pw - 8 - ow;
        button(g, "popok", bx, y, ow, 14, ok, 1, mx, my, this::popPrimary);
        if (folder) {
            String sec = popSec, path = popPath;
            if (isScriptFolder(sec)) {
                int sw2 = font.width("+ Script") + 10; bx -= sw2 + 4;
                button(g, "popscr", bx, y, sw2, 14, "+ Script", 0, mx, my, () -> { closePopup(); selFolder = sec; selPath = path; setFocused(nameBox); });
            }
            int iw = font.width("Insert…") + 10; bx -= iw + 4;
            button(g, "popins", bx, y, iw, 14, "Insert…", 0, mx, my, () -> { closePopup(); selFolder = sec; selPath = path; openInsert(sec); });
        }
    }

    // ------------------------------------------------------------------ ☰ menu
    static final String[] MENU = {"Tools", "Options", "About", "Help"};
    static final String[][] TOOLS = {{"Terrain DK", "dimensions · biomes · world-gen"}, {"Shader DK", "shaders with live preview"},
            {"World Editor", "Axiom-like world editing"}, {"GUI Maker", "design GUIs visually"}};

    void openTool(String n) {
        menuOpen = false;
        Screen sc = switch (n) {
            case "Terrain DK" -> new net.idea.fluwa.client.zspace.TerrainDKScreen(this);
            case "Shader DK" -> new net.idea.fluwa.client.zspace.ShaderDKScreen(this);
            case "World Editor" -> new net.idea.fluwa.client.zspace.WorldEditorScreen(this);
            case "GUI Maker" -> new net.idea.fluwa.client.zspace.GuiMakerScreen(this, scripts);
            case "Options" -> new net.idea.fluwa.client.zspace.ZPages.Options(this);
            case "About" -> new net.idea.fluwa.client.zspace.ZPages.About(this);
            default -> new net.idea.fluwa.client.zspace.ZPages.Help(this);
        };
        minecraft.setScreen(sc);
    }

    void renderMenu(GuiGraphics g, int mx, int my) {
        hits.add(new Hit(0, 0, width, height, () -> menuOpen = false));
        int w = 96, x1 = Math.min(width - 4, menuX + 16), x0 = x1 - w, y0 = TOPH + 2, rh = 15;
        int h = MENU.length * rh + 6;
        shadow(g, x0, y0, x1, y0 + h);
        round(g, x0, y0, x1, y0 + h, 0xFA1A1A24);
        outline(g, x0, y0, x1, y0 + h, alpha(ACCENT, 0.6f));
        hits.add(new Hit(x0, y0, x1, y0 + h, () -> {}));
        int y = y0 + 3, toolsY = y;
        for (String m : MENU) {
            boolean hov = in(mx, my, x0 + 2, y, x1 - 2, y + rh);
            if (m.equals("Tools") && hov) toolsSub = true;
            else if (hov) toolsSub = false;
            boolean act = hov || (m.equals("Tools") && toolsSub);
            if (act) round(g, x0 + 2, y, x1 - 2, y + rh, alpha(ACCENT, 0.35f));
            text(g, font, m, x0 + 8, y + 4, act ? 0xFFFFFFFF : 0xFFC8C8D8);
            if (m.equals("Tools")) { text(g, font, "◂", x1 - 12, y + 4, DIM); toolsY = y; }
            final String fm = m;
            hits.add(new Hit(x0 + 2, y, x1 - 2, y + rh, () -> { if (fm.equals("Tools")) toolsSub = !toolsSub; else openTool(fm); }));
            y += rh;
        }
        if (toolsSub) {
            int sw2 = 150, sx1 = x0 - 2, sx0 = Math.max(2, sx1 - sw2), sh2 = TOOLS.length * 22 + 6;
            shadow(g, sx0, toolsY - 3, sx1, toolsY - 3 + sh2);
            round(g, sx0, toolsY - 3, sx1, toolsY - 3 + sh2, 0xFA1A1A24);
            outline(g, sx0, toolsY - 3, sx1, toolsY - 3 + sh2, alpha(ACCENT, 0.6f));
            hits.add(new Hit(sx0, toolsY - 3, sx1, toolsY - 3 + sh2, () -> {}));
            int ty = toolsY;
            for (String[] t : TOOLS) {
                boolean hov = in(mx, my, sx0 + 2, ty, sx1 - 2, ty + 22);
                if (hov) round(g, sx0 + 2, ty, sx1 - 2, ty + 22, alpha(ACCENT, 0.35f));
                if (!icon(g, t[0], sx0 + 7, ty + 6, 10)) round(g, sx0 + 7, ty + 6, sx0 + 15, ty + 14, lerp(ACCENT, ACCENT2, ty % 7 / 6f));
                text(g, font, t[0], sx0 + 20, ty + 3, hov ? 0xFFFFFFFF : TEXT);
                small(g, font, t[1], sx0 + 20, ty + 13, DIM);
                final String n = t[0];
                hits.add(new Hit(sx0 + 2, ty, sx1 - 2, ty + 22, () -> openTool(n)));
                ty += 22;
            }
        }
    }

    void renderFolder(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my) {
        g.fill(x0, y0, x1, y1, EDITOR);
        int cx0 = x0 + 12, cx1 = x1 - 12, y = y0 + 12 - contentScroll;
        List<String> names = new ArrayList<>(scripts.getOrDefault(selFolder, Map.of()).keySet());
        if (!selPath.isEmpty()) names.removeIf(n -> !n.startsWith(selPath + "/"));
        names.sort(String.CASE_INSENSITIVE_ORDER);
        scissor(g, x0, y0, x1, y1);
        int col = folderColor(selFolder);
        int h = 44 + Math.max(1, names.size()) * 14;
        card(g, cx0, y, cx1, y + h, selFolder + (selPath.isEmpty() ? "" : "  ›  " + selPath.replace("/", "  ›  ")), col);
        small(g, font, folderHelp(selFolder), cx0 + 20, y + 20, DIM);
        int ly = y + 34;
        if (names.isEmpty()) text(g, font, "No scripts yet — type a name in the sidebar (+) and press Enter", cx0 + 12, ly + 2, FAINT);
        for (String n : names) {
            boolean hov = in(mx, my, cx0 + 6, ly, cx1 - 6, ly + 13) && my >= y0 && my < y1;
            float hv = anim("f:" + n, hov);
            if (hv > 0.02f) round(g, cx0 + 6, ly, cx1 - 6, ly + 13, alpha(HOVER, hv));
            g.fill(cx0 + 12, ly + 3, cx0 + 17, ly + 10, alpha(col, 0.35f));
            g.fill(cx0 + 12, ly + 3, cx0 + 17, ly + 4, col);
            text(g, font, (selPath.isEmpty() ? n : n.substring(selPath.length() + 1)) + ".lua", cx0 + 23, ly + 3, 0xFFD0D0DC);
            String src = scripts.get(selFolder).get(n);
            String info = (src == null ? 0 : src.split("\n", -1).length) + " lines";
            small(g, font, info, cx1 - 14 - font.width(info) * 3 / 4, ly + 4, FAINT);
            final String fn = n;
            hits.add(new Hit(cx0 + 6, Math.max(ly, y0), cx1 - 6, Math.min(ly + 13, y1), () -> openScript(selFolder, fn)));
            ly += 14;
        }
        g.disableScissor();
        contentScroll = Math.max(0, Math.min(contentScroll, h + 24 - (y1 - y0)));
    }

    void renderConsole(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my) {
        g.fill(x0, y0, x1, y1, 0xF70E0E13);
        g.fill(x0, y0, x1, y0 + 1, LINE);
        small(g, font, "CONSOLE", x0 + 10, y0 + 5, DIM);
        int sc = serverConsole.size(), cc = ClientState.CONSOLE.size();
        small(g, font, "server " + sc + " · client " + cc, x0 + 50, y0 + 5, FAINT);
        button(g, "conclose", x1 - 20, y0 + 2, 14, 11, "▾", 0, mx, my, this::toggleConsole);
        button(g, "conclear", x1 - 58, y0 + 2, 34, 11, "Clear", 0, mx, my, () -> { serverConsole.clear(); ClientState.CONSOLE.clear(); conScroll = 0; });
        String tl = consoleClient ? "Run on: client" : "Run on: server";
        int tw = font.width(tl) + 10;
        button(g, "context", x1 - 62 - tw, y0 + 2, tw, 11, tl, consoleClient ? 1 : 0, mx, my, () -> {
            consoleClient = !consoleClient;
            conInput.setHint(Component.literal(consoleClient ? "Run Lua on this client…  (Enter · s> = server)" : "Run Lua on the server…  (Enter · c> = client)").withStyle(ChatFormatting.DARK_GRAY));
        });
        // input
        int iy = y1 - 17;
        round(g, x0 + 6, iy, x1 - 6, iy + 14, conInput.isFocused() ? 0xFF1C1C26 : 0xFF16161D);
        if (conInput.isFocused()) outline(g, x0 + 6, iy, x1 - 6, iy + 14, alpha(ACCENT, 0.8f));
        text(g, font, "›", x0 + 10, iy + 3, ACCENT2);
        conInput.setX(x0 + 18); conInput.setY(iy + 3); conInput.setWidth(x1 - x0 - 28);
        // lines
        List<String[]> all = new ArrayList<>();
        for (String s : new ArrayList<>(serverConsole)) all.add(new String[]{"S", s});
        for (String s : new ArrayList<>(ClientState.CONSOLE)) all.add(new String[]{"C", s});
        int top = y0 + 16, bot = iy - 3;
        int max = Math.max(1, (bot - top) / 10);
        conScroll = Math.max(0, Math.min(conScroll, Math.max(0, all.size() - max)));
        int end = all.size() - conScroll, start = Math.max(0, end - max);
        scissor(g, x0, top, x1, bot);
        int ly = bot - (end - start) * 10;
        for (int i = start; i < end; i++) {
            String[] l = all.get(i);
            String low = l[1].toLowerCase(Locale.ROOT);
            int c = low.contains("error") || low.contains("exception") || low.contains("§c") ? ERR
                    : low.contains("warn") ? WARN : l[1].startsWith("> ") ? ACCENT2 : 0xFFC4C4D4;
            round(g, x0 + 8, ly + 1, x0 + 15, ly + 8, l[0].equals("S") ? 0x336FA8FF : 0x334FD1C5);
            small(g, font, l[0], x0 + 10, ly + 2, l[0].equals("S") ? 0xFF6FA8FF : 0xFF4FD1C5);
            if (c == ERR) g.fill(x0 + 18, ly, x0 + 19, ly + 9, ERR);
            text(g, font, l[1], x0 + 22, ly + 1, c);
            ly += 10;
        }
        g.disableScissor();
    }

    void renderStatus(GuiGraphics g, int mx, int my) {
        int y = height - STATH;
        g.fill(0, y, width, height, TOP);
        g.fill(0, y, width, y + 1, LINE);
        int x = 6;
        CodeEditor e = ed();
        boolean edView = e != null && view.equals("editor");
        if (edView) {
            String[] k = split(active);
            round(g, x, y + 4, x + 5, y + 9, folderColor(k[0]));
            x += 9;
            String path = k[0] + " / " + k[1] + ".lua";
            small(g, font, path, x, y + 4, 0xFFB8B8C8);
            x += font.width(path) * 3 / 4 + 12;
            if (e.errMsg != null) {
                String m = "✗ Ln " + (e.errLine + 1) + ": " + e.errMsg;
                m = ellipsize(font, m, Math.max(40, width / 2 - x));
                small(g, font, m, x, y + 4, ERR);
                int ex = x + font.width(m) * 3 / 4;
                hits.add(new Hit(x, y, ex, height, () -> { if (e.errLine >= 0) { e.gotoLine(e.errLine); focusEditor(); } }));
            } else small(g, font, "✓ No syntax errors", x, y + 4, OK);
        } else small(g, font, "Ready", x, y + 4, DIM);

        // right side
        int rx = width - 6;
        if (edView) {
            String r = "Ln " + e.line() + ", Col " + e.col() + "   " + e.lineCount() + " lines   Lua 5.2";
            rx -= font.width(r) * 3 / 4;
            small(g, font, r, rx, y + 4, DIM);
            rx -= 14;
        }
        if (!status.isEmpty()) {
            long age = System.currentTimeMillis() - statusSince;
            int c = statusOk ? (age < 6000 ? 0xFFB8F0CC : DIM) : (age < 6000 ? ERR : 0xFFB06070);
            String s = ellipsize(font, status, width / 3);
            rx -= font.width(s) * 3 / 4;
            small(g, font, s, rx, y + 4, c);
        }
    }

    void renderToasts(GuiGraphics g) {
        long now = System.currentTimeMillis();
        toasts.removeIf(t -> now - t.t > 3600);
        int y = TOPH + TABH + 6;
        for (Toast t : toasts) {
            float age = (now - t.t) / 1000f;
            float in = ease(age / 0.25f), out = age > 3.1f ? 1 - (age - 3.1f) / 0.5f : 1;
            String m = ellipsize(font, t.msg, 220);
            int w = font.width(m) + 26, x = width - 8 - (int) (w * in);
            int bg = alpha(0xFA1C1C26, out);
            shadow(g, x, y, x + w, y + 16);
            round(g, x, y, x + w, y + 16, bg);
            g.fill(x, y + 2, x + 2, y + 14, alpha(t.ok ? OK : ERR, out));
            text(g, font, t.ok ? "✓" : "!", x + 7, y + 4, alpha(t.ok ? OK : ERR, out));
            text(g, font, m, x + 17, y + 4, alpha(TEXT, out));
            y += 20;
        }
    }

    static String folderHelp(String f) {
        return switch (f) {
            case "InitScripts" -> "Run first, on the server AND every client. Shared modules (CAR) and Events.";
            case "ServerScripts" -> "Run on the server (world logic).";
            case "ClientScripts" -> "Run on each player's client (input, camera, effects).";
            case "UI" -> "Run on clients before ClientScripts; create ScreenGUI/Overlay here.";
            default -> "";
        };
    }

    static String uiNames() {
        if (!(net.idea.fluwa.api.GameRuntime.CLIENT instanceof ClientRuntime r)) return "-";
        List<String> n = new ArrayList<>();
        for (var o : r.ui.listChildren()) n.add(o.getName() + " (" + o.className + ")");
        return n.isEmpty() ? "-" : String.join(", ", n);
    }

    // ------------------------------------------------------------------ input
    @Override public boolean mouseClicked(double amx, double amy, int button) {
        double mx = (amx - wx) / S, my = (amy - wy) / S;
        if (!maxed && button == 0 && in(mx, my, width - 10, height - 10, width + 2, height + 2)) {
            dragMode = 2; dragX = amx; dragY = amy; dragNW = nw; dragNH = nh; return true;
        }
        if (mx < 0 || my < 0 || mx >= width || my >= height) { setFocused(null); return false; }
        return clickInner(mx, my, button);
    }

    boolean clickInner(double mx, double my, int button) {
        lmx = (int) mx; lmy = (int) my; lbtn = button;
        CodeEditor e = ed();
        boolean edView = e != null && view.equals("editor");
        if (edView && !menuOpen && !insOpen && popKind == null && in(mx, my, e.x, e.y, e.x + e.w, e.y + e.h)) {
            if (button == 2) return true;
            focusEditor();
            return e.mouseClicked(mx, my, button);
        }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (in(mx, my, h.x1, h.y1, h.x2, h.y2)) {
                if (button == 2 && my >= TOPH && my < TOPH + TABH) { // middle-click closes a tab
                    h.r.run(); if (active != null && lmx < width) closeTab(active); return true;
                }
                editorFocus = false;
                h.r.run();
                return true;
            }
        }
        if (button == 0 && my < TOPH && !insOpen) {
            long now = System.currentTimeMillis();
            if (now - lastTopClick < 300) { toggleMax(); lastTopClick = 0; return true; }
            lastTopClick = now;
            if (!maxed) { dragMode = 1; dragX = mx * S + wx; dragY = my * S + wy; dragNX = nx; dragNY = ny; }
            return true;
        }
        editorFocus = false;
        if (e != null) e.focused = false;
        if (editingProp != null && getFocused() == propBox) commitProp();
        boolean r = super.mouseClicked(mx, my, button);
        if (!r) setFocused(null);
        return r;
    }

    @Override public boolean mouseDragged(double amx, double amy, int b, double dx, double dy) {
        if (dragMode == 1) { nx = dragNX + (int) (amx - dragX); ny = dragNY + (int) (amy - dragY); applyWin(); return true; }
        if (dragMode == 2) { nw = dragNW + (int) (amx - dragX); nh = dragNH + (int) (amy - dragY); applyWin(); return true; }
        double mx = (amx - wx) / S, my = (amy - wy) / S;
        CodeEditor e = ed();
        if (e != null && view.equals("editor") && e.mouseDragged(mx, my)) return true;
        return super.mouseDragged(mx, my, b, dx / S, dy / S);
    }

    @Override public boolean mouseReleased(double amx, double amy, int b) {
        if (dragMode != 0) { dragMode = 0; return true; }
        double mx = (amx - wx) / S, my = (amy - wy) / S;
        if (ed() != null) ed().mouseReleased();
        return super.mouseReleased(mx, my, b);
    }

    @Override public boolean mouseScrolled(double amx, double amy, double delta) {
        double mx = (amx - wx) / S, my = (amy - wy) / S;
        if (mx < 0 || my < 0 || mx >= width || my >= height) return false;
        if (view.equals("workspace") && mx > sideW && !(consoleOpen && my >= contentBottom())) {
            if (mx < zSplit) zScrollT = Math.max(0, zScrollT - (int) (delta * ROW * 2)); else zScrollP = Math.max(0, zScrollP - (int) (delta * ROW * 2));
            return true;
        }
        if (mx < sideW) { sideScroll = Math.max(0, sideScroll - (int) (delta * ROW * 2)); return true; }
        if (consoleOpen && my >= contentBottom()) { conScroll = Math.max(0, conScroll + (int) (delta * 3)); return true; }
        CodeEditor e = ed();
        if (e != null && view.equals("editor") && e.mouseScrolled(mx, my, delta)) return true;
        contentScroll = Math.max(0, contentScroll - (int) (delta * 20));
        return true;
    }

    @Override public boolean charTyped(char c, int mods) {
        CodeEditor e = ed();
        if (getFocused() == null && e != null && view.equals("editor") && editorFocus) return e.charTyped(c);
        return super.charTyped(c, mods);
    }

    @Override public boolean keyPressed(int key, int sc, int mods) {
        boolean ctrl = hasControlDown(), shift = hasShiftDown();
        CodeEditor e = ed();
        boolean typingBox = getFocused() instanceof EditBox;
        // global shortcuts
        if (key == GLFW.GLFW_KEY_F8) { onClose(); return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE && menuOpen) { menuOpen = false; return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE && popKind != null) { closePopup(); return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE && insOpen) { insOpen = false; setFocused(null); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_M) { toggleMax(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_S) { save(); return true; }
        if (key == GLFW.GLFW_KEY_F5 || (ctrl && key == GLFW.GLFW_KEY_ENTER && !typingBox)) { run(); return true; }
        if (ctrl && shift && key == GLFW.GLFW_KEY_R) { reloadAll(); return true; }
        if (ctrl && (key == GLFW.GLFW_KEY_J || key == GLFW.GLFW_KEY_GRAVE_ACCENT)) { toggleConsole(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_W) { if (active != null) closeTab(active); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_N) { setFocused(nameBox); editorFocus = false; return true; }
        if (ctrl && key == GLFW.GLFW_KEY_P) { setFocused(filterBox); editorFocus = false; return true; }
        if (ctrl && key == GLFW.GLFW_KEY_TAB && !open.isEmpty()) {
            List<String> keys = new ArrayList<>(open.keySet());
            int i = Math.max(0, keys.indexOf(active));
            active = keys.get(Math.floorMod(i + (shift ? -1 : 1), keys.size()));
            view = "editor"; focusEditor();
            return true;
        }
        if (typingBox) {
            EditBox b = (EditBox) getFocused();
            if (key == GLFW.GLFW_KEY_ESCAPE && (b == insArg || b == insName || b == insValue)) { insOpen = false; setFocused(null); return true; }
            if (key == GLFW.GLFW_KEY_TAB && b == insName && insValue.visible) { setFocused(insValue); return true; }
            if (key == GLFW.GLFW_KEY_TAB && b == popName && popValue.visible) { setFocused(popValue); return true; }
            if (key == GLFW.GLFW_KEY_ESCAPE && b == propBox) { editingProp = null; propBox.visible = false; setFocused(null); return true; }
            if (key == GLFW.GLFW_KEY_ESCAPE) { setFocused(null); if (e != null && view.equals("editor")) editorFocus = true; return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                if (b == nameBox) create();
                else if (b == propBox) commitProp();
                else if (b == insArg || b == insName || b == insValue) doInsert();
                else if (b == popName || b == popValue) popPrimary();
                else if (b == conInput) runConsole();
                else if (b == filterBox) { var rs = rows(); for (Row r : rs) if (r.kind == 1) { openScript(r.folder, r.name); filterBox.setValue(""); break; } }
                return true;
            }
            if (b == conInput && (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) && !HISTORY.isEmpty()) {
                if (key == GLFW.GLFW_KEY_UP) histIdx = histIdx < 0 ? HISTORY.size() - 1 : Math.max(0, histIdx - 1);
                else histIdx = histIdx < 0 ? -1 : histIdx + 1 >= HISTORY.size() ? -1 : histIdx + 1;
                conInput.setValue(histIdx < 0 ? "" : HISTORY.get(histIdx));
                return true;
            }
            return super.keyPressed(key, sc, mods);
        }
        if (e != null && view.equals("editor") && editorFocus) {
            if (e.keyPressed(key, mods)) return true;
            if (key == GLFW.GLFW_KEY_TAB) return true;
        }
        return super.keyPressed(key, sc, mods);
    }

    @Override public void tick() {
        filterBox.tick(); nameBox.tick(); conInput.tick(); propBox.tick(); insArg.tick(); insName.tick(); insValue.tick(); popName.tick(); popValue.tick();
        for (CodeEditor e : open.values()) e.tick();
    }

    @Override public void removed() {
        net.idea.fluwa.client.zspace.ZUi.OX = net.idea.fluwa.client.zspace.ZUi.OY = 0; net.idea.fluwa.client.zspace.ZUi.SC = 1;
        lastActive = active; lastView = view; lastFolder = selFolder; lastConsole = consoleOpen; lastPath = selPath;
        super.removed();
    }

    @Override public boolean isPauseScreen() { return false; }
}
