package net.idea.fluwa.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/** Chromium:ShowPage / ShowText - simple in-game text browser (HTML is shown as plain text). */
public final class PageScreen extends Screen {
    final String url, text;
    List<FormattedCharSequence> lines = new ArrayList<>();
    double scroll;

    public PageScreen(String url, String text) { super(Component.literal(url)); this.url = url; this.text = text; }

    public static void show(String url, String text) {
        Minecraft.getInstance().execute(() -> Minecraft.getInstance().setScreen(new PageScreen(url, text)));
    }

    public static void open(String url) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            Screen back = mc.screen;
            mc.setScreen(new ConfirmLinkScreen(ok -> {
                if (ok) net.minecraft.Util.getPlatform().openUri(url);
                mc.setScreen(back);
            }, url, true));
        });
    }

    @Override protected void init() {
        lines = new ArrayList<>();
        for (String para : text.split("\n")) lines.addAll(font.split(Component.literal(para), width - 40));
        boolean web = url.startsWith("http://") || url.startsWith("https://");
        if (web) addRenderableWidget(Button.builder(Component.literal("Open in browser"), b -> open(url)).bounds(width - 210, 4, 100, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose()).bounds(width - 104, 4, 100, 18).build());
    }

    @Override public boolean mouseScrolled(double x, double y, double d) {
        int max = Math.max(0, lines.size() * 10 - (height - 40));
        scroll = Math.max(0, Math.min(max, scroll - d * 20));
        return true;
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(0, 0, width, 26, 0xC0101010);
        g.drawString(font, "§b" + font.plainSubstrByWidth(url, width - 230), 8, 9, 0xFFFFFF);
        g.enableScissor(0, 28, width, height);
        int y = 32 - (int) scroll;
        for (FormattedCharSequence l : lines) {
            if (y > 18 && y < height) g.drawString(font, l, 20, y, 0xE0E0E0);
            y += 10;
        }
        g.disableScissor();
        super.render(g, mx, my, pt);
    }
}
