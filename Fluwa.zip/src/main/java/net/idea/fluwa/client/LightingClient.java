package net.idea.fluwa.client;

import com.google.gson.*;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.idea.fluwa.api.GameRuntime;
import net.idea.fluwa.client.ui.UiTextures;
import net.idea.fluwa.lighting.*;
import net.idea.fluwa.lua.*;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.material.FogType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import org.joml.Matrix4f;
import org.luaj.vm2.LuaValue;

import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Client side of the v0.5 Lighting service: replicated server state + local client overrides, and every renderer
 * hook (fog, lightmap, sun/moon/stars, clouds, skyboxes, light glows). Post effects live in {@link LightingPost}.
 */
public final class LightingClient {
    private LightingClient() {}

    // ================================================================ replicated server state
    static final Map<String, LuaValue> SERVER = new HashMap<>();
    static final List<FxObj> SERVER_FX = new ArrayList<>();
    static final List<JsonObject> SERVER_LIGHTS = new ArrayList<>();

    static { LightingObj.CLIENT_INHERIT = SERVER::get; }
    public static void init() {}

    public static void receive(byte[] data) {
        SERVER.clear(); SERVER_FX.clear(); SERVER_LIGHTS.clear();
        if (data != null && data.length > 0) {
            try {
                JsonObject o = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
                if (o.has("props")) for (var e : o.getAsJsonObject("props").entrySet()) {
                    PropBag.P p = LightingObj.S.get(e.getKey());
                    if (p != null) SERVER.put(p.name(), PropBag.fromJson(p, e.getValue()));
                }
                if (o.has("fx")) for (JsonElement e : o.getAsJsonArray("fx")) { FxObj f = FxObj.fromFxJson(e.getAsJsonObject()); if (f != null) SERVER_FX.add(f); }
                if (o.has("lights")) for (JsonElement e : o.getAsJsonArray("lights")) SERVER_LIGHTS.add(e.getAsJsonObject());
            } catch (RuntimeException ex) { net.idea.fluwa.Fluwa.LOGGER.warn("Fluwa: bad lighting state", ex); }
        }
        LightingObj.VERSION++;
    }

    public static void reset() { receive(null); }

    static LightingObj local() { return GameRuntime.CLIENT instanceof ClientRuntime r && !r.closed ? LightingObj.of(r) : null; }

    // ================================================================ effective values
    static LuaValue v(String n) {
        LightingObj l = local();
        if (l != null) return l.value(n);
        LuaValue s = SERVER.get(n);
        if (s != null) return s;
        PropBag.P p = LightingObj.S.get(n);
        return p == null ? LuaValue.NIL : p.def();
    }
    static boolean explicit(String n) { LightingObj l = local(); return l != null ? l.has(n) : SERVER.containsKey(n); }
    static double num(String n) { return v(n).todouble(); }
    static boolean bool(String n) { return v(n).toboolean(); }
    static float[] col(LuaValue c) { return c instanceof ColorL x ? new float[]{x.r / 255f, x.g / 255f, x.b / 255f} : new float[]{1, 1, 1}; }
    static float[] col(String n) { return col(v(n)); }

    /** effects in order: server ones, then the ones created by client scripts */
    static List<FxObj> effects() {
        List<FxObj> l = new ArrayList<>(SERVER_FX);
        LightingObj lo = local();
        if (lo != null) l.addAll(lo.effects());
        return l;
    }
    /** last enabled effect of a class (Sky, Atmosphere, Clouds) */
    static FxObj last(String cls) {
        FxObj r = null;
        for (FxObj f : effects()) if (f.className.equals(cls) && (f.schema().get("Enabled") == null || f.bool("Enabled"))) r = f;
        return r;
    }
    static FxObj lastAny(String cls) { FxObj r = null; for (FxObj f : effects()) if (f.className.equals(cls)) r = f; return r; }

    // ================================================================ cached snapshot
    static int snapVersion = -1;
    static Snap snap = new Snap();

    static final class Snap {
        boolean fog, lightmap, celestial, skyFaces;
        float[] fogColor; float fogStart, fogEnd;
        FxObj atm, sky, clouds;
        float brightness = 1, softness; boolean shadows = true;
        float[] ambient = {0, 0, 0}, outdoor = {.5f, .5f, .5f}, shiftTop = {0, 0, 0}, shiftBottom = {0, 0, 0};
        Vec3 sunDir, moonDir; float latitude;
        boolean sunVis = true, moonVis = true, starsVis = true;
        float sunHalf = 30, moonHalf = 20; float[] sunColor = {1, 1, 1}, moonColor = {1, 1, 1};
        int stars = 1500; String sunTex = "", moonTex = "", starTex = "", skybox = "";
        String[] faces;
        String tech = "Legacy"; int techLevel; // 0 Legacy, 1 Compatibility, 2 Voxel, 3 ShadowMap, 4 Future
    }

    static Snap snap() {
        int ver = LightingObj.VERSION;
        if (ver == snapVersion) return snap;
        snapVersion = ver;
        Snap s = new Snap();
        try {
            s.atm = last("Atmosphere"); s.sky = last("Sky"); s.clouds = lastAny("Clouds");
            s.fog = bool("FogEnabled"); s.fogColor = col("FogColor"); s.fogStart = (float) num("FogStart"); s.fogEnd = (float) num("FogEnd");
            s.brightness = (float) num("Brightness"); s.softness = (float) num("ShadowSoftness"); s.shadows = bool("GlobalShadows");
            s.ambient = col("Ambient"); s.outdoor = col("OutdoorAmbient"); s.shiftTop = col("ColorShift_Top"); s.shiftBottom = col("ColorShift_Bottom");
            s.tech = v("Technology").isnil() ? "Legacy" : v("Technology").tojstring();
            s.techLevel = switch (s.tech) { case "Compatibility" -> 1; case "Voxel" -> 2; case "ShadowMap" -> 3; case "Future" -> 4; default -> 0; };
            s.lightmap = s.techLevel > 0 || s.brightness != 1 || !s.shadows || s.softness > 0 || nz(s.ambient) || Math.abs(s.outdoor[0] - 128 / 255f) > 0.003 || Math.abs(s.outdoor[1] - 128 / 255f) > 0.003
                    || Math.abs(s.outdoor[2] - 128 / 255f) > 0.003 || nz(s.shiftTop) || nz(s.shiftBottom);
            s.latitude = (float) num("GeographicLatitude");
            FxObj sky = s.sky;
            s.sunVis = bool("SunVisible") && bool("CelestialBodiesVisible") && (sky == null || sky.bool("SunVisible") && sky.bool("CelestialBodiesVisible"));
            s.moonVis = bool("MoonVisible") && bool("CelestialBodiesVisible") && (sky == null || sky.bool("MoonVisible") && sky.bool("CelestialBodiesVisible"));
            s.starsVis = bool("CelestialBodiesVisible") && (sky == null || sky.bool("CelestialBodiesVisible"));
            double sunAng = sky != null ? sky.num("SunAngularSize") : 33.4, moonAng = sky != null ? sky.num("MoonAngularSize") : 22.6;
            s.sunHalf = (float) (100 * Math.tan(Math.toRadians(Math.min(170, sunAng * num("SunSize")) / 2)));
            s.moonHalf = (float) (100 * Math.tan(Math.toRadians(Math.min(170, moonAng * num("MoonSize")) / 2)));
            s.sunColor = col("SunColor"); s.moonColor = col("MoonColor");
            s.stars = (int) (sky != null && sky.has("StarCount") ? sky.num("StarCount") : num("StarCount"));
            if (sky != null) { s.sunTex = sky.str("SunTexture"); s.moonTex = sky.str("MoonTexture"); s.starTex = sky.str("StarTexture"); }
            s.sunDir = explicit("SunPosition") && v("SunPosition") instanceof Vec3L p ? p.unit().mc() : null;
            s.moonDir = explicit("MoonPosition") && v("MoonPosition") instanceof Vec3L p ? p.unit().mc() : s.sunDir != null ? s.sunDir.scale(-1) : null;
            s.skybox = String.valueOf(v("Skybox").tojstring());
            if (sky != null) {
                String[] f = {sky.str("SkyboxUp"), sky.str("SkyboxDown"), sky.str("SkyboxFront"), sky.str("SkyboxBack"), sky.str("SkyboxLeft"), sky.str("SkyboxRight")};
                for (String x : f) if (!x.isEmpty()) { s.faces = f; s.skyFaces = true; break; }
            }
            s.celestial = s.skyFaces || !s.sunVis || !s.moonVis || !s.starsVis || s.latitude != 0 || s.sunHalf != 30 && Math.abs(s.sunHalf - 30) > 0.05
                    || Math.abs(s.moonHalf - 20) > 0.05 || nz1(s.sunColor) || nz1(s.moonColor) || s.stars != 1500 || s.sunDir != null || explicit("MoonPosition")
                    || !s.sunTex.isEmpty() || !s.moonTex.isEmpty() || !s.starTex.isEmpty();
        } catch (RuntimeException ex) { net.idea.fluwa.Fluwa.LOGGER.debug("lighting snapshot", ex); }
        snap = s;
        return s;
    }
    static boolean nz(float[] c) { return c[0] > 0.002 || c[1] > 0.002 || c[2] > 0.002; }
    static boolean nz1(float[] c) { return c[0] < 0.998 || c[1] < 0.998 || c[2] < 0.998; }

    // ================================================================ fog
    public static void fog(ViewportEvent.RenderFog e) {
        if (e.getMode() != net.minecraft.client.renderer.FogRenderer.FogMode.FOG_TERRAIN) return;
        if (e.getCamera().getFluidInCamera() != FogType.NONE) return;
        Snap s = snap();
        float near = e.getNearPlaneDistance(), far = e.getFarPlaneDistance();
        boolean ch = false;
        if (s.atm != null) {
            float d = (float) s.atm.num("Density"), off = (float) s.atm.num("Offset"), haze = (float) s.atm.num("Haze");
            far = far * (1 - 0.85f * Math.min(1, d + haze * 0.05f));
            near = far * (0.05f + 0.85f * off);
            ch = true;
        }
        if (s.fog) {
            float fe = Math.max(0.5f, s.fogEnd), fs = Math.min(s.fogStart, fe - 0.25f);
            if (fe < far || ch) { far = Math.min(far, fe); near = Math.min(far - 0.25f, fs); ch = true; }
            else { near = Math.min(near, fs); far = Math.min(far, fe); ch = true; }
        }
        if (!ch) return;
        e.setNearPlaneDistance(near);
        e.setFarPlaneDistance(far);
        e.setCanceled(true);
    }

    public static void fogColor(ViewportEvent.ComputeFogColor e) {
        if (e.getCamera().getFluidInCamera() != FogType.NONE) return;
        Snap s = snap();
        float r = e.getRed(), g = e.getGreen(), b = e.getBlue();
        if (s.atm != null) {
            float k = (float) Math.min(1, s.atm.num("Density") * 0.8 + s.atm.num("Haze") * 0.05);
            float[] c = col(s.atm.value("Color")), dc = col(s.atm.value("Decay"));
            float sunset = 0;
            ClientLevel lv = Minecraft.getInstance().level;
            if (lv != null) { float t = lv.getTimeOfDay((float) e.getPartialTick()); sunset = (float) Math.max(0, 1 - Math.abs(Math.cos(t * Math.PI * 2)) * 3); }
            float bright = Math.max(r, Math.max(g, b));
            for (int i = 0; i < 3; i++) {
                float tgt = (c[i] * (1 - sunset) + dc[i] * sunset) * Math.max(0.15f, bright);
                if (i == 0) r = r + (tgt - r) * k; else if (i == 1) g = g + (tgt - g) * k; else b = b + (tgt - b) * k;
            }
        }
        if (s.fog) { float[] c = s.fogColor; r = c[0]; g = c[1]; b = c[2];
            ClientLevel lv = Minecraft.getInstance().level;
            if (lv != null) { float sky = Math.max(0.12f, 1 - lv.getSkyDarken(1f) * 0.85f); r *= sky; g *= sky; b *= sky; } }
        e.setRed(r); e.setGreen(g); e.setBlue(b);
    }

    // ================================================================ lightmap (LightTextureMixin)
    static final int[] ORIG = new int[256];
    public static void lightmap(com.mojang.blaze3d.platform.NativeImage img) {
        Snap s = snap();
        if (!s.lightmap) return;
        for (int i = 0; i < 16; i++) for (int j = 0; j < 16; j++) ORIG[i * 16 + j] = img.getPixelRGBA(j, i);
        float[] base = rgb(ORIG[0]);
        float kr = s.brightness * s.outdoor[0] / (128 / 255f), kg = s.brightness * s.outdoor[1] / (128 / 255f), kb = s.brightness * s.outdoor[2] / (128 / 255f);
        for (int i = 0; i < 16; i++) {
            float[] skyOnly = rgb(ORIG[i * 16]);
            float sf = i / 15f;
            for (int j = 0; j < 16; j++) {
                float[] c = rgb(ORIG[i * 16 + j]);
                if (!s.shadows) c = rgb(ORIG[15 * 16 + j]);
                else if (s.softness > 0) { float[] l = rgb(ORIG[15 * 16 + j]); for (int k = 0; k < 3; k++) c[k] += (l[k] - c[k]) * s.softness * 0.5f; }
                float sr = Math.max(0, skyOnly[0] - base[0]), sg = Math.max(0, skyOnly[1] - base[1]), sb = Math.max(0, skyOnly[2] - base[2]);
                c[0] += (kr - 1) * sr; c[1] += (kg - 1) * sg; c[2] += (kb - 1) * sb;
                float dark = 1 - sf;
                for (int k = 0; k < 3; k++) c[k] += s.ambient[k] * dark * 0.6f + s.shiftTop[k] * sf * 0.25f * Math.min(1, skyOnly[k] * 2) + s.shiftBottom[k] * dark * 0.2f;
                if (s.techLevel > 0) tech(s, c, sf, j / 15f);
                img.setPixelRGBA(j, i, 0xFF000000 | cl(c[2]) << 16 | cl(c[1]) << 8 | cl(c[0]));
            }
        }
    }
    /**
     * Lighting.Technology response of the lightmap (sf = sky light 0..1, bf = block light 0..1).
     *  Compatibility - flat, low contrast (Roblox: no light shadows, simple ambient)
     *  Voxel         - soft voxel falloff, ambient bleeds into shade, lights spread wider
     *  ShadowMap     - deep sun shade + sun-coloured lit areas (sharp shadows come from LightingPost)
     *  Future        - ShadowMap + stronger, warmer local lights with a bright core
     */
    static void tech(Snap s, float[] c, float sf, float bf) {
        float l = (c[0] + c[1] + c[2]) / 3f;
        switch (s.techLevel) {
            case 1 -> { for (int k = 0; k < 3; k++) c[k] = c[k] * 0.7f + 0.3f * (0.35f + l * 0.65f); }
            case 2 -> {
                float spread = (float) Math.sqrt(bf) - bf; // wider, smoother light falloff
                for (int k = 0; k < 3; k++) c[k] += spread * 0.25f + s.outdoor[k] * (1 - sf) * 0.12f;
            }
            case 3, 4 -> {
                float shade = 1 - sf;
                for (int k = 0; k < 3; k++) {
                    c[k] *= 1 - shade * (1 - bf) * 0.28f;                       // deeper shade without light
                    c[k] *= 1 + (s.sunColor[k] - 1) * sf * sf * 0.18f;           // sun tint on lit surfaces
                }
                if (s.techLevel == 4) {
                    float core = bf * bf * bf;
                    c[0] += core * 0.22f; c[1] += core * 0.14f; c[2] += core * 0.05f; // warm, bright light cores
                }
            }
        }
    }
    static int techLevel() { try { return snap().techLevel; } catch (RuntimeException e) { return 0; } }

    static float[] rgb(int abgr) { return new float[]{(abgr & 255) / 255f, (abgr >> 8 & 255) / 255f, (abgr >> 16 & 255) / 255f}; }
    static int cl(float v) { return Math.max(0, Math.min(255, Math.round(v * 255))); }

    // ================================================================ sky hooks (LevelRendererMixin)
    /** true = vanilla sun/moon/stars are replaced by {@link #renderCelestial} */
    public static boolean customCelestial() { try { return snap().celestial; } catch (RuntimeException e) { return false; } }

    // clouds
    public static boolean cloudsDisabled() { FxObj c = snap().clouds; return c != null && !c.bool("Enabled"); }
    public static float cloudHeight(float vanilla) { FxObj c = snap().clouds; return c != null && c.has("Height") ? (float) c.num("Height") : vanilla; }
    public static float cloudSpeed(float vanilla) { FxObj c = snap().clouds; return c == null ? vanilla : (float) (vanilla * c.num("Speed")); }
    public static Vec3 cloudColor(Vec3 v) { FxObj c = snap().clouds; if (c == null) return v; float[] k = col(c.value("Color")); return new Vec3(v.x * k[0], v.y * k[1], v.z * k[2]); }
    public static float cloudAlpha() { FxObj c = snap().clouds; return c == null ? 1 : (float) Math.min(1.25, c.num("Density") / 0.8); }

    static ResourceLocation coverTex; static double coverFor = -1;
    public static ResourceLocation cloudTexture(ResourceLocation vanilla) {
        FxObj c = snap().clouds;
        if (c == null) return vanilla;
        String t = c.str("Texture");
        if (!t.isEmpty()) { ResourceLocation r = UiTextures.get(t, "textures"); if (r != null) return r; }
        double cover = c.num("Cover");
        if (Math.abs(cover - 0.5) < 0.001) return vanilla;
        if (coverTex == null || coverFor != cover) {
            coverFor = cover;
            com.mojang.blaze3d.platform.NativeImage img = new com.mojang.blaze3d.platform.NativeImage(256, 256, true);
            net.minecraft.world.level.levelgen.synth.ImprovedNoise n = new net.minecraft.world.level.levelgen.synth.ImprovedNoise(RandomSource.create(1234));
            double thr = 1 - cover * 2; // -1..1
            for (int x = 0; x < 256; x++) for (int y = 0; y < 256; y++) {
                double a = Math.PI * 2 * x / 256, b = Math.PI * 2 * y / 256; // tileable
                double v = n.noise(Math.cos(a) * 6, Math.sin(a) * 6 + Math.cos(b) * 6, Math.sin(b) * 6) * 1.6 + n.noise(Math.cos(a) * 14 + 50, Math.sin(a) * 14, Math.cos(b) * 14 + Math.sin(b) * 14) * 0.5;
                img.setPixelRGBA(x, y, v > thr * 0.9 ? 0xFFFFFFFF : 0);
            }
            var tex = new net.minecraft.client.renderer.texture.DynamicTexture(img);
            coverTex = new ResourceLocation("fluwa", "clouds_cover");
            Minecraft.getInstance().getTextureManager().register(coverTex, tex);
        }
        return coverTex;
    }

    // ================================================================ AFTER_SKY: skyboxes + custom sun, moon, stars
    static final String[] FACE_NAMES = {"Up", "Down", "Front", "Back", "Left", "Right"};

    /** @return true if a skybox was drawn */
    public static boolean renderSkybox(RenderLevelStageEvent e) {
        Snap s = snap();
        Minecraft mc = Minecraft.getInstance();
        PoseStack ps = e.getPoseStack();
        if (s.skyFaces) {
            RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getPositionTexShader);
            RenderSystem.setShaderColor(1, 1, 1, 1);
            for (int i = 0; i < 6; i++) {
                if (s.faces[i].isEmpty()) continue;
                ResourceLocation tex = UiTextures.get(s.faces[i], "skyboxes");
                if (tex == null) continue;
                RenderSystem.setShaderTexture(0, tex);
                ps.pushPose();
                switch (i) { // the quad is drawn on the top face (y = +100)
                    case 1 -> ps.mulPose(Axis.XP.rotationDegrees(180));
                    case 2 -> ps.mulPose(Axis.XP.rotationDegrees(-90)); // north (-Z)
                    case 3 -> { ps.mulPose(Axis.YP.rotationDegrees(180)); ps.mulPose(Axis.XP.rotationDegrees(-90)); }
                    case 4 -> { ps.mulPose(Axis.YP.rotationDegrees(90)); ps.mulPose(Axis.XP.rotationDegrees(-90)); } // west (-X)
                    case 5 -> { ps.mulPose(Axis.YP.rotationDegrees(-90)); ps.mulPose(Axis.XP.rotationDegrees(-90)); }
                }
                Matrix4f m = ps.last().pose();
                BufferBuilder b = Tesselator.getInstance().getBuilder();
                b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
                b.vertex(m, -100, 100, -100).uv(0, 0).endVertex();
                b.vertex(m, -100, 100, 100).uv(0, 1).endVertex();
                b.vertex(m, 100, 100, 100).uv(1, 1).endVertex();
                b.vertex(m, 100, 100, -100).uv(1, 0).endVertex();
                BufferUploader.drawWithShader(b.end());
                ps.popPose();
            }
            RenderSystem.depthMask(true); RenderSystem.disableBlend();
            return true;
        }
        String file = mc.level == null ? null : ClientState.SKYBOX.get(mc.level.dimension().location().toString());
        if ((file == null || file.isEmpty()) && !s.skybox.isEmpty()) file = s.skybox;
        if (file == null || file.isEmpty()) return false;
        return SkyboxRenderer.draw(ps, file);
    }

    /** current sun direction (world space) */
    static Vec3 sunDir(float pt) {
        Snap s = snap();
        if (s.sunDir != null) return s.sunDir;
        ClientLevel lv = Minecraft.getInstance().level;
        double th = (lv == null ? 0 : lv.getTimeOfDay(pt)) * Math.PI * 2, lat = Math.toRadians(s.latitude);
        return new Vec3(-Math.sin(th), Math.cos(th) * Math.cos(lat), Math.cos(th) * Math.sin(lat));
    }

    static VertexBuffer starBuf; static int starBufCount = -1; static boolean starBufTex;

    public static void renderCelestial(RenderLevelStageEvent e) {
        Snap s = snap();
        if (!s.celestial) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel lv = mc.level;
        if (lv == null || lv.effects().skyType() != net.minecraft.client.renderer.DimensionSpecialEffects.SkyType.NORMAL) return;
        Camera cam = e.getCamera();
        FogType ft = cam.getFluidInCamera();
        if (ft == FogType.LAVA || ft == FogType.POWDER_SNOW) return;
        float pt = e.getPartialTick();
        PoseStack ps = e.getPoseStack();
        float rain = 1 - lv.getRainLevel(pt);
        float time = lv.getTimeOfDay(pt);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE,
                com.mojang.blaze3d.platform.GlStateManager.SourceFactor.ONE, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ZERO);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull(); // the quads face the camera from any side (fix: SunSize / MoonSize made them invisible)
        ps.pushPose();
        ps.mulPose(Axis.XP.rotationDegrees(s.latitude));
        ps.pushPose();
        // ---- stars (follow the time of day)
        float sb = lv.getStarBrightness(pt) * rain;
        if (s.starsVis && sb > 0 && s.stars > 0) {
            ps.pushPose();
            ps.mulPose(Axis.YP.rotationDegrees(-90));
            ps.mulPose(Axis.XP.rotationDegrees(time * 360));
            ResourceLocation st = s.starTex.isEmpty() ? null : UiTextures.get(s.starTex, "skyboxes");
            buildStars(Math.min(20000, s.stars), st != null);
            RenderSystem.setShaderColor(sb, sb, sb, sb);
            net.minecraft.client.renderer.FogRenderer.setupNoFog();
            starBuf.bind();
            if (st != null) { RenderSystem.setShaderTexture(0, st); starBuf.drawWithShader(ps.last().pose(), e.getProjectionMatrix(), GameRenderer.getPositionTexShader()); }
            else starBuf.drawWithShader(ps.last().pose(), e.getProjectionMatrix(), GameRenderer.getPositionShader());
            VertexBuffer.unbind();
            ps.popPose();
        }
        ps.popPose();
        ps.popPose();
        ps.pushPose();
        // ---- sun & moon (world space; the default path is tilted by GeographicLatitude)
        double th = time * Math.PI * 2, lat = Math.toRadians(s.latitude);
        Vec3 sun = s.sunDir != null ? s.sunDir : new Vec3(-Math.sin(th), Math.cos(th) * Math.cos(lat), Math.cos(th) * Math.sin(lat));
        Vec3 moon = s.moonDir != null ? s.moonDir : sun.scale(-1);
        if (s.sunVis) {
            ResourceLocation t = s.sunTex.isEmpty() ? null : UiTextures.get(s.sunTex, "skyboxes");
            quad(ps, sun, s.sunHalf, t != null ? t : new ResourceLocation("textures/environment/sun.png"), 0, 0, 1, 1, s.sunColor, rain);
        }
        if (s.moonVis) {
            ResourceLocation t = s.moonTex.isEmpty() ? null : UiTextures.get(s.moonTex, "skyboxes");
            int k = lv.getMoonPhase(), l = k % 4, i1 = k / 4 % 2;
            if (t != null) quad(ps, moon, s.moonHalf, t, 0, 0, 1, 1, s.moonColor, rain);
            else quad(ps, moon, s.moonHalf, new ResourceLocation("textures/environment/moon_phases.png"), (l + 1) / 4f, (i1 + 1) / 2f, l / 4f, i1 / 2f, s.moonColor, rain);
        }
        ps.popPose();
        RenderSystem.setShaderColor(1, 1, 1, 1);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
    }

    static void quad(PoseStack ps, Vec3 dir, float half, ResourceLocation tex, float u0, float v0, float u1, float v1, float[] c, float alpha) {
        Vec3 d = dir.normalize();
        Vec3 up = Math.abs(d.y) > 0.95 ? new Vec3(0, 0, 1) : new Vec3(0, 1, 0);
        Vec3 a = d.cross(up).normalize().scale(half), b = a.cross(d).normalize().scale(half), cen = d.scale(100);
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShaderColor(c[0], c[1], c[2], alpha);
        Matrix4f m = ps.last().pose();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        Vec3 p0 = cen.subtract(a).subtract(b), p1 = cen.add(a).subtract(b), p2 = cen.add(a).add(b), p3 = cen.subtract(a).add(b);
        bb.vertex(m, (float) p0.x, (float) p0.y, (float) p0.z).uv(u0, v0).endVertex();
        bb.vertex(m, (float) p1.x, (float) p1.y, (float) p1.z).uv(u1, v0).endVertex();
        bb.vertex(m, (float) p2.x, (float) p2.y, (float) p2.z).uv(u1, v1).endVertex();
        bb.vertex(m, (float) p3.x, (float) p3.y, (float) p3.z).uv(u0, v1).endVertex();
        BufferUploader.drawWithShader(bb.end());
    }

    /** same distribution as vanilla (seed 10842), any count */
    static void buildStars(int count, boolean tex) {
        if (starBuf != null && starBufCount == count && starBufTex == tex) return;
        if (starBuf != null) starBuf.close();
        starBufCount = count; starBufTex = tex;
        RandomSource r = RandomSource.create(10842L);
        BufferBuilder b = Tesselator.getInstance().getBuilder();
        b.begin(VertexFormat.Mode.QUADS, tex ? DefaultVertexFormat.POSITION_TEX : DefaultVertexFormat.POSITION);
        int made = 0;
        for (int i = 0; made < count && i < count * 4; ++i) {
            double d0 = r.nextFloat() * 2 - 1, d1 = r.nextFloat() * 2 - 1, d2 = r.nextFloat() * 2 - 1;
            double d3 = 0.15f + r.nextFloat() * 0.1f * (tex ? 2.5 : 1);
            double d4 = d0 * d0 + d1 * d1 + d2 * d2;
            if (d4 < 0.01 || d4 >= 1) continue;
            made++;
            d4 = 1 / Math.sqrt(d4); d0 *= d4; d1 *= d4; d2 *= d4;
            double d5 = d0 * 100, d6 = d1 * 100, d7 = d2 * 100;
            double d8 = Math.atan2(d0, d2), d9 = Math.sin(d8), d10 = Math.cos(d8);
            double d11 = Math.atan2(Math.sqrt(d0 * d0 + d2 * d2), d1), d12 = Math.sin(d11), d13 = Math.cos(d11);
            double d14 = r.nextDouble() * Math.PI * 2, d15 = Math.sin(d14), d16 = Math.cos(d14);
            for (int j = 0; j < 4; ++j) {
                double d18 = ((j & 2) - 1) * d3, d19 = ((j + 1 & 2) - 1) * d3;
                double d21 = d18 * d16 - d19 * d15, d22 = d19 * d16 + d18 * d15;
                double d23 = d21 * d12, d24 = -d21 * d13;
                double d25 = d24 * d9 - d22 * d10, d26 = d22 * d9 + d24 * d10;
                var v = b.vertex(d5 + d25, d6 + d23, d7 + d26);
                if (tex) v.uv((j & 2) == 0 ? 0 : 1, ((j + 1) & 2) == 0 ? 0 : 1);
                v.endVertex();
            }
        }
        starBuf = new VertexBuffer(VertexBuffer.Usage.STATIC);
        starBuf.bind();
        starBuf.upload(b.end());
        VertexBuffer.unbind();
    }

    // ================================================================ light glows / cones (AFTER_PARTICLES)
    record L(boolean beam, Vec3 pos, Vec3 dir, float[] color, double bright, double range, double angle, double transp) {}

    static List<L> lights() {
        Minecraft mc = Minecraft.getInstance();
        List<L> out = new ArrayList<>();
        if (mc.level == null) return out;
        String dim = mc.level.dimension().location().toString();
        for (JsonObject j : SERVER_LIGHTS) {
            try {
                JsonObject p = j.getAsJsonObject("p");
                boolean beam = j.get("c").getAsString().equals("LightBeam");
                Vec3 pos, dir;
                if (j.has("ent")) {
                    Entity e = mc.level.getEntity(j.get("ent").getAsInt());
                    if (e == null) continue;
                    String face = p.has("Face") ? p.get("Face").getAsString() : "Front";
                    pos = beam ? e.getEyePosition(mc.getFrameTime()) : e.getPosition(mc.getFrameTime()).add(0, e.getBbHeight() * 0.6, 0);
                    dir = entDir(e, face);
                } else {
                    if (!dim.equals(j.get("dim").getAsString())) continue;
                    pos = vec(j.getAsJsonArray("pos")); dir = vec(j.getAsJsonArray("dir"));
                }
                out.add(new L(beam, pos, dir, colj(p.get("Color")), p.get("Brightness").getAsDouble(), p.get("Range").getAsDouble(),
                        beam ? p.get("Angle").getAsDouble() : 0, p.get("Transparency").getAsDouble()));
            } catch (RuntimeException ignored) {}
        }
        ClientRuntime r = GameRuntime.CLIENT instanceof ClientRuntime cr && !cr.closed ? cr : null;
        LightingObj lo = local();
        if (r != null && lo != null) {
            r.within(() -> {
                for (LightObj l : lo.lights()) {
                    if (!l.bool("Enabled")) continue;
                    LightObj.Placement pl = l.placement();
                    if (pl == null || pl.level() != mc.level) continue;
                    out.add(new L(l.beam(), pl.pos(), pl.dir(), col(l.value("Color")), l.num("Brightness"), l.num("Range"), l.beam() ? l.num("Angle") : 0, l.num("Transparency")));
                }
                return null;
            });
        }
        return out;
    }
    static Vec3 entDir(Entity e, String face) {
        Vec3 look = e.getLookAngle();
        float yaw = e instanceof LivingEntity l ? l.yHeadRot : e.getYRot();
        Vec3 fwd = Vec3.directionFromRotation(0, yaw);
        return switch (face) {
            case "Back" -> look.scale(-1); case "Top" -> new Vec3(0, 1, 0); case "Bottom" -> new Vec3(0, -1, 0);
            case "Left" -> new Vec3(fwd.z, 0, -fwd.x); case "Right" -> new Vec3(-fwd.z, 0, fwd.x); default -> look;
        };
    }
    static Vec3 vec(JsonArray a) { return new Vec3(a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble()); }
    static float[] colj(JsonElement e) { try { JsonArray a = e.getAsJsonArray(); return new float[]{a.get(0).getAsFloat(), a.get(1).getAsFloat(), a.get(2).getAsFloat()}; } catch (RuntimeException x) { return new float[]{1, 1, 1}; } }

    public static void renderLights(RenderLevelStageEvent e) {
        List<L> ls = lights();
        if (ls.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        Matrix4f m = ps.last().pose();
        BufferBuilder b = Tesselator.getInstance().getBuilder();
        Vec3 camLook = new Vec3(e.getCamera().getLookVector()), camUp = new Vec3(e.getCamera().getUpVector()), camLeft = new Vec3(e.getCamera().getLeftVector());
        for (L l : ls) {
            if (l.pos.distanceToSqr(cam) > 160 * 160) continue;
            float a = (float) Math.min(1, l.bright * 0.55) * (float) (1 - l.transp);
            if (a <= 0.01) continue;
            float[] c = l.color;
            Vec3 p = l.pos.subtract(cam);
            // glow billboard
            float rad = (float) Math.min(4, 0.35 + l.range * 0.12) * (l.beam ? 0.5f : 1f);
            b.begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
            b.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(c[0], c[1], c[2], a).endVertex();
            for (int i = 0; i <= 20; i++) {
                double t = Math.PI * 2 * i / 20;
                Vec3 q = p.add(camLeft.scale(Math.cos(t) * rad)).add(camUp.scale(Math.sin(t) * rad));
                b.vertex(m, (float) q.x, (float) q.y, (float) q.z).color(c[0], c[1], c[2], 0f).endVertex();
            }
            BufferUploader.drawWithShader(b.end());
            if (!l.beam) continue;
            // cone up to the first block hit
            Vec3 d = l.dir.normalize();
            if (d.lengthSqr() < 1e-6) continue;
            double len = l.range;
            var hit = mc.level.clip(new ClipContext(l.pos, l.pos.add(d.scale(l.range)), ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() != HitResult.Type.MISS) len = hit.getLocation().distanceTo(l.pos);
            double r = len * Math.tan(Math.toRadians(Math.min(170, l.angle)) / 2);
            Vec3 up = Math.abs(d.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
            Vec3 ax = d.cross(up).normalize(), ay = d.cross(ax).normalize(), end = p.add(d.scale(len));
            float ca = a * 0.35f;
            b.begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
            b.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(c[0], c[1], c[2], ca).endVertex();
            for (int i = 0; i <= 24; i++) {
                double t = Math.PI * 2 * i / 24;
                Vec3 q = end.add(ax.scale(Math.cos(t) * r)).add(ay.scale(Math.sin(t) * r));
                b.vertex(m, (float) q.x, (float) q.y, (float) q.z).color(c[0], c[1], c[2], 0f).endVertex();
            }
            BufferUploader.drawWithShader(b.end());
            // spot on the surface
            if (hit.getType() != HitResult.Type.MISS) {
                Vec3 sp = end.subtract(d.scale(0.05));
                b.begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
                b.vertex(m, (float) sp.x, (float) sp.y, (float) sp.z).color(c[0], c[1], c[2], a * 0.5f).endVertex();
                for (int i = 0; i <= 24; i++) {
                    double t = Math.PI * 2 * i / 24;
                    Vec3 q = sp.add(ax.scale(Math.cos(t) * r)).add(ay.scale(Math.sin(t) * r));
                    b.vertex(m, (float) q.x, (float) q.y, (float) q.z).color(c[0], c[1], c[2], 0f).endVertex();
                }
                BufferUploader.drawWithShader(b.end());
            }
        }
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }
}
