package net.idea.fluwa.client.zspace;

import net.idea.fluwa.Fluwa;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;

import java.util.ArrayList;
import java.util.List;

import static net.idea.fluwa.client.zspace.ZUi.*;

/** ZSpace → ☰ → Options / About / Help */
public final class ZPages {
    private ZPages() {}

    // ================================================================== Options
    public static final class Options extends ZWindow {
        public Options(Screen parent) { super("Options", parent, 360, 298); }
        @Override protected String subtitle() { return "ZSpace appearance & behaviour"; }

        void row(GuiGraphics g, int y, String name, String desc) {
            text(g, font, name, 14, y + 2, TEXT);
            small(g, font, desc, 14, y + 12, DIM);
        }

        @Override protected void renderBody(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my, float pt) {
            int y = y0 + 8, cx = x1 - 120;
            row(g, y, "Auto scale", "texts and layout follow the window size");
            toggle(g, "o:as", cx, y + 3, ZOptions.autoScale, mx, my, () -> { ZOptions.autoScale = !ZOptions.autoScale; changed(); });
            y += 24;
            row(g, y, "Scale", ZOptions.autoScale ? "multiplier on top of the automatic scale" : "fixed UI scale");
            button(g, "o:s-", cx, y + 2, 16, 14, "-", 0, mx, my, () -> { ZOptions.scale = Math.max(0.5, ZOptions.scale - 0.05); changed(); });
            centered(g, font, String.format("%.2f", ZOptions.scale), cx + 36, y + 5, TEXT);
            button(g, "o:s+", cx + 56, y + 2, 16, 14, "+", 0, mx, my, () -> { ZOptions.scale = Math.min(3, ZOptions.scale + 0.05); changed(); });
            y += 24;
            row(g, y, "Base size", "window size (px) that equals scale 1.0");
            button(g, "o:w-", cx, y + 2, 16, 14, "-", 0, mx, my, () -> { ZOptions.baseW = Math.max(240, ZOptions.baseW - 20); changed(); });
            centered(g, font, ZOptions.baseW + "×" + ZOptions.baseH, cx + 36, y + 5, TEXT);
            button(g, "o:w+", cx + 56, y + 2, 16, 14, "+", 0, mx, my, () -> { ZOptions.baseW = Math.min(2000, ZOptions.baseW + 20); changed(); });
            button(g, "o:h", cx + 76, y + 2, 34, 14, "H " + (ZOptions.baseH == 320 ? "std" : ZOptions.baseH), 0, mx, my, () -> {
                ZOptions.baseH = ZOptions.baseH >= 480 ? 240 : ZOptions.baseH + 40; changed(); });
            y += 24;
            row(g, y, "Background opacity", "how much of the world shows through");
            button(g, "o:o-", cx, y + 2, 16, 14, "-", 0, mx, my, () -> { ZOptions.opacity = Math.max(0.2, ZOptions.opacity - 0.05); changed(); });
            centered(g, font, Math.round(ZOptions.opacity * 100) + "%", cx + 36, y + 5, TEXT);
            button(g, "o:o+", cx + 56, y + 2, 16, 14, "+", 0, mx, my, () -> { ZOptions.opacity = Math.min(1, ZOptions.opacity + 0.05); changed(); });
            y += 24;
            row(g, y, "Accent", "colour of highlights");
            for (int i = 0; i < ACCENTS.length; i++) {
                int ax = cx + i * 18, ii = i;
                round(g, ax, y + 3, ax + 14, y + 15, ACCENTS[i][0]);
                if (ZOptions.accent == i) outline(g, ax - 1, y + 2, ax + 15, y + 16, 0xFFFFFFFF);
                hits.add(new Hit(ax, y + 3, ax + 14, y + 15, () -> { ZOptions.accent = ii; changed(); }));
            }
            y += 24;
            row(g, y, "Animations", "smooth hover / open transitions");
            toggle(g, "o:an", cx, y + 3, ZOptions.animations, mx, my, () -> { ZOptions.animations = !ZOptions.animations; changed(); });
            y += 24;
            row(g, y, "Autocomplete", "suggestions in the code editor");
            toggle(g, "o:ac", cx, y + 3, ZOptions.autocomplete, mx, my, () -> { ZOptions.autocomplete = !ZOptions.autocomplete; changed(); });
            y += 24;
            row(g, y, "Remember layout", "keep window positions and sizes");
            toggle(g, "o:rl", cx, y + 3, ZOptions.rememberLayout, mx, my, () -> { ZOptions.rememberLayout = !ZOptions.rememberLayout; changed(); });
            y += 24;
            row(g, y, "Reload scripts on save", ZOptions.reloadOnSave ? "saving / deleting a script restarts all scripts" : "only saves - press Reload (Ctrl+Shift+R) to apply");
            toggle(g, "o:ros", cx, y + 3, ZOptions.reloadOnSave, mx, my, () -> { ZOptions.reloadOnSave = !ZOptions.reloadOnSave; changed(); });
            y += 24;
            row(g, y, "World Editor UI size", "smaller panels = more of the world visible");
            button(g, "o:we-", cx, y + 2, 16, 14, "-", 0, mx, my, () -> { ZOptions.weScale = Math.max(0.5, ZOptions.weScale - 0.05); changed(); });
            centered(g, font, Math.round(ZOptions.weScale * 100) + "%", cx + 36, y + 5, TEXT);
            button(g, "o:we+", cx + 56, y + 2, 16, 14, "+", 0, mx, my, () -> { ZOptions.weScale = Math.min(1.5, ZOptions.weScale + 0.05); changed(); });
            y += 26;
            button(g, "o:reset", 14, y, 90, 14, "Reset defaults", 2, mx, my, () -> {
                ZOptions.autoScale = true; ZOptions.scale = 1; ZOptions.baseW = 560; ZOptions.baseH = 320; ZOptions.opacity = 0.85;
                ZOptions.accent = 0; ZOptions.animations = ZOptions.autocomplete = ZOptions.rememberLayout = ZOptions.reloadOnSave = true; ZOptions.weScale = 0.8; changed();
            });
        }

        void changed() { ZOptions.save(); computeWin(); setStatus(true, "Saved to .minecraft/fluwa/zspace_options.json"); }
    }

    // ================================================================== About
    public static final class About extends ZWindow {
        public About(Screen parent) { super("About", parent, 300, 200); }
        @Override protected void renderBody(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my, float pt) {
            int cx = (x0 + x1) / 2, y = y0 + 18;
            float t = (System.currentTimeMillis() % 6000) / 6000f;
            g.pose().pushPose();
            g.pose().translate(cx, y + 10, 0); g.pose().scale(3, 3, 1);
            centered(g, font, "Fluwa", 0, -4, lerp(ACCENT, ACCENT2, (float) (0.5 + 0.5 * Math.sin(t * Math.PI * 2))));
            g.pose().popPose();
            y += 36;
            centered(g, font, "version " + Fluwa.VERSION + " · Minecraft 1.20.1 · Forge", cx, y, DIM); y += 16;
            centered(g, font, "Lua scripting for Minecraft — servers, clients, GUIs,", cx, y, TEXT); y += 11;
            centered(g, font, "worlds, shaders and tools in one place.", cx, y, TEXT); y += 18;
            centered(g, font, "ZSpace · Terrain DK · Shader DK · World Editor · GUI Maker", cx, y, ACCENT2); y += 18;
            centered(g, font, "Lua VM: LuaJ (MIT). Open F8 to start, ☰ for tools.", cx, y, FAINT);
        }
    }

    // ================================================================== Help
    public static final class Help extends ZWindow {
        static final String[][] TOPICS = {
                {"Getting started",
                        "F8 opens ZSpace (creators only). The left tree shows sections: Workspace, UI, InitScripts, ServerScripts, ClientScripts.\n" +
                        "Click + next to a section to create a script, folder or value. Ctrl+S saves, F5 runs.\n" +
                        "InitScripts run once at world start, ServerScripts on the server, ClientScripts on every client, UI holds GUIs."},
                {"Folders & values",
                        "Folder, StrValue, IntValue, NumValue and ObjValue can be created in any section (+ → Insert).\n" +
                        "From Lua: Workspace.MyFolder.Speed.Value, ServerScripts.Config.Name.Value.\n" +
                        "Values fire E_Changed(new, old). ObjValue stores a path (\"Workspace.Spawn\") and returns the object.\n" +
                        "Right-click a folder to rename / delete it; click a value to edit it."},
                {"Terrain DK",
                        "☰ → Tools → Terrain DK edits dimensions, biomes and world-gen (noise) types stored in the datapack fluwa_generated.\n" +
                        "Pick an entry on the left, change fields, Save. Preview renders a top-down map; Biome paint fills biomes around you.\n" +
                        "New dimensions become available after a world restart (datapacks are loaded at start)."},
                {"Shader DK",
                        "☰ → Tools → Shader DK: a GLSL fragment editor with live preview of the current frame.\n" +
                        "Uniforms: Time, Resolution, DiffuseSampler. Apply in game shows it on screen, Export saves a ClientScript\n" +
                        "that loads the shader through ShaderService."},
                {"World Editor",
                        "☰ → Tools → World Editor: Axiom-like editing. Keys 1-8 choose tools (Select, Place, Brush, Erase, Paint, Smooth, Cube, Paste).\n" +
                        "LMB-drag selects a box; Fill / Replace / Walls / Outline / Clear / Copy / Stack work on it. RMB-drag looks, WASD moves,\n" +
                        "MMB picks a block, Ctrl+wheel changes the radius, Ctrl+Z / Ctrl+Y undo / redo. Blocks can be mixed: \"stone, andesite\"."},
                {"GUI Maker",
                        "☰ → Tools → GUI Maker: drag elements from the palette onto the canvas, edit properties on the right.\n" +
                        "Positions and sizes are UDim2 (scale + offset). Save stores a Lua script in UI/GUIs, Preview shows it in game."},
                {"UserInputService",
                        "Client only: local UIS = getAccess(\"UserInputService\").\n" +
                        "UIS.E_InputBegan:Connect(function(input, gp) if input.KeyCode == Enum.KeyCode.Space then ... end end)\n" +
                        "Also E_InputEnded, E_InputChanged, mouse / gamepad / window events and IsKeyDown, GetMouseLocation, ..."},
                {"Shortcuts",
                        "Ctrl+S save · F5 run · Ctrl+F find · Ctrl+Z / Ctrl+Y undo / redo · Ctrl+Space autocomplete · F8 close ZSpace.\n" +
                        "Windows: drag the title to move, the corner to resize, double-click the title to maximize."}};
        int topic;
        double scroll;

        public Help(Screen parent) { super("Help", parent, 420, 260); }

        @Override protected void renderBody(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my, float pt) {
            int lw = 110;
            panel(g, x0, y0, x0 + lw, y1);
            int y = y0 + 6;
            for (int i = 0; i < TOPICS.length; i++) {
                int ii = i;
                boolean sel = i == topic, on = in(mx, my, x0, y, x0 + lw, y + ROW);
                if (sel) g.fill(x0, y, x0 + lw, y + ROW, SELROW); else if (on) g.fill(x0, y, x0 + lw, y + ROW, HOVER);
                text(g, font, ellipsize(font, TOPICS[i][0], lw - 10), x0 + 6, y + 3, sel ? TEXT : DIM);
                hits.add(new Hit(x0, y, x0 + lw, y + ROW, () -> { topic = ii; scroll = 0; }));
                y += ROW;
            }
            int tx = x0 + lw + 10, tw = x1 - tx - 10;
            text(g, font, TOPICS[topic][0], tx, y0 + 8, ACCENT);
            List<String> lines = new ArrayList<>();
            for (String para : TOPICS[topic][1].split("\n")) {
                for (var l : font.split(net.minecraft.network.chat.Component.literal(para), tw)) {
                    StringBuilder sb = new StringBuilder();
                    l.accept((idx, st, cp) -> { sb.appendCodePoint(cp); return true; });
                    lines.add(sb.toString());
                }
                lines.add("");
            }
            scissor(g, tx, y0 + 22, x1, y1);
            int ly = y0 + 24 - (int) scroll;
            for (String l : lines) { text(g, font, l, tx, ly, TEXT); ly += 11; }
            g.disableScissor();
        }

        @Override protected boolean bodyScroll(double mx, double my, double d) { scroll = Math.max(0, scroll - d * 12); return true; }
    }
}
