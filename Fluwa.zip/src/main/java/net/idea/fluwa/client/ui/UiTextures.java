package net.idea.fluwa.client.ui;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.io.InputStream;
import java.nio.file.*;
import java.util.*;

/** Images: "namespace:path/to.png" from resource packs, or a file name in .minecraft/fluwa/images/ */
public final class UiTextures {
    private static final Map<String, ResourceLocation> CACHE = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();

    private UiTextures() {}

    public static ResourceLocation get(String img, String folder) {
        String key = folder + "|" + img;
        if (CACHE.containsKey(key)) return CACHE.get(key);
        if (FAILED.contains(key)) return null;
        ResourceLocation rl = null;
        if (img.contains(":") && !img.matches("^[A-Za-z]:[\\\\/].*")) {
            rl = ResourceLocation.tryParse(img);
        } else {
            Path p = Minecraft.getInstance().gameDirectory.toPath().resolve("fluwa").resolve(folder).resolve(img).normalize();
            try (InputStream in = Files.newInputStream(p)) {
                NativeImage ni = NativeImage.read(in);
                int[] wh = {ni.getWidth(), ni.getHeight()};
                rl = Minecraft.getInstance().getTextureManager().register("fluwa_" + folder, new DynamicTexture(ni));
                SIZES.put(rl, wh);
            } catch (Exception e) {
                net.idea.fluwa.lua.FluwaRuntime.LOG.warn("Fluwa: can't load image {}: {}", p, e.toString());
            }
        }
        if (rl == null) FAILED.add(key); else CACHE.put(key, rl);
        return rl;
    }

    public static void blit(GuiGraphics g, String img, int x, int y, int w, int h) {
        ResourceLocation rl = get(img, "images");
        if (rl == null || w <= 0 || h <= 0) return;
        g.blit(rl, x, y, w, h, 0, 0, 1, 1, 1, 1);
    }

    private static final Map<ResourceLocation, int[]> SIZES = new HashMap<>();

    /** pixel size of a texture (resource-pack images are probed once) */
    public static int[] size(ResourceLocation rl) {
        return SIZES.computeIfAbsent(rl, k -> {
            try (InputStream in = Minecraft.getInstance().getResourceManager().getResource(k).orElseThrow().open()) {
                NativeImage ni = NativeImage.read(in); int[] r = {ni.getWidth(), ni.getHeight()}; ni.close(); return r;
            } catch (Exception e) { return new int[]{16, 16}; }
        });
    }

    public static void clear() { CACHE.clear(); FAILED.clear(); SIZES.clear(); }
}
