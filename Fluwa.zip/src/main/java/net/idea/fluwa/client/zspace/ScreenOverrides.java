package net.idea.fluwa.client.zspace;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.api.GameRuntime;
import net.idea.fluwa.client.ClientRuntime;
import net.idea.fluwa.client.ui.UiTextures;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSelectionList;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.fml.loading.FMLPaths;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * v0.5.2: GUI Maker edits of Minecraft / mod screens. Saving an imported screen writes
 * .minecraft/fluwa/screens/<screen class>.json and the real screen is changed every time it opens:
 * moved / resized / renamed / hidden widgets (they keep working), plus new labels, frames, images, text boxes
 * and buttons with an Action. Restore original = delete the file.
 */
public final class ScreenOverrides {
    private ScreenOverrides() {}

    record Ov(String screen, List<GuiMakerScreen.El> els, List<String> keys, long mtime) {}
    static final Map<String, Ov> CACHE = new HashMap<>();

    public static Path dir() { return FMLPaths.GAMEDIR.get().resolve("fluwa").resolve("screens"); }
    static Path file(String cls) { return dir().resolve(cls.replaceAll("[^\\w.$\\-]", "_") + ".json"); }
    public static boolean has(String cls) { return Files.isRegularFile(file(cls)); }

    public static List<String> list() {
        List<String> l = new ArrayList<>();
        try (var st = Files.list(dir())) { st.filter(f -> f.toString().endsWith(".json")).forEach(f -> { String n = f.getFileName().toString(); l.add(n.substring(0, n.length() - 5)); }); }
        catch (Exception ignored) {}
        Collections.sort(l);
        return l;
    }

    static Ov load(String cls) {
        Path f = file(cls);
        if (!Files.isRegularFile(f)) { CACHE.remove(cls); return null; }
        try {
            long mt = Files.getLastModifiedTime(f).toMillis();
            Ov o = CACHE.get(cls);
            if (o != null && o.mtime == mt) return o;
            JsonObject j = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            List<GuiMakerScreen.El> els = new ArrayList<>(Arrays.asList(new Gson().fromJson(j.get("elements"), GuiMakerScreen.El[].class)));
            List<String> keys = new ArrayList<>();
            if (j.has("keys")) for (var k : j.getAsJsonArray("keys")) keys.add(k.getAsString());
            o = new Ov(cls, els, keys, mt);
            CACHE.put(cls, o);
            return o;
        } catch (Exception e) { Fluwa.LOGGER.warn("Fluwa: bad screen edit {}: {}", f, e.toString()); return null; }
    }

    public static List<GuiMakerScreen.El> elements(String cls) {
        Ov o = load(cls);
        if (o == null) return null;
        List<GuiMakerScreen.El> l = new ArrayList<>();
        for (GuiMakerScreen.El e : o.els) l.add(e.copy());
        return l;
    }
    public static List<String> keys(String cls) { Ov o = load(cls); return o == null ? List.of() : o.keys; }

    public static void save(String cls, List<GuiMakerScreen.El> els, List<String> keys) throws Exception {
        Files.createDirectories(dir());
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("screen", cls); m.put("keys", keys); m.put("elements", els);
        Files.writeString(file(cls), new GsonBuilder().setPrettyPrinting().create().toJson(m));
        CACHE.remove(cls);
    }
    public static boolean restore(String cls) {
        CACHE.remove(cls);
        try { return Files.deleteIfExists(file(cls)); } catch (Exception e) { return false; }
    }

    // ------------------------------------------------------------------ apply to the real screen
    static Field titleField;

    public static void apply(ScreenEvent.Init.Post ev) {
        Screen s = ev.getScreen();
        if (s == null || GuiImport.own(s)) return;
        Ov o = load(s.getClass().getName());
        if (o == null) return;
        try {
            Map<String, GuiMakerScreen.El> byKey = new HashMap<>();
            int minZ = Integer.MAX_VALUE;
            for (GuiMakerScreen.El e : o.els) if (!e.src.isEmpty()) { byKey.put(e.src, e); minZ = Math.min(minZ, e.z); }
            Set<String> keys = new HashSet<>(o.keys);
            for (Object[] wk : GuiImport.widgets(s)) {
                Object w = wk[0]; String k = (String) wk[1];
                GuiMakerScreen.El e = byKey.get(k);
                if (e == null) { if (keys.contains(k)) hide(ev, w); continue; }
                if (!e.visible) { hide(ev, w); continue; }
                boolean move = Math.abs(e.dx) >= 0.5 || Math.abs(e.dy) >= 0.5;
                boolean size = e.nw > 0 && e.nh > 0 && (Math.abs(e.nw - e.w0) >= 0.5 || Math.abs(e.nh - e.h0) >= 0.5);
                if (w instanceof AbstractSelectionList<?> l) {
                    if (move || size) {
                        int nw = size ? (int) Math.round(e.nw) : l.getWidth(), nh = size ? (int) Math.round(e.nh) : l.getBottom() - l.getTop();
                        int top = l.getTop() + (int) Math.round(e.dy), left = l.getLeft() + (int) Math.round(e.dx);
                        l.updateSize(nw, s.height, top, top + nh);
                        l.setLeftPos(left);
                    }
                } else if (w instanceof AbstractWidget aw) {
                    if (move) { aw.setX(aw.getX() + (int) Math.round(e.dx)); aw.setY(aw.getY() + (int) Math.round(e.dy)); }
                    if (size) { aw.setWidth((int) Math.round(e.nw)); aw.setHeight((int) Math.round(e.nh)); }
                    if (!e.text.equals(e.text0)) {
                        if (aw instanceof EditBox eb) eb.setValue(e.text);
                        else aw.setMessage(Component.literal(e.text));
                    }
                }
            }
            GuiMakerScreen.El title = byKey.get("title");
            if (title != null && (!title.visible || !title.text.equals(title.text0))) setTitle(s, title.visible ? title.text : "");
            // new elements
            List<GuiMakerScreen.El> added = new ArrayList<>();
            for (GuiMakerScreen.El e : o.els) if (e.src.isEmpty() && e.visible) added.add(e);
            added.sort(Comparator.comparingInt(e -> e.z));
            int front = 0;
            for (GuiMakerScreen.El e : added) {
                double[] r = abs(e, o.els, s.width, s.height, 0);
                AbstractWidget w;
                if (e.cls.equals("TextBox")) {
                    AddedBox b = new AddedBox(Minecraft.getInstance().font, (int) r[0], (int) r[1], Math.max(1, (int) r[2]), Math.max(1, (int) r[3]), e);
                    w = b;
                } else w = new ElWidget(s, e, (int) r[0], (int) r[1], Math.max(1, (int) r[2]), Math.max(1, (int) r[3]));
                ev.addListener(w);
                if (e.z < minZ && minZ != Integer.MAX_VALUE) { s.renderables.remove(w); s.renderables.add(front++, w); }
            }
        } catch (Throwable t) { Fluwa.LOGGER.warn("Fluwa: can't apply screen edit to {}: {}", s.getClass().getName(), t.toString()); }
    }

    static void hide(ScreenEvent.Init.Post ev, Object w) {
        if (w instanceof AbstractWidget aw) { aw.visible = false; aw.active = false; }
        else if (w instanceof net.minecraft.client.gui.components.events.GuiEventListener l) ev.removeListener(l);
    }

    static void setTitle(Screen s, String t) {
        try {
            if (titleField == null) { titleField = net.minecraftforge.fml.util.ObfuscationReflectionHelper.findField(Screen.class, "f_96539_"); titleField.setAccessible(true); }
            titleField.set(s, Component.literal(t));
        } catch (Throwable ignored) {}
    }

    static GuiMakerScreen.El byName(List<GuiMakerScreen.El> els, String n) { for (GuiMakerScreen.El e : els) if (e.name.equals(n)) return e; return null; }
    static double[] abs(GuiMakerScreen.El e, List<GuiMakerScreen.El> els, double vw, double vh, int depth) {
        double px = 0, py = 0, pw = vw, ph = vh;
        GuiMakerScreen.El p = e.parent.isEmpty() || depth > 20 ? null : byName(els, e.parent);
        if (p != null) { double[] r = abs(p, els, vw, vh, depth + 1); px = r[0]; py = r[1]; pw = r[2]; ph = r[3]; }
        return new double[]{px + e.sx * pw + e.ox, py + e.sy * ph + e.oy, e.wsx * pw + e.wox, e.wsy * ph + e.woy};
    }

    // ------------------------------------------------------------------ added elements
    public static final class AddedBox extends EditBox {
        AddedBox(net.minecraft.client.gui.Font f, int x, int y, int w, int h, GuiMakerScreen.El e) {
            super(f, x, y, w, h, Component.literal(e.name));
            setHint(Component.literal(e.text.isEmpty() ? "" : e.text));
        }
    }

    public static final class ElWidget extends AbstractWidget {
        final GuiMakerScreen.El e; final Screen screen;
        ElWidget(Screen s, GuiMakerScreen.El e, int x, int y, int w, int h) {
            super(x, y, w, h, Component.literal(e.text));
            this.e = e; this.screen = s;
            active = e.cls.endsWith("Button");
        }
        @Override protected void renderWidget(GuiGraphics g, int mx, int my, float pt) {
            int x = getX(), y = getY(), x2 = x + width, y2 = y + height;
            int a = (int) Math.round((1 - e.bgT) * 255);
            if (active && isHovered()) a = Math.min(255, a + 40);
            if (a > 0) g.fill(x, y, x2, y2, (a << 24) | GuiMakerScreen.color(e.bg, 0x2A2A3A));
            if (active && isHovered()) g.renderOutline(x, y, width, height, 0xFFFFFFFF);
            if (e.cls.startsWith("Image") && !e.image.isEmpty()) { try { UiTextures.blit(g, e.image, x, y, Math.max(1, width), Math.max(1, height)); } catch (Exception ignored) {} }
            if (e.cls.startsWith("Text") && !e.text.isEmpty()) {
                var font = Minecraft.getInstance().font;
                float ts = (float) (e.textSize / 9.0);
                g.pose().pushPose();
                g.pose().translate((x + x2) / 2f, (y + y2) / 2f - 4 * ts, 0);
                g.pose().scale(ts, ts, 1);
                g.drawString(font, e.text, -font.width(e.text) / 2, 0, 0xFF000000 | GuiMakerScreen.color(e.fg, 0xFFFFFF), true);
                g.pose().popPose();
            }
        }
        @Override public void onClick(double mx, double my) { run(screen, e.action); }
        @Override protected void updateWidgetNarration(NarrationElementOutput o) { defaultButtonNarrationText(o); }
    }

    /** button actions: /command, chat:text, close, screen:<class>, url:<link>, lua:<code>, quit */
    public static void run(Screen s, String action) {
        Minecraft mc = Minecraft.getInstance();
        String a = action == null ? "" : action.trim();
        try {
            if (a.isEmpty()) return;
            if (a.startsWith("/")) { if (mc.player != null) mc.player.connection.sendCommand(a.substring(1)); }
            else if (a.startsWith("chat:")) { if (mc.player != null) mc.player.connection.sendChat(a.substring(5)); }
            else if (a.equals("close") || a.equals("back")) s.onClose();
            else if (a.startsWith("screen:")) mc.setScreen(GuiImport.construct(a.substring(7).trim(), s.width, s.height));
            else if (a.startsWith("url:")) Util.getPlatform().openUri(a.substring(4).trim());
            else if (a.startsWith("lua:")) {
                if (GameRuntime.CLIENT instanceof ClientRuntime r && !r.closed) r.runScript("ScreenAction", a.substring(4));
            }
            else if (a.equals("quit")) mc.stop();
        } catch (Throwable t) { Fluwa.LOGGER.warn("Fluwa: screen action '{}' failed: {}", a, t.toString()); }
    }
}
