package net.idea.fluwa.client;

import net.idea.fluwa.mixin.EntityRenderDispatcherAccessor;
import net.idea.fluwa.mixin.ModelPartAccessor;
import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

/**
 * v0.5.2: every entity model is editable part by part. Part names come from the model definition
 * ("head", "right_hind_leg" -> Head, RightHindLeg), found through ModelPart.getChild (ModelPartMixin) and the
 * model's ModelPart fields / root tree - works for vanilla and modded models.
 */
public final class ModelParts {
    private ModelParts() {}

    /** ModelPart -> definition name (filled by ModelPartMixin) */
    public static final Map<ModelPart, String> NAMES = Collections.synchronizedMap(new WeakHashMap<>());
    static final Map<Model, LinkedHashMap<String, ModelPart>> CACHE = Collections.synchronizedMap(new WeakHashMap<>());

    public static String pascal(String n) {
        StringBuilder b = new StringBuilder(); boolean up = true;
        for (char c : n.toCharArray()) {
            if (c == '_' || c == ' ' || c == '-' || c == '.') { up = true; continue; }
            b.append(up ? Character.toUpperCase(c) : c); up = false;
        }
        return b.toString();
    }

    static Map<String, ModelPart> children(ModelPart p) {
        try { return ((ModelPartAccessor) (Object) p).fluwa$children(); } catch (Throwable t) { return Map.of(); }
    }

    /** name -> part for a model (cached per model instance) */
    public static LinkedHashMap<String, ModelPart> of(Model m) {
        if (m == null) return new LinkedHashMap<>();
        LinkedHashMap<String, ModelPart> c = CACHE.get(m);
        if (c != null) return c;
        LinkedHashMap<String, ModelPart> out = new LinkedHashMap<>();
        Set<ModelPart> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        List<ModelPart> roots = new ArrayList<>();
        if (m instanceof HierarchicalModel<?> h) { try { roots.add(h.root()); } catch (Throwable ignored) {} }
        List<Class<?>> chain = new ArrayList<>();
        for (Class<?> k = m.getClass(); k != null && k != Object.class; k = k.getSuperclass()) chain.add(0, k);
        for (Class<?> k : chain) for (Field f : k.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            try {
                if (ModelPart.class.isAssignableFrom(f.getType())) { f.setAccessible(true); Object v = f.get(m); if (v != null) roots.add((ModelPart) v); }
                else if (f.getType() == ModelPart[].class) { f.setAccessible(true); Object v = f.get(m); if (v != null) for (ModelPart p : (ModelPart[]) v) if (p != null) roots.add(p); }
                else if (Iterable.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true); Object v = f.get(m);
                    if (v instanceof Iterable<?> it) for (Object o : it) if (o instanceof ModelPart p) roots.add(p);
                }
            } catch (Throwable ignored) {}
        }
        int anon = 0;
        for (ModelPart r : roots) {
            if (seen.contains(r)) continue;
            String n = NAMES.get(r);
            if (n == null && children(r).isEmpty()) { n = "part" + (++anon); }
            if (n == null) { seen.add(r); walk(r, "", out, seen, 0); }   // unnamed root: only its children
            else add(r, pascal(n), "", out, seen, 0);
        }
        CACHE.put(m, out);
        return out;
    }

    static void add(ModelPart p, String name, String parent, LinkedHashMap<String, ModelPart> out, Set<ModelPart> seen, int d) {
        if (!seen.add(p) || d > 24) return;
        String n = name;
        if (n.isEmpty()) n = "Part";
        if (out.containsKey(n)) n = parent + n;
        int i = 2; String base = n; while (out.containsKey(n)) n = base + (i++);
        out.put(n, p);
        walk(p, n, out, seen, d + 1);
    }

    static void walk(ModelPart p, String parent, LinkedHashMap<String, ModelPart> out, Set<ModelPart> seen, int d) {
        for (var e : new TreeMap<>(children(p)).entrySet()) add(e.getValue(), pascal(e.getKey()), parent, out, seen, d);
    }

    // ---------------------------------------------------------------- entity -> model
    public static Model modelOf(EntityRenderer<?> r) { return r instanceof LivingEntityRenderer<?, ?> lr ? lr.getModel() : null; }

    public static Model modelFor(Entity e) {
        if (e == null) return null;
        try {
            String desc = ClientModels.desc(e.getUUID());
            if (desc != null && desc.contains(":") && ClientModels.hasModel(e.getUUID())) {
                EntityType<?> t = EntityType.byString(desc).orElse(null);
                if (t != null) { Model m = modelOf(renderers().get(t)); if (m != null) return m; }
            }
            return modelOf(Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(e));
        } catch (Throwable t) { return null; }
    }

    static Map<EntityType<?>, EntityRenderer<?>> renderers() {
        return ((EntityRenderDispatcherAccessor) Minecraft.getInstance().getEntityRenderDispatcher()).fluwa$renderers();
    }

    public static List<String> namesFor(Entity e) { return new ArrayList<>(of(modelFor(e)).keySet()); }

    // ---------------------------------------------------------------- tell the server the part names of every entity type
    public static void report() {
        try {
            List<String> rows = new ArrayList<>();
            Minecraft mc = Minecraft.getInstance();
            for (var en : renderers().entrySet()) {
                Model m = modelOf(en.getValue());
                if (m == null) continue;
                List<String> n = new ArrayList<>(of(m).keySet());
                if (n.isEmpty()) continue;
                rows.add(BuiltInRegistries.ENTITY_TYPE.getKey(en.getKey()) + "\t" + String.join(",", n));
            }
            var skins = mc.getEntityRenderDispatcher().getSkinMap();
            EntityRenderer<?> pr = skins.get("default");
            Model pm = modelOf(pr);
            if (pm != null) rows.add("minecraft:player\t" + String.join(",", of(pm).keySet()));
            List<String> chunk = new ArrayList<>(); int size = 0;
            for (String r : rows) {
                if (r.length() > 6000) continue;
                if (size + r.length() > 12000) { FluwaNet.toServer(new Pkt(Pkt.C_MODELPARTS, new ArrayList<>(chunk), new int[0], null)); chunk.clear(); size = 0; }
                chunk.add(r); size += r.length() + 4;
            }
            if (!chunk.isEmpty()) FluwaNet.toServer(new Pkt(Pkt.C_MODELPARTS, chunk, new int[0], null));
        } catch (Throwable t) { net.idea.fluwa.Fluwa.LOGGER.debug("Fluwa: model part report failed: {}", t.toString()); }
    }
}
