package net.idea.fluwa.client.zspace;

import com.google.gson.*;
import net.minecraft.client.Minecraft;

import java.nio.file.*;

/** ZSpace → ☰ → Options (stored in .minecraft/fluwa/zspace_options.json) */
public final class ZOptions {
    private ZOptions() {}
    /** texts follow the window size (Scale) instead of fixed pixel sizes */
    public static boolean autoScale = true;
    public static double scale = 1.0;
    public static int baseW = 560, baseH = 320;
    public static double opacity = 0.85;
    public static int accent = 0;
    public static boolean animations = true, autocomplete = true, rememberLayout = true;
    /** save / delete of a script reloads every script (server + clients); off = press Reload yourself */
    public static boolean reloadOnSave = true;
    /** extra multiplier of the World Editor interface (smaller = more world visible) */
    public static double weScale = 0.8;
    static boolean loaded;

    static Path file() { return Minecraft.getInstance().gameDirectory.toPath().resolve("fluwa").resolve("zspace_options.json"); }

    public static void load() {
        if (loaded) return;
        loaded = true;
        try {
            Path f = file();
            if (Files.exists(f)) {
                JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
                if (o.has("autoScale")) autoScale = o.get("autoScale").getAsBoolean();
                if (o.has("scale")) scale = o.get("scale").getAsDouble();
                if (o.has("baseW")) baseW = o.get("baseW").getAsInt();
                if (o.has("baseH")) baseH = o.get("baseH").getAsInt();
                if (o.has("opacity")) opacity = o.get("opacity").getAsDouble();
                if (o.has("accent")) accent = o.get("accent").getAsInt();
                if (o.has("animations")) animations = o.get("animations").getAsBoolean();
                if (o.has("autocomplete")) autocomplete = o.get("autocomplete").getAsBoolean();
                if (o.has("rememberLayout")) rememberLayout = o.get("rememberLayout").getAsBoolean();
                if (o.has("reloadOnSave")) reloadOnSave = o.get("reloadOnSave").getAsBoolean();
                if (o.has("weScale")) weScale = o.get("weScale").getAsDouble();
            }
        } catch (Exception ignored) {}
        apply();
    }

    public static void save() {
        JsonObject o = new JsonObject();
        o.addProperty("autoScale", autoScale); o.addProperty("scale", scale);
        o.addProperty("baseW", baseW); o.addProperty("baseH", baseH);
        o.addProperty("opacity", opacity); o.addProperty("accent", accent);
        o.addProperty("animations", animations); o.addProperty("autocomplete", autocomplete); o.addProperty("rememberLayout", rememberLayout);
        o.addProperty("reloadOnSave", reloadOnSave); o.addProperty("weScale", weScale);
        try { Files.createDirectories(file().getParent()); Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(o)); } catch (Exception ignored) {}
        apply();
    }

    public static void apply() {
        weScale = Math.max(0.5, Math.min(1.5, weScale));
        accent = Math.floorMod(accent, ZUi.ACCENTS.length);
        ZUi.ACCENT = ZUi.ACCENTS[accent][0]; ZUi.ACCENT2 = ZUi.ACCENTS[accent][1];
    }

    /** UI scale for a window of w x h screen pixels */
    public static float scaleFor(int w, int h) {
        load();
        double s = autoScale ? Math.min(w / (double) baseW, h / (double) baseH) * scale : scale;
        s = Math.max(0.5, Math.min(3, s));
        return Math.round(s * 20) / 20f;
    }

    /** window background alpha */
    public static int bg(int rgb) { return ((int) Math.round(Math.max(0.2, Math.min(1, opacity)) * 255) << 24) | (rgb & 0xFFFFFF); }
}
