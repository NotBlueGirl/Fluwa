package net.idea.fluwa.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/** Drawing helpers: rounded rects, outlines, gradients and images with ScaleType / ImageRect / tint. */
public final class UiDraw {
    private UiDraw() {}

    static int shade(int c, int d) {
        int r = Math.max(0, Math.min(255, (c >> 16 & 255) + d)), g = Math.max(0, Math.min(255, (c >> 8 & 255) + d)), b = Math.max(0, Math.min(255, (c & 255) + d));
        return (r << 16) | (g << 8) | b;
    }

    /** horizontal inset of a rounded corner at row dy (0..r) */
    static int inset(int r, int dy) {
        if (r <= 0) return 0;
        double y = r - dy - 0.5;
        return (int) Math.round(r - Math.sqrt(Math.max(0, (double) r * r - y * y)));
    }

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        if (w <= 0 || h <= 0 || (argb >>> 24) == 0) return;
        if (r <= 0) { g.fill(x, y, x + w, y + h, argb); return; }
        g.fill(x, y + r, x + w, y + h - r, argb);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + i, x + w - in, y + i + 1, argb);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, argb);
        }
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int t, int r, int argb) {
        if ((argb >>> 24) == 0 || w <= 0 || h <= 0) return;
        if (r <= 0) {
            g.fill(x, y, x + w, y + t, argb); g.fill(x, y + h - t, x + w, y + h, argb);
            g.fill(x, y + t, x + t, y + h - t, argb); g.fill(x + w - t, y + t, x + w, y + h - t, argb);
            return;
        }
        g.fill(x + r, y, x + w - r, y + t, argb); g.fill(x + r, y + h - t, x + w - r, y + h, argb);
        g.fill(x, y + r, x + t, y + h - r, argb); g.fill(x + w - t, y + r, x + w, y + h - r, argb);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i), inNext = i + 1 < r ? inset(r, i + 1) : 0;
            int len = Math.max(t, in - inNext + t);
            g.fill(x + in, y + i, x + Math.min(w / 2, in + len), y + i + 1, argb);
            g.fill(x + w - Math.min(w / 2, in + len), y + i, x + w - in, y + i + 1, argb);
            g.fill(x + in, y + h - 1 - i, x + Math.min(w / 2, in + len), y + h - i, argb);
            g.fill(x + w - Math.min(w / 2, in + len), y + h - 1 - i, x + w - in, y + h - i, argb);
        }
    }

    /** gradient fill: strips across the gradient direction, colors from ColorSequence x NumberSequence, tinted by base */
    static void gradient(GuiGraphics g, int x, int y, int w, int h, int r, int base, double baseTr, double ga, UiMods.Gradient gr) {
        double rad = Math.toRadians(gr.rotation);
        double dx = Math.cos(rad), dy = Math.sin(rad);
        boolean vertical = Math.abs(dy) > Math.abs(dx);
        int n = Math.max(1, Math.min(64, vertical ? h : w));
        for (int i = 0; i < n; i++) {
            int a0 = vertical ? y + i * h / n : x + i * w / n, a1 = vertical ? y + (i + 1) * h / n : x + (i + 1) * w / n;
            if (a1 <= a0) continue;
            double f = (i + 0.5) / n;
            if ((vertical ? dy : dx) < 0) f = 1 - f;
            f = Math.max(0, Math.min(1, f - (vertical ? gr.offset.y : gr.offset.x)));
            int c = gr.color.rgb(f);
            int rr = (c >> 16 & 255) * (base >> 16 & 255) / 255, gg = (c >> 8 & 255) * (base >> 8 & 255) / 255, bb = (c & 255) * (base & 255) / 255;
            double tr = 1 - (1 - baseTr) * (1 - gr.transp.num(f));
            int argb = UiObj.argb((rr << 16) | (gg << 8) | bb, tr, ga);
            if (vertical) {
                int top = a0 - y, bot = y + h - a1;
                int in = r > 0 ? Math.max(top < r ? inset(r, top) : 0, bot < r ? inset(r, bot) : 0) : 0;
                g.fill(x + in, a0, x + w - in, a1, argb);
            } else {
                int left = a0 - x, right = x + w - a1;
                int in = r > 0 ? Math.max(left < r ? inset(r, left) : 0, right < r ? inset(r, right) : 0) : 0;
                g.fill(a0, y + in, a1, y + h - in, argb);
            }
        }
    }

    static void image(GuiGraphics g, UiObj o, String img, double ga) {
        ResourceLocation rl = UiTextures.get(img, "images");
        if (rl == null || o.aw <= 0 || o.ah <= 0) return;
        int[] size = UiTextures.size(rl);
        int tw = Math.max(1, size[0]), th = Math.max(1, size[1]);
        float u0 = 0, v0 = 0, u1 = 1, v1 = 1;
        if (o.rectSize.x > 0 && o.rectSize.y > 0) {
            u0 = (float) (o.rectOffset.x / tw); v0 = (float) (o.rectOffset.y / th);
            u1 = (float) ((o.rectOffset.x + o.rectSize.x) / tw); v1 = (float) ((o.rectOffset.y + o.rectSize.y) / th);
            tw = (int) o.rectSize.x; th = (int) o.rectSize.y;
        }
        float a = (float) Math.max(0, Math.min(1, (1 - o.imageTransparency) * ga));
        if (a <= 0.01f) return;
        g.setColor((o.imageColor >> 16 & 255) / 255f, (o.imageColor >> 8 & 255) / 255f, (o.imageColor & 255) / 255f, a);
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        int x = o.ax, y = o.ay, w = o.aw, h = o.ah;
        switch (o.scaleType) {
            case "Fit", "Crop" -> {
                double s = "Fit".equals(o.scaleType) ? Math.min(w / (double) tw, h / (double) th) : Math.max(w / (double) tw, h / (double) th);
                int dw = (int) (tw * s), dh = (int) (th * s);
                if ("Crop".equals(o.scaleType)) {
                    g.enableScissor(x, y, x + w, y + h);
                    blit(g, rl, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh, u0, v0, u1, v1);
                    g.disableScissor();
                } else blit(g, rl, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh, u0, v0, u1, v1);
            }
            case "Tile" -> {
                int cw = (int) Math.max(1, o.tileSize.x <= 1 ? o.tileSize.x * w : o.tileSize.x), chh = (int) Math.max(1, o.tileSize.y <= 1 ? o.tileSize.y * h : o.tileSize.y);
                if (cw == w && chh == h) { cw = tw; chh = th; }
                g.enableScissor(x, y, x + w, y + h);
                for (int yy = y; yy < y + h && yy < y + 4000; yy += chh) for (int xx = x; xx < x + w && xx < x + 4000; xx += cw) blit(g, rl, xx, yy, cw, chh, u0, v0, u1, v1);
                g.disableScissor();
            }
            case "Slice" -> {
                double l = 0.33, t = 0.33, r = 0.67, b = 0.67;
                if (o.sliceCenter.istable()) {
                    l = o.sliceCenter.get(1).optdouble(tw / 3.0) / tw; t = o.sliceCenter.get(2).optdouble(th / 3.0) / th;
                    r = o.sliceCenter.get(3).optdouble(tw * 2 / 3.0) / tw; b = o.sliceCenter.get(4).optdouble(th * 2 / 3.0) / th;
                }
                int bl = (int) (l * tw * o.sliceScale), bt = (int) (t * th * o.sliceScale), br = (int) ((1 - r) * tw * o.sliceScale), bb = (int) ((1 - b) * th * o.sliceScale);
                int[] xs = {x, x + bl, x + w - br, x + w}, ys = {y, y + bt, y + h - bb, y + h};
                float[] us = {u0, u0 + (u1 - u0) * (float) l, u0 + (u1 - u0) * (float) r, u1}, vs = {v0, v0 + (v1 - v0) * (float) t, v0 + (v1 - v0) * (float) b, v1};
                for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
                    if (xs[i + 1] > xs[i] && ys[j + 1] > ys[j]) blit(g, rl, xs[i], ys[j], xs[i + 1] - xs[i], ys[j + 1] - ys[j], us[i], vs[j], us[i + 1], vs[j + 1]);
            }
            default -> blit(g, rl, x, y, w, h, u0, v0, u1, v1);
        }
        g.setColor(1, 1, 1, 1);
    }

    /** blit a sub-rectangle given in normalized UVs */
    static void blit(GuiGraphics g, ResourceLocation rl, int x, int y, int w, int h, float u0, float v0, float u1, float v1) {
        final int S = 4096;
        g.blit(rl, x, y, w, h, u0 * S, v0 * S, Math.max(1, (int) ((u1 - u0) * S)), Math.max(1, (int) ((v1 - v0) * S)), S, S);
    }
}
