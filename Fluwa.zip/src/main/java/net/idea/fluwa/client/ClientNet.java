package net.idea.fluwa.client;

import net.idea.fluwa.api.GameRuntime;
import net.idea.fluwa.lua.*;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.Minecraft;
import org.luaj.vm2.LuaValue;

import java.util.*;

public final class ClientNet {
    private ClientNet() {}

    static Map<String, Map<String, String>> scripts(Pkt p, int from) {
        Map<String, Map<String, String>> m = new LinkedHashMap<>();
        for (int i = from; i + 2 < p.s.size(); i += 3) m.computeIfAbsent(p.s.get(i), k -> new TreeMap<>()).put(p.s.get(i + 1), p.s.get(i + 2));
        return m;
    }

    record Partial(List<String> s, int type, java.io.ByteArrayOutputStream data) {}
    static final Map<Integer, Partial> PARTIAL = new HashMap<>();

    public static void handle(Pkt p) {
        Minecraft mc = Minecraft.getInstance();
        switch (p.type) {
            case Pkt.S_CHUNK -> {
                int id = p.n(0), idx = p.n(1), total = p.n(2);
                if (idx == 0) PARTIAL.put(id, new Partial(p.s, p.n(3), new java.io.ByteArrayOutputStream()));
                Partial pa = PARTIAL.get(id);
                if (pa == null) return;
                pa.data().writeBytes(p.data);
                if (idx == total - 1) { PARTIAL.remove(id); handle(new Pkt(pa.type(), pa.s(), null, pa.data().toByteArray())); }
            }
            case Pkt.S_MODELPART -> { if (p.n(0) == 2) ClientModels.setTransform(java.util.UUID.fromString(p.s(0)), p.s(1), net.idea.fluwa.api.ModelSync.parseXf(p.s(2))); else ClientModels.setHidden(java.util.UUID.fromString(p.s(0)), p.s(1), p.n(0) == 1); }
            case Pkt.S_PROJ -> ClientProjector.handle(p);
            case Pkt.S_TWEEN -> ClientTween.handle(p);
            case Pkt.S_HITBOX -> {
                java.util.UUID hid = net.idea.fluwa.api.Hitbox.receive(p);
                if (mc.level != null) for (net.minecraft.world.entity.Entity he : mc.level.entitiesForRendering()) if (he.getUUID().equals(hid)) { he.refreshDimensions(); break; }
            }
            case Pkt.S_ZTREE, Pkt.S_ZPROPS -> { if (mc.screen instanceof ZSpaceScreen z) z.explorerReply(p); }
            case Pkt.S_ENTFLAG -> ClientModels.entityFlag(p);
            case Pkt.S_SCRIPTS -> {
                if (GameRuntime.CLIENT != null) GameRuntime.CLIENT.close();
                ShaderDT.reset();
                ClientRuntime r = new ClientRuntime(scripts(p, 0));
                r.init();
                GameRuntime.CLIENT = r;
                r.start();
            }
            case Pkt.S_REMOTE -> {
                if (!(GameRuntime.CLIENT instanceof ClientRuntime r) || r.closed) return;
                RemoteEvent ev = r.remote(p.s(0));
                if (ev == null) { r.output(1, "Event '" + p.s(0) + "' does not exist on the client"); return; }
                r.within(() -> {
                    LuaValue arg = LuaSer.decode(p.data, r);
                    (p.n(0) == 1 ? ev.onMeFire : ev.onPlayerFire).fire(arg);
                    return null;
                });
            }
            case Pkt.S_ZSPACE -> {
                List<String> ws = Arrays.asList(p.s(0).split("\n"));
                List<String> con = p.s(1).isEmpty() ? new ArrayList<>() : new ArrayList<>(Arrays.asList(p.s(1).split("\n")));
                mc.setScreen(new ZSpaceScreen(scripts(p, 2), ws, con));
            }
            case Pkt.S_ZITEM -> {
                String key = "#" + p.s(1);
                boolean del = p.s(0).equals("delete");
                if (GameRuntime.CLIENT instanceof ClientRuntime r && !r.closed) {
                    var m = r.scripts.computeIfAbsent(key, k -> new TreeMap<>());
                    if (del) m.keySet().removeIf(k -> k.equals(p.s(2)) || k.startsWith(p.s(2) + "/")); else m.put(p.s(2), p.s(3) + "\t" + p.s(4));
                    r.within(() -> { var root = ItemTree.root(r, p.s(1)); if (del) ItemTree.remove(root, p.s(2)); else ItemTree.apply(root, p.s(2), p.s(3), p.s(4)); return null; });
                }
                if (mc.screen instanceof ZSpaceScreen z && !p.s(1).equals("Player")) {
                    var m = z.scripts.computeIfAbsent(key, k -> new TreeMap<>());
                    if (del) m.keySet().removeIf(k -> k.equals(p.s(2)) || k.startsWith(p.s(2) + "/")); else m.put(p.s(2), p.s(3) + "\t" + p.s(4));
                }
            }
            case Pkt.S_TDK -> { if (mc.screen instanceof net.idea.fluwa.client.zspace.TerrainDKScreen t) t.reply(p); }
            case Pkt.S_WEDIT -> net.idea.fluwa.client.zspace.WorldEditorScreen.reply(p);
            case Pkt.S_CONSOLE -> {
                if (mc.screen instanceof ZSpaceScreen z) z.serverConsole.add(p.s(0));
            }
            case Pkt.S_ZSTATUS -> {
                if (mc.screen instanceof ZSpaceScreen z) z.setStatus(p.s(0).equals("1"), p.s(1));
            }
            case Pkt.S_NOCOLLIDE -> net.idea.fluwa.api.NoCollide.receive(p.s(0), p.data);
            case Pkt.S_MODEL -> ClientModels.set(java.util.UUID.fromString(p.s(0)), p);
            case Pkt.S_SCREEN -> { if (GameRuntime.CLIENT instanceof ClientRuntime r) r.openScreen(p.s(0)); }
            case Pkt.S_STATE -> {
                ClientState.asynced = p.n(0) == 1;
                ClientState.asyncTick = Math.max(1, p.n(1));
                boolean wasFrozen = ClientState.frozen;
                ClientState.frozen = p.n(2) == 1;
                ClientState.freezeCam = p.n(3) == 1;
                if (ClientState.frozen && !wasFrozen && mc.player != null) { ClientState.frozenYaw = mc.player.getYRot(); ClientState.frozenPitch = mc.player.getXRot(); }
            }
            case Pkt.S_SKYBOX -> ClientState.SKYBOX.put(p.s(0), p.s(1));
            case Pkt.S_LIGHTING -> LightingClient.receive(p.data);
            case Pkt.S_SOUND -> {
                if (GameRuntime.CLIENT instanceof ClientRuntime r)
                    r.within(() -> { r.playLocalSound(null, p.s(0), p.n(0) / 1000f, p.n(1) / 1000f); return null; });
            }
        }
    }
}
