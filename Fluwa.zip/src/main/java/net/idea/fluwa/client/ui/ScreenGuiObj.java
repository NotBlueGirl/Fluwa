package net.idea.fluwa.client.ui;

import net.idea.fluwa.lua.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.luaj.vm2.*;

import java.util.List;

/**
 * ScreenGUI (opens as a screen with mouse, Enabled = open) and Overlay (drawn on the HUD while Enabled).
 * Parent them to UI / Player.PlayerGui / CoreGui – Block:ConnectScreen(name) and Item:SetGUI open a ScreenGUI by Name.
 */
public class ScreenGuiObj extends UiObj {
    public final boolean overlay;
    public boolean enabled;
    public boolean pauseGame, closeOnEsc = true, ignoreInset, resetOnSpawn = true, clickThrough = true;
    /** ScreenGUI: frees the mouse cursor while enabled (game keys keep working); false = display only, camera stays */
    public boolean modal = true;
    public int displayOrder;
    public double transparency;

    public ScreenGuiObj(boolean overlay) {
        super(overlay ? "Overlay" : "ScreenGUI");
        this.overlay = overlay;
        enabled = overlay;
        drawBg = false;
        size = new UDim2L(1, 0, 1, 0);
    }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Enabled": return valueOf(enabled);
            case "PauseGame": return valueOf(pauseGame);
            case "Modal": return valueOf(modal);
            case "CloseOnEsc": return valueOf(closeOnEsc);
            case "Opened": return ev("E_Opened");
            case "Closed": return ev("E_Closed");
            case "DisplayOrder": return valueOf(displayOrder);
            case "IgnoreGuiInset": return valueOf(ignoreInset);
            case "ResetOnSpawn": return valueOf(resetOnSpawn);
            case "ClickThrough": return valueOf(clickThrough);
            case "Transparency": return valueOf(transparency);
        }
        return super.getProp(k);
    }

    @Override protected boolean setUi(String k, LuaValue v) {
        switch (k) {
            case "Enabled": setEnabled(v.toboolean()); return true;
            case "PauseGame": pauseGame = v.toboolean(); return true;
            case "Modal": modal = v.toboolean(); return true;
            case "CloseOnEsc": closeOnEsc = v.toboolean(); return true;
            case "DisplayOrder": displayOrder = v.checkint(); return true;
            case "IgnoreGuiInset": ignoreInset = v.toboolean(); return true;
            case "ResetOnSpawn": resetOnSpawn = v.toboolean(); return true;
            case "ClickThrough": clickThrough = v.toboolean(); return true;
            case "Transparency": transparency = Math.max(0, Math.min(1, v.checkdouble())); return true;
        }
        return super.setUi(k, v);
    }

    @Override protected void copyTo(UiObj c) {
        super.copyTo(c);
        if (c instanceof ScreenGuiObj s) { s.pauseGame = pauseGame; s.closeOnEsc = closeOnEsc; s.ignoreInset = ignoreInset; s.resetOnSpawn = resetOnSpawn;
            s.clickThrough = clickThrough; s.modal = modal; s.displayOrder = displayOrder; s.transparency = transparency; s.enabled = overlay && enabled; }
    }

    public void setEnabled(boolean on) {
        if (enabled == on) return;
        enabled = on;
        if (!overlay) {
            // 0.4.1: a ScreenGUI is drawn together with the other GUIs on the HUD and the game keeps its controls.
            // Only PauseGame = true opens a real (pausing) Minecraft screen.
            Minecraft mc = Minecraft.getInstance();
            if (on && pauseGame) mc.setScreen(new FluwaUiScreen(this, false));
            else if (!on && mc.screen instanceof FluwaUiScreen s && s.gui == this) mc.setScreen(null);
        }
        fire(on ? "E_Opened" : "E_Closed");
    }

    public void renderRoot(GuiGraphics g, int w, int h, int mx, int my) {
        if (!visible) return;
        ax = 0; ay = 0; aw = w; ah = h;
        clipRect = null;
        double ga = 1 - transparency;
        List<UiObj> ch = uiChildren();
        layoutChildren(ch);
        for (UiObj c : ch) c.renderTree(g, mx, my, ga, null);
        net.idea.fluwa.client.BrowserRender.drawChildren(children, g, 0, 0, w, h, mx, my, ga);
    }

    @Override protected void onDestroy() { if (enabled && !overlay) setEnabled(false); }

    static {
        Class<ScreenGuiObj> C = ScreenGuiObj.class;
        reg(C, "Open", (s, a) -> { ((ScreenGuiObj) s).setEnabled(true); return NONE; });
        reg(C, "Close", (s, a) -> { ((ScreenGuiObj) s).setEnabled(false); return NONE; });
        reg(C, "Toggle", (s, a) -> { ScreenGuiObj o = (ScreenGuiObj) s; o.setEnabled(!o.enabled); return NONE; });
        reg(C, "SetDisplayOrder", (s, a) -> set(s, "DisplayOrder", a.arg1()));
        reg(C, "GetDisplayOrder", (s, a) -> valueOf(((ScreenGuiObj) s).displayOrder));
        reg(C, "SetIgnoreGuiInset", (s, a) -> set(s, "IgnoreGuiInset", a.arg1()));
        reg(C, "GetIgnoreGuiInset", (s, a) -> valueOf(((ScreenGuiObj) s).ignoreInset));
        reg(C, "SetResetOnSpawn", (s, a) -> set(s, "ResetOnSpawn", a.arg1()));
        reg(C, "SetEnabled", (s, a) -> set(s, "Enabled", a.arg1()));
        reg(C, "SetClickThrough", (s, a) -> set(s, "ClickThrough", a.arg1()));
    }
}
