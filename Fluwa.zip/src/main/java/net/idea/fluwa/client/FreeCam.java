package net.idea.fluwa.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

/**
 * ZSpace camera-mode: spectate freely while the body stays in place.
 * Rotation is applied every frame (smooth mouse look); position is integrated every tick with
 * inertia and interpolated by the renderer between ticks.
 */
public final class FreeCam {
    private static ArmorStand cam;
    private static float yaw, pitch, anchorYaw, anchorPitch;
    private static Vec3 vel = Vec3.ZERO;
    private FreeCam() {}

    public static boolean active() { return cam != null; }

    public static void toggle() {
        Minecraft mc = Minecraft.getInstance();
        if (cam != null) { stop(mc); return; }
        if (mc.player == null || mc.level == null) return;
        var p = mc.player;
        cam = new ArmorStand(mc.level, p.getX(), p.getEyeY() - 1.7775, p.getZ());
        cam.setInvisible(true);
        cam.noPhysics = true;
        yaw = anchorYaw = p.getYRot(); pitch = anchorPitch = p.getXRot();
        vel = Vec3.ZERO;
        applyRot();
        mc.setCameraEntity(cam);
    }

    private static void stop(Minecraft mc) {
        cam = null;
        if (mc.player != null) { mc.player.setYRot(anchorYaw); mc.player.setXRot(anchorPitch); mc.setCameraEntity(mc.player); }
    }

    private static void applyRot() {
        cam.setYRot(yaw); cam.setXRot(pitch); cam.yRotO = yaw; cam.xRotO = pitch;
        cam.setYHeadRot(yaw); cam.yHeadRotO = yaw;
    }

    /** Called every frame before rendering: the mouse turns mc.player, we move that delta to the camera. */
    public static void frame() {
        if (cam == null) return;
        var p = Minecraft.getInstance().player;
        if (p == null) return;
        float dy = p.getYRot() - anchorYaw, dp = p.getXRot() - anchorPitch;
        if (dy != 0 || dp != 0) {
            yaw += dy; pitch = Math.max(-90f, Math.min(90f, pitch + dp));
            p.setYRot(anchorYaw); p.setXRot(anchorPitch); p.yRotO = anchorYaw; p.xRotO = anchorPitch;
            p.setYHeadRot(anchorYaw); p.yHeadRotO = anchorYaw;
        }
        applyRot();
    }

    public static void tick() {
        if (cam == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level != cam.level()) { stop(mc); return; }
        var o = mc.options;
        cam.xo = cam.getX(); cam.yo = cam.getY(); cam.zo = cam.getZ();
        cam.xOld = cam.getX(); cam.yOld = cam.getY(); cam.zOld = cam.getZ();
        double speed = o.keySprint.isDown() ? 1.5 : 0.5;
        Vec3 fwd = Vec3.directionFromRotation(0, yaw);              // horizontal forward
        Vec3 right = Vec3.directionFromRotation(0, yaw + 90);
        Vec3 m = Vec3.ZERO;
        if (mc.screen == null) {
            if (o.keyUp.isDown()) m = m.add(fwd);
            if (o.keyDown.isDown()) m = m.subtract(fwd);
            if (o.keyRight.isDown()) m = m.add(right);
            if (o.keyLeft.isDown()) m = m.subtract(right);
            if (o.keyJump.isDown()) m = m.add(0, 1, 0);
            if (o.keyShift.isDown()) m = m.add(0, -1, 0);
        }
        Vec3 target = m.lengthSqr() > 0 ? m.normalize().scale(speed) : Vec3.ZERO;
        vel = vel.add(target.subtract(vel).scale(0.5));            // smooth acceleration / braking
        if (vel.lengthSqr() < 1e-5) vel = Vec3.ZERO;
        cam.setPos(cam.getX() + vel.x, cam.getY() + vel.y, cam.getZ() + vel.z);
    }
}
