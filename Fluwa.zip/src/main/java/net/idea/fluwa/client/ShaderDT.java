package net.idea.fluwa.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferUploader;
import net.idea.fluwa.Fluwa;
import net.idea.fluwa.lua.*;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.luaj.vm2.*;
import org.lwjgl.opengl.*;

import java.util.*;

/**
 * getAccess("ShaderDT") - Shader Development Tool (client, OpenGL only).
 *   ShaderDT:Preset("invert")                 vanilla post effects (ShaderDT.Presets)
 *   local s = ShaderDT:Create(glslFragment)   your own full-screen post-processing shader
 *   s:SetUniform("Strength", 0.5); s.Enabled = true; s:Destroy()
 *   ok, log = ShaderDT:Compile(src)            check a shader without creating it
 * Fragment shader gets: uniform sampler2D DiffuseSampler; uniform float Time; uniform vec2 ScreenSize;
 * in vec2 texCoord; out vec4 fragColor;  (added automatically if your code has no #version line)
 */
@Mod.EventBusSubscriber(modid = Fluwa.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ShaderDT extends LObj {
    static final List<String> PRESETS = List.of("invert", "blur", "creeper", "spider", "desaturate", "green", "bits", "notch", "pencil",
            "sobel", "wobble", "art", "ntsc", "flip", "deconverge", "phosphor", "scan_pincushion", "color_convolve", "antialias", "fxaa", "blobs", "blobs2", "bumpy");
    static final String HEADER = "#version 150\nuniform sampler2D DiffuseSampler;\nuniform float Time;\nuniform vec2 ScreenSize;\nin vec2 texCoord;\nout vec4 fragColor;\n#line 1\n";
    static final String VERTEX = "#version 150\nout vec2 texCoord;\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n"
            + "  texCoord = p;\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}\n";
    static final List<Shader> ACTIVE = new ArrayList<>();
    static final long START = System.currentTimeMillis();
    static TextureTarget copy;
    static int vao;
    static String preset;

    public ShaderDT() { super("Service"); name = "ShaderDT"; }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "Available": return TRUE;
            case "GLVersion": return valueOf(String.valueOf(GL11.glGetString(GL11.GL_VERSION)));
            case "Renderer": return valueOf(String.valueOf(GL11.glGetString(GL11.GL_RENDERER)));
            case "CurrentPreset": return preset == null ? NIL : valueOf(preset);
            case "Presets": { LuaTable t = new LuaTable(); for (String p : PRESETS) t.insert(0, valueOf(p)); return t; }
        }
        return super.getProp(k);
    }

    // ------------------------------------------------------------ compile helpers (render thread)
    static int compile(int type, String src, StringBuilder log) {
        int sh = GL20.glCreateShader(type);
        GL20.glShaderSource(sh, src);
        GL20.glCompileShader(sh);
        if (GL20.glGetShaderi(sh, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            log.append(GL20.glGetShaderInfoLog(sh, 8192).trim());
            GL20.glDeleteShader(sh);
            return 0;
        }
        return sh;
    }

    public static int link(String fragment, StringBuilder log) {
        String src = fragment.contains("#version") ? fragment : HEADER + fragment;
        int vs = compile(GL20.GL_VERTEX_SHADER, VERTEX, log);
        if (vs == 0) return 0;
        int fs = compile(GL20.GL_FRAGMENT_SHADER, src, log);
        if (fs == 0) { GL20.glDeleteShader(vs); return 0; }
        int prog = GL20.glCreateProgram();
        GL20.glAttachShader(prog, vs); GL20.glAttachShader(prog, fs);
        GL20.glLinkProgram(prog);
        GL20.glDeleteShader(vs); GL20.glDeleteShader(fs);
        if (GL20.glGetProgrami(prog, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            log.append(GL20.glGetProgramInfoLog(prog, 8192).trim());
            GL20.glDeleteProgram(prog);
            return 0;
        }
        return prog;
    }

    /** A user post-processing shader */
    public static final class Shader extends LObj {
        int program; boolean enabled; final Map<String, float[]> uniforms = new LinkedHashMap<>();
        Shader(int p) { super("Shader"); program = p; name = "Shader"; }
        @Override protected LuaValue getProp(String k) {
            if (k.equals("Enabled")) return valueOf(enabled);
            if (k.equals("Valid")) return valueOf(program != 0);
            return super.getProp(k);
        }
        @Override protected boolean setProp(String k, LuaValue v) {
            if (k.equals("Enabled")) { enable(v.toboolean()); return true; }
            return super.setProp(k, v);
        }
        void enable(boolean on) {
            if (program == 0) throw new LuaError("Shader was destroyed");
            enabled = on;
            ACTIVE.remove(this);
            if (on) ACTIVE.add(this);
        }
        @Override protected void onDestroy() { ACTIVE.remove(this); if (program != 0) GL20.glDeleteProgram(program); program = 0; }
        static {
            reg(Shader.class, "Enable", (s, a) -> { ((Shader) s).enable(true); return NONE; });
            reg(Shader.class, "Disable", (s, a) -> { ((Shader) s).enable(false); return NONE; });
            reg(Shader.class, "SetUniform", (s, a) -> {
                LuaValue v = a.arg(2); float[] f;
                if (v instanceof Vec3L p) f = new float[]{(float) p.x, (float) p.y, (float) p.z};
                else if (v.istable()) { int n = Math.min(4, Math.max(1, v.length())); f = new float[n]; for (int i = 0; i < n; i++) f[i] = (float) v.get(i + 1).todouble(); }
                else if (v instanceof ColorL c) f = new float[]{c.r / 255f, c.g / 255f, c.b / 255f};
                else f = new float[]{(float) v.checkdouble()};
                ((Shader) s).uniforms.put(a.checkjstring(1), f);
                return NONE; });
        }
    }

    static {
        reg(ShaderDT.class, "Create", (s, a) -> {
            StringBuilder log = new StringBuilder();
            int p = link(a.checkjstring(1), log);
            if (p == 0) throw new LuaError("ShaderDT compile error:\n" + log);
            Shader sh = new Shader(p);
            if (a.optboolean(2, true)) sh.enable(true);
            return sh; });
        reg(ShaderDT.class, "Compile", (s, a) -> {
            StringBuilder log = new StringBuilder();
            int p = link(a.checkjstring(1), log);
            if (p != 0) GL20.glDeleteProgram(p);
            return varargsOf(valueOf(p != 0), valueOf(log.toString())); });
        reg(ShaderDT.class, "Preset", (s, a) -> {
            String n = a.checkjstring(1).toLowerCase(Locale.ROOT);
            if (!PRESETS.contains(n)) throw new LuaError("Unknown preset '" + n + "'. See ShaderDT.Presets");
            Minecraft.getInstance().gameRenderer.loadEffect(new ResourceLocation("shaders/post/" + n + ".json"));
            preset = n; return NONE; });
        reg(ShaderDT.class, "ClearPreset", (s, a) -> { Minecraft.getInstance().gameRenderer.shutdownEffect(); preset = null; return NONE; });
        reg(ShaderDT.class, "DisableAll", (s, a) -> { for (Shader sh : new ArrayList<>(ACTIVE)) sh.enabled = false; ACTIVE.clear(); return NONE; });
    }

    // ------------------------------------------------------------ Shader DK (ZSpace tool) support
    static Shader studio;
    /** world snapshot (without GUI) for the Shader DK preview; captured while requested */
    public static TextureTarget snapshot;
    public static long snapshotWanted;

    /** applies (or removes with 0) the shader edited in Shader DK to the game view */
    public static void studio(int program, Map<String, float[]> uniforms) {
        if (studio != null) {
            int old = studio.program;
            ACTIVE.remove(studio); studio.enabled = false; studio.program = 0;
            if (program != 0 && old != 0 && old != program) GL20.glDeleteProgram(old);
        }
        studio = null;
        if (program != 0) { studio = new Shader(program); studio.uniforms.putAll(uniforms); studio.enabled = true; ACTIVE.add(studio); }
    }
    public static int studioProgram() { return studio == null ? 0 : studio.program; }
    public static void studioUniforms(Map<String, float[]> u) { if (studio != null) { studio.uniforms.clear(); studio.uniforms.putAll(u); } }
    public static List<String> presets() { return PRESETS; }
    public static String currentPreset() { return preset; }
    public static void loadPreset(String n) {
        if (n == null) { Minecraft.getInstance().gameRenderer.shutdownEffect(); preset = null; return; }
        Minecraft.getInstance().gameRenderer.loadEffect(new ResourceLocation("shaders/post/" + n + ".json")); preset = n;
    }

    static void capture(RenderTarget main) {
        int w = main.width, h = main.height;
        if (snapshot == null) snapshot = new TextureTarget(w, h, false, Minecraft.ON_OSX);
        else if (snapshot.width != w || snapshot.height != h) snapshot.resize(w, h, Minecraft.ON_OSX);
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.frameBufferId);
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, snapshot.frameBufferId);
        GlStateManager._glBlitFrameBuffer(0, 0, w, h, 0, 0, w, h, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
        main.bindWrite(true);
    }

    /** remove everything (runtime closed / logout) */
    public static void reset() {
        for (Shader s : new ArrayList<>(ACTIVE)) { if (s.program != 0) GL20.glDeleteProgram(s.program); s.program = 0; s.enabled = false; }
        ACTIVE.clear();
        if (preset != null) { Minecraft.getInstance().gameRenderer.shutdownEffect(); preset = null; }
    }

    // ------------------------------------------------------------ rendering
    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL) return;
        RenderTarget main = Minecraft.getInstance().getMainRenderTarget();
        if (System.currentTimeMillis() - snapshotWanted < 1000) { try { capture(main); } catch (RuntimeException ex) { Fluwa.LOGGER.debug("snapshot", ex); } }
        if (ACTIVE.isEmpty()) return;
        int w = main.width, h = main.height;
        if (copy == null) copy = new TextureTarget(w, h, false, Minecraft.ON_OSX);
        else if (copy.width != w || copy.height != h) copy.resize(w, h, Minecraft.ON_OSX);
        if (vao == 0) vao = GL30.glGenVertexArrays();
        float time = (System.currentTimeMillis() - START) / 1000f;
        for (Shader s : new ArrayList<>(ACTIVE)) {
            try {
                GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.frameBufferId);
                GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, copy.frameBufferId);
                GlStateManager._glBlitFrameBuffer(0, 0, w, h, 0, 0, w, h, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_NEAREST);
                main.bindWrite(true);
                RenderSystem.disableDepthTest(); RenderSystem.depthMask(false); RenderSystem.disableBlend(); RenderSystem.disableCull();
                GlStateManager._glUseProgram(s.program);
                RenderSystem.activeTexture(GL13.GL_TEXTURE0);
                RenderSystem.bindTexture(copy.getColorTextureId());
                GL20.glUniform1i(GL20.glGetUniformLocation(s.program, "DiffuseSampler"), 0);
                GL20.glUniform1f(GL20.glGetUniformLocation(s.program, "Time"), time);
                GL20.glUniform2f(GL20.glGetUniformLocation(s.program, "ScreenSize"), w, h);
                for (var u : s.uniforms.entrySet()) {
                    int loc = GL20.glGetUniformLocation(s.program, u.getKey());
                    if (loc < 0) continue;
                    float[] f = u.getValue();
                    switch (f.length) {
                        case 1 -> GL20.glUniform1f(loc, f[0]);
                        case 2 -> GL20.glUniform2f(loc, f[0], f[1]);
                        case 3 -> GL20.glUniform3f(loc, f[0], f[1], f[2]);
                        default -> GL20.glUniform4f(loc, f[0], f[1], f[2], f[3]);
                    }
                }
                GL30.glBindVertexArray(vao);
                GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
                GL30.glBindVertexArray(0);
            } catch (RuntimeException ex) {
                s.enabled = false; ACTIVE.remove(s);
                Fluwa.LOGGER.error("ShaderDT: shader disabled after render error", ex);
            } finally {
                BufferUploader.invalidate();
                GlStateManager._glUseProgram(0);
                RenderSystem.depthMask(true); RenderSystem.enableDepthTest(); RenderSystem.enableCull();
                main.bindWrite(true);
            }
        }
    }
}
