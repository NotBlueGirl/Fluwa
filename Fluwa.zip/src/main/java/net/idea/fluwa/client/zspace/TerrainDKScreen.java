package net.idea.fluwa.client.zspace;

import net.idea.fluwa.net.FluwaNet;
import net.idea.fluwa.net.Pkt;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;

import java.util.*;

import static net.idea.fluwa.client.zspace.ZUi.*;

/**
 * ZSpace → ☰ → Tools → Terrain DK: edit existing dimensions and biomes, create new dimensions, biomes and
 * world generation types, with a live preview (biome / height map computed by the server's real generator).
 */
public class TerrainDKScreen extends ZWindow {
    static final String[] KINDS = {"D", "B", "G"};
    static final String[] KIND_NAMES = {"Dimensions", "Biomes", "Gen types"};
    static String kind = "D", selId;
    static int zoom = 4;

    /** field -> type: t text, n number, b bool, c:<a|b|c> choice, k colour */
    static final LinkedHashMap<String, String> DFIELDS = new LinkedHashMap<>(), BFIELDS = new LinkedHashMap<>(), GFIELDS = new LinkedHashMap<>();
    static {
        String[][] d = {{"#Generator", "h"}, {"Type", "c:noise|flat|void"}, {"Preset", "t"}, {"BiomeSource", "c:multi_noise|fixed|the_end|checkerboard"}, {"BiomePreset", "t"}, {"Biome", "t"},
                {"CheckerboardScale", "n"}, {"Layers", "t"}, {"Features", "b"}, {"Lakes", "b"}, {"Structures", "t"},
                {"#Dimension type", "h"}, {"DimensionType", "t"}, {"MinY", "n"}, {"Height", "n"}, {"LogicalHeight", "n"}, {"HasSkylight", "b"}, {"HasCeiling", "b"},
                {"Ultrawarm", "b"}, {"Natural", "b"}, {"AmbientLight", "n"}, {"FixedTime", "n"}, {"Effects", "c:minecraft:overworld|minecraft:the_nether|minecraft:the_end"},
                {"CoordinateScale", "n"}, {"BedWorks", "b"}, {"RespawnAnchorWorks", "b"}, {"HasRaids", "b"}, {"PiglinSafe", "b"}, {"Infiniburn", "t"},
                {"#Monsters", "h"}, {"MonsterSpawnLight", "t"}, {"MonsterSpawnBlockLight", "n"}};
        for (String[] x : d) DFIELDS.put(x[0], x[1]);
        String[][] b = {{"CopyFrom", "t"}, {"#Climate", "h"}, {"Temperature", "n"}, {"Downfall", "n"}, {"HasPrecipitation", "b"}, {"TemperatureModifier", "c:none|frozen"},
                {"#Colours", "h"}, {"SkyColor", "k"}, {"FogColor", "k"}, {"WaterColor", "k"}, {"WaterFogColor", "k"}, {"GrassColor", "k"}, {"FoliageColor", "k"},
                {"GrassColorModifier", "c:none|dark_forest|swamp"},
                {"#Atmosphere", "h"}, {"Particle", "t"}, {"ParticleProbability", "n"}, {"AmbientSound", "t"}, {"MoodSound", "t"}, {"AdditionsSound", "t"}, {"AdditionsChance", "n"},
                {"Music", "t"}, {"MusicMinDelay", "n"}, {"MusicMaxDelay", "n"}, {"ReplaceMusic", "b"},
                {"#Mob spawning", "h"}, {"CreatureSpawnProbability", "n"}, {"SpawnMonster", "t"}, {"SpawnCreature", "t"}, {"SpawnAmbient", "t"}, {"SpawnWaterCreature", "t"},
                {"SpawnWaterAmbient", "t"}, {"SpawnUndergroundWater", "t"}, {"SpawnAxolotls", "t"}, {"SpawnMisc", "t"},
                {"#Generation", "h"}, {"Carvers", "t"}, {"AddFeatures", "t"}, {"RemoveFeatures", "t"}};
        for (String[] x : b) BFIELDS.put(x[0], x[1]);
        String[][] g = {{"CopyFrom", "t"}, {"#Blocks", "h"}, {"SeaLevel", "n"}, {"DefaultBlock", "t"}, {"DefaultFluid", "t"}, {"SurfaceBlock", "t"}, {"UnderSurfaceBlock", "t"},
                {"BedrockFloor", "b"}, {"BedrockRoof", "b"}, {"#Shape", "h"}, {"MinY", "n"}, {"Height", "n"}, {"SizeHorizontal", "n"}, {"SizeVertical", "n"}, {"DensityOffset", "n"},
                {"#Features", "h"}, {"AquifersEnabled", "b"}, {"OreVeinsEnabled", "b"}, {"DisableMobGeneration", "b"}, {"LegacyRandomSource", "b"}, {"WorldPreset", "b"}};
        for (String[] x : g) GFIELDS.put(x[0], x[1]);
    }
    static final Map<String, String> HELP = Map.ofEntries(
            Map.entry("Preset", "Generation type (noise settings): minecraft:overworld, minecraft:nether, minecraft:amplified, fluwa:my_type…"),
            Map.entry("Layers", "flat: block:height, …  e.g. bedrock:1, stone:60, dirt:3, grass_block:1"),
            Map.entry("Biome", "fixed / flat biome (minecraft:plains); checkerboard: several, comma separated"),
            Map.entry("BiomePreset", "multi_noise parameter list: minecraft:overworld or minecraft:nether"),
            Map.entry("DimensionType", "empty = own type from the fields below; or an existing type id"),
            Map.entry("CopyFrom", "base the new object on an existing one (features, spawns, noise router…)"),
            Map.entry("WorldPreset", "also add a world type (world_preset) using this generation"),
            Map.entry("MinY", "multiple of 16"), Map.entry("Height", "multiple of 16 (16..4064)"),
            Map.entry("CheckerboardScale", "checkerboard: size of each square = 2^(scale+2) blocks (0..62, default 2)"),
            Map.entry("Lakes", "flat: generate lava / water lakes"),
            Map.entry("Structures", "flat: structure sets, e.g. villages, strongholds, mineshafts (empty = none)"),
            Map.entry("Infiniburn", "block tag that burns forever: #minecraft:infiniburn_overworld / _nether / _end"),
            Map.entry("MonsterSpawnLight", "max sky+block light for monsters: 0 (vanilla overworld 0-7) or a range a-b"),
            Map.entry("MonsterSpawnBlockLight", "max block light for monster spawns (0..15, nether 15)"),
            Map.entry("GrassColorModifier", "none, dark_forest (darker) or swamp (noise-based)"),
            Map.entry("Particle", "ambient particle, e.g. minecraft:ash, white_ash, crimson_spore, warped_spore, spore_blossom_air (empty = none)"),
            Map.entry("ParticleProbability", "chance per block per tick (0..1), e.g. 0.01"),
            Map.entry("AmbientSound", "looping ambient sound, e.g. minecraft:ambient.crimson_forest.loop"),
            Map.entry("MoodSound", "cave mood sound, e.g. minecraft:ambient.cave"),
            Map.entry("AdditionsSound", "random extra sound, e.g. minecraft:ambient.nether_wastes.additions"),
            Map.entry("AdditionsChance", "chance per tick of AdditionsSound (0.0111 vanilla)"),
            Map.entry("Music", "music sound event, e.g. minecraft:music.overworld.forest"),
            Map.entry("MusicMinDelay", "ticks between tracks (min, 20 ticks = 1 s)"), Map.entry("MusicMaxDelay", "ticks between tracks (max)"),
            Map.entry("ReplaceMusic", "stop the current track when entering this biome"),
            Map.entry("CreatureSpawnProbability", "chance of passive mobs at chunk generation (0..0.9999, vanilla 0.1)"),
            Map.entry("SpawnMonster", "mob*weight(min-max), …  e.g. zombie*95(4-4), skeleton*100(4-4); empty = none"),
            Map.entry("SpawnCreature", "e.g. sheep*12(4-4), pig*10(4-4), cow*8(4-4)"),
            Map.entry("SpawnAmbient", "e.g. bat*10(8-8)"), Map.entry("SpawnWaterCreature", "e.g. squid*2(1-4)"),
            Map.entry("SpawnWaterAmbient", "e.g. cod*10(3-6), salmon*5(1-5)"), Map.entry("SpawnUndergroundWater", "e.g. glow_squid*10(4-6)"),
            Map.entry("SpawnAxolotls", "e.g. axolotl*10(4-6)"), Map.entry("SpawnMisc", "anything else"),
            Map.entry("Carvers", "caves / canyons: cave, cave_extra_underground, canyon (empty = none)"),
            Map.entry("AddFeatures", "placed features, feature@step: e.g. ore_diamond@underground_ores, trees_plains (default step vegetal_decoration)"),
            Map.entry("RemoveFeatures", "placed features removed from every step, e.g. ore_diamond, lake_lava_surface"),
            Map.entry("SurfaceBlock", "top block of the land (e.g. sand, moss_block); empty = keep the vanilla surface rules"),
            Map.entry("UnderSurfaceBlock", "blocks under the top (e.g. sandstone, dirt)"),
            Map.entry("BedrockFloor", "bedrock layer at the bottom"), Map.entry("BedrockRoof", "bedrock ceiling at the top (nether style)"),
            Map.entry("DensityOffset", "added to the final density: + = more solid / higher land, - = more air (try -0.2 / 0.2)"));

    final List<String[]> entries = new ArrayList<>();
    final LinkedHashMap<String, String> fields = new LinkedHashMap<>();
    boolean loading;
    int listScroll, formScroll;
    // preview
    int pN, pStep, pMin, pMax, pSea; String pErr;
    String[] pal = new String[0]; int[] palCol = new int[0];
    byte[] pData; boolean pBusy;
    String hoverInfo;
    long deleteArm;

    public TerrainDKScreen(Screen parent) { super("Terrain DK", parent, 520, 300); }

    @Override protected void onInit() {
        if (entries.isEmpty()) send("list");
        if (selId != null && fields.isEmpty()) load(kind, selId);
    }

    static void send(String... s) { FluwaNet.toServer(new Pkt(Pkt.C_TDK, s)); }

    void load(String k, String id) {
        kind = k; selId = id; fields.clear(); loading = true; formScroll = 0; pData = null; pErr = null;
        for (String f : fieldsOf(k).keySet()) box("f:" + f, "").setValue("");
        send("load", k, id);
    }

    static LinkedHashMap<String, String> fieldsOf(String k) { return k.equals("D") ? DFIELDS : k.equals("B") ? BFIELDS : GFIELDS; }

    /** server replies */
    public void reply(Pkt p) {
        switch (p.s(0)) {
            case "list" -> { entries.clear(); for (int i = 1; i < p.s.size(); i++) entries.add(p.s.get(i).split("\t", -1)); }
            case "fields" -> {
                if (!p.s(1).equals(kind) || !p.s(2).equals(selId)) { kind = p.s(1); selId = p.s(2); }
                fields.clear();
                for (int i = 3; i + 1 < p.s.size(); i += 2) fields.put(p.s.get(i), p.s.get(i + 1));
                for (var e : fieldsOf(kind).entrySet()) {
                    String v = fields.getOrDefault(e.getKey(), "");
                    fields.put(e.getKey(), v);
                    box("f:" + e.getKey(), "").setValue(v);
                }
                loading = false;
                if (!kind.equals("B")) preview();
            }
            case "msg" -> setStatus(p.s(1).equals("1"), p.s(2));
            case "preview" -> {
                pBusy = false;
                pErr = p.s(1).isEmpty() ? null : p.s(1);
                pN = parse(p.s(2)); pStep = parse(p.s(3)); pMin = parse(p.s(4)); pMax = parse(p.s(5)); pSea = parse(p.s(6));
                int n = p.s.size() - 7;
                pal = new String[n]; palCol = new int[n];
                for (int i = 0; i < n; i++) { String[] x = p.s.get(7 + i).split("\t"); pal[i] = x[0]; palCol[i] = x.length > 1 ? parse(x[1]) : 0x808080; }
                pData = p.data.length >= pN * pN * 4 ? p.data : null;
                if (pErr != null) setStatus(false, "Preview: " + pErr);
            }
            default -> {}
        }
    }
    static int parse(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; } }

    Map<String, String> collect() {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        for (var e : fieldsOf(kind).entrySet()) {
            String t = e.getValue();
            if (t.equals("h")) continue;
            m.put(e.getKey(), t.equals("b") || t.startsWith("c:") ? fields.getOrDefault(e.getKey(), "") : box("f:" + e.getKey(), "").getValue());
        }
        return m;
    }

    void sendWithFields(String op) {
        List<String> s = new ArrayList<>(List.of(op, kind, selId));
        collect().forEach((k, v) -> { s.add(k); s.add(v); });
        FluwaNet.toServer(new Pkt(Pkt.C_TDK, s, new int[]{zoom}, null));
    }
    void preview() { if (selId == null || kind.equals("B")) return; pBusy = true; sendWithFields("preview"); setStatus(true, "Computing preview…"); }
    void save() { if (selId == null) return; sendWithFields("save"); setStatus(true, "Saving…"); }

    @Override protected String subtitle() { return "dimensions · biomes · generation types"; }
    @Override protected String hint() { return "Changes go to the world datapack fluwa_generated and apply after a world/server restart"; }

    // ------------------------------------------------------------------ render
    @Override protected void renderBody(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my, float pt) {
        int listW = Math.max(120, (x1 - x0) * 26 / 100);
        int prevW = kind.equals("B") ? Math.max(110, (x1 - x0) * 24 / 100) : Math.max(140, (x1 - x0) * 34 / 100);
        renderList(g, x0, y0, x0 + listW, y1, mx, my);
        g.fill(x0 + listW, y0, x0 + listW + 1, y1, LINE);
        renderForm(g, x0 + listW + 1, y0, x1 - prevW, y1, mx, my);
        g.fill(x1 - prevW - 1, y0, x1 - prevW, y1, LINE);
        renderPreview(g, x1 - prevW, y0, x1, y1, mx, my);
    }

    void renderList(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my) {
        g.fill(x0, y0, x1, y1, SIDE);
        int tw = (x1 - x0 - 8) / 3;
        for (int i = 0; i < 3; i++) {
            String k = KINDS[i];
            button(g, "k" + k, x0 + 4 + i * tw, y0 + 4, tw - 2, 13, KIND_NAMES[i], k.equals(kind) ? 3 : 0, mx, my, () -> { kind = k; listScroll = 0; });
        }
        EditBox search = place(g, box("search", "Search…"), x0 + 4, y0 + 21, x1 - x0 - 8);
        String q = search.getValue().trim().toLowerCase(Locale.ROOT);
        int top = y0 + 39, bot = y1 - 40;
        List<String[]> l = new ArrayList<>();
        for (String[] e : entries) if (e[0].equals(kind) && (q.isEmpty() || e[1].contains(q))) l.add(e);
        int max = Math.max(0, l.size() * ROW - (bot - top));
        listScroll = Math.max(0, Math.min(listScroll, max));
        scissor(g, x0, top, x1, bot);
        int y = top - listScroll;
        if (entries.isEmpty()) small(g, font, "Loading… (needs Creator rights)", x0 + 8, top + 4, FAINT);
        for (String[] e : l) {
            if (y + ROW > top && y < bot) {
                boolean sel = e[1].equals(selId) && e[0].equals(kind), hov = in(mx, my, x0 + 2, y, x1 - 2, y + ROW) && my >= top && my < bot;
                if (sel) round(g, x0 + 2, y, x1 - 2, y + ROW, SELROW); else if (hov) round(g, x0 + 2, y, x1 - 2, y + ROW, HOVER);
                int c = e[2].contains("restart") ? WARN : e[2].contains("custom") || e[2].contains("edited") ? ACCENT2 : e[2].startsWith("loaded") ? OK : FAINT;
                round(g, x0 + 7, y + 4, x0 + 12, y + 9, c);
                String nm = e[1].startsWith("minecraft:") ? e[1].substring(10) : e[1];
                text(g, font, ellipsize(font, nm, x1 - x0 - 22), x0 + 16, y + 3, sel ? 0xFFFFFFFF : 0xFFC8C8D8);
                final String id = e[1], k = e[0];
                hits.add(new Hit(x0 + 2, Math.max(y, top), x1 - 2, Math.min(y + ROW, bot), () -> load(k, id)));
            }
            y += ROW;
        }
        g.disableScissor();
        // new
        g.fill(x0 + 4, bot + 3, x1 - 4, bot + 4, LINE);
        EditBox nb = place(g, box("newname", "new id (fluwa:my_" + (kind.equals("D") ? "dim" : kind.equals("B") ? "biome" : "type") + ")"), x0 + 4, bot + 8, x1 - x0 - 8);
        String nl = "+ New " + (kind.equals("D") ? "dimension" : kind.equals("B") ? "biome" : "generation type");
        button(g, "new", x0 + 4, bot + 24, x1 - x0 - 8, 13, nl, 1, mx, my, () -> {
            String n = nb.getValue().trim();
            if (n.isEmpty()) { setStatus(false, "Type an id for the new object first"); return; }
            if (!n.contains(":")) n = "fluwa:" + n;
            n = n.toLowerCase(Locale.ROOT).replace(' ', '_');
            nb.setValue("");
            load(kind, n);
            setStatus(true, "New " + n + " — edit the fields and press Save");
        });
    }

    void renderForm(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my) {
        g.fill(x0, y0, x1, y1, EDITOR);
        if (selId == null) {
            centered(g, font, "Select or create an object", (x0 + x1) / 2, (y0 + y1) / 2 - 10, DIM);
            small(g, font, "Dimensions · Biomes · Generation types", (x0 + x1) / 2 - font.width("Dimensions · Biomes · Generation types") * 3 / 8, (y0 + y1) / 2 + 4, FAINT);
            return;
        }
        String kn = kind.equals("D") ? "Dimension" : kind.equals("B") ? "Biome" : "Generation type";
        text(g, font, ellipsize(font, selId, x1 - x0 - 16), x0 + 8, y0 + 5, TEXT);
        small(g, font, kn.toUpperCase(Locale.ROOT), x0 + 8, y0 + 15, DIM);
        int bx = x1 - 6;
        boolean armed = System.currentTimeMillis() - deleteArm < 3000;
        int w = bw(armed ? "Confirm?" : "Delete"); bx -= w;
        button(g, "del", bx, y0 + 5, w, 13, armed ? "Confirm?" : "Delete", 2, mx, my, () -> {
            if (System.currentTimeMillis() - deleteArm > 3000) { deleteArm = System.currentTimeMillis(); return; }
            deleteArm = 0; send("delete", kind, selId);
        });
        w = bw("Save"); bx -= w + 3; button(g, "save", bx, y0 + 5, w, 13, "Save", 1, mx, my, this::save);
        if (!kind.equals("B")) { w = bw("Preview"); bx -= w + 3; button(g, "prev", bx, y0 + 5, w, 13, "Preview", 0, mx, my, this::preview); }
        w = bw("Reset"); bx -= w + 3; button(g, "reset", bx, y0 + 5, w, 13, "Reset", 0, mx, my, () -> load(kind, selId));
        int top = y0 + 26, bot = y1 - 2;
        g.fill(x0, top - 2, x1, top - 1, LINE);
        if (loading) { small(g, font, "Loading…", x0 + 10, top + 6, FAINT); return; }
        var fs = fieldsOf(kind);
        int rowH = 17;
        int max = Math.max(0, fs.size() * rowH + 30 - (bot - top));
        formScroll = Math.max(0, Math.min(formScroll, max));
        int lw = Math.max(70, (x1 - x0) * 40 / 100);
        scissor(g, x0, top, x1, bot);
        int y = top + 3 - formScroll;
        String helpShown = null;
        for (var e : fs.entrySet()) {
            String k = e.getKey(), t = e.getValue();
            boolean vis = y + rowH > top && y < bot;
            boolean hov = in(mx, my, x0, y, x1, y + rowH) && my >= top && my < bot;
            if (t.equals("h")) {
                if (vis) { text(g, font, k.substring(1), x0 + 8, y + 6, ACCENT); g.fill(x0 + 12 + font.width(k.substring(1)), y + 10, x1 - 8, y + 11, LINE); }
                y += rowH;
                continue;
            }
            if (hov && HELP.containsKey(k)) helpShown = HELP.get(k);
            text(g, font, ellipsize(font, k, lw - 12), x0 + 8, y + 3, hov ? TEXT : DIM);
            int vx = x0 + lw, vw = x1 - vx - 8;
            if (t.equals("b")) {
                boolean on = fields.getOrDefault(k, "").equalsIgnoreCase("true");
                if (vis) toggle(g, "t:" + k, vx, y + 1, on, mx, my, () -> fields.put(k, String.valueOf(!on)));
                small(g, font, on ? "true" : "false", vx + 25, y + 4, on ? OK : FAINT);
            } else if (t.startsWith("c:")) {
                String[] opts = t.substring(2).split("\\|");
                String cur = fields.getOrDefault(k, "");
                if (cur.isEmpty()) cur = opts[0];
                if (vis) choice(g, "c:" + k, vx, y, vw, cur, opts, mx, my, v -> fields.put(k, v));
            } else {
                EditBox b = box("f:" + k, t.equals("k") ? "#RRGGBB (default)" : t.equals("n") ? "number" : "");
                if (vis && y >= top && y + 14 <= bot) {
                    int sw2 = t.equals("k") ? 14 : 0;
                    place(g, b, vx, y, vw - sw2);
                    if (t.equals("k")) {
                        int c = color(b.getValue());
                        if (c >= 0) round(g, vx + vw - 12, y + 1, x1 - 8, y + 13, 0xFF000000 | c);
                        else outline(g, vx + vw - 12, y + 1, x1 - 8, y + 13, FAINT);
                    }
                } else if (vis) text(g, font, ellipsize(font, b.getValue(), vw - 8), vx + 4, y + 3, TEXT);
            }
            y += rowH;
        }
        if (kind.equals("B")) {
            y += 4;
            button(g, "paint", x0 + 8, y, bw("Paint this biome around me (r 32)"), 13, "Paint this biome around me (r 32)", 0, mx, my, () -> FluwaNet.toServer(new Pkt(Pkt.C_TDK, List.of("biome", selId), new int[]{32}, null)));
            small(g, font, "runtime, like /fillbiome — works now, without restart", x0 + 8, y + 16, FAINT);
        }
        g.disableScissor();
        if (helpShown != null) {
            int hw = Math.min(x1 - x0 - 12, font.width(helpShown) * 3 / 4 + 10);
            int hy = Math.min(bot - 14, my + 10);
            round(g, x0 + 6, hy, x0 + 6 + hw, hy + 12, 0xF0202030);
            small(g, font, ellipsize(font, helpShown, (hw - 8) * 4 / 3), x0 + 10, hy + 3, 0xFFD8D8F0);
        }
    }

    static int color(String s) {
        try { s = s.trim().replace("#", "").replace("0x", ""); return s.isEmpty() ? -1 : Integer.parseInt(s, 16) & 0xFFFFFF; } catch (Exception e) { return -1; }
    }

    void renderPreview(GuiGraphics g, int x0, int y0, int x1, int y1, int mx, int my) {
        g.fill(x0, y0, x1, y1, PANEL);
        label(g, "Preview", x0 + 8, y0 + 6);
        if (selId == null) return;
        if (kind.equals("B")) { biomePreview(g, x0 + 8, y0 + 18, x1 - 8, y1 - 8); return; }
        // zoom
        int zx = x1 - 6;
        int[] zs = {16, 8, 4, 2, 1};
        for (int z : zs) {
            String l = z + "";
            int w = font.width(l) + 8; zx -= w + 2;
            button(g, "z" + z, zx, y0 + 3, w, 12, l, z == zoom ? 3 : 0, mx, my, () -> { zoom = z; preview(); });
        }
        small(g, font, "blocks/px", zx - 34, y0 + 6, FAINT);
        int size = Math.min(x1 - x0 - 16, y1 - y0 - 50);
        int px = x0 + (x1 - x0 - size) / 2, py = y0 + 20;
        round(g, px - 1, py - 1, px + size + 1, py + size + 1, 0xFF0A0A10);
        hoverInfo = null;
        if (pData != null && pN > 0) {
            float cell = size / (float) pN;
            int range = Math.max(1, pMax - pMin);
            for (int j = 0; j < pN; j++) for (int i = 0; i < pN; i++) {
                int o = (j * pN + i) * 4;
                int idx = pData[o] & 255, h = (short) (((pData[o + 1] & 255) << 8) | (pData[o + 2] & 255));
                boolean water = pData[o + 3] == 1;
                int c = idx < palCol.length ? palCol[idx] : 0x808080;
                float shade;
                if (water) { c = lerp(0xFF1B3F8F, 0xFF3F76E4, Math.max(0, Math.min(1, 1 - (pSea - h) / 40f))); shade = 1; }
                else shade = 0.55f + 0.6f * Math.max(0, Math.min(1, (h - pMin) / (float) range));
                // relief: compare with the north-west neighbour
                if (!water && i > 0 && j > 0) {
                    int o2 = ((j - 1) * pN + i - 1) * 4;
                    int h2 = (short) (((pData[o2 + 1] & 255) << 8) | (pData[o2 + 2] & 255));
                    shade += Math.max(-0.25f, Math.min(0.25f, (h - h2) * 0.04f));
                }
                int r = Math.min(255, (int) (((c >> 16) & 255) * shade)), gg = Math.min(255, (int) (((c >> 8) & 255) * shade)), b = Math.min(255, (int) ((c & 255) * shade));
                int ax = px + (int) (i * cell), ay = py + (int) (j * cell), bx2 = px + (int) ((i + 1) * cell), by2 = py + (int) ((j + 1) * cell);
                g.fill(ax, ay, Math.max(ax + 1, bx2), Math.max(ay + 1, by2), 0xFF000000 | r << 16 | gg << 8 | b);
                if (in(mx, my, ax, ay, bx2, by2)) hoverInfo = (idx < pal.length ? pal[idx].replace("minecraft:", "") : "?") + " · y " + h + (water ? " (water)" : "")
                        + " · " + ((i - pN / 2) * pStep) + ", " + ((j - pN / 2) * pStep);
            }
            // player marker
            int cx = px + size / 2, cy = py + size / 2;
            g.fill(cx - 2, cy, cx + 3, cy + 1, 0xFFFFFFFF); g.fill(cx, cy - 2, cx + 1, cy + 3, 0xFFFFFFFF);
        } else centered(g, font, pBusy ? "Generating…" : pErr != null ? "Preview failed" : "Press Preview", px + size / 2, py + size / 2 - 4, pErr != null ? ERR : FAINT);
        int iy = py + size + 5;
        if (hoverInfo != null) small(g, font, ellipsize(font, hoverInfo, (x1 - x0 - 16) * 4 / 3), x0 + 8, iy, TEXT);
        else if (pData != null) small(g, font, (pN * pStep) + "×" + (pN * pStep) + " blocks around you · " + pal.length + " biomes", x0 + 8, iy, DIM);
        if (pBusy) { int d = (int) (System.currentTimeMillis() / 200 % 4); small(g, font, "computing" + ".".repeat(d), x0 + 8, iy + 10, ACCENT2); }
        else if (pErr != null) small(g, font, ellipsize(font, pErr, (x1 - x0 - 16) * 4 / 3), x0 + 8, iy + 10, ERR);
    }

    void biomePreview(GuiGraphics g, int x0, int y0, int x1, int y1) {
        int sky = col("SkyColor", 0x78A7FF), fog = col("FogColor", 0xC0D8FF), water = col("WaterColor", 0x3F76E4), wfog = col("WaterFogColor", 0x050533);
        float t = 0.8f, d = 0.4f;
        try { t = Float.parseFloat(box("f:Temperature", "").getValue()); d = Float.parseFloat(box("f:Downfall", "").getValue()); } catch (Exception ignored) {}
        int grassDef = t < 0.15f ? 0xEEF3F8 : lerp(0xFFBDB25F, 0xFF3E8F2A, Math.max(0, Math.min(1, d))) & 0xFFFFFF;
        int grass = col("GrassColor", grassDef), foliage = col("FoliageColor", lerp(0xFF0000FF | grass, 0xFF2F6F1F, 0.3f) & 0xFFFFFF);
        int h = Math.min(y1 - y0 - 40, (x1 - x0) * 3 / 4);
        int horizon = y0 + h * 55 / 100;
        for (int y = y0; y < horizon; y++) g.fill(x0, y, x1, y + 1, lerp(0xFF000000 | sky, 0xFF000000 | fog, (y - y0) / (float) Math.max(1, horizon - y0)));
        g.fill(x0, horizon, x1, y0 + h * 70 / 100, 0xFF000000 | grass);
        g.fill(x0, y0 + h * 70 / 100, x1, y0 + h * 85 / 100, 0xFF000000 | water);
        g.fill(x0, y0 + h * 85 / 100, x1, y0 + h, 0xFF000000 | wfog);
        // a tree
        int tx = x0 + (x1 - x0) / 3;
        g.fill(tx, horizon - 18, tx + 4, horizon + 2, 0xFF6B4A2B);
        round(g, tx - 9, horizon - 34, tx + 13, horizon - 14, 0xFF000000 | foliage);
        if (t < 0.15f) for (int i = 0; i < 18; i++) { int sx = x0 + (i * 37) % Math.max(1, x1 - x0), sy = y0 + (i * 53 + (int) (System.currentTimeMillis() / 60)) % Math.max(1, horizon - y0); g.fill(sx, sy, sx + 1, sy + 1, 0xFFFFFFFF); }
        int ly = y0 + h + 6;
        String[][] sw = {{"Sky", hex(sky)}, {"Fog", hex(fog)}, {"Water", hex(water)}, {"Grass", hex(grass)}, {"Foliage", hex(foliage)}};
        for (String[] s : sw) { small(g, font, s[0] + " " + s[1], x0, ly, DIM); ly += 9; }
    }
    int col(String f, int d) { int c = color(box("f:" + f, "").getValue()); return c < 0 ? d : c; }
    static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    @Override protected boolean bodyScroll(double mx, double my, double d) {
        int listW = Math.max(120, width * 26 / 100);
        if (mx < listW) listScroll = Math.max(0, listScroll - (int) (d * ROW * 2)); else formScroll = Math.max(0, formScroll - (int) (d * 17 * 2));
        return true;
    }
}
