package net.idea.fluwa;

import com.mojang.logging.LogUtils;
import net.idea.fluwa.net.FluwaNet;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Fluwa - a Roblox-Studio-like Lua scripting environment for Minecraft.
 * Press F8 in game (Creator / Co-Creator) to open ZSpace.
 */
@Mod(Fluwa.MODID)
public class Fluwa {
    public static final String MODID = "fluwa";
    public static final String VERSION = "0.5.0";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Fluwa() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(FluwaNet::register);
        LOGGER.info("Fluwa {} loaded - Lua scripting for Minecraft", VERSION);
    }
}
