package net.idea.fluwa.lighting;

import com.google.gson.*;
import net.idea.fluwa.lua.*;
import org.luaj.vm2.*;

import java.util.*;

/**
 * Base of the v0.5 lighting objects (Lighting, Sky, Bloom, LightPoint...): a typed property bag.
 * Every property gets Set&lt;Name&gt;(v) / Get&lt;Name&gt;() methods, fires E_Changed(property, value) and an optional
 * specific event. Only explicitly assigned values are stored (unset = default), which makes replication cheap.
 */
public abstract class PropBag extends LObj {
    public enum T { NUM, BOOL, COLOR, STR, VEC3 }

    /** property definition: name, type, default, specific event (nullable), min, max */
    public record P(String name, T type, LuaValue def, String event, double min, double max) {}

    public static final class Schema {
        final Map<String, P> props = new LinkedHashMap<>();
        final Set<String> events = new LinkedHashSet<>();
        public Schema num(String n, double def, String ev) { return num(n, def, ev, -Double.MAX_VALUE, Double.MAX_VALUE); }
        public Schema num(String n, double def, String ev, double min, double max) { return add(new P(n, T.NUM, LuaValue.valueOf(def), ev, min, max)); }
        public Schema bool(String n, boolean def, String ev) { return add(new P(n, T.BOOL, LuaValue.valueOf(def), ev, 0, 0)); }
        public Schema color(String n, int r, int g, int b, String ev) { return add(new P(n, T.COLOR, new ColorL(r, g, b), ev, 0, 0)); }
        public Schema str(String n, String def, String ev) { return add(new P(n, T.STR, LuaValue.valueOf(def), ev, 0, 0)); }
        public Schema vec(String n, Vec3L def, String ev) { return add(new P(n, T.VEC3, def == null ? LuaValue.NIL : def, ev, 0, 0)); }
        public Schema event(String e) { events.add(e); return this; }
        Schema add(P p) { props.put(p.name, p); if (p.event != null) events.add(p.event); return this; }
        public P get(String n) { return props.get(n); }
        public Collection<P> all() { return props.values(); }
    }

    protected final Map<String, LuaValue> vals = new LinkedHashMap<>();
    private final Map<String, Signal> signals = new HashMap<>();

    protected PropBag(String cls) { super(cls); }

    public abstract Schema schema();

    /** registers Set/Get/Is methods for every property of the schema on cls */
    protected static void defineAccessors(Class<? extends PropBag> cls, Schema sc) {
        for (P p : sc.all()) {
            String n = p.name;
            reg(cls, "Set" + n, (s, a) -> { ((PropBag) s).assign(n, a.arg1()); return NONE; });
            reg(cls, "Get" + n, (s, a) -> ((PropBag) s).value(n));
            if (p.type == T.BOOL && !n.startsWith("Is")) reg(cls, "Is" + n, (s, a) -> ((PropBag) s).value(n));
        }
    }

    // ------------------------------------------------------------ values
    public LuaValue value(String n) {
        LuaValue v = vals.get(n);
        if (v != null) return v;
        LuaValue inh = inherited(n);
        if (inh != null) return inh;
        P p = schema().get(n);
        return p == null ? NIL : p.def;
    }
    /** explicitly assigned here or in the replicated layer */
    public boolean has(String n) { return vals.containsKey(n) || inherited(n) != null; }
    /** load values from {@link #toJson()} output */
    public void loadJson(JsonObject o) {
        for (var e : o.entrySet()) { P p = schema().get(e.getKey()); if (p != null) vals.put(p.name(), fromJson(p, e.getValue())); }
    }
    /** value from another layer (client: the server replicated state) */
    protected LuaValue inherited(String n) { return null; }

    public double num(String n) { return value(n).todouble(); }
    public boolean bool(String n) { return value(n).toboolean(); }
    public String str(String n) { LuaValue v = value(n); return v.isnil() ? "" : v.tojstring(); }

    public static LuaValue coerce(P p, LuaValue v) {
        if (v.isnil()) return p.def;
        switch (p.type) {
            case NUM: {
                double d = v.checkdouble();
                if (Double.isNaN(d)) throw new LuaError(p.name + " can't be NaN");
                return valueOf(Math.max(p.min, Math.min(p.max, d)));
            }
            case BOOL: return valueOf(v.toboolean());
            case COLOR: {
                if (v instanceof ColorL) return v;
                int c = ColorL.check(v);
                return new ColorL(c >> 16 & 255, c >> 8 & 255, c & 255);
            }
            case STR: return valueOf(v.checkjstring());
            case VEC3: return Vec3L.check(v);
        }
        return v;
    }

    public void assign(String n, LuaValue v) {
        P p = schema().get(n);
        if (p == null) throw new LuaError(n + " is not a valid member of " + className);
        LuaValue nv = coerce(p, v);
        LuaValue old = value(n);
        if (v.isnil()) vals.remove(n); else vals.put(n, nv);
        if (same(old, nv)) return;
        changed(p, nv);
    }

    static boolean same(LuaValue a, LuaValue b) {
        if (a instanceof ColorL x && b instanceof ColorL y) return x.rgb() == y.rgb();
        if (a instanceof Vec3L x && b instanceof Vec3L y) return x.x == y.x && x.y == y.y && x.z == y.z;
        return a.raweq(b);
    }

    /** called after a property changed (fires events, replication) */
    protected void changed(P p, LuaValue v) {
        markDirty();
        fire("E_Changed", valueOf(p.name), v);
        if (p.event != null) fire(p.event, eventArgs(p, v));
    }

    protected LuaValue[] eventArgs(P p, LuaValue v) { return new LuaValue[]{v}; }

    public void fire(String ev, LuaValue... args) {
        Signal s = signals.get(ev);
        if (s != null && s.hasHandlers()) s.fire(args);
    }
    public boolean listens(String ev) { Signal s = signals.get(ev); return s != null && s.hasHandlers(); }

    /** replication hook */
    protected abstract void markDirty();

    // ------------------------------------------------------------ Lua access
    @Override protected LuaValue getProp(String k) {
        if (schema().get(k) != null) return value(k);
        if (k.equals("E_Changed") || k.equals("Changed") || schema().events.contains(k))
            return signals.computeIfAbsent(k.equals("Changed") ? "E_Changed" : k, Signal::new);
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        if (schema().get(k) != null) { assign(k, v); return true; }
        return super.setProp(k, v);
    }

    // ------------------------------------------------------------ JSON
    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        for (var e : vals.entrySet()) o.add(e.getKey(), json(e.getValue()));
        return o;
    }

    public static JsonElement json(LuaValue v) {
        if (v instanceof ColorL c) { JsonArray a = new JsonArray(); a.add(c.r / 255.0); a.add(c.g / 255.0); a.add(c.b / 255.0); return a; }
        if (v instanceof Vec3L p) { JsonArray a = new JsonArray(); a.add(p.x); a.add(p.y); a.add(p.z); return a; }
        if (v.isboolean()) return new JsonPrimitive(v.toboolean());
        if (v.isnumber()) return new JsonPrimitive(v.todouble());
        return new JsonPrimitive(v.tojstring());
    }

    public static LuaValue fromJson(P p, JsonElement e) {
        try {
            switch (p.type) {
                case NUM: return valueOf(e.getAsDouble());
                case BOOL: return valueOf(e.getAsBoolean());
                case COLOR: { JsonArray a = e.getAsJsonArray(); return new ColorL((int) Math.round(a.get(0).getAsDouble() * 255), (int) Math.round(a.get(1).getAsDouble() * 255), (int) Math.round(a.get(2).getAsDouble() * 255)); }
                case STR: return valueOf(e.getAsString());
                case VEC3: { JsonArray a = e.getAsJsonArray(); return new Vec3L(a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble()); }
            }
        } catch (RuntimeException ignored) {}
        return p.def;
    }

    protected void copyInto(PropBag o) { o.vals.putAll(vals); o.name = name; }
}
