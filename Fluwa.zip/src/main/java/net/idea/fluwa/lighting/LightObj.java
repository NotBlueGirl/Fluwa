package net.idea.fluwa.lighting;

import com.google.gson.*;
import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.luaj.vm2.*;

import java.util.*;

/**
 * LightPoint / LightBeam (v0.5). Parent (or AttachTo) a Block, Entity, ProjectorObject - or Lighting with a Position.
 * Server lights light the world with invisible minecraft:light blocks (vanilla light, colourless) and every client renders a
 * coloured glow / light cone. Lights created on a client are visual only.
 */
public abstract class LightObj extends PropBag {
    public static final String[] FACES = {"Front", "Back", "Top", "Bottom", "Left", "Right"};
    LObj attached; String attachFace;
    /** runtime-local registry of every light */
    @SuppressWarnings("unchecked")
    static List<LightObj> registry(FluwaRuntime r) {
        return (List<LightObj>) r.state.computeIfAbsent("fluwa.lights", k -> new java.util.concurrent.CopyOnWriteArrayList<LightObj>());
    }

    protected LightObj(String cls) {
        super(cls);
        if (rt != null) { registry(rt).add(this); LightingObj.touch(rt); }
    }

    public boolean beam() { return this instanceof LightBeam; }

    @Override protected void markDirty() { if (rt != null) LightingObj.touch(rt); }

    @Override public void setParent(LObj p) {
        super.setParent(p);
        if (p instanceof BlockObj || p instanceof EntityObj || p instanceof ProjectorObj) { if (attached != p) attach(p, attachFace); }
        else if (attached != null && attached == p) {} // unchanged
        markDirty();
    }

    void attach(LObj o, String face) {
        if (!(o instanceof BlockObj || o instanceof EntityObj || o instanceof ProjectorObj))
            throw new LuaError("Lights can be attached to a Block, Entity or ProjectorObject");
        if (face != null) assign("Face", valueOf(face));
        LObj old = attached;
        attached = o; attachFace = face;
        if (old != null && old != o) fire("E_Detached", old);
        fire("E_Attached", beam() ? new LuaValue[]{o, valueOf(str("Face"))} : new LuaValue[]{o});
        markDirty();
    }

    void detach() {
        LObj old = attached;
        attached = null;
        if (old != null) fire("E_Detached", old);
        markDirty();
    }

    @Override protected void onDestroy() {
        if (rt != null) { registry(rt).remove(this); LightingObj.touch(rt); }
    }

    @Override protected LuaValue getProp(String k) {
        if (k.equals("AttachedTo")) return attached == null ? NIL : attached;
        return super.getProp(k);
    }

    // ------------------------------------------------------------ world placement
    /** resolved light: position, direction, level */
    public record Placement(Level level, net.minecraft.world.phys.Vec3 pos, net.minecraft.world.phys.Vec3 dir) {}

    public Placement placement() {
        try {
            if (attached instanceof EntityObj eo) {
                Entity e = eo.raw();
                if (e == null || e.isRemoved()) return null;
                net.minecraft.world.phys.Vec3 look = e.getLookAngle();
                float yaw = e instanceof LivingEntity l ? l.yHeadRot : e.getYRot();
                net.minecraft.world.phys.Vec3 fwd = net.minecraft.world.phys.Vec3.directionFromRotation(0, yaw);
                net.minecraft.world.phys.Vec3 dir = switch (str("Face")) {
                    case "Back" -> look.scale(-1);
                    case "Top" -> new net.minecraft.world.phys.Vec3(0, 1, 0);
                    case "Bottom" -> new net.minecraft.world.phys.Vec3(0, -1, 0);
                    case "Left" -> new net.minecraft.world.phys.Vec3(fwd.z, 0, -fwd.x);
                    case "Right" -> new net.minecraft.world.phys.Vec3(-fwd.z, 0, fwd.x);
                    default -> look;
                };
                net.minecraft.world.phys.Vec3 p = beam() ? e.getEyePosition() : e.position().add(0, e.getBbHeight() * 0.6, 0);
                return new Placement(e.level(), p, dir);
            }
            if (attached instanceof BlockObj b) {
                if (b.rawLevel() == null || b.blockPos() == null) return null;
                net.minecraft.world.phys.Vec3 d = faceDir(str("Face"));
                net.minecraft.world.phys.Vec3 c = net.minecraft.world.phys.Vec3.atCenterOf(b.blockPos());
                return new Placement(b.rawLevel(), beam() ? c.add(d.scale(0.51)) : c, d);
            }
            if (attached instanceof ProjectorObj po) {
                CFrameL cf = po.worldCF();
                Level l = levelById(po.worldDim());
                if (l == null) return null;
                Vec3L lv = switch (str("Face")) {
                    case "Back" -> cf.look().scale(-1); case "Top" -> cf.up(); case "Bottom" -> cf.up().scale(-1);
                    case "Left" -> cf.right().scale(-1); case "Right" -> cf.right(); default -> cf.look();
                };
                return new Placement(l, cf.pos().mc(), lv.mc());
            }
            LuaValue p = value("Position");
            if (p instanceof Vec3L v) {
                Level l = levelById(str("Dimension"));
                if (l == null) return null;
                return new Placement(l, v.mc(), faceDir(str("Face")));
            }
        } catch (LuaError e) { return null; }
        return null;
    }

    static net.minecraft.world.phys.Vec3 faceDir(String f) {
        return switch (f) {
            case "Back" -> new net.minecraft.world.phys.Vec3(0, 0, 1);
            case "Top" -> new net.minecraft.world.phys.Vec3(0, 1, 0);
            case "Bottom" -> new net.minecraft.world.phys.Vec3(0, -1, 0);
            case "Left" -> new net.minecraft.world.phys.Vec3(-1, 0, 0);
            case "Right" -> new net.minecraft.world.phys.Vec3(1, 0, 0);
            default -> new net.minecraft.world.phys.Vec3(0, 0, -1);
        };
    }

    Level levelById(String id) {
        if (!(rt instanceof GameRuntime g)) return null;
        Collection<? extends Level> ls = g.levels();
        if (id == null || id.isEmpty()) return ls.isEmpty() ? null : ls.iterator().next();
        String n = id.contains(":") ? id : "minecraft:" + id;
        for (Level l : ls) if (l.dimension().location().toString().equals(n)) return l;
        return null;
    }

    public JsonObject toLightJson(Placement pl) {
        JsonObject o = new JsonObject();
        o.addProperty("c", className);
        JsonObject p = new JsonObject();
        for (P d : schema().all()) if (!d.name().equals("Position") && !d.name().equals("Dimension")) p.add(d.name(), json(value(d.name())));
        o.add("p", p);
        o.addProperty("dim", pl.level().dimension().location().toString());
        JsonArray a = new JsonArray(); a.add(pl.pos().x); a.add(pl.pos().y); a.add(pl.pos().z); o.add("pos", a);
        JsonArray d = new JsonArray(); d.add(pl.dir().x); d.add(pl.dir().y); d.add(pl.dir().z); o.add("dir", d);
        return o;
    }

    static {
        reg(LightObj.class, "AttachTo", (s, a) -> { LightObj l = (LightObj) s; l.attach(LObj.checkObj(a.arg1(), LObj.class), a.isnil(2) ? null : a.checkjstring(2)); return NONE; });
        reg(LightObj.class, "Detach", (s, a) -> { ((LightObj) s).detach(); return NONE; });
    }

    static Schema base(boolean beam) {
        Schema s = new Schema()
                .bool("Enabled", true, "E_EnabledChanged").color("Color", 255, 255, 255, "E_ColorChanged")
                .num("Brightness", 1, "E_BrightnessChanged", 0, 100).num("Range", 8, "E_RangeChanged", 0, 60);
        if (beam) s.num("Angle", 45, "E_AngleChanged", 0, 180).str("Face", "Front", "E_FaceChanged");
        s.bool("Shadows", false, "E_ShadowsChanged").str("Texture", "", "E_TextureChanged")
                .num("Transparency", 0, "E_TransparencyChanged", 0, 1).num("Decay", 1, "E_DecayChanged", 0, 10)
                .num("Contrast", 0, "E_ContrastChanged", 0, 1).num("Falloff", 1, "E_FalloffChanged", 0, 10);
        if (beam) s.num("InnerAngle", 10, "E_InnerAngleChanged", 0, 180).num("OuterAngle", 45, "E_OuterAngleChanged", 0, 180);
        if (!beam) s.str("Face", "Front", null);
        s.vec("Position", null, null).str("Dimension", "", null).event("E_Attached").event("E_Detached");
        return s;
    }

    @Override public void assign(String n, LuaValue v) {
        if (n.equals("Face") && !v.isnil() && !Arrays.asList(FACES).contains(v.tojstring()))
            throw new LuaError("Face must be Front, Back, Top, Bottom, Left or Right");
        super.assign(n, v);
    }

    public static final class LightPoint extends LightObj {
        public static final Schema S = base(false);
        public LightPoint() { super("LightPoint"); }
        @Override public Schema schema() { return S; }
        @Override protected LuaValue cloneObj() { LightPoint o = new LightPoint(); copyInto(o); return o; }
        static { defineAccessors(LightPoint.class, S); }
    }

    public static final class LightBeam extends LightObj {
        public static final Schema S = base(true);
        public LightBeam() { super("LightBeam"); }
        @Override public Schema schema() { return S; }
        @Override protected LuaValue cloneObj() { LightBeam o = new LightBeam(); copyInto(o); return o; }
        static { defineAccessors(LightBeam.class, S); }
    }
}
