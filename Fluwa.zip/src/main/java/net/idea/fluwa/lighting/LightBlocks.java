package net.idea.fluwa.lighting;

import net.idea.fluwa.lua.FluwaRuntime;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Server side of LightPoint / LightBeam: real (colourless) block light through invisible minecraft:light blocks,
 * placed only into air cells and removed again when the light moves, is disabled or the runtime stops.
 */
final class LightBlocks {
    private LightBlocks() {}
    record Cell(Level level, BlockPos pos) {}

    @SuppressWarnings("unchecked")
    static Map<Cell, Integer> owned(FluwaRuntime r) { return (Map<Cell, Integer>) r.state.computeIfAbsent("fluwa.lightcells", k -> new HashMap<Cell, Integer>()); }

    static void update(FluwaRuntime r, List<LightObj> lights) {
        Map<Cell, Integer> want = new HashMap<>();
        for (LightObj l : lights) {
            if (!l.bool("Enabled")) continue;
            LightObj.Placement pl = l.placement();
            if (pl == null) continue;
            double eff = l.num("Brightness") * (1 - l.num("Transparency"));
            if (l.beam()) beam(l, pl, eff, want); else point(l, pl, eff, want);
        }
        Map<Cell, Integer> have = owned(r);
        for (Iterator<Map.Entry<Cell, Integer>> it = have.entrySet().iterator(); it.hasNext(); ) {
            var e = it.next();
            Integer w = want.get(e.getKey());
            if (w == null || !w.equals(e.getValue())) {
                if (w == null) { remove(e.getKey()); it.remove(); }
            }
        }
        for (var e : want.entrySet()) {
            Integer h = have.get(e.getKey());
            if (h != null && h.equals(e.getValue())) continue;
            if (place(e.getKey(), e.getValue())) have.put(e.getKey(), e.getValue()); else have.remove(e.getKey());
        }
    }

    static void clear(FluwaRuntime r) {
        Map<Cell, Integer> have = owned(r);
        for (Cell c : have.keySet()) remove(c);
        have.clear();
    }

    static void put(Map<Cell, Integer> want, Level l, BlockPos p, int lvl) {
        if (lvl <= 0) return;
        want.merge(new Cell(l, p.immutable()), Math.min(15, lvl), Math::max);
    }

    static void point(LightObj l, LightObj.Placement pl, double eff, Map<Cell, Integer> want) {
        int lvl = (int) Math.round(Math.min(15, l.num("Range") * Math.min(1, eff)));
        BlockPos p = BlockPos.containing(pl.pos());
        BlockPos free = freeNear(pl.level(), p);
        if (free != null) put(want, pl.level(), free, lvl);
    }

    static void beam(LightObj l, LightObj.Placement pl, double eff, Map<Cell, Integer> want) {
        double range = l.num("Range");
        if (range <= 0 || eff <= 0) return;
        Vec3 dir = pl.dir().normalize();
        if (dir.lengthSqr() < 1e-6) return;
        Vec3 o = pl.pos();
        BlockHitResult hit = pl.level().clip(new ClipContext(o, o.add(dir.scale(range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, null));
        double dist = hit.getType() == HitResult.Type.MISS ? range : hit.getLocation().distanceTo(o);
        int base = (int) Math.round(15 * Math.min(1, eff));
        // along the ray (dim)
        for (double d = 4; d < dist - 1; d += 6)
            put(want, pl.level(), BlockPos.containing(o.add(dir.scale(d))), (int) Math.round(base * 0.6 * (1 - d / range * 0.5)));
        // spot on the surface hit (or at the end of the beam)
        Vec3 end = o.add(dir.scale(Math.max(0, dist - 0.6)));
        int spot = (int) Math.round(base * (1 - dist / range * 0.4));
        BlockPos ep = freeNear(pl.level(), BlockPos.containing(end));
        if (ep != null) put(want, pl.level(), ep, spot);
        // ring of the cone on wide beams
        double rad = dist * Math.tan(Math.toRadians(Math.min(170, l.num("Angle")) / 2));
        if (rad >= 3) {
            Vec3 up = Math.abs(dir.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
            Vec3 a = dir.cross(up).normalize(), b = dir.cross(a).normalize();
            int n = rad >= 7 ? 8 : 4;
            double rr = Math.min(rad * 0.7, 12);
            for (int i = 0; i < n; i++) {
                double t = Math.PI * 2 * i / n;
                Vec3 q = end.add(a.scale(Math.cos(t) * rr)).add(b.scale(Math.sin(t) * rr)).subtract(dir.scale(0.4));
                BlockPos qp = freeNear(pl.level(), BlockPos.containing(q));
                if (qp != null) put(want, pl.level(), qp, spot - 2);
            }
        }
    }

    static boolean usable(Level l, BlockPos p) {
        if (!l.isLoaded(p)) return false;
        BlockState s = l.getBlockState(p);
        return s.isAir() || s.is(Blocks.LIGHT);
    }

    static BlockPos freeNear(Level l, BlockPos p) {
        if (usable(l, p)) return p;
        for (BlockPos q : new BlockPos[]{p.above(), p.below(), p.north(), p.south(), p.east(), p.west()}) if (usable(l, q)) return q;
        return null;
    }

    static boolean place(Cell c, int lvl) {
        Level l = c.level();
        if (!usable(l, c.pos())) return false;
        BlockState s = l.getBlockState(c.pos());
        if (s.is(Blocks.LIGHT) && s.getValue(LightBlock.LEVEL) == lvl) return true;
        if (!s.isAir() && !s.is(Blocks.LIGHT)) return false;
        return l.setBlock(c.pos(), Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, lvl), 2 | 16);
    }

    static void remove(Cell c) {
        Level l = c.level();
        if (l.isLoaded(c.pos()) && l.getBlockState(c.pos()).is(Blocks.LIGHT)) l.setBlock(c.pos(), Blocks.AIR.defaultBlockState(), 2 | 16);
    }
}
