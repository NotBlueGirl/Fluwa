package net.idea.fluwa.lighting;

import com.google.gson.JsonObject;
import net.idea.fluwa.lua.*;
import org.luaj.vm2.*;

/**
 * Post-processing / sky objects parented to Lighting (v0.5): Sky, Atmosphere, Bloom, Blur, ColorCorrection,
 * DepthOfField, SunRays, Clouds. They are active while their Parent is Lighting (and Enabled = true).
 * Created on the server they replicate to every client; created on a client they are local.
 */
public abstract class FxObj extends PropBag {
    protected FxObj(String cls) { super(cls); }

    public static final String[] CLASSES = {"Sky", "Atmosphere", "Bloom", "Blur", "ColorCorrection", "DepthOfField", "SunRays", "Clouds"};

    public static FxObj create(String cls) {
        return switch (cls) {
            case "Sky" -> new Sky();
            case "Atmosphere" -> new Atmosphere();
            case "Bloom" -> new Bloom();
            case "Blur" -> new Blur();
            case "ColorCorrection" -> new ColorCorrection();
            case "DepthOfField" -> new DepthOfField();
            case "SunRays" -> new SunRays();
            case "Clouds" -> new Clouds();
            default -> null;
        };
    }

    public static Schema schemaOf(String cls) {
        return switch (cls) {
            case "Sky" -> Sky.S; case "Atmosphere" -> Atmosphere.S; case "Bloom" -> Bloom.S; case "Blur" -> Blur.S;
            case "ColorCorrection" -> ColorCorrection.S; case "DepthOfField" -> DepthOfField.S; case "SunRays" -> SunRays.S; case "Clouds" -> Clouds.S;
            default -> null;
        };
    }

    LightingObj lighting() { return parent instanceof LightingObj l ? l : null; }

    @Override protected void markDirty() { LightingObj l = lighting(); if (l != null) l.markDirty(); }

    @Override public void setParent(LObj p) {
        LightingObj old = lighting();
        super.setParent(p);
        LightingObj now = lighting();
        if (old != now) {
            if (old != null) { old.markDirty(); old.fire("E_EffectRemoved", this); }
            if (now != null) { now.markDirty(); now.fire("E_EffectAdded", this); }
        }
    }

    public static FxObj fromFxJson(JsonObject o) {
        FxObj f = create(o.get("c").getAsString());
        if (f != null && o.has("p")) f.loadJson(o.getAsJsonObject("p"));
        return f;
    }

    public JsonObject toFxJson() { JsonObject o = new JsonObject(); o.addProperty("c", className); o.add("p", toJson()); return o; }

    @Override protected LuaValue cloneObj() { FxObj o = create(className); copyInto(o); return o; }

    // =================================================================== classes
    public static final class Sky extends FxObj {
        public static final Schema S = new Schema()
                .str("SkyboxUp", "", "E_SkyboxChanged").str("SkyboxDown", "", "E_SkyboxChanged").str("SkyboxLeft", "", "E_SkyboxChanged")
                .str("SkyboxRight", "", "E_SkyboxChanged").str("SkyboxFront", "", "E_SkyboxChanged").str("SkyboxBack", "", "E_SkyboxChanged")
                .num("StarCount", 1500, "E_StarCountChanged", 0, 20000)
                .str("SunTexture", "", "E_SunTextureChanged").str("MoonTexture", "", "E_MoonTextureChanged")
                .bool("CelestialBodiesVisible", true, "E_CelestialBodiesVisibilityChanged")
                .bool("SunVisible", true, "E_SunVisibilityChanged").bool("MoonVisible", true, "E_MoonVisibilityChanged")
                .num("SunAngularSize", 33.4, "E_SunAngularSizeChanged", 0, 120).num("MoonAngularSize", 22.6, "E_MoonAngularSizeChanged", 0, 120)
                .str("StarTexture", "", "E_StarTextureChanged");
        public Sky() { super("Sky"); }
        @Override public Schema schema() { return S; }
        @Override protected LuaValue[] eventArgs(P p, LuaValue v) {
            if (p.name().startsWith("Skybox")) return new LuaValue[]{valueOf(p.name().substring(6)), v};
            return super.eventArgs(p, v);
        }
        static { defineAccessors(Sky.class, S); }
    }

    public static final class Atmosphere extends FxObj {
        public static final Schema S = new Schema().num("Density", 0.3, null, 0, 1).num("Offset", 0, null, 0, 1)
                .color("Color", 199, 170, 107, null).color("Decay", 92, 60, 13, null)
                .num("Glare", 0, null, 0, 10).num("Haze", 0, null, 0, 10).bool("Enabled", true, null);
        public Atmosphere() { super("Atmosphere"); }
        @Override public Schema schema() { return S; }
        static { defineAccessors(Atmosphere.class, S); }
    }

    public static final class Bloom extends FxObj {
        public static final Schema S = new Schema().bool("Enabled", true, null).num("Intensity", 1, null, 0, 10)
                .num("Size", 24, null, 0, 56).num("Threshold", 2, null, 0, 4);
        public Bloom() { super("Bloom"); }
        @Override public Schema schema() { return S; }
        static { defineAccessors(Bloom.class, S); }
    }

    public static final class Blur extends FxObj {
        public static final Schema S = new Schema().bool("Enabled", true, null).num("Size", 24, null, 0, 56);
        public Blur() { super("Blur"); }
        @Override public Schema schema() { return S; }
        static { defineAccessors(Blur.class, S); }
    }

    public static final class ColorCorrection extends FxObj {
        public static final Schema S = new Schema().bool("Enabled", true, null).num("Brightness", 0, null, -1, 1)
                .num("Contrast", 0, null, -1, 3).num("Saturation", 0, null, -1, 3).color("TintColor", 255, 255, 255, null);
        public ColorCorrection() { super("ColorCorrection"); }
        @Override public Schema schema() { return S; }
        static { defineAccessors(ColorCorrection.class, S); }
    }

    public static final class DepthOfField extends FxObj {
        public static final Schema S = new Schema().bool("Enabled", true, null).num("FarIntensity", 0.75, null, 0, 1)
                .num("FocusDistance", 0.05, null, 0, 500).num("InFocusRadius", 10, null, 0, 500).num("NearIntensity", 0.75, null, 0, 1);
        public DepthOfField() { super("DepthOfField"); }
        @Override public Schema schema() { return S; }
        static { defineAccessors(DepthOfField.class, S); }
    }

    public static final class SunRays extends FxObj {
        public static final Schema S = new Schema().bool("Enabled", true, null).num("Intensity", 0.25, null, 0, 1).num("Spread", 1, null, 0, 1);
        public SunRays() { super("SunRays"); }
        @Override public Schema schema() { return S; }
        static { defineAccessors(SunRays.class, S); }
    }

    public static final class Clouds extends FxObj {
        public static final Schema S = new Schema().bool("Enabled", true, null).num("Cover", 0.5, null, 0, 1).num("Density", 0.8, null, 0, 1)
                .color("Color", 255, 255, 255, null).num("Speed", 1, null, -100, 100).num("Height", 192, null, -2048, 4096).str("Texture", "", null);
        public Clouds() { super("Clouds"); }
        @Override public Schema schema() { return S; }
        static { defineAccessors(Clouds.class, S); }
    }
}
