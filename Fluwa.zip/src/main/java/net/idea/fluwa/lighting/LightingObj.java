package net.idea.fluwa.lighting;

import com.google.gson.*;
import net.idea.fluwa.api.*;
import net.idea.fluwa.lua.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.luaj.vm2.*;

import java.util.*;
import java.util.function.Function;

/**
 * v0.5 Lighting service (getAccess("Lighting") / Workspace.Lighting / global Lighting).
 * Server values replicate to every client; values set by a client script override them locally on that client.
 * Children FxObj (Sky, Bloom, ...) are its effects; LightPoint/LightBeam lights are tracked per runtime.
 */
public class LightingObj extends PropBag {
    public static final String[] TECHNOLOGIES = {"Legacy", "Compatibility", "Voxel", "ShadowMap", "Future"};
    public static final Schema S = new Schema()
            .num("GeographicLatitude", 0, "E_GeographicLatitudeChanged", -90, 90)
            .color("Ambient", 0, 0, 0, "E_AmbientChanged")
            .color("OutdoorAmbient", 128, 128, 128, "E_OutdoorAmbientChanged")
            .num("Brightness", 1, "E_BrightnessChanged", 0, 10)
            .color("ColorShift_Top", 0, 0, 0, "E_ColorShift_TopChanged")
            .color("ColorShift_Bottom", 0, 0, 0, "E_ColorShift_BottomChanged")
            .bool("GlobalShadows", true, "E_GlobalShadowsChanged")
            .num("ShadowSoftness", 0, "E_ShadowSoftnessChanged", 0, 1)
            .bool("FogEnabled", false, "E_FogChanged")
            .color("FogColor", 192, 192, 192, "E_FogChanged")
            .num("FogStart", 0, "E_FogChanged", 0, 100000)
            .num("FogEnd", 100000, "E_FogChanged", 0, 100000)
            .num("EnvironmentDiffuseScale", 0, "E_EnvironmentDiffuseScaleChanged", 0, 1)
            .num("EnvironmentSpecularScale", 0, "E_EnvironmentSpecularScaleChanged", 0, 1)
            .num("ExposureCompensation", 0, "E_ExposureChanged", -3, 3)
            .str("Technology", "Legacy", "E_TechnologyChanged")
            .str("Skybox", "", "E_SkyboxChanged")
            .vec("SunPosition", null, "E_SunPositionChanged")
            .vec("MoonPosition", null, "E_MoonPositionChanged")
            .num("StarCount", 1500, "E_StarCountChanged", 0, 20000)
            .bool("CelestialBodiesVisible", true, "E_CelestialBodiesVisibilityChanged")
            .bool("SunVisible", true, "E_SunVisibilityChanged")
            .bool("MoonVisible", true, "E_MoonVisibilityChanged")
            .num("SunSize", 1, "E_SunSizeChanged", 0, 20)
            .num("MoonSize", 1, "E_MoonSizeChanged", 0, 20)
            .color("SunColor", 255, 255, 255, "E_SunColorChanged")
            .color("MoonColor", 255, 255, 255, "E_MoonColorChanged")
            .event("E_TimeChanged").event("E_ClockTimeChanged").event("E_EffectAdded").event("E_EffectRemoved");

    /** client hook: value replicated from the server (null on the server) */
    public static volatile Function<String, LuaValue> CLIENT_INHERIT;
    /** bumped whenever any lighting state changes (client renderers cache on it) */
    public static volatile int VERSION;
    /** last state sent by the server runtime (sent to joining players) */
    public static volatile byte[] SERVER_STATE;
    /** server hook: broadcast a state (set by the server networking code) */
    public static volatile java.util.function.Consumer<byte[]> BROADCAST;

    public final WorldObj world;
    boolean dirty = true;
    String lastSent;
    double lastClock = Double.NaN;

    public LightingObj(WorldObj w) {
        super("Lighting");
        name = "Lighting";
        world = w;
        if (rt != null) {
            rt.state.put("fluwa.lighting", this);
            rt.tickers.add(this::tick);
            if (rt.server) rt.onClose(() -> { LightBlocks.clear(rt); SERVER_STATE = null; if (BROADCAST != null) BROADCAST.accept(new byte[0]); });
            else rt.onClose(() -> VERSION++);
        }
    }

    @Override public Schema schema() { return S; }
    @Override public void setName(String n) { throw new LuaError("Lighting.Name is read-only"); }

    public static LightingObj of(FluwaRuntime r) { return r == null ? null : (LightingObj) r.state.get("fluwa.lighting"); }
    /** something changed in the lights of runtime r */
    public static void touch(FluwaRuntime r) { LightingObj l = of(r); if (l != null) l.markDirty(); else VERSION++; }

    @Override protected void markDirty() { dirty = true; VERSION++; }

    @Override protected LuaValue inherited(String n) {
        if (rt != null && !rt.server && CLIENT_INHERIT != null) return CLIENT_INHERIT.apply(n);
        return null;
    }

    @Override protected LuaValue[] eventArgs(P p, LuaValue v) {
        if (p.event() != null && p.event().equals("E_FogChanged"))
            return new LuaValue[]{value("FogEnabled"), value("FogColor"), value("FogStart"), value("FogEnd")};
        return super.eventArgs(p, v);
    }

    @Override public void assign(String n, LuaValue v) {
        if (n.equals("Technology") && !v.isnil()) {
            String t = v.tojstring().replaceFirst("^Enum\\.Technology\\.", "");
            if (!Arrays.asList(TECHNOLOGIES).contains(t))
                throw new LuaError("Technology must be \"Legacy\", \"Compatibility\", \"Voxel\", \"ShadowMap\" or \"Future\"");
            v = LuaValue.valueOf(t);
        }
        super.assign(n, v);
    }

    // ------------------------------------------------------------ time
    Level level() { return world.overworld(); }
    public double clockTime() { return ((level().getDayTime() % 24000 + 24000) % 24000 / 1000.0 + 6) % 24; }
    static String fmtTime(double h) {
        int s = (int) Math.round(h * 3600) % 86400;
        return String.format("%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60);
    }
    static double parseTime(LuaValue v) {
        if (v.isnumber()) return v.todouble();
        String[] p = v.checkjstring().trim().split(":");
        try {
            double h = Double.parseDouble(p[0]);
            if (p.length > 1) h += Double.parseDouble(p[1]) / 60;
            if (p.length > 2) h += Double.parseDouble(p[2]) / 3600;
            return h;
        } catch (NumberFormatException e) { throw new LuaError("TimeOfDay must be \"HH:MM:SS\""); }
    }
    void setClock(double h) {
        if (!rt.server) throw new LuaError("Lighting time can only be changed on the server");
        h = ((h % 24) + 24) % 24;
        long day = Math.floorDiv(level().getDayTime(), 24000) * 24000;
        world.setDay(day + Math.round(((h - 6 + 24) % 24) * 1000));
        pollTime();
    }

    void pollTime() {
        double c;
        try { c = clockTime(); } catch (RuntimeException e) { return; }
        if (c == lastClock) return;
        boolean first = Double.isNaN(lastClock);
        String oldS = first ? "" : fmtTime(lastClock);
        lastClock = c;
        if (first) return;
        fire("E_ClockTimeChanged", valueOf(c));
        String ns = fmtTime(c);
        if (!ns.equals(oldS)) fire("E_TimeChanged", valueOf(ns));
    }

    /** default sun / moon direction from the time of day + latitude */
    public Vec3L celestial(boolean moon) {
        float a;
        try { a = level().getTimeOfDay(1f); } catch (RuntimeException e) { a = 0; }
        double th = a * Math.PI * 2;
        double x = -Math.sin(th), y = Math.cos(th), z = 0;
        double lat = Math.toRadians(num("GeographicLatitude"));
        double y2 = y * Math.cos(lat), z2 = y * Math.sin(lat);
        Vec3L v = new Vec3L(x, y2, z2);
        return moon ? v.scale(-1) : v;
    }

    @Override public LuaValue value(String n) {
        LuaValue v = super.value(n);
        if (v.isnil() && (n.equals("SunPosition") || n.equals("MoonPosition"))) {
            if (n.equals("MoonPosition")) { LuaValue s = super.value("SunPosition"); if (s instanceof Vec3L sv) return sv.unit().scale(-1); }
            return celestial(n.equals("MoonPosition"));
        }
        return v;
    }

    // ------------------------------------------------------------ effects
    public List<FxObj> effects() {
        List<FxObj> l = new ArrayList<>();
        for (LObj c : children) if (c instanceof FxObj f && !f.destroyed) l.add(f);
        return l;
    }
    public List<LightObj> lights() {
        List<LightObj> l = new ArrayList<>();
        if (rt != null) for (LightObj o : LightObj.registry(rt)) if (!o.destroyed) l.add(o);
        return l;
    }

    @Override protected void onChildAdded(LObj c) { super.onChildAdded(c); if (c instanceof LightObj) markDirty(); }
    @Override protected void onChildRemoved(LObj c) { super.onChildRemoved(c); if (c instanceof LightObj) markDirty(); }

    @Override protected LuaValue getProp(String k) {
        switch (k) {
            case "TimeOfDay": return valueOf(fmtTime(clockTime()));
            case "ClockTime": return valueOf(clockTime());
            case "MoonPhase": return valueOf(level().getMoonPhase());
            case "SkyDarken": return valueOf(level().getSkyDarken());
            case "Effects": return list(effects());
            case "Lights": return list(lights());
        }
        return super.getProp(k);
    }

    @Override protected boolean setProp(String k, LuaValue v) {
        switch (k) {
            case "TimeOfDay": case "ClockTime": setClock(parseTime(v)); return true;
            case "Effects": case "MoonPhase": case "SkyDarken": case "Lights": throw new LuaError("Lighting." + k + " is read-only");
        }
        return super.setProp(k, v);
    }

    // ------------------------------------------------------------ replication
    void tick() {
        pollTime();
        if (!rt.server) { if (dirty) { dirty = false; VERSION++; } return; }
        boolean hasLights = false;
        for (LightObj o : LightObj.registry(rt)) if (!o.destroyed) { hasLights = true; break; }
        if (hasLights && rt.tick % 2 == 0) { LightBlocks.update(rt, lights()); dirty = true; }
        else if (!hasLights && rt.tick % 20 == 0) LightBlocks.update(rt, List.of());
        if (!dirty) return;
        dirty = false;
        String js = stateJson().toString();
        if (js.equals(lastSent)) return;
        lastSent = js;
        byte[] b = js.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        SERVER_STATE = b;
        if (BROADCAST != null) BROADCAST.accept(b);
    }

    public JsonObject stateJson() {
        JsonObject o = new JsonObject();
        o.add("props", toJson());
        JsonArray fx = new JsonArray();
        for (FxObj f : effects()) fx.add(f.toFxJson());
        o.add("fx", fx);
        JsonArray ls = new JsonArray();
        for (LightObj l : lights()) {
            JsonObject j = lightJson(l);
            if (j != null) ls.add(j);
        }
        o.add("lights", ls);
        return o;
    }

    /** JSON of one light; entity attachments are resolved on each client (smooth movement) */
    public static JsonObject lightJson(LightObj l) {
        if (!l.bool("Enabled")) return null;
        if (l.attached instanceof EntityObj eo) {
            Entity e = eo.raw();
            if (e == null || e.isRemoved()) return null;
            LightObj.Placement pl = l.placement();
            if (pl == null) return null;
            JsonObject j = l.toLightJson(pl);
            j.addProperty("ent", e.getId());
            j.remove("pos"); j.remove("dir");
            return j;
        }
        LightObj.Placement pl = l.placement();
        return pl == null ? null : l.toLightJson(pl);
    }

    static {
        Class<LightingObj> C = LightingObj.class;
        defineAccessors(C, S);
        reg(C, "SetTimeOfDay", (s, a) -> { ((LightingObj) s).setClock(parseTime(a.arg1())); return NONE; });
        reg(C, "GetTimeOfDay", (s, a) -> valueOf(fmtTime(((LightingObj) s).clockTime())));
        reg(C, "SetClockTime", (s, a) -> { ((LightingObj) s).setClock(a.checkdouble(1)); return NONE; });
        reg(C, "GetClockTime", (s, a) -> valueOf(((LightingObj) s).clockTime()));
        reg(C, "GetMinutesAfterMidnight", (s, a) -> valueOf(((LightingObj) s).clockTime() * 60));
        reg(C, "SetMinutesAfterMidnight", (s, a) -> { ((LightingObj) s).setClock(a.checkdouble(1) / 60); return NONE; });
        reg(C, "AddEffect", (s, a) -> {
            LObj o = checkObj(a.arg1(), LObj.class);
            if (!(o instanceof FxObj || o instanceof LightObj)) throw new LuaError("AddEffect expects Sky, Atmosphere, Bloom, Blur, ColorCorrection, DepthOfField, SunRays, Clouds, LightPoint or LightBeam");
            o.setParent(s); return o; });
        reg(C, "RemoveEffect", (s, a) -> {
            LObj o = checkObj(a.arg1(), LObj.class);
            if (o.parent == s) o.setParent(null);
            return NONE; });
        reg(C, "ClearEffects", (s, a) -> { for (FxObj f : ((LightingObj) s).effects()) f.setParent(null); return NONE; });
        reg(C, "GetEffects", (s, a) -> list(((LightingObj) s).effects()));
        reg(C, "GetLights", (s, a) -> list(((LightingObj) s).lights()));
        reg(C, "Raycast", (s, a) -> {
            LightingObj l = (LightingObj) s;
            DimensionObj d = a.arg(4) instanceof DimensionObj x ? x : ((GameRuntime) l.rt).wrap(l.level());
            return d.raycast(Vec3L.check(a.arg1()), Vec3L.check(a.arg(2)), a.optdouble(3, 1000), false, null); });
    }
}
